package com.zjb.framework.manager;

import java.util.TimerTask;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * 异步任务管理器
 *
 * @author zjb
 */
public class AsyncManager {
    /**
     * 操作延迟10毫秒
     */
    private final int OPERATE_DELAY_TIME = 10;

    /**
     * 异步操作任务调度线程池
     */
    private ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(250);

    /**
     * 单例模式
     */
    private static AsyncManager me = new AsyncManager();

    public static AsyncManager me() {
        return me;
    }

    /**
     * 执行任务
     *
     * @param task 任务task
     */
    public void execute(TimerTask task) {
        executor.schedule(task, OPERATE_DELAY_TIME, TimeUnit.MILLISECONDS);
    }

    /**
     * 延迟的时间后执行任务
     *
     * @param task               任务task
     * @param operate_delay_time 延迟的时间，单位：毫秒
     */
    public void execute(TimerTask task, int operate_delay_time) {
        executor.schedule(task, operate_delay_time, TimeUnit.MILLISECONDS);
    }

    /**
     * 周期性执行任务
     *
     * @param task         任务task
     * @param initialDelay 初始等待时间，单位：毫秒
     * @param period       周期时间，单位：毫秒
     */
    public void executeAtFixedRate(TimerTask task, long initialDelay, long period) {
        executor.scheduleAtFixedRate(task, initialDelay, period, TimeUnit.MILLISECONDS);
    }

    public ScheduledThreadPoolExecutor getExecutor() {
        return executor;
    }

    public void setExecutor(ScheduledThreadPoolExecutor executor) {
        this.executor = executor;
    }
}
