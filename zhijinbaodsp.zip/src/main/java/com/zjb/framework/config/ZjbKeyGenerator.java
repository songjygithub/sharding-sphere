package com.zjb.framework.config;

import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cache.interceptor.SimpleKeyGenerator;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

/**
 * @author songjy
 * @date 2020-04-26
 */
@Component
public class ZjbKeyGenerator extends SimpleKeyGenerator {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public Object generate(Object target, Method method, Object... params) {
        Object key = super.generate(target, method, params);

        if (SystemUtils.IS_OS_WINDOWS || SystemUtils.IS_OS_MAC) {
            logger.info("函数【{}：{}】key>>{}", target.getClass().getName(), method.getName(), key);
        } else {
            logger.debug("key>>{}", key);
        }

        return key;
    }
}
