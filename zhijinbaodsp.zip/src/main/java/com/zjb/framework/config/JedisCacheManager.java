package com.zjb.framework.config;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

/**
 * @author songjy
 * @date 2019/09/26
 */
public class JedisCacheManager implements CacheManager {

    private final ConcurrentMap<String, Cache> caches = new ConcurrentHashMap<>();

    @Override
    public <K, V> Cache<K, V> getCache(String s) throws CacheException {
        Cache cache = caches.get(s);

        if (null == cache) {
            cache = new ShiroCache();
            caches.put(s , cache);
        }

        return cache;
    }

    public void clear(){
        new ShiroCache().clear();
    }
}
