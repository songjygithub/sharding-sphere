package com.zjb.framework.config;

import com.zjb.common.utils.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import java.text.DateFormat;
import java.text.ParseException;

/**
 * @author songjy
 * @date 2019/09/07
 */
public class ZjbDateEditor extends CustomDateEditor {

    private String[] parsePatterns = {"yyyy-MM-dd HH:mm:ss" , "yyyy-MM-dd"};

    public ZjbDateEditor(DateFormat dateFormat , boolean allowEmpty) {
        super(dateFormat , allowEmpty);
    }

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
        if (StringUtils.isBlank(text)) {
            return;
        }

        try {
            setValue(DateUtils.parseDate(text.trim() , parsePatterns));
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }
}
