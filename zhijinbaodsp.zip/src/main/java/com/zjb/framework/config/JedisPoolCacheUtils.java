package com.zjb.framework.config;

import com.alibaba.fastjson.JSON;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbEnvConstants;
import com.zjb.common.utils.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.params.SetParams;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/**
 * @author zjb
 */
@Component
public class JedisPoolCacheUtils {
    private static final Logger log = LoggerFactory.getLogger(JedisPoolCacheUtils.class);

    private static final String LOCK_SUCCESS = "OK";
    private static final String SET_IF_NOT_EXIST = "NX";
    private static final String SET_WITH_EXPIRE_TIME = "PX";

    public final static String DATA_REDIS_KEY = "data_";

    /**
     * redis过期时间,以秒为单位
     */
    public final static int EXRP_SECOND = 1;            //一秒，删除用
    public final static int EXRP_15_SECOND = 15;        //15秒
    public final static int EXRP_MINUTE = 60;            //一分钟
    public final static int EXRP_5_MINUTE = 5 * 60;            //五分钟
    public final static int EXRP_HOUR = 60 * 60;            //一小时
    public final static int EXRP_HALF_DAY = 60 * 60 * 12;        //半天
    public final static int EXRP_DAY = 60 * 60 * 24;        //一天
    public final static int EXRP_TWO_DAY = 60 * 60 * 24 * 2;        //两天
    public final static int EXRP_THREE_DAY = 60 * 60 * 24 * 3;        //三天
    public final static int EXRP_WEEK = 60 * 60 * 24 * 7; //七天
    public final static int EXRP_MONTH = 60 * 60 * 24 * 30; //一个月
    public final static int EXRP_YEAR = 60 * 60 * 24 * 365;            //年
    public final static int EXRP_HALF_YEAR = 60 * 60 * 24 * 180;       //半年

    //特殊的过期时间
    public final static int EXRP_PAPEROUT = 60 * 3;        //出纸openid-qrcode保存时间
    public final static int EXRP_THREE_MINITE = 60 * 3;        //换纸指令的防止重复时间

    private static JedisPool jedisPool = null;

    //配置参数
    private static final String host = ZjbEnvConstants.REDIS_HOST;
    private static int port = 6379;
    private static int timeOut = 3000;
    private static String password = ZjbEnvConstants.REDIS_PASSWORD;
    private static int maxTotal = 18000;//最大连接数

    /**
     * 初始化Redis连接池
     */
    static {
        try {
            JedisPoolConfig config = new JedisPoolConfig();
            config.setMaxTotal(maxTotal);
            //允许最大空闲连接数
            int maxIdle = 15000;
            config.setMaxIdle(maxIdle);
            int minIdle = 100;
            config.setMinIdle(minIdle);
            int maxWait = 100;
            config.setMaxWaitMillis(maxWait);
            config.setTestOnBorrow(true);
            config.setTestOnReturn(true);
            config.setTestWhileIdle(true);

            if (StringUtils.isBlank(password)) {
                jedisPool = new JedisPool(config, host, port, timeOut);
            } else {
                jedisPool = new JedisPool(config, host, port, timeOut, password);
            }


            log.info("=====初始化redis池成功!");
        } catch (Exception e) {
            log.error("First create JedisPool error : " + e);
        }

    }


    /**
     * setVExpire(设置key值，同时设置失效时间 秒)
     *
     * @param @param key
     * @param @param value
     * @param @param seconds
     * @param index  具体数据库 默认使用0号库
     * @return void
     * @throws
     * @Title: setVExpire
     */
    public static void setVExpire(String key, Object value, int seconds, int index) {

        if (null == value) {
            return;
        }
        String json = value.getClass() == String.class ? value.toString() : JSON.toJSONString(value);
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            jedis.set(DATA_REDIS_KEY + key, json);
            jedis.expire(DATA_REDIS_KEY + key, seconds);
        }

    }

    /**
     * 设置原始字符串
     *
     * @param key
     * @param value
     * @param seconds
     * @param index
     */
    public static void setRExpire(String key, String value, int seconds, int index) {
        if (ZjbConstants.ZJB_CURRENT_EVN.equals("TEST") && !"127.0.0.1".equals(host)) {
            return;
        }

        if (null == value) {
            return;
        }

        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            jedis.set(DATA_REDIS_KEY + key, value);
            jedis.expire(DATA_REDIS_KEY + key, seconds);
        }
    }

    /**
     * 设置不带前缀字符串
     *
     * @param key
     * @param value
     * @param seconds
     * @param index
     */
    public static void setNotRExpire(String key, String value, int seconds, int index) {
        if (ZjbConstants.ZJB_CURRENT_EVN.equals("TEST") && !"127.0.0.1".equals(host)) {
            return;
        }

        if (null == value) {
            return;
        }

        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            jedis.set(key, value);
            jedis.expire(key, seconds);
        }
    }

    /**
     * 对象JSON解析
     *
     * @param key
     * @param index
     * @param clazz
     * @param <V>
     * @return
     */
    public static <V> V getV(String key, int index, Class<V> clazz) {

        String value = "";
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            value = jedis.get(DATA_REDIS_KEY + key);
        }

        if (null == value || StringUtils.isBlank(value)) {
            return null;
        }

        return JSON.parseObject(value, clazz);
    }

    /**
     * getVString(返回json字符串)
     *
     * @param @param  key
     * @param @param  index
     * @param @return
     * @return String
     * @throws
     * @Title: getVString
     */
    public static String getVStr(String key, int index) {
        if (ZjbConstants.ZJB_CURRENT_EVN.equals("TEST") && !"127.0.0.1".equals(host)) {
            return "";
        }

        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            return jedis.get(DATA_REDIS_KEY + key);
        }
    }

    /**
     * 不带DATA_REDIS_KEY
     */
    public static String getVStr2(String key, int index) {
        if (ZjbConstants.ZJB_CURRENT_EVN.equals("TEST") && !"127.0.0.1".equals(host)) {
            return "";
        }

        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            return jedis.get(key);
        }
    }

    /**
     * 获得队列的长度
     *
     * @param queue
     * @return
     */
    public static long llen(String queue) {
        try (Jedis jedis = jedisPool.getResource()) {
            return jedis.llen(queue);
        }
    }

    /**
     * Push(存入 数据到队列中)
     *
     * @param queue
     * @param value
     */
    public static void lpush(String queue, Serializable value) {

        if (StringUtils.isBlank(queue) || null == value) {
            return;
        }

        String json = (value.getClass() == String.class) ? value.toString() : JSON.toJSONString(value);
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.lpush(queue, json);
        }
    }

    /**
     * 消息队列：消费
     *
     * @param queue
     * @return
     */
    public static List<String> brpop(String queue) {

        if (StringUtils.isBlank(queue)) {
            return Collections.emptyList();
        }

        try (Jedis jedis = jedisPool.getResource()) {
            return jedis.brpop(0, queue);
        }

    }

    /**
     * keys 查找匹配的所有key
     *
     * @param @param key
     * @return Set<String>
     * @throws
     * @Title: expireKey
     */
    public static Set<String> keys(String pattern, int index) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            return jedis.keys(pattern);
        }
    }

    /**
     * 删除
     *
     * @param key
     * @param hasPrefix 是否添加DATA_REDIS_KEY前缀
     * @param index     具体数据库
     * @return Long
     */
    public static Long del(String key, boolean hasPrefix, int index) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            return jedis.del(hasPrefix ? DATA_REDIS_KEY + key : key);
        }
    }

    /**
     * 向redis中添加Set数据
     *
     * @param key
     * @param db
     * @param expire
     * @param members
     */
    public static Long sadd(String key, int db, int expire, String... members) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            long r = jedis.sadd(DATA_REDIS_KEY + key, members);
            jedis.expire(DATA_REDIS_KEY + key, expire);
            return r;
        }
    }

    /**
     * 移除redis之Set中的数据
     *
     * @param key
     * @param db
     * @param members
     */
    public static Long srem(String key, int db, String... members) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            return jedis.srem(DATA_REDIS_KEY + key, members);
        }
    }

    /**
     * 获取redis之Set中的数据
     *
     * @param key
     * @param db
     */
    public static Set<String> smembers(String key, int db) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            return jedis.smembers(DATA_REDIS_KEY + key);
        }
    }

    /**
     * 查询成员是否在集合中
     *
     * @param key
     * @param db
     * @param member
     * @return
     */
    public static boolean sismember(String key, int db, String member) {

        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            return jedis.sismember(DATA_REDIS_KEY + key, member);
        }
    }

    /**
     * 判定键是否存在
     *
     * @param key
     * @param hasPrefix
     * @param db
     * @return
     */
    public static boolean exists(String key, boolean hasPrefix, int db) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            return jedis.exists(hasPrefix ? DATA_REDIS_KEY + key : key);
        }
    }

    /**
     * 发布消息
     *
     * @param channel
     * @param message
     */
    public static void publish(final String channel, final Serializable message) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.publish(channel, String.class == message.getClass() ? message.toString() : JSON.toJSONString(message));
        }
    }

    /**
     * @return
     */
    public static JedisPool getJedisPool() {
        return jedisPool;
    }

    /**
     * 尝试获取分布式锁
     *
     * @param lockKey     锁
     * @param requestId   请求标识
     * @param millisecond 超期时间(毫秒)
     * @return 是否获取成功
     */
    public static boolean tryGetDistributedLock(String lockKey, String requestId, int millisecond) {
        try (Jedis jedis = jedisPool.getResource()) {
            //String result = jedis.set(lockKey, requestId, SET_IF_NOT_EXIST, SET_WITH_EXPIRE_TIME, millisecond);
            SetParams px = SetParams.setParams().nx().px(millisecond);
            String result = jedis.set(lockKey, requestId, px);
            return LOCK_SUCCESS.equals(result);
        }
    }

    /**
     * 释放分布式锁
     *
     * @param lockKey   锁
     * @param requestId 请求标识
     * @return 是否释放成功
     */
    public static boolean releaseDistributedLock(String lockKey, String requestId) {
        try (Jedis jedis = jedisPool.getResource()) {
            String script = "if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end";
            Object result = jedis.eval(script, Collections.singletonList(lockKey), Collections.singletonList(requestId));
            return result.equals(1L);
        }
    }

    /**
     * 自增
     *
     * @param key
     * @param seconds
     * @return
     */
    public static long incr(String key, int seconds) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(0);
            long incr = jedis.incr(key);
            jedis.expire(key, seconds);
            return incr;
        }
    }

    /**
     * 自增
     *
     * @param key
     * @param v       每次递增多少
     * @param seconds 过期时间（秒）
     * @param db      几号库
     * @return 自增后的值
     */
    public static long incrBy(String key, long v, int seconds, int db) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            long incr = jedis.incrBy(key, v);
            jedis.expire(key, seconds);
            return incr;
        }
    }


    /**
     * 递减
     *
     * @param key
     * @param seconds
     * @return
     */
    public static long decr(String key, int seconds) {
        try (Jedis jedis = jedisPool.getResource()) {
            long incr = jedis.decr(key);
            jedis.expire(key, seconds);
            return incr;
        }
    }

    /**
     * 自增
     *
     * @param key
     * @param seconds
     * @param value
     * @return
     */
    public static Double incrByFloat(String key, int seconds, double value) {
        try (Jedis jedis = jedisPool.getResource()) {
            Double incr = jedis.incrByFloat(key, value);
            jedis.expire(key, seconds);
            return incr;
        }
    }

    /**
     * 获取redis中set元素个数
     *
     * @param key
     * @param index
     * @return
     */
    public static Long scard(String key, int index) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(index);
            return jedis.scard(DATA_REDIS_KEY + key);
        }
    }

    /**
     * 根据key从指定的数据库中获取数据
     *
     * @param key key
     * @param db  数据库
     * @return value
     */
    public static String get(String key, int db) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            return jedis.get(key);
        }
    }

    /**
     * 缓存值
     *
     * @param key   key
     * @param value value
     * @param db    数据库
     * @param expireSeconds 超时时间（秒）
     * @return OK：成功
     */
    public static String set(String key, String value, int db, long expireSeconds) {
        try (Jedis jedis = jedisPool.getResource()) {
            jedis.select(db);
            String result = jedis.set(key, value);
            jedis.expire(key, (int) expireSeconds);
            return result;
        }
    }
}