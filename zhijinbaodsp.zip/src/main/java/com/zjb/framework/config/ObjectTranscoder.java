package com.zjb.framework.config;

import com.zjb.common.utils.StringUtils;

import java.io.*;

/**
 * 序列化与反序列化
 * Created by Administrator on 2019/9/2.
 */
public class ObjectTranscoder {
    /**
     * 序列化
     * @param value
     * @return
     */
    public static byte[] serialize(Object value) {
        byte[] dataArray = null;
        try {
            //1、创建OutputStream对象
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            //2、创建OutputStream的包装对象ObjectOutputStream，PS：对象将写到OutputStream流中
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            //3、将对象写到OutputStream流中
            objectOutputStream.writeObject(value);
            //4、将OutputStream流转换成字节数组
            dataArray = outputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return dataArray;
    }

    /**
     * 反序列化
     * @param data
     * @return
     */
    public static Object deserialize(byte[] data) {
        Object object = null;

        try {
            ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            object = objectInputStream.readObject();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        return object;
    }

    public static String byteToString(byte[] in){
        String result = "";
        result = in.toString();
        return result;
    }
    public static byte[] stringToByte(String str){
        byte[] result = null;
        if(StringUtils.isNotEmpty(str)){
            result = str.getBytes();
        }
        return result;
    }
}

