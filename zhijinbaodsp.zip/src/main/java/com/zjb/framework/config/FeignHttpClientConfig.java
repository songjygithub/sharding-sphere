package com.zjb.framework.config;

import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.protocol.HttpContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import javax.net.ssl.SSLException;
import java.io.IOException;
import java.net.UnknownHostException;

/**
 * @author songjy
 * @date 2020-05-28
 */
@Configuration
@Deprecated
public class FeignHttpClientConfig {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /*The bean 'httpClient', defined in class path resource [org/springframework/cloud/openfeign/ribbon/HttpClientFeignLoadBalancedConfiguration$HttpClientFeignConfiguration.class], could not be registered. A bean with that name has already been defined in class path resource [com/zjb/framework/config/FeignHttpClientConfig.class] and overriding is disabled.*/
    //@Bean
    //@Primary
    public HttpClient httpClient() {

        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(100);
        cm.setDefaultMaxPerRoute(50);

        HttpRequestRetryHandler retryHandler = new HttpRequestRetryHandler() {

            /* 允许重连次数 */
            private static final int retryCount = 3;

            @Override
            public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {

                if (executionCount > retryCount) {
                    logger.warn("重连{}次失败,放弃", retryCount);
                    return false;
                }

                if (exception instanceof UnknownHostException) {
                    logger.warn("UnknownHostException丢掉了连接：重连");
                    return true;
                }

                if (exception instanceof ConnectTimeoutException) {
                    logger.warn("ConnectTimeoutException丢掉了连接：重连");
                    return true;
                }

                if (exception instanceof NoHttpResponseException) {
                    logger.warn("服务器丢掉了连接：重连");
                    return true;
                }

                if (exception instanceof SSLException) {
                    logger.warn("SSL握手异常：放弃");
                    return false;
                }

                logger.warn("重连次数：{}", executionCount);

                HttpClientContext clientContext = HttpClientContext.adapt(context);
                HttpRequest request = clientContext.getRequest();
                boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);

                if (idempotent) {
                    /* 如果请求被认为是幂等的，那么就重试。即重复执行不影响程序其他效果的 */
                    logger.warn("请求是幂等：重连 ");
                    return true;
                }

                return false;

            }
        };

        RequestConfig defaultRequestConfig = RequestConfig.custom()
                /*从连接池获取连接的超时时间(毫秒)*/
                .setConnectionRequestTimeout(1000)
                /*连接建立时间，三次握手完成时间(毫秒)*/
                .setConnectTimeout(2000)
                /*数据传输过程中数据包之间间隔的最大时间*/
                .setSocketTimeout(3000)
                .build();

        return HttpClients.custom()
                .setDefaultRequestConfig(defaultRequestConfig)
                .setRetryHandler(retryHandler)
                .setConnectionManager(cm)
                .build();
    }
}
