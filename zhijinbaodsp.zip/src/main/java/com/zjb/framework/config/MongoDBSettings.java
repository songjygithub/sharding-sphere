package com.zjb.framework.config;

import com.mongodb.ClientSessionOptions;
//import com.mongodb.MongoClientOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author songjy
 * @date 2020-04-27
 */
@Configuration
public class MongoDBSettings {

   /* @Bean
    public com.mongodb.MongoClientOptions.MongoClientOptions zjbMongoClientOptions() {
        return com.mongodb.MongoClientOptions.MongoClientOptions.builder()
                .serverSelectionTimeout(1000)
                //.socketTimeout(1000)
                //.connectTimeout(1000)
                .build();
    }
*/
    //@Bean
    public ClientSessionOptions zjbClientSessionOptions(){
        return ClientSessionOptions.builder().causallyConsistent(true).build();
    }
}
