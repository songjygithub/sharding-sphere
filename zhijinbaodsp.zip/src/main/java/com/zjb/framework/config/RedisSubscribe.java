package com.zjb.framework.config;

import cn.hutool.core.util.NetUtil;
import cn.hutool.core.util.RuntimeUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Splitter;
import com.zjb.common.constant.AdvertisingConstants;
import com.zjb.common.constant.Constants;
import com.zjb.common.enums.ZjbConfigEnum;
import com.zjb.common.utils.IpUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.dsp.advertisingADExchange.service.AdExchangeServiceImpl;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.domain.FileBeatData;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.service.IAdvertisingUnitWxService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.backupFileRecord.domain.Mq;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.service.IForbidPutOfficialAccountConfigService;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.domain.ForbidPutPersonalAccountConfig;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.service.IForbidPutPersonalAccountConfigService;
import com.zjb.project.dsp.limiting.service.IMailLimiterService;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.qqPersonal.service.IQqPersonalService;
import com.zjb.project.dsp.rpcrequest.domain.RpcRequest;
import com.zjb.project.dsp.systemAppInfo.domain.SystemAppInfo;
import com.zjb.project.dsp.systemAppInfo.service.ISystemAppInfoService;
import com.zjb.project.dsp.userPrintLogWhite.domain.UserPrintLogWhite;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.service.IWeChatPersonalService;
import com.zjb.project.system.config.domain.Config;
import com.zjb.project.system.config.service.IConfigService;
import org.apache.commons.lang3.SystemUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import redis.clients.jedis.JedisPubSub;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.zjb.common.constant.AdvertisingConstants.*;
import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.project.dsp.userPrintLogWhite.service.IUserPrintLogWhiteService.USER_PRINT_LOG_WHITE;

/**
 * @author songjy
 * @date 2019/07/20
 */
public class RedisSubscribe extends JedisPubSub {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    private IAdvertisingPlanPepoleService advertisingPlanPeopleService;
    private IConfigService configService;
    private IAdvertisingPlanService advertisingPlanService;
    private IAdvertisingUnitService advertisingUnitService;
    private IAdvertisingPlanWxService advertisingPlanWxService;
    private IAdvertisingPlanFansService advertisingPlanFansService;
    private IAdvertisingUnitWxService advertisingUnitWxService;
    private IAdvertisingUnitFansService advertisingUnitFansService;
    private IMediumSellRullService mediumSellRuleService;
    private ISystemAppInfoService systemAppInfoService;
    private IForbidPutOfficialAccountConfigService forbidPutOfficialAccountConfigService;
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    private IWeChatPersonalService weChatPersonalService;
    private IAuthorizationUserInfoService authorizationUserInfoService;
    private IQqPersonalService qqPersonalService;
    private IForbidPutPersonalAccountConfigService forbidPutPersonalAccountConfigService;
    private IMailLimiterService mailLimiterService;

    public RedisSubscribe(ApplicationContext applicationContext) {
        super();
        this.advertisingUnitWxService = applicationContext.getBean(IAdvertisingUnitWxService.class);
        this.advertisingUnitService = applicationContext.getBean(IAdvertisingUnitService.class);
        this.advertisingPlanDeviceService = applicationContext.getBean(IAdvertisingPlanDeviceService.class);
        this.advertisingPlanPeopleService = applicationContext.getBean(IAdvertisingPlanPepoleService.class);
        this.configService = applicationContext.getBean(IConfigService.class);
        this.advertisingPlanService = applicationContext.getBean(IAdvertisingPlanService.class);
        this.advertisingPlanWxService = applicationContext.getBean(IAdvertisingPlanWxService.class);
        this.mediumSellRuleService = applicationContext.getBean(IMediumSellRullService.class);
        this.systemAppInfoService = applicationContext.getBean(ISystemAppInfoService.class);
        this.advertisingPlanFansService = applicationContext.getBean(IAdvertisingPlanFansService.class);
        this.advertisingUnitFansService = applicationContext.getBean(IAdvertisingUnitFansService.class);
        this.forbidPutOfficialAccountConfigService = applicationContext.getBean(IForbidPutOfficialAccountConfigService.class);
        this.componentAuthorizationInfoService = applicationContext.getBean(IComponentAuthorizationInfoService.class);
        this.weChatPersonalService = applicationContext.getBean(IWeChatPersonalService.class);
        this.authorizationUserInfoService = applicationContext.getBean(IAuthorizationUserInfoService.class);
        this.qqPersonalService = applicationContext.getBean(IQqPersonalService.class);
        this.forbidPutPersonalAccountConfigService = applicationContext.getBean(IForbidPutPersonalAccountConfigService.class);
        this.mailLimiterService = applicationContext.getBean(IMailLimiterService.class);
    }

    /**
     * 设备定向正则添加订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_ADD_DEVICE = "channel_ad_pattern_add_device";
    /**
     * 设备定向正则移除订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_REMOVE_DEVICE = "channel_ad_pattern_remove_device";

    /**
     * 设备定向正则修改订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_UPDATE_DEVICE = "channel_ad_pattern_update_device";

    /**
     * 人群定向正则添加订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_ADD_PEOPLE = "channel_ad_pattern_add_people";

    /**
     * 人群定向正则移除订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_REMOVE_PEOPLE = "channel_ad_pattern_remove_people";

    /**
     * 人群定向正则修改订阅channel
     */
    public static final String CHANNEL_AD_PATTERN_UPDATE_PEOPLE = "channel_ad_pattern_update_people";

    /**
     * 广告统计信息订阅channel消费数量
     */
    public static final AtomicInteger CHANNEL_STATISTICS_AD_INFO_COUNT_CONSUME = new AtomicInteger(0);

    /**
     * 系统配置信息修改订阅channel
     */
    public static final String CHANNEL_CONFIG_UPDATE = "channel_config_update";

    /**
     * 系统运行日志订阅channel
     */
    public static final String CHANNEL_DSP_LOGS = "channel_dsp_logs";

    /**
     * $ZJBPL命令下发消息订阅channel
     */
    public static final String CHANNEL_ZJB_PL_IOT_INFO = "channel_zjb_pl_iot_info";

    /**
     * 慢SQL日志正则
     */
    private Pattern PATTERN_LOGS_SLOW_SQL = Pattern.compile("\\d{4}.*?ERROR\\sc.a.d.f.s.StatFilter.*?slow\\ssql.*", Pattern.DOTALL);
    /**
     * 错误日志
     */
    private Pattern PATTERN_LOGS_ERROR = Pattern.compile("\\d{4}.+?\\sERROR\\s(.+)\\s-\\s\\[(.+),(\\d+)\\]\\s-\\s.+", Pattern.DOTALL);
    /**
     * 本机IP
     */
    private String IP = IpUtils.getLocalIP();

    /**
     * 系统MQ状态信息订阅channel
     */
    public static final String CHANNEL_ZJB_ADMIN_MQ_INFO = "channel_zjb_admin_mq_info";

    /**
     * 用户关注公众号事件
     */
    public static final String MESSAGE_WE_CHAT_OFFICIAL_ACCOUNT_EVENT = "message:weChatOfficialAccount:event";

    /**
     * DSP系统通用信息订阅channel
     */
    public static final String CHANNEL_DSP_SYSTEM_COMMON = "channel_dsp_system_common";

    /**
     * 核心系统通用订阅channel
     */
    public static final String CHANNEL_CORE_ADMIN_COMMON_EVENT = "channel_core_admin_common_event";

    /**
     * DSP消息队列通用
     */
    public static final String MESSAGE_QUEUE_DSP_COMMON = "message:queue:dsp:common";

    /**
     * 公众号展示记录
     */
    public static final String KEY_GZH_VIEW_COUNT_EVENT = "key_gzh_view_count_event";

    /**
     * 移除公众号展示记录
     */
    public static final String KEY_REMOVE_GZH_VIEW_COUNT_EVENT = "key_remove_gzh_view_count_event";

    /**
     * 个人号展示次数记录
     * 用于用户扫码获取到公众号记录到临时记录表中
     */
    public static final String KEY_GRH_SHOW_COUNT_EVENT = "key_grh_show_count_event";

    /**
     * 记录展示次数达到3次的个人号
     */
    public static final String KEY_GRH_RECORD_EVENT = "key_grh_record_event";

    /**
     * 移除个人号展示记录
     */
    public static final String KEY_REMOVE_GRH_SHOW_COUNT_EVENT = "key_remove_grh_show_count_event";

    /**
     * 修改用户获取该个人号次数
     */
    public static final String KEY_UPDATE_GRH_SHOW_PERSON_COUNT_EVENT = "key_update_grh_show_person_count_event";

    /**
     * 移除核心appidopenidindex中个人号关注记录
     */
    public static final String KEY_REMOVE_GRH_RECORD_EVENT = "key_remove_grh_record_event";

    /**
     * 移除appidopenidindex中公众号展示记录
     */
    public static final String KEY_REMOVE_GZH_RECORD_EVENT = "key_remove_gzh_record_event";
    /**
     * 记录展示次数达到2次的公众号
     */
    public static final String KEY_GZH_RECORD_EVENT = "key_gzh_record_event";

    /**
     * 核心系统公众号相关队列
     */
    public static final String MESSAGE_QUEUE_ADMIN_GZH = "message_queue_admin_gzh";

    /**
     * 修改DSP个人号胜出记录表中下发PL状态
     */
    public static final String KEY_PERSONAL_ACCOUNT_ISSUE_PL_STATUS_EVENT = "key_personal_account_issue_pl_status_event";

    /**
     * 非竞价广告点击事件
     */
    public static final String KEY_WITHOUT_BIDDING_PRICE_AD_CLICK_EVENT = "key_without_bidding_price_ad_click_event";

    /**
     * 非竞价广告展示事件
     */
    public static final String KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_EVENT = "key_without_bidding_price_ad_show_event";

    /**
     * 非竞价广告点击统计事件
     */
    public static final String KEY_WITHOUT_BIDDING_PRICE_AD_CLICK_STATISTICS_EVENT = "key_without_bidding_price_ad_click_statistics_event";

    /**
     * 非竞价广告展示统计事件
     */
    public static final String KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_STATISTICS_EVENT = "key_without_bidding_price_ad_show_statistics_event";

    /**
     * 第三方公众号广告方案胜出事件
     */
    public static final String KEY_AD_GZH_INFO_WIN_THIRD_EVENT = "key_ad_gzh_info_win_third_event";

    /**
     * 修改第三方公众号广告方案胜出记录表中下发PL状态
     */
    public static final String KEY_AD_GZH_ISSUE_PL_STATUS_EVENT = "key_ad_gzh_issue_pl_status_event";

    /**
     * 修改用户获取第三方公众号次数
     */
    public static final String KEY_UPDATE_GZH_SHOW_PERSON_COUNT_EVENT = "key_update_gzh_show_person_count_event";

    @Override
    public void onSubscribe(String channel, int subscribedChannels) {
        logger.info("成功订阅：{}，总共订阅频道数：{}", channel, subscribedChannels);
    }

    @Override
    public void onMessage(String channel, String message) {

        try {

            /*设备定向正则移除*/
            adPlanPatternRemoveDevice(channel, message);
            /*设备定向正则添加*/
            adPlanPatternAddDevice(channel, message);
            /*设备定向正则修改*/
            adPlanPatternUpdateDevice(channel, message);

            /*人群定向正则添加*/
            adPlanPatternAddPeople(channel, message);
            /*人群定向正则移除*/
            adPlanPatternRemovePeople(channel, message);
            /*人群定向正则修改*/
            adPlanPatternUpdatePeople(channel, message);

            /*系统配置信息修改*/
            channelConfigUpdate(channel, message);
            /*系统运行日志处理*/
            channelDspLogs(channel, message);
            /*系统MQ状态信息处理*/
            channelZjbAdminMqInfo(channel, message);
            /*$ZJBPL命令下发消息处理*/
            channelZjbPlIotInfo(channel, message);

            if (CHANNEL_DSP_SYSTEM_COMMON.equalsIgnoreCase(channel)) {

                Map<String, Object> map = JSON.parseObject(message, Map.class);
                keyAppIdStopAdPlanEvent(map);
                keyMediumSellRuleUpdateEvent(map);
                stopSystemApp(map);
                handleCpuMenPercentage(map);
                handleForbidPutOfficialAccountConfigEvent(map);
                handleComponentAuthorizationInfoEvent(map);
                handleWeChatPersonalEvent(map);
                handleQQPersonalEvent(map);
                handleKAdPlanWinEvent(map);
                handleForbidPutPersonalAccountConfigEvent(map);
                handleUserPrintLogWhiteEvent(map);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

    /**
     * 允许打印日志的用户白名单信息处理
     *
     * @param map
     */
    private void handleUserPrintLogWhiteEvent(Map<String, Object> map) {
        if (map.containsKey(KEY_USER_PRINT_LOG_WHITE_REMOVE)) {
            Object obj = map.get(KEY_USER_PRINT_LOG_WHITE_REMOVE);
            UserPrintLogWhite record = ((JSONObject) obj).toJavaObject(UserPrintLogWhite.class);
            USER_PRINT_LOG_WHITE.remove(record.getOpenId());
        }

        if (map.containsKey(KEY_USER_PRINT_LOG_WHITE_ADD)) {
            Object obj = map.get(KEY_USER_PRINT_LOG_WHITE_ADD);
            UserPrintLogWhite record = ((JSONObject) obj).toJavaObject(UserPrintLogWhite.class);

            if (null != record.getGmtEndPrint() && record.getGmtEndPrint().isAfter(LocalDateTime.now())) {
                USER_PRINT_LOG_WHITE.add(record.getOpenId());
            }
        }
    }

    /**
     * $ZJBPL命令下发消息订阅channel
     *
     * @param channel
     * @param message
     */
    private void channelZjbPlIotInfo(String channel, String message) {
        if (!CHANNEL_ZJB_PL_IOT_INFO.equals(channel)) {
            return;
        }

        RpcRequest pl = JSON.parseObject(message, RpcRequest.class);

        invalidateWinWeChatNickName(pl);
    }

    /**
     * 移除胜出微信昵称
     *
     * @param pl
     */
    private void invalidateWinWeChatNickName(RpcRequest pl) {
        if (StringUtils.isBlank(pl.getOpenId())) {
            logger.warn("$ZJBPL缺失用户openId：{}", JSON.toJSONString(pl));
            return;
        }

        AuthorizationUserInfoDTO userInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(pl.getOpenId());

        if (null == userInfo) {
            logger.error("根据{}获取用户授权信息失败", pl.getOpenId());
            return;
        }

        if (StringUtils.isBlank(pl.getPlanId())) {
            logger.warn("设备{}未关联广告计划", pl.getDeviceName());
            return;
        }

        String key = AD_PLAN_ID_PREFIX + '_' + pl.getPlanId();
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null == planFromRedis) {
            logger.error("广告计划{}不存在Redis中，无法移除胜出微信昵称", pl.getPlanId());
            return;
        }

        if (StringUtils.isNotBlank(planFromRedis.getWeChatPersonalId())) {
            weChatPersonalService.invalidateWinWeChatNickName(userInfo.getUserNick());
            weChatPersonalService.invalidateWinWeChatNickName(planFromRedis.getWeChatPersonalId());
            logger.info("用户【{}：{}】匹配到的微信个人号{}已从本地缓存中移除", pl.getOpenId(), userInfo.getUserNick(), planFromRedis.getWeChatPersonalId());
        }

        if (StringUtils.isNotBlank(planFromRedis.getQqPersonalId())) {
            qqPersonalService.invalidateWinWeChatNickName(userInfo.getUserNick());
            qqPersonalService.invalidateWinWeChatNickName(planFromRedis.getQqPersonalId());
            logger.info("用户【{}：{}】匹配到的QQ个人号{}已从本地缓存中移除", pl.getOpenId(), userInfo.getUserNick(), planFromRedis.getQqPersonalId());
        }
    }

    /**
     * 广告计划胜出事件
     *
     * @param map
     */
    private void handleKAdPlanWinEvent(Map<String, Object> map) {
        if (!map.containsKey(KEY_AD_PLAN_WIN_EVENT)) {
            return;
        }

        Object objectPlan = map.get(KEY_AD_PLAN_WIN_EVENT);
        Object objectTargetInfo = map.get(AdvertisingTargetInfo.class.getName());
        Object objectUserInfo = map.get(AuthorizationUserInfoDTO.class.getName());
        AdvertisingPlan plan = ((JSONObject) objectPlan).toJavaObject(AdvertisingPlan.class);
        plan.setRecentWinTimestamp(System.currentTimeMillis());
        advertisingPlanDeviceService.localCacheWinPlan(plan);

        AuthorizationUserInfoDTO userInfo = (null == objectUserInfo) ? null : ((JSONObject) objectUserInfo).toJavaObject(AuthorizationUserInfoDTO.class);
        AdvertisingTargetInfo targetInfo = (null == objectTargetInfo) ? null : ((JSONObject) objectTargetInfo).toJavaObject(AdvertisingTargetInfo.class);
        AdvertisingPeopleInfo peopleInfo = null == targetInfo ? null : targetInfo.getPeopleInfo();
        weChatPersonalService.cacheWinWeChatNickName((null == peopleInfo ? null : peopleInfo.getOpenId()), plan);
        qqPersonalService.cacheWinWeChatNickName((null == peopleInfo ? null : peopleInfo.getOpenId()), plan);

        weChatPersonalService.removeOnWinAndNoPl(userInfo, plan);
        qqPersonalService.removeOnWinAndNoPl(userInfo, plan);
    }

    /**
     * 处理QQ个人号事件
     *
     * @param map
     */
    private void handleQQPersonalEvent(Map<String, Object> map) {
        if (map.containsKey(KEY_QQ_PERSONAL_UPDATE_EVENT)) {
            Object jsonObject = map.get(KEY_QQ_PERSONAL_UPDATE_EVENT);
            QqPersonal qqPersonal = ((JSONObject) jsonObject).toJavaObject(QqPersonal.class);
            qqPersonalService.clearLocalCache(qqPersonal);
        }
    }

    /**
     * 处理微信个人号事件
     *
     * @param map
     */
    private void handleWeChatPersonalEvent(Map<String, Object> map) {
        if (map.containsKey(KEY_WE_CHAT_PERSONAL_UPDATE_EVENT)) {
            Object jsonObject = map.get(KEY_WE_CHAT_PERSONAL_UPDATE_EVENT);
            WeChatPersonal weChatPersonal = ((JSONObject) jsonObject).toJavaObject(WeChatPersonal.class);
            weChatPersonalService.clearLocalCache(weChatPersonal);
        }
    }

    /**
     * 系统MQ状态信息处理
     *
     * @param channel
     * @param message
     */
    private void channelZjbAdminMqInfo(String channel, String message) {
        if (CHANNEL_ZJB_ADMIN_MQ_INFO.equals(channel)) {
            logger.info("收到来自：{}发布的消息：{}", channel, message);
            Mq mq = JSON.parseObject(message, Mq.class);

            if (null == mq || StringUtils.isBlank(mq.getDomain())) {
                return;
            }

            String domain = mq.getDomain();
            Config config = new Config();
            config.setConfigKey(ZjbConfigEnum.ZJB_GDT_SERVER_DOMAIN.getKey());
            config.setDeleted(NO.getValue());
            List<Config> list = configService.selectConfigList(config);

            if (null == list || list.isEmpty()) {
                return;
            }

            if (1 != list.size()) {
                return;
            }

            config = list.get(0);
            String[] values = StringUtils.split(config.getConfigValue(), ',');
            Set<String> set = new HashSet<>(Arrays.asList(values));

            if (MQ_STATUS_STARTED.getValue().equals(mq.getStatus())) {
                set.add(domain);
            } else if (MQ_STATUS_STOPPED.getValue().equals(mq.getStatus())) {
                set.remove(domain);
            }

            config.setConfigValue(String.join(",", set));
            configService.updateConfig(config);

            return;
        }
    }

    /**
     * 系统运行日志处理
     *
     * @param channel
     * @param message
     */
    private void channelDspLogs(String channel, String message) {
        if (CHANNEL_DSP_LOGS.equals(channel)) {
            logger.debug("收到来自：{}发布的消息：{}", channel, message);
            FileBeatData fileBeatData = JSON.parseObject(message, FileBeatData.class);

            if (null == fileBeatData || StringUtils.isBlank(fileBeatData.getMessage()) || null == fileBeatData.getHost()) {
                return;
            }

            FileBeatData.Host host = fileBeatData.getHost();

            if (null == host.getIp() || !host.getIp().contains(IP)) {
                logger.debug("非本机系统产生的日志，忽略");
                return;
            }

            FileBeatData.Log log = fileBeatData.getLog();
            if (null == log || null == log.getFile()) {
                return;
            }

            FileBeatData.Log.File file = log.getFile();

            if (StringUtils.isBlank(file.getPath()) || !file.getPath().startsWith(SystemUtils.USER_DIR)) {
                logger.debug("非自身系统产生的日志，忽略");
                return;
            }

            Matcher matcher = PATTERN_LOGS_SLOW_SQL.matcher(fileBeatData.getMessage());

            if (matcher.matches()) {
                Collection<String> tos = Arrays.asList("jiangbingjie@sczj-inc.com", "shenlong@sczj-inc.com", "zhanghuan@sczj-inc.com");
                Collection<String> ccs = Arrays.asList("lichuang@sczj-inc.com");
                Collection<String> bcc = Arrays.asList("sunlifeng@sczj-inc.com", "renqiyao@sczj-inc.com");
                mailLimiterService.send(tos, ccs, bcc, "DSP慢SQL", "<pre>" + message + "</pre>", true);
            } else if ((matcher = PATTERN_LOGS_ERROR.matcher(fileBeatData.getMessage())).matches()) {
                List<String> tos = Arrays.asList("shenlong@sczj-inc.com");
                Collection<String> ccs = Arrays.asList("renqiyao@sczj-inc.com", "lichuang@sczj-inc.com");
                Collection<String> bcc = Arrays.asList("jiangbingjie@sczj-inc.com", "sunlifeng@sczj-inc.com");
                mailLimiterService.send(tos, ccs, bcc, "DSP错误日志：" + matcher.group(1) + '.' + matcher.group(2), "<pre>" + message + "</pre>", true);
            }

        }
    }

    /**
     * 系统配置信息修改
     *
     * @param channel
     * @param message
     */
    private void channelConfigUpdate(String channel, String message) {
        if (CHANNEL_CONFIG_UPDATE.equals(channel)) {
            logger.warn("收到来自：{}发布的消息：{}", channel, message);
            Config config = JSON.parseObject(message, Config.class);
            configService.synchronize(config);
        }
    }

    /**
     * 人群定向正则修改
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternUpdatePeople(String channel, String message) {
        if (CHANNEL_AD_PATTERN_UPDATE_PEOPLE.equals(channel)) {
            logger.info("收到来自：{}发布的消息：{}", channel, message);
            Map<String, JSONObject> map = JSON.parseObject(message, Map.class);
            AdvertisingPlanPepole oldRecord = map.get("oldRecord").toJavaObject(AdvertisingPlanPepole.class);
            AdvertisingPlanPepole newRecord = map.get("newRecord").toJavaObject(AdvertisingPlanPepole.class);
            advertisingPlanPeopleService.removePattern(oldRecord);
            advertisingPlanPeopleService.addPattern(newRecord);
            String regex = AdExchangeServiceImpl.getRegex(newRecord);
            logger.warn("人群正则[{}]对应的广告计划ID[{}]添加成功", regex, newRecord.getAdPlanId());
        }
    }

    /**
     * 人群定向正则移除
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternRemovePeople(String channel, String message) {
        if (CHANNEL_AD_PATTERN_REMOVE_PEOPLE.equals(channel)) {
            logger.info("收到来自：{}发布的消息：{}", channel, message);
            AdvertisingPlanPepole advertisingPlanPepole = JSON.parseObject(message, AdvertisingPlanPepole.class);
            advertisingPlanPeopleService.removePattern(advertisingPlanPepole);
        }
    }

    /**
     * 人群定向正则添加
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternAddPeople(String channel, String message) {
        if (CHANNEL_AD_PATTERN_ADD_PEOPLE.equals(channel)) {
            logger.info("收到来自：{}发布的消息：{}", channel, message);
            AdvertisingPlanPepole advertisingPlanPepole = JSON.parseObject(message, AdvertisingPlanPepole.class);
            advertisingPlanPeopleService.addPattern(advertisingPlanPepole);
        }
    }

    /**
     * 设备定向正则修改
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternUpdateDevice(String channel, String message) {
        if (!CHANNEL_AD_PATTERN_UPDATE_DEVICE.equals(channel)) {
            return;
        }

        logger.info("收到来自：{}发布的消息：{}", channel, message);
        Map<String, JSONObject> map = JSON.parseObject(message, Map.class);
        AdvertisingPlanDevice oldRecord = map.get("oldRecord").toJavaObject(AdvertisingPlanDevice.class);
        AdvertisingPlanDevice newRecord = map.get("newRecord").toJavaObject(AdvertisingPlanDevice.class);
        advertisingPlanDeviceService.removePattern(oldRecord);
        advertisingPlanDeviceService.addPattern(newRecord);
        String regex = AdExchangeServiceImpl.getRegex(newRecord);
        logger.warn("设备正则[{}]对应的广告计划ID[{}]添加成功", regex, newRecord.getAdPlanId());
    }

    /**
     * 设备定向正则移除
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternRemoveDevice(String channel, String message) {
        if (!CHANNEL_AD_PATTERN_REMOVE_DEVICE.equals(channel)) {
            return;
        }

        logger.info("收到来自：{}发布的消息：{}", channel, message);
        AdvertisingPlanDevice advertisingPlanDevice = JSON.parseObject(message, AdvertisingPlanDevice.class);
        advertisingPlanDeviceService.removePattern(advertisingPlanDevice);
    }

    /**
     * 设备定向正则添加
     *
     * @param channel
     * @param message
     */
    private void adPlanPatternAddDevice(String channel, String message) {
        if (!CHANNEL_AD_PATTERN_ADD_DEVICE.equals(channel)) {
            return;
        }

        logger.info("收到来自：{}发布的消息：{}", channel, message);
        AdvertisingPlanDevice advertisingPlanDevice = JSON.parseObject(message, AdvertisingPlanDevice.class);
        advertisingPlanDeviceService.addPattern(advertisingPlanDevice);
    }

    /**
     * 微信公众号事件处理
     *
     * @param map
     */
    private void handleComponentAuthorizationInfoEvent(Map<String, Object> map) {
        if (map.containsKey(KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE)) {
            Object jsonObject = map.get(KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE);
            ComponentAuthorizationInfo info = ((JSONObject) jsonObject).toJavaObject(ComponentAuthorizationInfo.class);
            componentAuthorizationInfoService.clearLocalCache(info);
        }

        if (map.containsKey(KEY_COMPONENT_AUTHORIZATION_INFO_CLEAN_DAY_FOLLOW_AMOUNT)) {
            componentAuthorizationInfoService.clearAllLocalCache();
            componentAuthorizationInfoService.cleanDayFollowAmount();
            componentAuthorizationInfoService.clearAllLocalCache();
        }

    }

    /**
     * 公众号屏蔽记录事件处理
     *
     * @param map
     */
    private void handleForbidPutOfficialAccountConfigEvent(Map<String, Object> map) {

        if (map.containsKey(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE)) {
            Object jsonObject = map.get(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE);

            ForbidPutOfficialAccountConfig config = ((JSONObject) jsonObject).toJavaObject(ForbidPutOfficialAccountConfig.class);
            forbidPutOfficialAccountConfigService.removePattern(config);
        }

        if (map.containsKey(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD)) {
            Object jsonObject = map.get(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD);

            ForbidPutOfficialAccountConfig config = ((JSONObject) jsonObject).toJavaObject(ForbidPutOfficialAccountConfig.class);

            forbidPutOfficialAccountConfigService.addPattern(config);
        }
    }

    /**
     * 处理CPU、内存占用百分比
     *
     * @param map
     */
    private void handleCpuMenPercentage(Map<String, Object> map) {
        if (!map.containsKey(KEY_CPU_MEN_PERCENTAGE_EVENT)) {
            return;
        }

        if (SystemUtils.IS_OS_MAC || SystemUtils.IS_OS_WINDOWS) {
            return;
        }

        String ip = NetUtil.getLocalhostStr();

        SystemAppInfo query = new SystemAppInfo();
        query.setSystemAppIp(ip);
        List<SystemAppInfo> list = systemAppInfoService.selectSystemAppInfoList(query);

        if (null == list || list.isEmpty()) {
            return;
        }

        String commands = "ps -ux";
        String result = RuntimeUtil.execForStr(commands);
        logger.info("执行命令【{}】结果：{}{}", commands, System.lineSeparator(), result);

        List<String> pidList = Splitter.on(System.lineSeparator())
                .omitEmptyStrings()
                .splitToList(result);

        for (SystemAppInfo appInfo : list) {
            pidList.forEach(e -> {
                String[] array = org.apache.commons.lang3.StringUtils.split(e);
                String pid = org.apache.commons.lang3.StringUtils.split(appInfo.getSystemAppPid(), '@')[0];

                if (array[0].equals(SystemUtils.USER_NAME) && array[1].equals(pid)) {
                    appInfo.setCpuPercentage(array[2]);
                    appInfo.setMenPercentage(array[3]);
                    systemAppInfoService.updateSystemAppInfo(appInfo);
                }

            });
        }

    }

    /**
     * 停止系统应用
     *
     * @param map
     */
    private void stopSystemApp(Map<String, Object> map) {
        if (!map.containsKey(KEY_STOP_SYSTEM_APP_EVENT)) {
            return;
        }

        Object jsonObject = map.get(KEY_STOP_SYSTEM_APP_EVENT);

        SystemAppInfo systemAppInfo = ((JSONObject) jsonObject).toJavaObject(SystemAppInfo.class);

        if (!Constants.SYSTEM_ID.equals(systemAppInfo.getSystemAppId())) {
            return;
        }

        /*取消所有订阅*/
        unsubscribe();
        logger.info("所有订阅已取消");

        systemAppInfoService.deleteSystemAppInfoByIds(String.valueOf(systemAppInfo.getId()));
        systemAppInfoService.shutdown();
    }

    /**
     * 售卖规则变更事件
     *
     * @param map
     */
    private void keyMediumSellRuleUpdateEvent(Map<String, Object> map) {

        if (!map.containsKey(AdvertisingConstants.MEDIUM_SELL_RULE_UPDATE_EVENT)) {
            return;
        }

        Object jsonObject = map.get(AdvertisingConstants.MEDIUM_SELL_RULE_UPDATE_EVENT);
        MediumSellRull mediumSellRule = ((JSONObject) jsonObject).toJavaObject(MediumSellRull.class);

        restartPlanMediumSellRuleOneAliPay(mediumSellRule, true);
        restartPlanMediumSellRuleOneWx(mediumSellRule, true);

        restartPlanMediumSellRuleTwoAliPay(mediumSellRule, true);
        restartPlanMediumSellRuleTwoWx(mediumSellRule, true);

        MediumSellRull query = new MediumSellRull();
        query.setRullStatus(RULL_STATUS_EFFECTIV.getValue());
        query.setDeleted(NO.getValue());

        List<MediumSellRull> list = mediumSellRuleService.selectMediumSellRullList(query);
        IMediumSellRullService.MEDIUM_SELL_RULES.clear();
        if (null != list && !list.isEmpty()) {
            IMediumSellRullService.MEDIUM_SELL_RULES.addAll(list);
        }

        restartPlanMediumSellRuleOneAliPay(mediumSellRule, false);
        restartPlanMediumSellRuleOneWx(mediumSellRule, false);

        restartPlanMediumSellRuleTwoAliPay(mediumSellRule, false);
        restartPlanMediumSellRuleTwoWx(mediumSellRule, false);

        mediumSellRuleService.mediumSellRuleThree();

    }

    /**
     * 售卖规则2 禁投公众号广告	该规则配置的设备将自动过滤标记“公众号”标签的广告计划
     *
     * @param mediumSellRuleTwo
     * @param clean             是否清理旧规则，true 清理旧规则，但不重新载入新规则 false 载入新规则，但不清理旧规则
     */
    private void restartPlanMediumSellRuleTwoWx(MediumSellRull mediumSellRuleTwo, boolean clean) {

        if (!mediumSellRuleTwo.getRullId().equals(2)) {
            /*非售卖规则2*/
            return;
        }

        AdvertisingPlanWx query = new AdvertisingPlanWx();
        query.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        query.setWeChatAccount(YES.getValue());
        List<AdvertisingPlanWx> planList = advertisingPlanWxService.selectAdvertisingPlanWxList(query);

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlanWx plan : planList) {
            if (clean) {
                advertisingPlanWxService.clearLocalCacheRegex(plan.getPlanId());
            } else {
                advertisingPlanWxService.reloadPattern(plan.getPlanId());
            }

        }

    }

    /**
     * 售卖规则2 禁投公众号广告	该规则配置的设备将自动过滤标记“公众号”标签的广告计划
     * <p>
     * 售卖规则4：支持配置设备|代理商的指定次数不出现公众号广告
     *
     * @param mediumSellRuleTwo
     * @param clean             是否清理旧规则，true 清理旧规则，但不重新载入新规则 false 载入新规则，但不清理旧规则
     */
    private void restartPlanMediumSellRuleTwoAliPay(MediumSellRull mediumSellRuleTwo, boolean clean) {

        Set<Integer> ruleId = new HashSet<>(Arrays.asList(new Integer[]{2, 4}));

        if (!ruleId.contains(mediumSellRuleTwo.getRullId())) {
            return;
        }

        AdvertisingPlan query = new AdvertisingPlan();
        query.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        query.setWeChatAccount(YES.getValue());
        List<AdvertisingPlan> planList = advertisingPlanService.selectAdvertisingPlanList(query);

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlan plan : planList) {
            if (clean) {
                advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
            } else {
                advertisingPlanService.reloadPattern(plan.getPlanId());
            }

        }

    }

    /**
     * 售卖规则1 禁投金融行业	学校场景，禁投金融行业广告
     *
     * @param mediumSellRuleOne
     * @param clean             是否清理旧规则，true 清理旧规则，但不重新载入新规则 false 载入新规则，但不清理旧规则
     */
    private void restartPlanMediumSellRuleOneAliPay(MediumSellRull mediumSellRuleOne, boolean clean) {

        if (!mediumSellRuleOne.getRullId().equals(1)) {
            /*非售卖规则1*/
            return;
        }

        AdvertisingPlan query = new AdvertisingPlan();
        query.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        query.setCategoryFinance(YES.getValue());
        List<AdvertisingPlan> planList = advertisingPlanService.selectAdvertisingPlanList(query);

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlan plan : planList) {
            if (clean) {
                advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
            } else {
                advertisingPlanService.reloadPattern(plan.getPlanId());
            }

        }

    }

    /**
     * 售卖规则1 禁投金融行业	学校场景，禁投金融行业广告
     *
     * @param mediumSellRuleOne
     * @param clean             是否清理旧规则，true 清理旧规则，但不重新载入新规则 false 载入新规则，但不清理旧规则
     */
    private void restartPlanMediumSellRuleOneWx(MediumSellRull mediumSellRuleOne, boolean clean) {

        if (!mediumSellRuleOne.getRullId().equals(1)) {
            /*非售卖规则1*/
            return;
        }

        AdvertisingPlanWx query = new AdvertisingPlanWx();
        query.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        query.setCategoryFinance(YES.getValue());
        List<AdvertisingPlanWx> planList = advertisingPlanWxService.selectAdvertisingPlanWxList(query);

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlanWx plan : planList) {
            if (clean) {
                advertisingPlanWxService.clearLocalCacheRegex(plan.getPlanId());
            } else {
                advertisingPlanWxService.reloadPattern(plan.getPlanId());
            }
        }

    }

    /**
     * 公众号停止之广告投放计划暂停联动事件
     *
     * @param map
     */
    private void keyAppIdStopAdPlanEvent(Map<String, Object> map) {

        if (!map.containsKey(AdvertisingConstants.KEY_APP_ID_STOP_AD_PLAN_EVENT)) {
            return;
        }

        if (!Constants.SYSTEM_ID.equals(map.get(AdvertisingConstants.KEY_SYSTEM_ID))) {
            return;
        }

        Object jsonObject = map.get(AdvertisingConstants.KEY_APP_ID_STOP_AD_PLAN_EVENT);
        ComponentAuthorizationInfo componentAuthorizationInfo = ((JSONObject) jsonObject).toJavaObject(ComponentAuthorizationInfo.class);

        if (null == componentAuthorizationInfo || StringUtils.isBlank(componentAuthorizationInfo.getAppId())) {
            return;
        }

        stopPlanAliPay(componentAuthorizationInfo);
        stopPlanWx(componentAuthorizationInfo);
        stopPlanFans(componentAuthorizationInfo);
    }

    /**
     * 微信投放计划暂停
     *
     * @param componentAuthorizationInfo
     */
    private void stopPlanWx(ComponentAuthorizationInfo componentAuthorizationInfo) {
        List<AdvertisingPlanWx> listWx = advertisingPlanWxService.selectByAdAppId(componentAuthorizationInfo.getAppId());

        if (null == listWx || listWx.isEmpty()) {
            return;
        }

        for (AdvertisingPlanWx plan : listWx) {

            if (!plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                continue;
            }

            if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_TOTAL_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_DAY_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STOP_MANUAL.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_MANUAL.getValue());
            } else {
                continue;
            }

            advertisingPlanWxService.updateAdvertisingPlanWx(plan);

            /*配置公众号任务的广告单元亦需要停止*/
            stopPlanUnitWx(plan);
        }

        /*广告单元直配的公众号取纸位亦需要暂停*/
        stopPlanUnitWx(componentAuthorizationInfo);
    }

    /**
     * 粉丝通投放计划暂停
     *
     * @param componentAuthorizationInfo
     */
    private void stopPlanFans(ComponentAuthorizationInfo componentAuthorizationInfo) {
        List<AdvertisingPlanFans> fansList = advertisingPlanFansService.selectByAdAppId(componentAuthorizationInfo.getAppId());

        if (null == fansList || fansList.isEmpty()) {
            return;
        }

        for (AdvertisingPlanFans plan : fansList) {

            if (!plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                continue;
            }

            if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_TOTAL_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_DAY_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STOP_MANUAL.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_MANUAL.getValue());
            } else {
                continue;
            }

            logger.info("公众号【{}】状态变更为【{}】，对应广告计划【{}】状态变更为【{}】", componentAuthorizationInfo.getNickName(), componentAuthorizationInfo.getDeliveryStatus(), plan.getPlanId(), plan.getAdvertisingStatus());

            advertisingPlanFansService.updateAdvertisingPlanFans(plan);

            /*配置公众号任务的广告单元亦需要停止：粉丝通公众号都是直配，无需处理*/
            //stopPlanUnitFans(plan);
        }

        /*广告单元直配的公众号取纸位亦需要暂停*/
        stopPlanUnitFans(componentAuthorizationInfo);
    }

    /**
     * 广告单元直配的公众号取纸位亦需要暂停
     *
     * @param authInfo
     */
    private void stopPlanUnitWx(ComponentAuthorizationInfo authInfo) {

        if (null == authInfo) {
            return;
        }

        List<AdvertisingUnitWx> unitList = advertisingUnitWxService.selectUnitByWeChatOfficialAccount(authInfo.getAppId());

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnitWx unitWx : unitList) {

            if (!AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(unitWx.getRedirectUrlType())
                    && !AD_REDIRECT_TASK.getValue().equals(unitWx.getRedirectUrlType())) {
                continue;
            }

            if (!AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(unitWx.getAdSpaceIdentifier())
                    || !AD_USE_YES.getValue().equals(unitWx.getAdUseStatus())) {
                continue;
            }

            unitWx.setAdUseStatus(AD_USE_NO.getValue());
            int r = advertisingUnitWxService.updateAdvertisingUnitWx(unitWx);
            if (r > 0) {
                logger.info("公众号【{}:{}】状态变更为【{}】广告单元【{}】停用", authInfo.getNickName(), authInfo.getAppId(), authInfo.getDeliveryStatus(), unitWx.getAdName());
            }
        }
    }

    /**
     * 广告单元直配的公众号取纸位亦需要暂停
     *
     * @param authInfo
     */
    private void stopPlanUnitFans(ComponentAuthorizationInfo authInfo) {

        if (null == authInfo) {
            return;
        }

        List<AdvertisingUnitFans> unitFansList = advertisingUnitFansService.selectUnitByWeChatOfficialAccount(authInfo.getAppId());

        if (null == unitFansList || unitFansList.isEmpty()) {
            return;
        }

        for (AdvertisingUnitFans unitFans : unitFansList) {
            unitFans.setAdUseStatus(AD_USE_NO.getValue());
            int r = advertisingUnitFansService.updateAdvertisingUnitFans(unitFans);
            if (r > 0) {
                logger.info("公众号【{}:{}】状态变更为【{}】广告单元【{}】停用", authInfo.getNickName(), authInfo.getAppId(), authInfo.getDeliveryStatus(), unitFans.getAdName());
            }
        }
    }

    /**
     * 配置公众号任务的广告单元亦需要停止
     *
     * @param planWx
     */
    private void stopPlanUnitWx(AdvertisingPlanWx planWx) {

        if (null == planWx) {
            return;
        }

        List<AdvertisingUnitWx> unitList = advertisingUnitWxService.selectAdvertisingUnitWxListByPlanId(planWx.getId());

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnitWx unitWx : unitList) {
            if (!AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(unitWx.getAdSpaceIdentifier())
                    || !AD_REDIRECT_TASK.getValue().equals(unitWx.getRedirectUrlType())
                    || !StringUtils.isNumeric(unitWx.getAppId())
                    || !AD_USE_YES.getValue().equals(unitWx.getAdUseStatus())) {
                continue;
            }

            unitWx.setAdUseStatus(AD_USE_NO.getValue());
            int r = advertisingUnitWxService.updateAdvertisingUnitWx(unitWx);
            if (r > 0) {
                logger.info("广告计划【{}】状态变更为【{}】广告单元【{}】停用", planWx.getPlanId(), planWx.getAdvertisingStatus(), unitWx.getAdName());
            }
        }
    }

    /**
     * 展示通投放广告计划暂停
     *
     * @param componentAuthorizationInfo
     */
    private void stopPlanAliPay(ComponentAuthorizationInfo componentAuthorizationInfo) {
        List<AdvertisingPlan> list = advertisingPlanService.selectByAdAppId(componentAuthorizationInfo.getAppId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingPlan plan : list) {

            if (!plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                continue;
            }

            if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_TOTAL_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_DAY_LIMIT.getValue());
            } else if (componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STOP_MANUAL.getValue())) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_MANUAL.getValue());
            } else {
                continue;
            }

            advertisingPlanService.updateAdvertisingPlan(plan);

            /*配置公众号任务的广告单元亦需要停止*/
            stopPlanUnitAliPay(plan);
        }

        stopPlanUnitAliPay(componentAuthorizationInfo);
    }

    /**
     * 广告单元直配的公众号取纸位亦需要暂停
     *
     * @param authInfo
     */
    private void stopPlanUnitAliPay(ComponentAuthorizationInfo authInfo) {
        if (null == authInfo) {
            return;
        }

        List<AdvertisingUnit> unitList = advertisingUnitService.selectUnitByWeChatOfficialAccount(authInfo.getAppId());

        if (null == unitList) {
            return;
        }

        for (AdvertisingUnit unit : unitList) {

            if (!AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(unit.getRedirectUrlType())
                    && !AD_REDIRECT_TASK.getValue().equals(unit.getRedirectUrlType())) {
                continue;
            }

            if (!AD_SPACE_PAPER_OUTPUT.getValue().equals(unit.getAdSpaceIdentifier())
                    || !AD_USE_YES.getValue().equals(unit.getAdUseStatus())) {
                continue;
            }

            unit.setAdUseStatus(AD_USE_NO.getValue());
            int r = advertisingUnitService.updateAdvertisingUnit(unit);
            if (r > 0) {
                logger.info("公众号【{}:{}】状态变更为【{}】广告单元【{}】停用", authInfo.getNickName(), authInfo.getAppId(), authInfo.getDeliveryStatus(), unit.getAdName());
            }
        }
    }

    /**
     * 广告计划对应的广告单元取纸位亦需要暂停
     *
     * @param plan
     */
    private void stopPlanUnitAliPay(AdvertisingPlan plan) {

        if (null == plan) {
            return;
        }

        List<AdvertisingUnit> unitList = advertisingUnitService.selectAdvertisingUnitListByPlanId(plan.getId());

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnit advertisingUnit : unitList) {
            if (!AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                    || !AD_REDIRECT_TASK.getValue().equals(advertisingUnit.getRedirectUrlType())
                    || !StringUtils.isNumeric(advertisingUnit.getAppId())
                    || !AD_USE_YES.getValue().equals(advertisingUnit.getAdUseStatus())) {
                continue;
            }

            advertisingUnit.setAdUseStatus(AD_USE_NO.getValue());
            int r = advertisingUnitService.updateAdvertisingUnit(advertisingUnit);
            if (r > 0) {
                logger.info("广告计划【{}】状态变更为【{}】广告单元【{}】停用", plan.getPlanId(), plan.getAdvertisingStatus(), advertisingUnit.getAdName());
            }

        }

    }

    /**
     * 个人号屏蔽记录事件处理
     *
     * @param map
     */
    private void handleForbidPutPersonalAccountConfigEvent(Map<String, Object> map) {

        if (map.containsKey(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE)) {
            Object jsonObject = map.get(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE);

            ForbidPutPersonalAccountConfig config = ((JSONObject) jsonObject).toJavaObject(ForbidPutPersonalAccountConfig.class);
            forbidPutPersonalAccountConfigService.removePattern(config);
        }

        if (map.containsKey(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD)) {
            Object jsonObject = map.get(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD);

            ForbidPutPersonalAccountConfig config = ((JSONObject) jsonObject).toJavaObject(ForbidPutPersonalAccountConfig.class);

            forbidPutPersonalAccountConfigService.addPattern(config);
        }
    }
}
