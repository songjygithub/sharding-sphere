package com.zjb.framework.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 读取项目相关配置
 *
 * @author zjb
 */
@Component
@ConfigurationProperties(prefix = "zjb")
public class ZjbConfig {
    /**
     * 项目名称
     */
    private String name;
    /**
     * 版本
     */
    private String version;
    /**
     * 版权年份
     */
    private String copyrightYear;
    /**
     * 头像上传路径
     */
    private static String profile;
    /**
     * 获取地址开关
     */
    private static boolean addressEnabled;
    /**
     * 后台管理端域名url
     */
    private String domainUrl;
    /**
     * 移动端域名url
     */
    private String mdomainUrl;
    /**
     * 项目根路径
     */
    private String rootUrl;
    /**
     * 设备二维码url
     */
    private String deviceUrl;
    /**
     * 设备批量导入文件上传路径
     */
    private String deviceImportFolder;
    /**
     * 耗材付款凭证文件上传路径
     */
    private String evidenceFolder;
    /**
     * 提现打款凭证文件上传路径
     */
    private String remitEvidenceFolder;
    /**
     * 代理商营业执照文件上传路径
     */
    private String businessLicenceFolder;
    /**
     * 代理商法人身份证文件上传路径
     */
    private String legalPersonIdentityCardFolder;
    /**
     * 设备安装图片文件上传路径
     */
    private String installPhotoFolder;
    /**
     * 跳转路由URL的图片的地址
     */
    private String businessRouteFolder;
    /**
     * 设备二维码的图片的地址
     */
    private String deviceUrlFolder;
    /**
     * 设备小程序的图片的地址
     */
    private String miniUrlFolder;
    /**
     * 设备qrcode图片
     */
    private String qrCodeImgUrl;
    /**
     * 扫码分成配置的设备xls文件的地址
     */
    private String benefitDeviceUrl;
    /**
     * 设备故障上报图片地址
     */
    private String deviceAbnormalImgUrl;
    /**
     * 广告图片地址
     */
    private String adPhotoUrl;
    /**
     * 小树叶任务图标
     */
    private String leafTaskImgUrl;
    /**
     * 保底任务广告素材
     */
    private String guaranteeTaskAdUrl;

    /**
     * 首页推送图标地址
     */
    private String pushIconUrl;

    /**
     * 首页配置图片
     */
    private String leafHomeImgUrl;

    /**
     * 用户交单截图地址
     */
    private String userSubmitImgUrl;

    /**
     * 广告投放指定设备
     */
    private String adPlanDeviceFileUrl;
    /**
     * 微信首页-浮层弹窗指定设备(Excel)
     */
    private String adWithoutBiddingPriceFileUrl;

    /**
     * 临时文件地址
     */
    private String tempFileUrl;

    /**
     * 人工上架公众号图片二维码
     */
    private String gzhQrcodeUrl;

    /**
     * 微信个人号二维码图片
     */
    private String weChatPersonalQrCodeUrl;

    /**
     * QQ个人号二维码图片
     */
    private String qqPersonalQrCodeUrl;
    /**
     * 素材url
     */
    private String mediaUrl;

    /**
     * 广告交易数据
     */
    private String advertisingTargetInfoUrl;

    public String getMiniUrlFolder() {
        return miniUrlFolder;
    }

    public void setMiniUrlFolder(String miniUrlFolder) {
        this.miniUrlFolder = miniUrlFolder;
    }

    public String getRemitEvidenceFolder() {
        return remitEvidenceFolder;
    }

    public void setRemitEvidenceFolder(String remitEvidenceFolder) {
        this.remitEvidenceFolder = remitEvidenceFolder;
    }

    public String getEvidenceFolder() {
        return evidenceFolder;
    }

    public void setEvidenceFolder(String folder) {
        this.evidenceFolder = folder;
    }

    public String getBusinessLicenceFolder() {
        return businessLicenceFolder;
    }

    public void setBusinessLicenceFolder(String businessLicenceFolder) {
        this.businessLicenceFolder = businessLicenceFolder;
    }

    public String getLegalPersonIdentityCardFolder() {
        return legalPersonIdentityCardFolder;
    }

    public void setLegalPersonIdentityCardFolder(String legalPersonIdentityCardFolder) {
        this.legalPersonIdentityCardFolder = legalPersonIdentityCardFolder;
    }

    public String getInstallPhotoFolder() {
        return installPhotoFolder;
    }

    public void setInstallPhotoFolder(String installPhotoFolder) {
        this.installPhotoFolder = installPhotoFolder;
    }

    public String getBusinessRouteFolder() {
        return businessRouteFolder;
    }

    public void setBusinessRouteFolder(String businessRouteFolder) {
        this.businessRouteFolder = businessRouteFolder;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    public String getCopyrightYear() {
        return copyrightYear;
    }

    public void setCopyrightYear(String copyrightYear) {
        this.copyrightYear = copyrightYear;
    }

    public static String getProfile() {
        return profile;
    }

    public void setProfile(String profile) {
        ZjbConfig.profile = profile;
    }

    public static boolean isAddressEnabled() {
        return addressEnabled;
    }

    public void setAddressEnabled(boolean addressEnabled) {
        ZjbConfig.addressEnabled = addressEnabled;
    }

    public String getDeviceUrl() {
        return deviceUrl;
    }

    public void setDeviceUrl(String deviceUrl) {
        this.deviceUrl = deviceUrl;
    }

    public String getDomainUrl() {
        return domainUrl;
    }

    public void setDomainUrl(String domainUrl) {
        this.domainUrl = domainUrl;
    }

    public String getMdomainUrl() {
        return mdomainUrl;
    }

    public void setMdomainUrl(String mdomainUrl) {
        this.mdomainUrl = mdomainUrl;
    }

    public String getRootUrl() {
        return rootUrl;
    }

    public void setRootUrl(String rootUrl) {
        this.rootUrl = rootUrl;
    }

    public String getDeviceImportFolder() {
        return deviceImportFolder;
    }

    public void setDeviceImportFolder(String deviceImportFolder) {
        this.deviceImportFolder = deviceImportFolder;
    }

    public String getDeviceUrlFolder() {
        return deviceUrlFolder;
    }

    public void setDeviceUrlFolder(String deviceUrlFolder) {
        this.deviceUrlFolder = deviceUrlFolder;
    }

    public String getQrCodeImgUrl() {
        return qrCodeImgUrl;
    }

    public void setQrCodeImgUrl(String qrCodeImgUrl) {
        this.qrCodeImgUrl = qrCodeImgUrl;
    }


    public String getBenefitDeviceUrl() {
        return benefitDeviceUrl;
    }

    public void setBenefitDeviceUrl(String benefitDeviceUrl) {
        this.benefitDeviceUrl = benefitDeviceUrl;
    }

    public String getDeviceAbnormalImgUrl() {
        return deviceAbnormalImgUrl;
    }

    public void setDeviceAbnormalImgUrl(String deviceAbnormalImgUrl) {
        this.deviceAbnormalImgUrl = deviceAbnormalImgUrl;
    }

    public String getAdPhotoUrl() {
        return adPhotoUrl;
    }

    public void setAdPhotoUrl(String adPhotoUrl) {
        this.adPhotoUrl = adPhotoUrl;
    }

    public String getLeafTaskImgUrl() {
        return leafTaskImgUrl;
    }

    public void setLeafTaskImgUrl(String leafTaskImgUrl) {
        this.leafTaskImgUrl = leafTaskImgUrl;
    }

    public String getGuaranteeTaskAdUrl() {
        return guaranteeTaskAdUrl;
    }

    public void setGuaranteeTaskAdUrl(String guaranteeTaskAdUrl) {
        this.guaranteeTaskAdUrl = guaranteeTaskAdUrl;
    }

    public String getPushIconUrl() {
        return pushIconUrl;
    }

    public void setPushIconUrl(String pushIconUrl) {
        this.pushIconUrl = pushIconUrl;
    }

    public String getLeafHomeImgUrl() {
        return leafHomeImgUrl;
    }

    public void setLeafHomeImgUrl(String leafHomeImgUrl) {
        this.leafHomeImgUrl = leafHomeImgUrl;
    }

    public String getUserSubmitImgUrl() {
        return userSubmitImgUrl;
    }

    public void setUserSubmitImgUrl(String userSubmitImgUrl) {
        this.userSubmitImgUrl = userSubmitImgUrl;
    }

    public String getAdPlanDeviceFileUrl() {
        return adPlanDeviceFileUrl;
    }

    public void setAdPlanDeviceFileUrl(String adPlanDeviceFileUrl) {
        this.adPlanDeviceFileUrl = adPlanDeviceFileUrl;
    }

    public String getAdWithoutBiddingPriceFileUrl() {
        return adWithoutBiddingPriceFileUrl;
    }

    public void setAdWithoutBiddingPriceFileUrl(String adWithoutBiddingPriceFileUrl) {
        this.adWithoutBiddingPriceFileUrl = adWithoutBiddingPriceFileUrl;
    }

    public String getTempFileUrl() {
        return tempFileUrl;
    }

    public void setTempFileUrl(String tempFileUrl) {
        this.tempFileUrl = tempFileUrl;
    }

    public String getGzhQrcodeUrl() {
        return gzhQrcodeUrl;
    }

    public void setGzhQrcodeUrl(String gzhQrcodeUrl) {
        this.gzhQrcodeUrl = gzhQrcodeUrl;
    }

    public String getWeChatPersonalQrCodeUrl() {
        return weChatPersonalQrCodeUrl;
    }

    public void setWeChatPersonalQrCodeUrl(String weChatPersonalQrCodeUrl) {
        this.weChatPersonalQrCodeUrl = weChatPersonalQrCodeUrl;
    }

    public String getQqPersonalQrCodeUrl() {
        return qqPersonalQrCodeUrl;
    }

    public void setQqPersonalQrCodeUrl(String qqPersonalQrCodeUrl) {
        this.qqPersonalQrCodeUrl = qqPersonalQrCodeUrl;
    }

    public String getMediaUrl() {
        return mediaUrl;
    }

    public void setMediaUrl(String mediaUrl) {
        this.mediaUrl = mediaUrl;
    }

    public String getAdvertisingTargetInfoUrl() {
        return advertisingTargetInfoUrl;
    }

    public void setAdvertisingTargetInfoUrl(String advertisingTargetInfoUrl) {
        this.advertisingTargetInfoUrl = advertisingTargetInfoUrl;
    }
}
