package com.zjb.framework.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * 通用配置
 *
 * @author zjb
 */
@Configuration
public class ResourcesConfig implements WebMvcConfigurer {
    @Autowired
    ZjbConfig zjbConfig;

    /**
     * 首页地址
     */
    @Value("${shiro.user.indexUrl}")
    private String indexUrl;

    /**
     * 默认首页的设置，当输入域名是可以自动跳转到默认指定的网页
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("forward:" + indexUrl);
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        /** 头像上传路径 */
        registry.addResourceHandler("/profile/**").addResourceLocations("file:" + ZjbConfig.getProfile());
        /** 耗材订单付款凭证上传路径 */
        registry.addResourceHandler("/cm_paidevidence/**").addResourceLocations("file:" + zjbConfig.getEvidenceFolder());
        /** 提现申请打款上传路径 */
        registry.addResourceHandler("/remitevidence/**").addResourceLocations("file:" + zjbConfig.getRemitEvidenceFolder());
        /** 代理商营业执照文件上传路径 */
        registry.addResourceHandler("/agency/businesslicence/**").addResourceLocations("file:" + zjbConfig.getBusinessLicenceFolder());
        /** 代理商法人身份证文件上传路径 */
        registry.addResourceHandler("/agency/legalpersonidentitycard/**").addResourceLocations("file:" + zjbConfig.getLegalPersonIdentityCardFolder());
        /** 设备安装照片文件上传路径 */
        registry.addResourceHandler("/installphoto/**").addResourceLocations("file:" + zjbConfig.getInstallPhotoFolder());
        /** 跳转路由URL的图片的地址 */
        registry.addResourceHandler("/businessroute/**").addResourceLocations("file:" + zjbConfig.getBusinessRouteFolder());
        /** 设备二维码的图片的地址 */
        registry.addResourceHandler("/deviceqrcode/**").addResourceLocations("file:" + zjbConfig.getDeviceUrlFolder());
        /**qrcode图片地址*/
        registry.addResourceHandler("/qrCodeImgUrl/**").addResourceLocations("file:" + zjbConfig.getQrCodeImgUrl());
        /**扫码分成配置的设备xls文件的地址*/
        registry.addResourceHandler("/benefitDeviceUrl/**").addResourceLocations("file:" + zjbConfig.getBenefitDeviceUrl());
        /** 设备故障上报图片*/
        registry.addResourceHandler("/deviceAbnormalImgUrl/**").addResourceLocations("file:" + zjbConfig.getDeviceAbnormalImgUrl());
        /** 广告图片上传地址*/
        registry.addResourceHandler("adPhotoUrl/**").addResourceLocations("filr:" + zjbConfig.getAdPhotoUrl());
        /** 人工上架公众号二维码 */
        registry.addResourceHandler("gzhQrCodeUrl/**").addResourceLocations("filr:" + zjbConfig.getGzhQrcodeUrl());
        /** swagger配置 */
        registry.addResourceHandler("swagger-ui.html").addResourceLocations("classpath:/META-INF/resources/");
        registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
    }
}