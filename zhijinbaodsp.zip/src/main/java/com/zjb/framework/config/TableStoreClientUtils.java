package com.zjb.framework.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.alicloud.openservices.tablestore.SyncClient;
import com.zjb.common.constant.ZjbConstants;

/**
 * @author zjb
 */
@Component
public class TableStoreClientUtils implements ApplicationRunner {


    static final String endPoint = "https://zjb-device.cn-shanghai.ots.aliyuncs.com";
    static final String accessKeyId = "LTAI4FgKW8qnBBbf7ZNii4Vs";
    static final String accessKeySecret = "l84Wwnx8dlHYrkorVNitSozupnIwej";
    static final String instanceName = "zjb-command";

    /**
     * 表结构:      =====|device_name(主键1&分片键)|type(主键2)|date(主键3)|command(value)|==============
     */
    public static final String pk1 = "device_name";

    /**
     * 主键2键名  (命令类型 参考硬件接口文档)
     */
    public static final String pk2 = "type";
    /**
     * 主键3键名  (日期)
     */
    public static final String pk3 = "date";
    /**
     * 主键4键名  (命令详情)
     */
    public static final String value = "command";

    public static SyncClient client = null;

    public static SyncClient getClient() {

        if (client == null) {
            initialPool();
        }
        return client;
    }


    /**
     * 初始化
     */
    public static void initialPool() {

        client = new SyncClient(endPoint, accessKeyId, accessKeySecret, instanceName);
        if (client != null) {
            System.out.println("TableStore初始化成功------------client:" + client.toString());
        } else {
            System.out.println("TableStore初始化失败------------");
        }

    }


    @Override
    public void run(ApplicationArguments args) throws Exception {
        if (ZjbConstants.ZJB_CURRENT_EVN.equals("ONLINE") || ZjbConstants.ZJB_CURRENT_EVN.equals("PRERELEASE")) {
            TableStoreClientUtils.initialPool();
        }
    }

}