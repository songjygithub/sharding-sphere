package com.zjb.framework.config;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * @author songjy
 * @date 2019/09/26
 */
public class ShiroCache<K extends Serializable, V extends Serializable> implements Cache<K, V>, Serializable {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    private static final long serialVersionUID = -5632535907336637889L;

    /**
     * session超时时间(秒)，即12小时
     */
    public static int EXPIRE_SECONDS = 12 * 60 * 60;

    public static byte[] getByteKey(Serializable key) {

        if (key.getClass() == String.class) {
            return (ShiroConfig.PREFIX + key).getBytes(StandardCharsets.UTF_8);
        }

        return SerializationUtils.serialize(key);
    }

    @Override
    public V get(K k) throws CacheException {

        if (null == k) {
            return null;
        }

        JedisPool jedisPool = JedisPoolCacheUtils.getJedisPool();

        try (Jedis jedis = jedisPool.getResource()) {
            byte[] bytes = jedis.get(getByteKey(k));

            if (null == bytes) {
                return null;
            }

            return SerializationUtils.deserialize(bytes);
        }
    }

    @Override
    public V put(K k , V v) throws CacheException {

        try (Jedis jedis = JedisPoolCacheUtils.getJedisPool().getResource()) {
            byte[] key = getByteKey(k);
            jedis.set(key , SerializationUtils.serialize(v));
            jedis.expire(key , EXPIRE_SECONDS);
            byte[] value = jedis.get(SerializationUtils.serialize(key));

            if (null == value) {
                return null;
            }

            return SerializationUtils.deserialize(value);
        }

    }

    @Override
    public V remove(K k) throws CacheException {

        try (Jedis jedis = JedisPoolCacheUtils.getJedisPool().getResource()) {
            byte[] key = getByteKey(k);

            if (null == key) {
                return null;
            }

            String sessionID = new String(key);

            byte[] value = jedis.get(key);
            Long result = jedis.del(key);

            if (result > 0) {
                logger.warn("Shiro之SessionID【{}】删除成功" , sessionID);
            }

            if (null == value || 0 == value.length) {
                return null;
            }

            return SerializationUtils.deserialize(value);
        }
    }

    @Override
    public void clear() throws CacheException {

        Set<K> keys = keys();

        keys.forEach(e -> {
            try (Jedis jedis = JedisPoolCacheUtils.getJedisPool().getResource()) {
                byte[] key = getByteKey(e);
                if (null != key) {
                    jedis.del(key);
                }
            }
        });

        logger.warn("Shiro之Session清理完毕，总计：{}" , keys.size());
    }

    @Override
    public int size() {

        int size = keys().size();

        logger.warn("Shiro之Session缓存个数：{}" , size);

        return size;
    }

    @Override
    public Set<K> keys() {

        Set keys = new HashSet<>();

        try (Jedis jedis = JedisPoolCacheUtils.getJedisPool().getResource()) {
            Set<byte[]> set = jedis.keys((ShiroConfig.PREFIX + '*').getBytes(StandardCharsets.UTF_8));
            if (null == set || set.isEmpty()) {
                return keys;
            }

            for (byte[] bytes : set) {
                keys.add(new String(bytes));
            }
        }

        return keys;
    }

    @Override
    public Collection<V> values() {
        List<V> list = new ArrayList<>();
        Set<K> keys = keys();

        try (Jedis jedis = JedisPoolCacheUtils.getJedisPool().getResource()) {
            for (K key : keys) {
                byte[] bytes = jedis.get(getByteKey(key));
                if (null == bytes || 0 == bytes.length) {
                    continue;
                }
                list.add(SerializationUtils.deserialize(bytes));
            }
        }

        return list;
    }
}
