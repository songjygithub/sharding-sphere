package com.zjb.framework.config;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import com.zjb.common.constant.ZjbConstants;

/**
 * zjb项目相关初始化
 *
 * @author zjb
 */
@Component
@Order(value = 1)
public class ZjbInit implements ApplicationRunner {
   

    @Override
    public void run(ApplicationArguments args) throws Exception {
        if(ZjbConstants.ZJB_CURRENT_EVN.equals("TEST")){
            return;
        }
    }
}