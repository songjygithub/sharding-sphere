package com.zjb.framework.web.mgservice;

import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.util.IdUtil;
import cn.hutool.core.util.NetUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.bean.BeanUtils;
import org.bson.BsonArray;
import org.bson.BsonType;
import org.bson.BsonValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * @author zjb
 */
public abstract class BaseMongoDbServiceImpl<T> implements IMgBaseService<T> {
    private static final Logger logger = LoggerFactory.getLogger(BaseMongoDbServiceImpl.class);

    public static final String IP = NetUtil.getLocalhostStr();
    public static final long WORKER_ID = NetUtil.ipv4ToLong(IP) % 32;
    public static final long DATA_CENTER_ID = NetUtil.ipv4ToLong(IP) % 32;
    /**
     * 分布式自增主键
     */
    public static final Snowflake SNOWFLAKE = IdUtil.createSnowflake(WORKER_ID, DATA_CENTER_ID);

    protected abstract Class<T> getEntityClass();

    @Autowired
    protected MongoTemplate mongoTemplate;

    @Override
    public void save(T entity) {
        mongoTemplate.save(entity);
    }

    @Override
    public void update(T entity) {
        Map<String, Object> map = null;
        try {
            map = parseEntity(entity);
        } catch (Exception e) {
            logger.error("MgBaseServiceImpl update()异常：" + org.apache.commons.lang.exception.ExceptionUtils.getFullStackTrace(e));
        }
        String id = null;
        Object value = null;
        Update update = new Update();
        if (map != null && map.size() > 0) {
            for (String key : map.keySet()) {
                if (key.startsWith("{")) {
                    id = key.substring(key.indexOf("{") + 1, key.indexOf("}"));
                    value = map.get(key);
                } else {
                    update.set(key, map.get(key));
                }
            }
        }
        mongoTemplate.updateFirst(new Query().addCriteria(Criteria.where(id).is(value)), update, getEntityClass());
    }

    @Override
    public void delete(Serializable... ids) {
        if (ids != null && ids.length > 0) {
            for (Serializable id : ids) {
                mongoTemplate.remove(mongoTemplate.findById(id, getEntityClass()));
            }
        }
    }

    @Override
    public T find(Serializable id) {
        return mongoTemplate.findById(id, getEntityClass());
    }

    @Override
    public List<T> findAll() {
        return mongoTemplate.findAll(getEntityClass());
    }

    @SuppressWarnings("deprecation")
    @Override
    public List<T> findAll(String order) {
        List<Order> orderlist = parseOrder(order);
        if (orderlist == null || orderlist.size() == 0) {
            return findAll();
        }

        return mongoTemplate.find(new Query().with(Sort.by(orderlist)), getEntityClass());
    }

    @Override
    public List<T> findByProp(String propName, Object value) {
        return findByProp(propName, value, null);
    }

    @SuppressWarnings("deprecation")
    @Override
    public List<T> findByProp(String propName, Object value, String order) {
        Query query = new Query();
        query.addCriteria(Criteria.where(propName).is(value));
        List<Order> orderlist = parseOrder(order);
        if (orderlist != null && orderlist.size() > 0) {
            query.with(Sort.by(orderlist));
        }
        return null;
    }

    @Override
    public List<T> findByProps(String[] propName, Object[] values) {
        return findByProps(propName, values, null);
    }

    @Override
    public List<T> findByProps(String[] propName, Object[] values, String order) {
        Query query = createQuery(propName, values, order);
        return mongoTemplate.find(query, getEntityClass());
    }

    @Override
    public T uniqueByProp(String propName, Object value) {
        return mongoTemplate.findOne(new Query().addCriteria(Criteria.where(propName).is(value)), getEntityClass());
    }

    @Override
    public T uniqueByProps(String[] propName, Object[] values) {
        Query query = createQuery(propName, values, null);
        return mongoTemplate.findOne(query, getEntityClass());
    }

    @Override
    public int countByCondition(String[] params, Object[] values) {
        Query query = createQuery(params, values, null);
        Long count = mongoTemplate.count(query, getEntityClass());
        return count.intValue();
    }


    protected Map<String, Object> parseEntity(T t) throws Exception {
        Map<String, Object> map = new HashMap<>();
        String id = "";
        Field[] declaredFields = getEntityClass().getDeclaredFields();
        for (Field field : declaredFields) {
            if (field.isAnnotationPresent(Id.class)) {
                field.setAccessible(true);
                map.put("{" + field.getName() + "}", field.get(t));
                id = field.getName();
                break;
            }
        }

        Method[] declaredMethods = getEntityClass().getDeclaredMethods();
        if (declaredFields.length > 0) {
            for (Method method : declaredMethods) {
                if (method.getName().startsWith("get") && method.getModifiers() == Modifier.PUBLIC) {
                    String fieldName = parse2FieldName(method.getName());
                    if (!fieldName.equals(id)) {
                        map.put(fieldName, method.invoke(t));
                    }
                }
            }
        }
        return map;
    }

    private String parse2FieldName(String method) {
        String name = method.replace("get", "");
        name = name.substring(0, 1).toLowerCase() + name.substring(1);
        return name;
    }

    @SuppressWarnings("deprecation")
    public Query createQuery(String[] propName, Object[] values, String order) {
        Query query = new Query();
        //where
        if (propName != null && values != null) {
            for (int i = 0; i < propName.length; i++) {
                query.addCriteria(Criteria.where(propName[i]).is(values[i]));
            }
        }

        List<Order> orderlist = parseOrder(order);
        if (orderlist != null && orderlist.size() > 0) {
            query.with(Sort.by(orderlist));
        }
        return query;
    }

    public List<Order> parseOrder(String order) {
        List<Order> list = null;
        if (order != null && !"".equals(order)) {
            list = new ArrayList<>();
            String[] fields = order.split(",");
            Order o = null;
            String[] items = null;
            for (String field : fields) {
                if (field == null) {
                    continue;
                }
                items = field.split(" ");
                if (items.length == 1) {
                    o = new Order(Direction.ASC, items[0]);
                } else if (items.length == 2) {
                    o = new Order("desc".equalsIgnoreCase(items[1]) ? Direction.DESC : Direction.ASC, items[0]);
                } else {
                    throw new RuntimeException("order field parse error");
                }
                list.add(o);
            }
        }
        return list;
    }

    @Override
    public void updateByKey(Object entity, String primaryKeyProperty) {
        if (null == entity || StringUtils.isBlank(primaryKeyProperty)) {
            return;
        }

        Map<String, Field> allField = BeanUtils.getAllField(entity.getClass());

        if (!allField.containsKey(primaryKeyProperty)) {
            return;
        }

        Query query = new Query();
        Update update = new Update();

        try {
            for (Map.Entry<String, Field> entry : allField.entrySet()) {
                String name = entry.getKey();
                Field field = entry.getValue();
                Object value = BeanUtils.PROPERTY_UTILS_BEAN.getProperty(entity, name);
                if (null == value) {
                    continue;
                }

                if (null != field.getAnnotation(Transient.class)) {
                    continue;
                }

                if (name.equals(primaryKeyProperty)) {
                    query.addCriteria(Criteria.where(primaryKeyProperty).is(value));
                    Object obj = mongoTemplate.findOne(query, entity.getClass());
                    if (null == obj) {
                        return;
                    }
                } else {
                    update.set(name, value);
                }

            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            logger.error(e.getMessage(), e);
            return;
        }

        if (update.getUpdateObject().isEmpty()) {
            return;
        }

        mongoTemplate.updateFirst(query, update, entity.getClass());

    }

    /**
     * toInt
     *
     * @param bsonValue
     * @return
     */
    public static int toInt(BsonValue bsonValue) {

        if (null == bsonValue) {
            return 0;
        }

        switch (bsonValue.getBsonType()) {
            case INT32:
                return bsonValue.asInt32().getValue();
            case INT64:
                return bsonValue.asInt64().intValue();
            case DOUBLE:
                return bsonValue.asDouble().intValue();
            case DECIMAL128:
                return bsonValue.asDecimal128().intValue();
            default:
                logger.error("未处理的数据类型：{}", bsonValue.getBsonType());
                return 0;
        }

    }

    /**
     * toSetString
     *
     * @param bsonArray
     * @return
     */
    /**
     * toSetString
     *
     * @param bsonArray
     * @return
     */
    public static Set<String> toSetString(BsonArray bsonArray) {
        if (null == bsonArray || bsonArray.isEmpty()) {
            return Collections.emptySet();
        }

        Set<String> stringSet = new HashSet<>(bsonArray.size());

        for (BsonValue value : bsonArray) {

            if (null == value) {
                continue;
            }

            if (BsonType.NULL == value.getBsonType()) {
                continue;
            }

            if (BsonType.STRING != value.getBsonType()) {
                logger.error("数据{}类型非{}", value.getBsonType(), BsonType.STRING);
                continue;
            }

            if (StringUtils.isBlank(value.asString().getValue())) {
                continue;
            }

            stringSet.add(value.asString().getValue());
        }

        return stringSet;
    }
}
