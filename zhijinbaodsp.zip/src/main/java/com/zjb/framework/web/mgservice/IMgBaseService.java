package com.zjb.framework.web.mgservice;

import com.zjb.framework.web.page.TableDataInfo;
import org.springframework.data.domain.Pageable;

import java.io.Serializable;
import java.util.List;

/**
 * @author zjb
 */
public interface IMgBaseService<T> {

    ThreadLocal<Pageable> PAGEABLE_THREAD_LOCAL = new ThreadLocal<>();
    ThreadLocal<TableDataInfo> TABLE_DATA_INFO_THREAD_LOCAL = new ThreadLocal<>();

    void save(T entity);

    void update(T entity);

    void delete(Serializable... ids);

    T find(Serializable id);

    List<T> findAll();

    List<T> findAll(String order);

    List<T> findByProp(String propName, Object value);

    List<T> findByProp(String propName, Object value, String order);

    List<T> findByProps(String[] propName, Object[] values);

    List<T> findByProps(String[] propName, Object[] values, String order);

    T uniqueByProp(String propName, Object value);

    T uniqueByProps(String[] propName, Object[] values);

    int countByCondition(String[] params, Object[] values);

    void updateByKey(Object entity, String primaryKeyProperty);
}