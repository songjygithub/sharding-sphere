package com.zjb.framework.web.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.security.ShiroUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbDateEditor;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.PageDomain;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.page.TableSupport;
import com.zjb.project.dsp.advertisingADExchange.service.IAdExchangeService;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombinationUnit;
import com.zjb.project.dsp.advertisingCombination.service.IAdvertisingCombinationService;
import com.zjb.project.dsp.advertisingCombinationFans.service.IAdvertisingCombinationFansService;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationUnitWx;
import com.zjb.project.dsp.advertisingCombinationWx.service.IAdvertisingCombinationWxService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.service.IAdvertisingUnitWxService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.system.config.service.IConfigService;
import com.zjb.project.system.user.domain.User;
import com.zjb.project.system.user.service.IUserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.project.system.config.service.IConfigService.GUARANTEE_AD_PLAN_ID;

/**
 * web层通用数据处理
 *
 * @author zjb
 */
public class BaseController {
    private Logger logger = LoggerFactory.getLogger(BaseController.class);

    @Autowired
    protected IUserService userService;
    @Autowired
    protected IConfigService configService;
    @Autowired
    protected IAdvertisingPlanService advertisingPlanService;
    @Autowired
    protected IAdvertisingPlanFansService advertisingPlanFansService;
    @Autowired
    protected IAdvertisingCombinationService advertisingCombinationService;
    @Autowired
    protected IAdvertisingCombinationFansService advertisingCombinationFansService;
    @Autowired
    protected IAdvertisingCombinationWxService advertisingCombinationWxService;
    @Autowired
    protected IAdvertisingPlanWxService advertisingPlanWxService;
    @Autowired
    protected IAdvertisingUnitService advertisingUnitService;
    @Autowired
    protected IAdvertisingUnitWxService advertisingUnitWxService;
    @Autowired
    protected IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    protected IAdExchangeService adExchangeService;


    /**
     * 将前台传递过来的日期格式的字符串，自动转化为Date类型
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        dateFormat.setLenient(false);
        binder.registerCustomEditor(Date.class, new ZjbDateEditor(dateFormat, true));
    }

    /**
     * 设置请求分页数据
     */
    protected void startPage() {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();
        if (StringUtils.isNotNull(pageNum) && StringUtils.isNotNull(pageSize)) {
            String orderBy = pageDomain.getOrderBy();
            PageHelper.startPage(pageNum, pageSize, orderBy);
        }
    }

    protected void startPageForDiy() {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();
        if (StringUtils.isNotNull(pageNum) && StringUtils.isNotNull(pageSize)) {
            String orderBy = pageDomain.getOrderBy();
            if(StringUtils.isNotBlank(orderBy)){
                orderBy = "ta." + orderBy;
            }
            PageHelper.startPage(pageNum, pageSize, orderBy);
        }
    }

    /**
     * 响应请求分页数据
     */
    @SuppressWarnings({"rawtypes", "unchecked"})
    protected TableDataInfo getDataTable(List<?> list) {
        TableDataInfo rspData = new TableDataInfo();
        rspData.setCode(0);
        rspData.setRows(list);
        rspData.setTotal(new PageInfo(list).getTotal());
        return rspData;
    }

    /**
     * 响应返回结果
     *
     * @param rows 影响行数
     * @return 操作结果
     */
    protected AjaxResult toAjax(int rows) {
        return rows > 0 ? success() : error();
    }

    /**
     * 返回成功
     */
    public AjaxResult success() {
        return AjaxResult.success();
    }

    /**
     * 返回失败消息
     */
    public AjaxResult error() {
        return AjaxResult.error();
    }

    /**
     * 返回成功消息
     */
    public AjaxResult success(String message) {
        return AjaxResult.success(message);
    }

    public AjaxResult success(Object obj) {
        return AjaxResult.success(obj);
    }

    /**
     * 返回失败消息
     */
    public AjaxResult error(String message) {
        return AjaxResult.error(message);
    }

    /**
     * 返回错误码消息
     */
    public AjaxResult error(int code, String message) {
        return AjaxResult.error(code, message);
    }

    /**
     * 页面跳转
     */
    public String redirect(String url) {
        return StringUtils.format("redirect:{}", url);
    }

    public User getUser() {
        return ShiroUtils.getUser();
    }

    public void setUser(User user) {
        ShiroUtils.setUser(user);
    }

    public Long getUserId() {
        return getUser().getUserId();
    }

    public String getLoginName() {
        User user = getUser();
        if (user == null) {
            return "";
        } else {
            return user.getLoginName();
        }
    }

    public User getUser(long userId) {
        String key = ZjbConstantsRedis.REDIS_USER_INFO + userId;
        User userInfo = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_54, User.class);

        if (userInfo == null) {
            User userInfo_db = userService.selectUserById(userId);
            if (userInfo_db != null) {
                JedisPoolCacheUtils.setVExpire(key, userInfo_db, JedisPoolCacheUtils.EXRP_MONTH, ZjbConstantsRedis.ZJB_DB_54);

                return userInfo_db;
            }
        } else {
            return userInfo;
        }

        return null;
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param advertisingUnit
     */
    protected void restartAdvertisingPlan(AdvertisingUnit advertisingUnit) {

        if (!advertisingUnit.getAdSpaceIdentifier().equals(ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT.getValue())) {
            return;
        }

        List<AdvertisingCombinationUnit> list = advertisingCombinationService.selectByUnitId(advertisingUnit.getId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnit combinationUnit : list) {

            AdvertisingPlan advertisingPlan = new AdvertisingPlan();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());

            List<AdvertisingPlan> advertisingPlans = advertisingPlanService.selectAdvertisingPlanList(advertisingPlan);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlan plan : advertisingPlans) {

                String adAppIdOld = plan.getAdAppId();

                List<ComponentAuthorizationInfo> componentAuthorizationInfos = advertisingCombinationService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
                if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
                    plan.setWeChatOfficialAccounts(String.join(",", componentAuthorizationInfos.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
                    if (null == plan.getRadioWeChatOfficialAccount()
                            || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(plan.getRadioWeChatOfficialAccount())) {
                        plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue());
                    }
                    plan.setAdAppId(componentAuthorizationInfos.get(0).getAppId());
                    plan.setComponentAuthorizationType(componentAuthorizationInfos.get(0).getComponentAuthorizationType());
                } else {
                    plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue());
                    plan.setWeChatOfficialAccounts(null);
                    plan.setAdAppId(null);
                    plan.setComponentAuthorizationType(0);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanService.updateAdvertisingPlan(plan);

                if (!StringUtils.equals(adAppIdOld, plan.getAdAppId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanService.reloadPattern(plan.getPlanId());
                }

            }

        }
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param advertisingUnit
     */
    protected void restartAdvertisingPlanWx(AdvertisingUnitWx advertisingUnit) {

        if (!advertisingUnit.getAdSpaceIdentifier().equals(ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT_WX.getValue())) {
            return;
        }

        List<AdvertisingCombinationUnitWx> list = advertisingCombinationWxService.selectByUnitId(advertisingUnit.getId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitWx combinationUnit : list) {

            AdvertisingPlanWx advertisingPlan = new AdvertisingPlanWx();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());

            List<AdvertisingPlanWx> advertisingPlans = advertisingPlanWxService.selectAdvertisingPlanWxList(advertisingPlan);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlanWx plan : advertisingPlans) {

                String adAppIdOld = plan.getAdAppId();

                List<ComponentAuthorizationInfo> componentAuthorizationInfos = advertisingCombinationWxService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
                if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
                    plan.setWeChatOfficialAccounts(String.join(",", componentAuthorizationInfos.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
                    if (null == plan.getRadioWeChatOfficialAccount()
                            || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(plan.getRadioWeChatOfficialAccount())) {
                        plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue());
                    }
                    plan.setAdAppId(componentAuthorizationInfos.get(0).getAppId());
                    plan.setComponentAuthorizationType(componentAuthorizationInfos.get(0).getComponentAuthorizationType());
                } else {
                    plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue());
                    plan.setWeChatOfficialAccounts(null);
                    plan.setAdAppId(null);
                    plan.setComponentAuthorizationType(0);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanWxService.updateAdvertisingPlanWx(plan);

                if (!StringUtils.equals(adAppIdOld, plan.getAdAppId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanService.reloadPattern(plan.getPlanId());
                }

            }

        }
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param advertisingUnit
     */
    protected void restartAdvertisingPlanFans(AdvertisingUnitFans advertisingUnit) {

        if (null == advertisingUnit) {
            logger.error("广告单元对象为空");
            return;
        }

        if (!advertisingUnit.getAdSpaceIdentifier().equals(AD_FANS_PAPER_OUTPUT.getValue())) {
            return;
        }

        List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansService.selectByUnitId(advertisingUnit.getId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitFans combinationUnit : list) {

            AdvertisingPlanFans planFans = new AdvertisingPlanFans();
            planFans.setCombinationId(combinationUnit.getCombinationId());
            planFans.setDeleted(NO.getValue());

            List<AdvertisingPlanFans> advertisingPlans = advertisingPlanFansService.selectAdvertisingPlanFansList(planFans);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlanFans plan : advertisingPlans) {

                /*广告单元关联的微信公众号发生变化时的处理*/
                weChatOfficialAccountOnchange(combinationUnit.getCombinationId(), plan);
                /*广告单元关联的微信个人号发生变化时的处理*/
                weChatPersonalOnchange(combinationUnit.getCombinationId(), plan);
                /*广告单元关联的QQ个人号发生变化时的处理*/
                qqPersonalOnchange(combinationUnit.getCombinationId(), plan);

            }

        }
    }

    /**
     * 广告单元关联的QQ个人号发生变化时的处理
     *
     * @param combinationId 广告计划方案
     * @param plan
     */
    private void qqPersonalOnchange(Integer combinationId, AdvertisingPlanFans plan) {
        String oldQqPersonalId = plan.getQqPersonalId();

        List<QqPersonal> list = advertisingCombinationFansService.isQQPersonalAccountOnSpacePaperOutput(combinationId);
        if (null != list && !list.isEmpty()) {
            plan.setQqPersonalId(list.get(0).getPersonalId());
        } else {
            plan.setQqPersonalId(null);
        }

        plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
        advertisingPlanFansService.updateAdvertisingPlanFans(plan);

        if (!StringUtils.equals(oldQqPersonalId, plan.getQqPersonalId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            advertisingPlanFansService.clearLocalCacheRegex(plan.getPlanId());
            advertisingPlanFansService.reloadPattern(plan.getPlanId());
            logger.info("广告单元QQ个人号从{}更改为{}，计划{}重新载入投放", oldQqPersonalId, plan.getQqPersonalId(), plan.getPlanId());
        }
    }

    /**
     * 广告单元关联的微信个人号发生变化时的处理
     *
     * @param combinationId 广告计划方案
     * @param plan
     */
    private void weChatPersonalOnchange(Integer combinationId, AdvertisingPlanFans plan) {
        String oldWeChatPersonalId = plan.getWeChatPersonalId();

        List<WeChatPersonal> list = advertisingCombinationFansService.isWeChatPersonalAccountOnSpacePaperOutput(combinationId);
        if (null != list && !list.isEmpty()) {
            plan.setWeChatPersonalId(list.get(0).getPersonalId());
        } else {
            plan.setWeChatPersonalId(null);
        }

        plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
        advertisingPlanFansService.updateAdvertisingPlanFans(plan);

        if (!StringUtils.equals(oldWeChatPersonalId, plan.getWeChatPersonalId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            advertisingPlanFansService.clearLocalCacheRegex(plan.getPlanId());
            advertisingPlanFansService.reloadPattern(plan.getPlanId());
            logger.info("广告单元微信个人号从{}更改为{}，计划{}重新载入投放", oldWeChatPersonalId, plan.getWeChatPersonalId(), plan.getPlanId());
        }
    }

    /**
     * 广告单元关联的微信公众号发生变化时的处理
     *
     * @param combinationId 广告计划方案
     * @param plan
     */
    private void weChatOfficialAccountOnchange(Integer combinationId, AdvertisingPlanFans plan) {
        String adAppIdOld = plan.getAdAppId();

        List<ComponentAuthorizationInfo> componentAuthorizationInfos = advertisingCombinationFansService.isWeChatOfficialAccountOnSpacePaperOutput(combinationId);
        if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
            plan.setWeChatOfficialAccounts(String.join(",", componentAuthorizationInfos.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == plan.getRadioWeChatOfficialAccount()
                    || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(plan.getRadioWeChatOfficialAccount())) {
                plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue());
            }
            plan.setAdAppId(componentAuthorizationInfos.get(0).getAppId());
            plan.setComponentAuthorizationType(componentAuthorizationInfos.get(0).getComponentAuthorizationType());
        } else {
            plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue());
            plan.setWeChatOfficialAccounts(null);
            plan.setAdAppId(null);
            plan.setComponentAuthorizationType(0);
        }

        plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
        advertisingPlanFansService.updateAdvertisingPlanFans(plan);

        if (!StringUtils.equals(adAppIdOld, plan.getAdAppId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            advertisingPlanFansService.clearLocalCacheRegex(plan.getPlanId());
            advertisingPlanFansService.reloadPattern(plan.getPlanId());
            logger.info("广告单元微信公众号号从{}更改为{}，计划{}重新载入投放", adAppIdOld, plan.getAdAppId(), plan.getPlanId());
        }
    }

    /**
     * 涉及的投放广告计划重启：微信个人号更换
     *
     * @param advertisingUnit
     */
    protected void restartAdvertisingPlanFansWithWeChatPersonal(AdvertisingUnitFans advertisingUnit) {

        if (!advertisingUnit.getAdSpaceIdentifier().equals(AD_FANS_PAPER_OUTPUT.getValue())) {
            return;
        }

        List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansService.selectByUnitId(advertisingUnit.getId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitFans combinationUnit : list) {

            AdvertisingPlanFans planFans = new AdvertisingPlanFans();
            planFans.setCombinationId(combinationUnit.getCombinationId());
            planFans.setDeleted(NO.getValue());

            List<AdvertisingPlanFans> advertisingPlans = advertisingPlanFansService.selectAdvertisingPlanFansList(planFans);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlanFans plan : advertisingPlans) {

                String oldWeChatPersonalId = plan.getWeChatPersonalId();

                List<WeChatPersonal> componentAuthorizationInfos = advertisingCombinationFansService.isWeChatPersonalAccountOnSpacePaperOutput(planFans.getCombinationId());
                if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
                    plan.setWeChatPersonalId(componentAuthorizationInfos.get(0).getPersonalId());
                } else {
                    plan.setWeChatPersonalId(null);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanFansService.updateAdvertisingPlanFans(plan);

                if (!StringUtils.equals(oldWeChatPersonalId, plan.getWeChatPersonalId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanFansService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanFansService.reloadPattern(plan.getPlanId());
                    logger.info("广告单元微信个人号从{}更改为{}，计划{}重新载入投放", oldWeChatPersonalId, plan.getWeChatPersonalId(), plan.getPlanId());
                }

            }

        }
    }

    /**
     * 涉及的投放广告计划重启：QQ个人号更换
     *
     * @param advertisingUnit
     */
    protected void restartAdvertisingPlanFansWithQQPersonal(AdvertisingUnitFans advertisingUnit) {

        if (!advertisingUnit.getAdSpaceIdentifier().equals(AD_FANS_PAPER_OUTPUT.getValue())) {
            return;
        }

        List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansService.selectByUnitId(advertisingUnit.getId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitFans combinationUnit : list) {

            AdvertisingPlanFans planFans = new AdvertisingPlanFans();
            planFans.setCombinationId(combinationUnit.getCombinationId());
            planFans.setDeleted(NO.getValue());

            List<AdvertisingPlanFans> advertisingPlans = advertisingPlanFansService.selectAdvertisingPlanFansList(planFans);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlanFans plan : advertisingPlans) {

                String oldQqPersonalId = plan.getQqPersonalId();

                List<QqPersonal> QqPersonal = advertisingCombinationFansService.isQQPersonalAccountOnSpacePaperOutput(planFans.getCombinationId());
                if (null != QqPersonal && !QqPersonal.isEmpty()) {
                    plan.setQqPersonalId(QqPersonal.get(0).getPersonalId());
                } else {
                    plan.setQqPersonalId(null);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanFansService.updateAdvertisingPlanFans(plan);

                if (!StringUtils.equals(oldQqPersonalId, plan.getQqPersonalId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanFansService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanFansService.reloadPattern(plan.getPlanId());
                    logger.info("广告单元QQ个人号从{}更改为{}，计划{}重新载入投放", oldQqPersonalId, plan.getQqPersonalId(), plan.getPlanId());
                }

            }

        }
    }

    /**
     * 保底广告计划
     *
     * @param randomNum 用户扫码流水号
     * @return
     */
    protected AdvertisingPlan guaranteePlan(String randomNum) {
        /*保底广告*/
        int index = ThreadLocalRandom.current().nextInt(GUARANTEE_AD_PLAN_ID.size());
        String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + GUARANTEE_AD_PLAN_ID.get(index);
        AdvertisingPlan win = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
        win.setRandomNum(randomNum);
        /*设置域名*/
        adExchangeService.setDomainAddress(win);
        return win;
    }
}
