package com.zjb.framework.web.exception;


import com.zjb.common.constant.ZjbConstants;
import com.zjb.project.system.dict.service.IDictDataService;
import com.zjb.project.system.exceptionInfo.domain.ExceptionInfo;
import com.zjb.project.system.exceptionInfo.service.IExceptionInfoService;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.shiro.authz.AuthorizationException;
import org.apache.shiro.web.util.WebUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.zjb.common.exception.DemoModeException;
import com.zjb.framework.web.domain.AjaxResult;
import org.thymeleaf.exceptions.TemplateInputException;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Date;
import java.util.UUID;

/**
 * 自定义异常处理器
 *
 * @author zjb
 */
@RestControllerAdvice
public class DefaultExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(DefaultExceptionHandler.class);

    @Autowired
    private IExceptionInfoService exceptionInfoService;
    @Autowired
    private IDictDataService dictDataService;
    @Autowired(required = false)
    private HttpServletRequest request;
    /**
     * 强制退出后重定向的地址
     */
    @Value("${shiro.user.unauthorizedUrl}")
    private String loginUrl;

    /**
     * 权限校验失败
     */
    @ExceptionHandler(AuthorizationException.class)
    public AjaxResult handleAuthorizationException(AuthorizationException e , ServletRequest request , ServletResponse response) throws IOException {
        //logger.error("handleAuthorizationException：" + org.apache.commons.lang.exception.ExceptionUtils.getFullStackTrace(e));
        logger.warn("登陆超时或权限不足：{}" , e.getMessage());

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(401);
        exception.setExceptionType("权限校验异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "401");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);
        WebUtils.issueRedirect(request , response , loginUrl);

        return AjaxResult.error("权限校验异常.错误编号:" + uuid);
    }

    /**
     * 请求方式不支持
     */
    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    public AjaxResult handleException(HttpRequestMethodNotSupportedException e) {
        logger.error("handleException：" + request.getRequestURL() + System.lineSeparator() + e.getMessage() , e);

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(400);
        exception.setExceptionType("请求方式异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "400");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);

        return AjaxResult.error("服务器错误，请联系管理员.错误编号:" + uuid);
    }

    /**
     * sql 异常
     */
    @ExceptionHandler(SQLException.class)
    public AjaxResult sqlException(SQLException e) {
        logger.error("sqlException：" + request.getRequestURL() + System.lineSeparator() + e.getMessage() , e);

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(501);
        exception.setExceptionType("SQL异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "501");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);
        return AjaxResult.error("服务器错误，请联系管理员.错误编号:" + uuid);
    }

    /**
     * thymeleaf 异常
     */
    @ExceptionHandler(TemplateInputException.class)
    public AjaxResult templateInputException(TemplateInputException e) {
        logger.error("templateInputException：" + request.getRequestURL() + System.lineSeparator() + e.getMessage() , e);

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(100);
        exception.setExceptionType("thymeleaf异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "100");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);
        return AjaxResult.error("服务器错误，请联系管理员.错误编号:" + uuid);
    }


    /**
     * 拦截未知的运行时异常
     */
    @ExceptionHandler(RuntimeException.class)
    public AjaxResult notFount(RuntimeException e) {
        logger.error("notFount：" + request.getRequestURL() + System.lineSeparator() + e.getMessage() , e);

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(500);
        exception.setExceptionType("运行时异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "500");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);
        return AjaxResult.error("服务器错误，请联系管理员.错误编号:" + uuid);
    }

    /**
     * 系统异常
     */
    @ExceptionHandler(Exception.class)
    public AjaxResult handleException(Exception e) {
        logger.error(request.getRequestURL() + System.lineSeparator() + e.getMessage() , e);

        ExceptionInfo exception = new ExceptionInfo();
        exception.setCreateTime(new Date());
        exception.setExceptionMessage(e.getMessage());
        exception.setExceptionCode(101);
        exception.setExceptionType("系统异常");
        exception.setExceptionStackTrace(ExceptionUtils.getFullStackTrace(e));
        String uuid = UUID.randomUUID().toString().replace("-" , "");
        exception.setNumbering(uuid);
        String status = dictDataService.selectDictStatus(ZjbConstants.ZJB_EXCEPTION_INFO , "101");
        if (StringUtils.isNotEmpty(status)) {
            exception.setStatus(Integer.parseInt(status));
        }
        exceptionInfoService.insertExceptionInfo(exception);
        return AjaxResult.error("服务器错误，请联系管理员.错误编号:" + uuid);
    }

    /**
     * 演示模式异常
     */
    @ExceptionHandler(DemoModeException.class)
    public AjaxResult demoModeException(DemoModeException e) {
        return AjaxResult.error("演示模式，不允许操作");
    }

}
