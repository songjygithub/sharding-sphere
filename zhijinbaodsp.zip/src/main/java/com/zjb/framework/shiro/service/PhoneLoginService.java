package com.zjb.framework.shiro.service;

import com.zjb.common.constant.*;
import com.zjb.common.exception.user.*;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.MessageUtils;
import com.zjb.common.utils.security.ShiroUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.framework.manager.factory.AsyncFactory;
import com.zjb.project.system.user.domain.User;
import com.zjb.project.system.user.domain.UserStatus;
import com.zjb.project.system.user.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * 手机验证码登录校验方法
 * 
 * @author zjb
 */
@Component
public class PhoneLoginService{

    @Autowired
    private IUserService userService;

    /**
     * 登录
     */
    public User login(String phone, String captcha)
    {

        //获取当前手机短信验证码
        String redis_captcha = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.SMS_LOGIN + "_captcha_" + phone, ZjbConstantsRedis.ZJB_DB_53);

        // 密码如果不在指定范围内 错误
        if (!captcha.equals(redis_captcha))
        {
            AsyncManager.me().execute(AsyncFactory.recordLogininfor(phone, Constants.LOGIN_FAIL, MessageUtils.message("user.captcha.error")));
            throw new PhoneCaptcheNotMatchException();
        }


        // 查询用户信息
        User user = userService.selectUserByPhoneNumber(phone);

        if (user == null || UserStatus.DELETED.getCode().equals(user.getDelFlag()))
        {
            AsyncManager.me().execute(AsyncFactory.recordLogininfor(phone, Constants.LOGIN_FAIL, MessageUtils.message("user.not.exists")));
            throw new UserNotExistsException();
        }


        if (UserStatus.DISABLE.getCode().equals(user.getStatus()))
        {
            AsyncManager.me().execute(AsyncFactory.recordLogininfor(phone, Constants.LOGIN_FAIL, MessageUtils.message("user.blocked", user.getRemark())));
            throw new UserBlockedException(user.getRemark());
        }
        AsyncManager.me().execute(AsyncFactory.recordLogininfor(phone, Constants.LOGIN_SUCCESS, MessageUtils.message("user.login.success")));
        recordLoginInfo(user);
        return user;
    }


    /**
     * 记录登录信息
     */
    public void recordLoginInfo(User user)
    {
        user.setLoginIp(ShiroUtils.getIp());
        user.setLoginDate(DateUtils.getNowDate());
        userService.updateUserInfo(user);
    }

}
