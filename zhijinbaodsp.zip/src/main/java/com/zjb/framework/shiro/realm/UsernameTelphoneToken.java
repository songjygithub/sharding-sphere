package com.zjb.framework.shiro.realm;

import org.apache.shiro.authc.UsernamePasswordToken;

public class UsernameTelphoneToken extends UsernamePasswordToken {

	private static final long serialVersionUID = 7889723705369307449L;
	
	// 手机号码
    private String telphoneNum;
    // 验证码
    private String captcha;


    /**
     * 重写getPrincipal方法
     */
    @Override
    public Object getPrincipal() {

        // 如果获取到用户名，则返回用户名，否则返回电话号码
        if (telphoneNum == null) {
            return getUsername();
        } else {
            return getTelphoneNum();
        }
    }

    /**
     * 重写getCredentials方法
     */
    @Override
    public Object getCredentials() {

        // 如果获取到密码，则返回密码，否则返回null
        if (telphoneNum == null) {
            return getPassword();
        } else {
            return getCaptcha();
        }
    }

    public UsernameTelphoneToken() {
        // TODO Auto-generated constructor stub
    }

    public UsernameTelphoneToken(final String telphoneNum,final String captcha) {
        // TODO Auto-generated constructor stub
        this.telphoneNum = telphoneNum;
        this.captcha = captcha ;
    }

//    public UsernameTelphoneToken(final String userName, final String password) {
//        // TODO Auto-generated constructor stub
//        super(userName, password);
//    }
    public UsernameTelphoneToken(final String userName, final String password, final boolean rememberMe) {
        // TODO Auto-generated constructor stub
        super(userName, password,rememberMe);
    }

    public String getTelphoneNum() {
        return telphoneNum;
    }

    public void setTelphoneNum(String telphoneNum) {
        this.telphoneNum = telphoneNum;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    @Override
    public String toString() {
        return "TelphoneToken [telphoneNum=" + telphoneNum + "]";
    }

}
