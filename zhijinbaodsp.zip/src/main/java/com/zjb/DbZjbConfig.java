package com.zjb;

import com.alibaba.druid.pool.DruidDataSource;
import com.zjb.common.constant.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * @author songjy
 * @date 2019/07/19
 */
@Configuration
public class DbZjbConfig {
    @Autowired
    private Environment environment;

    @Bean(value = Constants.DB_ZJB_ID)
    public JdbcTemplate lisJdbcTemplate() {
        DruidDataSource dataSource = new DruidDataSource();

        dataSource.setUsername(environment.getProperty("db.zjb.username"));
        dataSource.setPassword(environment.getProperty("db.zjb.password"));
        dataSource.setUrl(environment.getProperty("db.zjb.url"));
        dataSource.setDriverClassName(environment.getProperty("db.zjb.driverClass"));
        dataSource.setMaxWait(12L * 1000L);
        dataSource.setDefaultAutoCommit(true);

        return new JdbcTemplate(dataSource);
    }
}