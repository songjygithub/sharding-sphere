package com.zjb;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.zjb.common.enums.ZjbConfigEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.system.config.service.IConfigService;

/**
 * @author songjy
 * @date 2019/08/03
 */
@Configuration
public class CorsConfig implements WebMvcConfigurer {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IConfigService configService;

    @Override
    public void addCorsMappings(CorsRegistry registry) {

        String allowedOrigins = configService.selectConfigByKey(ZjbConfigEnum.ZJB_CORS_ALLOWED_ORIGINS.getKey());
        String[] arr = StringUtils.split(allowedOrigins , ',');

        logger.warn("允许跨域的域名：{}" , Arrays.deepToString(arr));

        registry.addMapping("/**")
                .allowedOrigins(arr)
                .allowCredentials(true)
                .allowedMethods("POST" , "GET")
                .maxAge(3600);
    }

}
