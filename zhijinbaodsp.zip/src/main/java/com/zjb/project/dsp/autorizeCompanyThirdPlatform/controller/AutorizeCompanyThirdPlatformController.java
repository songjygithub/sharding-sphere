package com.zjb.project.dsp.autorizeCompanyThirdPlatform.controller;

import java.util.List;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.domain.AutorizeCompanyThirdPlatform;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.service.IAutorizeCompanyThirdPlatformService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 授权公司第三方平台 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-03-05
 */
@Controller
@RequestMapping("/dsp/autorizeCompanyThirdPlatform")
public class AutorizeCompanyThirdPlatformController extends BaseController
{
    private String prefix = "dsp/autorizeCompanyThirdPlatform";
	
	@Autowired
	private IAutorizeCompanyThirdPlatformService autorizeCompanyThirdPlatformService;
	
	@RequiresPermissions("dsp:autorizeCompanyThirdPlatform:view")
	@GetMapping()
	public String autorizeCompanyThirdPlatform()
	{
	    return prefix + "/autorizeCompanyThirdPlatform";
	}
	
	/**
	 * 查询授权公司第三方平台列表
	 */
	@RequiresPermissions("dsp:autorizeCompanyThirdPlatform:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{
		startPage();
        List<AutorizeCompanyThirdPlatform> list = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformList(autorizeCompanyThirdPlatform);
		return getDataTable(list);
	}
	
	/**
	 * 新增授权公司第三方平台
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存授权公司第三方平台
	 */
	@RequiresPermissions("dsp:autorizeCompanyThirdPlatform:add")
	@Log(title = "授权公司第三方平台", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{		
		return toAjax(autorizeCompanyThirdPlatformService.insertAutorizeCompanyThirdPlatform(autorizeCompanyThirdPlatform));
	}

	/**
	 * 修改授权公司第三方平台
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformById(id);
		mmap.put("autorizeCompanyThirdPlatform", autorizeCompanyThirdPlatform);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存授权公司第三方平台
	 */
	@RequiresPermissions("dsp:autorizeCompanyThirdPlatform:edit")
	@Log(title = "授权公司第三方平台", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{		
		return toAjax(autorizeCompanyThirdPlatformService.updateAutorizeCompanyThirdPlatform(autorizeCompanyThirdPlatform));
	}
	
	/**
	 * 删除授权公司第三方平台
	 */
	@RequiresPermissions("dsp:autorizeCompanyThirdPlatform:remove")
	@Log(title = "授权公司第三方平台", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(autorizeCompanyThirdPlatformService.deleteAutorizeCompanyThirdPlatformByIds(ids));
	}

	/**
	 * 根据公司主体下第三方平台APPID获取APPSECRET
	 * @param autorizeCompanyThirdPlatform
	 * @return
	 */
	@PostMapping("/getThirdPlatformAppSecretByAppId")
	@ResponseBody
	public String getThirdPlatformAppSecretByAppId(@RequestBody AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform){
		if(null == autorizeCompanyThirdPlatform || StringUtils.isEmpty(autorizeCompanyThirdPlatform.getAppId())){
			return null;
		}
		AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform1 = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformByAppId(autorizeCompanyThirdPlatform.getAppId());
		if(autorizeCompanyThirdPlatform1 == null || StringUtils.isEmpty(autorizeCompanyThirdPlatform1.getAppSecret())){
			return null;
		}else{
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.GZH_AUTORIZE_COMPANY_THIRD_PLATOFRM_SECRET + "_" + autorizeCompanyThirdPlatform.getAppId(), autorizeCompanyThirdPlatform1.getAppSecret(), JedisPoolCacheUtils.EXRP_MONTH, ZjbConstantsRedis.ZJB_DB_6);
		}
		return autorizeCompanyThirdPlatform1.getAppSecret();
	}
	
}
