package com.zjb.project.dsp.blackPersonalAccountTemporary.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
												import java.util.Date;

/**
 * 个人号黑名单临时表 zjb_black_personal_account_temporary
 * 
 * @author jiangbingjie
 * @date 2020-05-08
 */
public class BlackPersonalAccountTemporary extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 自增主键 */
	private Integer id;
	/** 个人号唯一标识 */
	private String personalAppId;
	/** 个人号名称 */
	private String personalNickName;
	/** 个人号来源通道(参考字典) */
	private String personalSourceType;
	/** 用户扫码流水号，多个之间用英文逗号分隔 */
	private String randomNums;
	/** 加入黑名单类型（1:人数，2:次数） */
	private Integer joinBlackType;
	/**结束时间 非数据库映射字段*/
	private String createTimeEnd;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setPersonalAppId(String personalAppId) 
	{
		this.personalAppId = personalAppId;
	}

	public String getPersonalAppId() 
	{
		return personalAppId;
	}
	public void setPersonalNickName(String personalNickName) 
	{
		this.personalNickName = personalNickName;
	}

	public String getPersonalNickName() 
	{
		return personalNickName;
	}
	public void setPersonalSourceType(String personalSourceType) 
	{
		this.personalSourceType = personalSourceType;
	}

	public String getPersonalSourceType() 
	{
		return personalSourceType;
	}
	public void setRandomNums(String randomNums) 
	{
		this.randomNums = randomNums;
	}

	public String getRandomNums() 
	{
		return randomNums;
	}
	public void setJoinBlackType(Integer joinBlackType) 
	{
		this.joinBlackType = joinBlackType;
	}

	public Integer getJoinBlackType() 
	{
		return joinBlackType;
	}

	public String getCreateTimeEnd() {
		return createTimeEnd;
	}

	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}

	public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("personalAppId", getPersonalAppId())
            .append("personalNickName", getPersonalNickName())
            .append("personalSourceType", getPersonalSourceType())
            .append("randomNums", getRandomNums())
            .append("createTime", getCreateTime())
            .append("joinBlackType", getJoinBlackType())
            .append("gmtCreated", getGmtCreated())
            .append("createrId", getCreaterId())
            .append("gmtModified", getGmtModified())
            .append("modifierId", getModifierId())
            .append("deleted", getDeleted())
            .toString();
    }
}
