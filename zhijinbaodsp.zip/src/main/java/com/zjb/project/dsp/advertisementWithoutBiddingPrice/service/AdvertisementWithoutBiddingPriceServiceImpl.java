package com.zjb.project.dsp.advertisementWithoutBiddingPrice.service;

import java.util.List;

import com.github.pagehelper.util.StringUtil;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import com.zjb.project.dsp.advertisementPlanDevice.service.IAdvertisementPlanDeviceService;
import com.zjb.project.dsp.advertisingADExchange.domain.WithoutBiddingAd;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.mapper.AdvertisementWithoutBiddingPriceMapper;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.AdvertisementWithoutBiddingPrice;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.service.IAdvertisementWithoutBiddingPriceService;
import com.zjb.common.support.Convert;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 非竞价广告投放 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-03-30
 */
@Service
public class AdvertisementWithoutBiddingPriceServiceImpl implements IAdvertisementWithoutBiddingPriceService 
{
	@Autowired
	private AdvertisementWithoutBiddingPriceMapper advertisementWithoutBiddingPriceMapper;
	@Autowired
	private IAdvertisementPlanDeviceService iAdvertisementPlanDeviceService;

	/**
     * 查询非竞价广告投放信息
     * 
     * @param id 非竞价广告投放ID
     * @return 非竞价广告投放信息
     */
    @Override
	public AdvertisementWithoutBiddingPrice selectAdvertisementWithoutBiddingPriceById(Integer id)
	{
	    return advertisementWithoutBiddingPriceMapper.selectAdvertisementWithoutBiddingPriceById(id);
	}
	
	/**
     * 查询非竞价广告投放列表
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 非竞价广告投放集合
     */
	@Override
	public List<AdvertisementWithoutBiddingPrice> selectAdvertisementWithoutBiddingPriceList(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
	    return advertisementWithoutBiddingPriceMapper.selectAdvertisementWithoutBiddingPriceList(advertisementWithoutBiddingPrice);
	}
	
    /**
     * 新增非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	@Override
	public int insertAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{

		int i = advertisementWithoutBiddingPriceMapper.insertAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice);

		/*设备定向信息存储*/
		AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
		advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
		//advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
		List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
		if(CollectionUtils.isNotEmpty(advertisementPlanDevices) || advertisementPlanDevices.size() > 0){
			BeanUtils.copyProperties(advertisementWithoutBiddingPrice, advertisementPlanDevice);
			advertisementPlanDevice.setId(advertisementPlanDevices.get(0).getId());
			advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
			advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
			if(AD_RADIO_DEVICE_SN_ALL.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
				advertisementPlanDevice.setDeviceSn("");
			}
			int r = iAdvertisementPlanDeviceService.updateAdvertisementPlanDevice(advertisementPlanDevice);
		}else {
			BeanUtils.copyProperties(advertisementWithoutBiddingPrice, advertisementPlanDevice);
			advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
			advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
			advertisementPlanDevice.setId(null);
			int r = iAdvertisementPlanDeviceService.insertAdvertisementPlanDevice(advertisementPlanDevice);
		}
		return i;
	}
	
	/**
     * 修改非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	@Override
	public int updateAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
		/*设备定向信息存储*/
		AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
		advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
		//advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
		List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
		if(CollectionUtils.isNotEmpty(advertisementPlanDevices) || advertisementPlanDevices.size() > 0){
			BeanUtils.copyProperties(advertisementWithoutBiddingPrice, advertisementPlanDevice);
			advertisementPlanDevice.setId(advertisementPlanDevices.get(0).getId());
			advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
			advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
			if(AD_RADIO_DEVICE_SN_ALL.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
				advertisementPlanDevice.setDeviceSn("");
			}
			int r = iAdvertisementPlanDeviceService.updateAdvertisementPlanDevice(advertisementPlanDevice);
		}else {
			BeanUtils.copyProperties(advertisementWithoutBiddingPrice, advertisementPlanDevice);
			advertisementPlanDevice.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
			advertisementPlanDevice.setId(null);
			int r = iAdvertisementPlanDeviceService.insertAdvertisementPlanDevice(advertisementPlanDevice);
		}

	    return advertisementWithoutBiddingPriceMapper.updateAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice);
	}

	/**
     * 删除非竞价广告投放对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisementWithoutBiddingPriceByIds(String ids)
	{
		int i = advertisementWithoutBiddingPriceMapper.logicDeleteAdvertisementWithoutBiddingPriceByIds(Convert.toStrArray(ids));

		iAdvertisementPlanDeviceService.deleteAdvertisementPlanDeviceByAdvertisementPlanIds(Convert.toStrArray(ids));
		return i;
	}

	/**
	 * 暂停非竞价广告投放
	 * @param ids
	 * @param userId
	 * @return
	 */
	@Override
	public int stopAdvertisementWithoutBiddingPrice(String ids, Integer userId) {
		if(StringUtils.isEmpty(ids)){
			return 0;
		}
		String[] idArray = Convert.toStrArray(ids);
		if(idArray != null && idArray.length>0){
			for(String id : idArray){
				if(StringUtils.isNotEmpty(id)){
					AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice = advertisementWithoutBiddingPriceMapper.selectAdvertisementWithoutBiddingPriceById(Integer.parseInt(id));
					if(advertisementWithoutBiddingPrice != null){
						advertisementWithoutBiddingPrice.setAdvertisementStatus(ZjbDictionaryEnum.ADVERTISEMENT_STATUS_STOP.getValue());
						advertisementWithoutBiddingPrice.setUpdateBaseParams(userId);
						advertisementWithoutBiddingPriceMapper.updateAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice);
					}
				}
			}
		}
		return idArray.length;
	}

	/**
	 * 投放非竞价广告
	 * @param ids
	 * @param userId
	 * @return
	 */
	@Override
	public int startAdvertisementWithoutBiddingPrice(String ids, Integer userId) {
		if(StringUtils.isEmpty(ids)){
			return 0;
		}
		String[] idArray = Convert.toStrArray(ids);
		if(idArray != null && idArray.length>0){
			for(String id : idArray){
				if(StringUtils.isNotEmpty(id)){
					AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice = advertisementWithoutBiddingPriceMapper.selectAdvertisementWithoutBiddingPriceById(Integer.parseInt(id));
					if(advertisementWithoutBiddingPrice != null){
						advertisementWithoutBiddingPrice.setAdvertisementStatus(ZjbDictionaryEnum.ADVERTISEMENT_STATUS_RUN.getValue());
						advertisementWithoutBiddingPrice.setUpdateBaseParams(userId);
						advertisementWithoutBiddingPriceMapper.updateAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice);
					}
				}
			}
		}
		return idArray.length;
	}

	/**
	 * 获取胜出的非竞价广告信息
	 * @param withoutBiddingAd
	 * @return
	 */
	@Override
	public List<AdvertisingUnit> getAdvertisingUnitFansInfo(WithoutBiddingAd withoutBiddingAd) {
		return advertisementWithoutBiddingPriceMapper.getAdvertisingUnitFansInfo(withoutBiddingAd);
	}

}
