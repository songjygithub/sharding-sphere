package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.util.Date;

/**
 * @author songjy
 * @Date 2019/12/09
 **/
public class StatisticsAreaInfo implements Serializable {
    private static final long serialVersionUID = -5930826965932621766L;

    /**
     * 统计日期
     */
    private Date dateStatistics;

    /**
     * 统计日期：yyyy-MM-dd
     */
    @Excel(name = "统计日期")
    private String statisticsDate;

    /**
     * 省id 参考 省市区表
     */
    private Integer provinceId;
    /**
     * 省id 参考 省市区表
     */
    private String provinceCode;
    /**
     * 省 参考 省市区表
     */
    @Excel(name = "省")
    private String provinceName;
    /**
     * 市id 参考 省市区表
     */
    private Integer cityId;
    /**
     * 市id 参考 省市区表
     */
    private String cityCode;
    /**
     * 市 参考 省市区表
     */
    @Excel(name = "市")
    private String cityName;
    /**
     * 区id 参考 省市区表
     */
    private Integer areaId;
    /**
     * 区id 参考 省市区表
     */
    private String areaCode;
    /**
     * 区 参考 省市区表
     */
    @Excel(name = "区")
    private String areaName;

    /**
     * 设备安装场景，参阅字典【zjb_device_scene】
     */
    private String deviceScene;

    /**
     * 设备安装场景名称
     */
    @Excel(name = "设备安装场景")
    private String sceneName;

    /**
     * 出纸成功次数
     */
    @Excel(name = "出纸次数")
    private Integer paperSuccessCount;

    /**
     * 出纸人数
     */
    @Excel(name = "出纸人数")
    private Integer paperUserCount;

    @Excel(name = "设备数量")
    private Integer deviceCount;

    public Date getDateStatistics() {
        return dateStatistics;
    }

    public void setDateStatistics(Date dateStatistics) {
        this.dateStatistics = dateStatistics;
    }

    public String getStatisticsDate() {
        return statisticsDate;
    }

    public void setStatisticsDate(String statisticsDate) {
        this.statisticsDate = statisticsDate;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public Integer getPaperSuccessCount() {
        return paperSuccessCount;
    }

    public void setPaperSuccessCount(Integer paperSuccessCount) {
        this.paperSuccessCount = paperSuccessCount;
    }

    public Integer getPaperUserCount() {
        return paperUserCount;
    }

    public void setPaperUserCount(Integer paperUserCount) {
        this.paperUserCount = paperUserCount;
    }

    public String getProvinceCode() {
        return provinceCode;
    }

    public void setProvinceCode(String provinceCode) {
        this.provinceCode = provinceCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }

    public String getDeviceScene() {
        return deviceScene;
    }

    public void setDeviceScene(String deviceScene) {
        this.deviceScene = deviceScene;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    public Integer getDeviceCount() {
        return deviceCount;
    }

    public void setDeviceCount(Integer deviceCount) {
        this.deviceCount = deviceCount;
    }
}
