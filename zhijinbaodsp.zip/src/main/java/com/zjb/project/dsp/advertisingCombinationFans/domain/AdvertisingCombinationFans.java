package com.zjb.project.dsp.advertisingCombinationFans.domain;

import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
													import java.util.Date;

/**
 * 粉丝通广告方案表 zjb_advertising_combination_fans
 * 
 * @author shenlong
 * @date 2019-11-22
 */
public class AdvertisingCombinationFans extends AdvertisingCombination
{
	private static final long serialVersionUID = 1L;
	

}
