package com.zjb.project.dsp.backupRecord.mapper;

import com.zjb.project.dsp.backupRecord.domain.BackupRecord;

import java.time.LocalDate;
import java.util.List;

/**
 * 数据备份记录 数据层
 *
 * @author songjy
 * @date 2020-04-17
 */
public interface BackupRecordMapper {
    /**
     * 查询数据备份记录信息
     *
     * @param id 数据备份记录ID
     * @return 数据备份记录信息
     */
    BackupRecord selectBackupRecordById(Long id);

    /**
     * 查询数据备份记录列表
     *
     * @param backupRecord 数据备份记录信息
     * @return 数据备份记录集合
     */
    List<BackupRecord> selectBackupRecordList(BackupRecord backupRecord);

    /**
     * 按天分组且备份记录数小于24的记录
     *
     * @param typeData 数据类型：如广告交易数据
     * @return 备份记录数小于24的记录
     */
    List<BackupRecord> selectGroupByDayLess24(String typeData);

    /**
     * 新增数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    int insertBackupRecord(BackupRecord backupRecord);

    /**
     * 修改数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    int updateBackupRecord(BackupRecord backupRecord);

    /**
     * 删除数据备份记录
     *
     * @param id 数据备份记录ID
     * @return 结果
     */
    int deleteBackupRecordById(Long id);

    /**
     * 批量删除数据备份记录
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteBackupRecordByIds(String[] ids);

    /**
     * 指定数据最后的备份日期
     *
     * @param typeData 数据类型
     * @return 指定数据最后的备份日期
     */
    LocalDate selectMaxDay(String typeData);
}