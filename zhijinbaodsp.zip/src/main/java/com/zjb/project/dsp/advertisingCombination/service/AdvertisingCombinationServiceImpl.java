package com.zjb.project.dsp.advertisingCombination.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombinationUnit;
import com.zjb.project.dsp.advertisingCombination.mapper.AdvertisingCombinationMapper;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.mapper.AdvertisingUnitMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.mapper.ScanTaskMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 广告方案-支付宝 服务层实现
 *
 * @author zjb
 * @date 2019-07-13
 */
@Service
public class AdvertisingCombinationServiceImpl implements IAdvertisingCombinationService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AdvertisingCombinationMapper advertisingCombinationMapper;
    @Autowired
    private AdvertisingUnitMapper advertisingUnitMapper;
    @Autowired
    private ScanTaskMapper scanTaskMapper;
    @Autowired
    private GzhGroupMapper gzhGroupMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;

    /**
     * 查询广告方案信息
     *
     * @param id 广告方案ID
     * @return 广告方案信息
     */
    @Override
    public AdvertisingCombination selectAdvertisingCombinationById(Integer id) {
        return advertisingCombinationMapper.selectAdvertisingCombinationById(id);
    }

    /**
     * 查询广告方案列表
     *
     * @param advertisingCombination 广告方案信息
     * @return 广告方案集合
     */
    @Override
    public List<AdvertisingCombination> selectAdvertisingCombinationList(AdvertisingCombination advertisingCombination) {
        return advertisingCombinationMapper.selectAdvertisingCombinationList(advertisingCombination);
    }

    /**
     * 查询广告方案详情列表
     *
     * @param advertisingCombinationUnit 广告方案详情信息
     * @return 广告方案详情
     */
    @Override
    public List<AdvertisingCombinationUnit> selectAdvertisingCombinationUnitList(AdvertisingCombinationUnit advertisingCombinationUnit) {
        return advertisingCombinationMapper.selectAdvertisingCombinationUnitList(advertisingCombinationUnit);
    }

    /**
     * 新增广告方案
     *
     * @param advertisingCombination 广告方案信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingCombination(AdvertisingCombination advertisingCombination) {
        int result = advertisingCombinationMapper.insertAdvertisingCombination(advertisingCombination);
        if (result > 0) {
            advertisingCombination.setComId(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue().toString() + advertisingCombination.getId());
            result += advertisingCombinationMapper.updateAdvertisingCombination(advertisingCombination);
        }
        return result;
    }

    /**
     * 新增广告方案详情
     */
    @Override
    public int insertAdvertisingCombinationUnit(AdvertisingCombinationUnit advertisingCombinationUnit) {

        if (null == advertisingCombinationUnit.getAdUnitId() || null == advertisingCombinationUnit.getCombinationId()) {
            logger.warn("缺失广告单元ID||广告方案ID");
            return 0;
        }

        removeOldOutPaper(advertisingCombinationUnit);

        return advertisingCombinationMapper.insertAdvertisingCombinationUnit(advertisingCombinationUnit);
    }

    /**
     * 扫码取纸位在一个方案中只能出现一次，即需要删除旧的扫码取纸位
     *
     * @param adCombinationUnit
     */
    private void removeOldOutPaper(AdvertisingCombinationUnit adCombinationUnit) {

        if (null == adCombinationUnit
                || null == adCombinationUnit.getCombinationId()
                || null == adCombinationUnit.getAdUnitId()) {
            return;
        }

        AdvertisingUnit advertisingUnit = advertisingUnitMapper.selectAdvertisingUnitById(adCombinationUnit.getAdUnitId());

        if (null == advertisingUnit
                || null == advertisingUnit.getAdSpaceIdentifier()
                || !advertisingUnit.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT.getValue())) {
            return;
        }

        AdvertisingCombinationUnit query = new AdvertisingCombinationUnit();
        query.setCombinationId(adCombinationUnit.getCombinationId());
        List<AdvertisingCombinationUnit> combinationUnits = advertisingCombinationMapper.selectAdvertisingCombinationUnitList(query);

        if (null == combinationUnits || combinationUnits.isEmpty()) {
            return;
        }

        List<AdvertisingCombinationUnit> list = combinationUnits.stream()
                .filter(e -> e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT.getValue()))
                .collect(Collectors.toList());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnit combinationUnit : list) {
            advertisingCombinationMapper.deleteByCombinationIdAndAdUnitId(combinationUnit);
            logger.info("方案【{}】移除旧的扫码广告位【{}:{}】成功", combinationUnit.getCombinationId(), combinationUnit.getAdUnitId(), combinationUnit.getAdName());
        }
    }

    /**
     * 修改广告方案
     *
     * @param advertisingCombination 广告方案信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingCombination(AdvertisingCombination advertisingCombination) {
        return advertisingCombinationMapper.updateAdvertisingCombination(advertisingCombination);
    }

    /**
     * 删除广告方案对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationByIds(String ids) {
        return advertisingCombinationMapper.deleteAdvertisingCombinationByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除广告方案详情
     *
     * @param ids 需删除的数据id
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitByIds(String ids) {
        return advertisingCombinationMapper.deleteAdvertisingCombinationUnitByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除广告方案详情
     *
     * @param combinationIds 广告方案id
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitByCombinationId(String combinationIds) {
        return advertisingCombinationMapper.deleteAdvertisingCombinationUnitByCombinationId(Convert.toStrArray(combinationIds));
    }

    /**
     * 删除广告方案详情
     *
     * @param unitIds 广告池id集
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitByUnitId(String unitIds) {
        return advertisingCombinationMapper.deleteAdvertisingCombinationUnitByUnitId(Convert.toStrArray(unitIds));
    }

    /**
     * 更换广告方案详情
     *
     * @param advertisingCombinationUnit 广告方案
     * @return 结果
     */
    @Override
    public int modifyDetails(AdvertisingCombinationUnit advertisingCombinationUnit) {
        return advertisingCombinationMapper.modifyDetails(advertisingCombinationUnit);
    }

    @Override
    public List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer id) {
        AdvertisingCombinationUnit combinationUnit = new AdvertisingCombinationUnit();
        combinationUnit.setCombinationId(id);
        List<AdvertisingCombinationUnit> list = advertisingCombinationMapper.selectAdvertisingCombinationUnitList(combinationUnit);
        if (null == list || list.isEmpty()) {
            return Collections.emptyList();
        }

        List<ComponentAuthorizationInfo> all = new ArrayList<>();

        for (AdvertisingCombinationUnit advertisingCombinationUnit : list) {
            AdvertisingUnit advertisingUnit = advertisingUnitMapper.selectAdvertisingUnitById(advertisingCombinationUnit.getAdUnitId());

            if (null != advertisingUnit
                    && AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                    && AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())
                    && StringUtils.isNotBlank(advertisingUnit.getWeChatAccount())
                    && advertisingUnit.getWeChatAccount().startsWith(AD_ZJB_OPEN_PLATFORM_PREFIX.getValue())) {
                ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(advertisingUnit.getWeChatAccount());

                if (null != componentAuthorizationInfo) {
                    all.add(componentAuthorizationInfo);
                }

                continue;
            }

            if (null == advertisingUnit
                    || !AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                    || !AD_REDIRECT_TASK.getValue().equals(advertisingUnit.getRedirectUrlType())
                    || !StringUtils.isNumeric(advertisingUnit.getAppId())) {
                continue;
            }

            ScanTask scanTask = scanTaskMapper.selectScanTaskById(Integer.parseInt(advertisingUnit.getAppId()));

            if (null == scanTask || !StringUtils.isNumeric(scanTask.getExpansionA())) {
                continue;
            }

            GzhGroup gzhGroup = gzhGroupMapper.selectGzhGroupById(Integer.parseInt(scanTask.getExpansionA()));

            if (null == gzhGroup || StringUtils.isBlank(gzhGroup.getGzhList())) {
                continue;
            }

            String[] arr = StringUtils.split(gzhGroup.getGzhList(), ',');

            for (String str : arr) {
                ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(Integer.parseInt(str));

                if (null != componentAuthorizationInfo) {
                    all.add(componentAuthorizationInfo);
                }
            }
        }

        return all;
    }

    @Override
    public List<AdvertisingCombinationUnit> selectByUnitId(Integer unitId) {
        return advertisingCombinationMapper.selectByUnitId(unitId);
    }
}
