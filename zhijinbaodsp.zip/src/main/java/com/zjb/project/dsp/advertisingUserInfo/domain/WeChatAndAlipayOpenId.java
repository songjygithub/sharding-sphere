package com.zjb.project.dsp.advertisingUserInfo.domain;

import java.io.Serializable;

/**
 * @author ：guoj
 * @date ：Created in 2019/8/19 16:08
 * @description： 微信和支付宝openId入参类
 */

public class WeChatAndAlipayOpenId implements Serializable {

    private static final long serialVersionUID = -6843375340777479119L;

    /** 微信openId */
    private String weChatOpenId;

    /** 支付宝openId */
    private String alipayOpenId;

    public String getWeChatOpenId() {
        return weChatOpenId;
    }

    public void setWeChatOpenId(String weChatOpenId) {
        this.weChatOpenId = weChatOpenId;
    }

    public String getAlipayOpenId() {
        return alipayOpenId;
    }

    public void setAlipayOpenId(String alipayOpenId) {
        this.alipayOpenId = alipayOpenId;
    }
}
