package com.zjb.project.dsp.deviceInstallScene.controller;

import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.project.dsp.deviceInstallScene.domain.InstallScene;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

/**
 * @author jiangbingjie
 * @date 2020/2/27 12:58 AM
 */
@Controller
@RequestMapping("/dsp/deviceInstallScene")
public class DeviceInstallSceneController extends BaseController {

    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;

    /**
     * 获取设备安装场景信息
     * @return
     */
    @GetMapping("/sceneList")
    @ResponseBody
    public AjaxResult sceneList()
    {
        List<InstallScene> installScenes = new ArrayList<InstallScene>();
        List<InstallScene> installSceneList = new ArrayList<InstallScene>();
        //获取设备安装场景类型信息
        installSceneList = deviceInstallSceneService.selectInstallSceneTypeList();
        if(installSceneList != null && installSceneList.size()>0){
            for(InstallScene installScene : installSceneList){
                if(installScene != null && null != installScene.getValue()){
                    //获取设备安装场景类型下的安装场景信息
                    List<InstallScene> installSceneList1 = deviceInstallSceneService.selectInstallSceneListByType(installScene.getValue());
                    if(installSceneList1 != null && !(installSceneList1.isEmpty())){
                        installScene.setChildren(installSceneList1);
                        installScenes.add(installScene);
                    }
                }
            }
        }
        return success(installScenes);
    }
}
