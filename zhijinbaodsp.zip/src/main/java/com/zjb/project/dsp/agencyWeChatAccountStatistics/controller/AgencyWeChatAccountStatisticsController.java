package com.zjb.project.dsp.agencyWeChatAccountStatistics.controller;

import com.zjb.common.utils.DateUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.agencyWeChatAccountStatistics.domain.AgencyWeChatAccountStatistics;
import com.zjb.project.dsp.agencyWeChatAccountStatistics.service.IAgencyWeChatAccountStatisticsService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * 代理商维度公众号统计 信息操作处理
 *
 * @author songjy
 * @date 2020-01-02
 */
@Controller
@RequestMapping("/dsp/agencyWeChatAccountStatistics")
public class AgencyWeChatAccountStatisticsController extends BaseController {
    private String prefix = "dsp/agencyWeChatAccountStatistics";

    @Autowired
    private IAgencyWeChatAccountStatisticsService agencyWeChatAccountStatisticsService;
    @Autowired
    private IAgencyService agencyService;

    @RequiresPermissions("dsp:agencyWeChatAccountStatistics:view")
    @GetMapping()
    public String agencyWeChatAccountStatistics(ModelMap modelMap) {
        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());
        modelMap.put("agencyList", agencyList);
        modelMap.put("statisticsDay", LocalDate.now().minusDays(1L).toString());
        return prefix + "/agencyWeChatAccountStatistics";
    }

    /**
     * 查询代理商维度公众号统计列表
     */
    @RequiresPermissions("dsp:agencyWeChatAccountStatistics:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {

        if (null == agencyWeChatAccountStatistics.getStatisticsDay()) {
            /*默认查询昨天的数据*/
            agencyWeChatAccountStatistics.setStatisticsDay(DateUtils.toDate(LocalDate.now().minusDays(1L)));
        }

        startPage();
        List<AgencyWeChatAccountStatistics> list = agencyWeChatAccountStatisticsService.selectAgencyWeChatAccountStatisticsList(agencyWeChatAccountStatistics);
        return getDataTable(list);
    }

    /**
     * 新增代理商维度公众号统计
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存代理商维度公众号统计
     */
    @RequiresPermissions("dsp:agencyWeChatAccountStatistics:add")
    @Log(title = "代理商维度公众号统计", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {
        return toAjax(agencyWeChatAccountStatisticsService.insertAgencyWeChatAccountStatistics(agencyWeChatAccountStatistics));
    }

    /**
     * 修改代理商维度公众号统计
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        AgencyWeChatAccountStatistics agencyWeChatAccountStatistics = agencyWeChatAccountStatisticsService.selectAgencyWeChatAccountStatisticsById(id);
        mmap.put("agencyWeChatAccountStatistics", agencyWeChatAccountStatistics);
        return prefix + "/edit";
    }

    /**
     * 修改保存代理商维度公众号统计
     */
    @RequiresPermissions("dsp:agencyWeChatAccountStatistics:edit")
    @Log(title = "代理商维度公众号统计", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {
        return toAjax(agencyWeChatAccountStatisticsService.updateAgencyWeChatAccountStatistics(agencyWeChatAccountStatistics));
    }

    /**
     * 删除代理商维度公众号统计
     */
    @RequiresPermissions("dsp:agencyWeChatAccountStatistics:remove")
    @Log(title = "代理商维度公众号统计", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(agencyWeChatAccountStatisticsService.deleteAgencyWeChatAccountStatisticsByIds(ids));
    }

}
