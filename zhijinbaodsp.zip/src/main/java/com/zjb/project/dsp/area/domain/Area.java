package com.zjb.project.dsp.area.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 地区编码表 sys_area
 *
 * @author zjb
 * @date 2019-05-17
 */
public class Area extends BaseEntity {
    private static final long serialVersionUID = -1393397353426826901L;

    /**
     * id
     */
    private Integer id;
    /**
     * 地区编码
     */
    private Integer areaCode;
    /**
     * 地区名
     */
    private String areaName;
    /**
     * 地区级别（1:省份province,2:市city,3:区县district,4:街道street）
     */
    private Integer level;
    /**
     * 城市编码
     */
    private String cityCode;
    /**
     * 城市中心点（即：经纬度坐标）
     */
    private String center;
    /**
     * 地区父节点
     */
    private String parentId;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setAreaCode(Integer areaCode) {
        this.areaCode = areaCode;
    }

    public Integer getAreaCode() {
        return areaCode;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setLevel(Integer level) {
        this.level = level;
    }

    public Integer getLevel() {
        return level;
    }

    public void setCityCode(String cityCode) {
        this.cityCode = cityCode;
    }

    public String getCityCode() {
        return cityCode;
    }

    public void setCenter(String center) {
        this.center = center;
    }

    public String getCenter() {
        return center;
    }

    public void setParentId(String parentId) {
        this.parentId = parentId;
    }

    public String getParentId() {
        return parentId;
    }


}
