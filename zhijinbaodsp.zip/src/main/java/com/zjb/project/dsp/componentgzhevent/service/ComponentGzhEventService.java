package com.zjb.project.dsp.componentgzhevent.service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.constant.Constants;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService;
import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.appidOpenidIndex.service.IAppidOpenidIndexService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.systemAppInfo.service.ISystemAppInfoService;
import com.zjb.project.dsp.takePaperRecord.domain.TakePaperRecord;
import com.zjb.project.dsp.takePaperRecord.service.ITakePaperRecordService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_DAY;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_YEAR;
import static com.zjb.framework.web.mgservice.BaseMongoDbServiceImpl.SNOWFLAKE;

/**
 * @author songjy
 * @date 2019/10/28
 */
@Service
public class ComponentGzhEventService implements IComponentGzhEventService, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(this.getClass());
    /**
     * 微信用户昵称提取规范，便于数据导出
     */
    private static final Pattern PATTERN_NICK_NAME = Pattern.compile("\\w*[\\u4e00-\\u9fa5]*\\d*");

    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private IAppidOpenidIndexService appIdOpenIdIndexService;
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private ISystemAppInfoService systemAppInfoService;

    @Override
    public void afterPropertiesSet() throws Exception {

        AsyncManager.me().execute(new TimerTask() {

            @Override
            public void run() {

                while (System.currentTimeMillis() > Integer.MIN_VALUE && !systemAppInfoService.isShutdown()) {
                    List<String> values = JedisPoolCacheUtils.brpop(RedisSubscribe.MESSAGE_WE_CHAT_OFFICIAL_ACCOUNT_EVENT);
                    logger.debug("队列消息：{}", values);

                    try {


                        ComponentGzhEvent gzhEvent = JSON.parseObject(values.get(1), ComponentGzhEvent.class);

                        /*补充用户openId*/
                        if (StringUtils.isBlank(gzhEvent.getZjbOpenid()) && StringUtils.isNotBlank(gzhEvent.getOpenid()) && StringUtils.isNotBlank(gzhEvent.getAppid())) {
                            AppIdOpenIdIndex appIdOpenIdIndex = appIdOpenIdIndexService.selectByOpenIdAndAppId(gzhEvent.getOpenid(), gzhEvent.getAppid());
                            if (null != appIdOpenIdIndex && StringUtils.isNotBlank(appIdOpenIdIndex.getZjbOpenid())) {
                                gzhEvent.setZjbOpenid(appIdOpenIdIndex.getZjbOpenid());
                            }
                        }

                        /*关注次数递增*/
                        incrFollow(gzhEvent);

                        /*用户公众号取纸记录事件发生时间*/
                        handleTakePaperRecord(gzhEvent);

                        /*完善设备信息*/
                        handleDeviceInfoWhenSubscribe(gzhEvent);
                        handleDeviceInfoWhenUnsubscribe(gzhEvent);
                    } catch (Exception e) {
                        logger.error("用户关注公众号事件处理异常：" + e.getMessage(), e);
                        logger.error("用户关注公众号事件处理异常：{}", values);
                    }
                }
            }
        });

    }

    /**
     * 完善设备信息
     *
     * @param gzhEvent
     */
    private void handleDeviceInfoWhenSubscribe(ComponentGzhEvent gzhEvent) {
        if (null == gzhEvent || null == gzhEvent.getId() || StringUtils.isBlank(gzhEvent.getQrCode())) {
            return;
        }

        DeviceDTO device = deviceService.selectByQrCode(gzhEvent.getQrCode());

        if (null == device) {
            return;
        }

        gzhEvent.setAgencyId(device.getAgencyId());
        gzhEvent.setAgencyName(device.getAgencyName());
        gzhEvent.setDeviceName(device.getName());
        gzhEvent.setDeviceSn(device.getSn());

        updatePerfectDeviceInfo(gzhEvent);

    }

    /**
     * 完善设备信息
     *
     * @param gzhEvent
     */
    private void handleDeviceInfoWhenUnsubscribe(ComponentGzhEvent gzhEvent) {
        if (null == gzhEvent || null == gzhEvent.getId() || StringUtils.isNotBlank(gzhEvent.getQrCode())) {
            return;
        }

        ComponentGzhEvent gzhSubscribe = findLastByAppIdAndOpenIdAndEvent(gzhEvent.getAppid(),
                StringUtils.defaultIfBlank(gzhEvent.getOpenid(), gzhEvent.getZjbOpenid()),
                AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue());

        if (null == gzhSubscribe || null == gzhSubscribe.getAgencyId() || gzhSubscribe.getAgencyId().equals(-1)) {
            return;
        }

        gzhEvent.setQrCode(gzhSubscribe.getQrCode());
        gzhEvent.setAgencyId(gzhSubscribe.getAgencyId());
        gzhEvent.setAgencyName(gzhSubscribe.getAgencyName());
        gzhEvent.setDeviceName(gzhSubscribe.getDeviceName());
        gzhEvent.setDeviceSn(gzhSubscribe.getDeviceSn());

        updatePerfectDeviceInfo(gzhEvent);

    }

    /**
     * 关注次数递增
     *
     * @param gzhEvent
     */
    private void incrFollow(ComponentGzhEvent gzhEvent) {

        if (null == gzhEvent) {
            return;
        }

        if (StringUtils.isBlank(gzhEvent.getAppid())) {
            logger.error("缺失公众号{}", StringUtils.isNotBlank(gzhEvent.getSearchValue()) ? "，发生位置：" + gzhEvent.getSearchValue() : "");
            return;
        }

        if (!AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(gzhEvent.getEvent())) {
            logger.debug("用户【{}】公众号【{}】事件【{}】非关注事件", gzhEvent.getOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());
            return;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(gzhEvent.getAppid());

        if (null == componentAuthorizationInfo) {
            /*也许来自云粉吧*/
            logger.warn("公众号【{}】不存在", gzhEvent.getAppid());
            return;
        }

        /*日关注量*/
        String keyDayFollowAmount = componentAuthorizationInfo.getAppId() + '_' + LocalDate.now();
        long dayFollowAmount = JedisPoolCacheUtils.incr(keyDayFollowAmount, EXRP_DAY);
        componentAuthorizationInfo.setDayFollowAmount((int) dayFollowAmount);
        /*总关注量*/
        String keyTotalFollowAmount = componentAuthorizationInfo.getAppId() + "_total_follow_amount";
        long totalFollowAmount;
        boolean exists = JedisPoolCacheUtils.exists(keyTotalFollowAmount, false, 0);
        if (exists) {
            totalFollowAmount = JedisPoolCacheUtils.incr(keyTotalFollowAmount, EXRP_YEAR);
        } else {
            /*历史关注量+今日关注量*/
            totalFollowAmount = componentAuthorizationInfoService.countSubscribeBeforeToday(componentAuthorizationInfo.getAppId()) + dayFollowAmount;
            JedisPoolCacheUtils.set(keyTotalFollowAmount, String.valueOf(totalFollowAmount), 0, EXRP_YEAR);
        }
        componentAuthorizationInfo.setTotalFollowAmount((int) totalFollowAmount);
        componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);
    }

    /**
     * 用户公众号取纸记录事件发生时间
     *
     * @param gzhEvent
     */
    private void handleTakePaperRecord(ComponentGzhEvent gzhEvent) {

        if (null == gzhEvent) {
            return;
        }

        if (StringUtils.isBlank(gzhEvent.getZjbOpenid()) && StringUtils.isBlank(gzhEvent.getAppid())) {
            logger.error("用户openId和公众号都为空{}", StringUtils.isNotBlank(gzhEvent.getSearchValue()) ? "，发生位置：" + gzhEvent.getSearchValue() : "");
            return;
        }

        if (StringUtils.isBlank(gzhEvent.getZjbOpenid())) {
            logger.warn("用户openId为空{}", StringUtils.isNotBlank(gzhEvent.getSearchValue()) ? "，发生位置：" + gzhEvent.getSearchValue() : "");
            return;
        }

        if (StringUtils.isBlank(gzhEvent.getAppid())) {
            logger.error("公众号为空{}", StringUtils.isNotBlank(gzhEvent.getSearchValue()) ? "，发生位置：" + gzhEvent.getSearchValue() : "");
            return;
        }

        if (StringUtils.isBlank(gzhEvent.getEvent())) {
            logger.error("用户【{}】公众号【{}】事件类型未指定{}", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), StringUtils.isNotBlank(gzhEvent.getSearchValue()) ? "，发生位置：" + gzhEvent.getSearchValue() : "");
            return;
        }

        Query query = new Query(Criteria.where(IAdvertisingUserInfoService.PRIMARY_KEY_OPEN_ID).is(gzhEvent.getZjbOpenid()).and("weChatAccount").is(gzhEvent.getAppid()));
        query.with(Sort.by(Sort.Direction.DESC, ITakePaperRecordService.PRIMARY_KEY_ID));

        TakePaperRecord record = mongoTemplate.findOne(query, TakePaperRecord.class);

        if (null == record) {
            logger.warn("用户【{}】扫码取纸公众号【{}】记录不存在，本次动作：{}", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());
            /*用户非平台扫码公众号事件记录*/
            saveNewTakePaperRecordWeChatAccount(gzhEvent);
            return;
        }

        query = new Query(Criteria.where(ITakePaperRecordService.PRIMARY_KEY_ID).is(record.getId()));
        if (AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(gzhEvent.getEvent())) {
            if (null != record.getGmtSubscribe()) {
                /*同一次扫码，多次关注公众号*/
                saveOnceAgainTakePaperRecord(record);
                logger.warn("用户【{}】公众号【{}】事件【{}】已记录", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());
                return;
            }

            Update update = Update.update("gmtSubscribe", new Date());
            mongoTemplate.updateFirst(query, update, TakePaperRecord.class);
            return;
        }

        if (AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue().equals(gzhEvent.getEvent())) {
            if (null != record.getGmtUnsubscribe()) {
                logger.warn("用户【{}】公众号【{}】事件【{}】已记录", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());
                return;
            }
            Update update = Update.update("gmtUnsubscribe", new Date());
            mongoTemplate.updateFirst(query, update, TakePaperRecord.class);

            return;
        }

        logger.error("用户【{}】公众号【{}】事件【{}】未处理", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());

    }

    /**
     * 用户非平台扫码公众号事件记录
     *
     * @param gzhEvent
     */
    private void saveNewTakePaperRecordWeChatAccount(ComponentGzhEvent gzhEvent) {

        if (StringUtils.isBlank(gzhEvent.getAppid())) {
            return;
        }

        TakePaperRecord recordNew = new TakePaperRecord();
        recordNew.setId(JedisPoolCacheUtils.incr(TakePaperRecord.class.getName(), EXRP_DAY));
        recordNew.setCreateDate(DateUtils.toDate(LocalDate.now()));
        recordNew.setWeChatAccount(gzhEvent.getAppid());
        recordNew.setOpenId(gzhEvent.getZjbOpenid());

        if (AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue().equals(gzhEvent.getEvent())) {
            recordNew.setGmtUnsubscribe(new Date());
        } else if (AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(gzhEvent.getEvent())) {
            recordNew.setGmtSubscribe(new Date());
        } else {
            logger.error("用户【{}】公众号【{}】事件【{}】未处理", gzhEvent.getZjbOpenid(), gzhEvent.getAppid(), gzhEvent.getEvent());
            return;
        }

        mongoTemplate.save(recordNew);
    }

    /**
     * 同一次扫码，多次关注公众号
     *
     * @param record
     */
    private void saveOnceAgainTakePaperRecord(TakePaperRecord record) {
        TakePaperRecord recordNew = new TakePaperRecord();
        BeanUtils.copyProperties(record, recordNew);
        recordNew.setId(SNOWFLAKE.nextId());
        recordNew.setGmtSubscribe(new Date());
        recordNew.setGmtZjbPl(null);
        recordNew.setGmtZjbPr(null);
        recordNew.setGmtUnsubscribe(null);
        recordNew.setOutPaperStatus(null);
        recordNew.setSnPaper(null);
        mongoTemplate.save(recordNew);
    }

    /**
     * 设置值
     *
     * @param rs
     * @param record
     * @throws SQLException
     */
    private void setValues(ResultSet rs, AppIdOpenIdIndex record) throws SQLException {
        record.setId(rs.getInt("id"));
        record.setZjbOpenid(rs.getString("zjb_openid"));
        record.setOpenid(rs.getString("openid"));
        record.setAppid(rs.getString("appid"));
        record.setNickName(rs.getString("nick_name"));
        record.setSex(rs.getInt("sex"));
        record.setHeadImgUrl(rs.getString("head_img_url"));
        record.setEvent(rs.getString("event"));
    }

    @Override
    public ComponentGzhEvent findById(Integer id) {
        String sql = "SELECT * FROM `zjb_component_gzh_event` WHERE id = ?";
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{id}, new int[]{Types.INTEGER}, new RowMapper<ComponentGzhEvent>() {
                @Override
                public ComponentGzhEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ComponentGzhEvent record = new ComponentGzhEvent();

                    record.setId(rs.getInt("id"));
                    record.setZjbOpenid(rs.getString("zjb_openid"));
                    record.setOpenid(rs.getString("openid"));
                    record.setAppid(rs.getString("appid"));
                    record.setGmtCreated(rs.getTimestamp("gmt_created"));
                    record.setGmtDate(rs.getTimestamp("gmt_date"));
                    record.setAgencyId(null == rs.getObject("agency_id") ? null : rs.getInt("agency_id"));
                    record.setAgencyName(rs.getString("agency_name"));
                    record.setQrCode(rs.getString("qr_code"));
                    record.setDeviceSn(rs.getString("device_sn"));
                    record.setDeviceName(rs.getString("device_name"));
                    record.setEvent(rs.getString("event"));

                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public ComponentGzhEvent findLastByAppIdAndOpenIdAndEvent(String appId, String openId, String event) {
        String sql = "SELECT * FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `event` = ? AND (`openid` = ? OR `zjb_openid` = ?) ORDER BY id DESC LIMIT 1";
        Object[] args = {appId, event, openId, openId};
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<ComponentGzhEvent>() {
                @Override
                public ComponentGzhEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
                    ComponentGzhEvent record = new ComponentGzhEvent();

                    record.setId(rs.getInt("id"));
                    record.setZjbOpenid(rs.getString("zjb_openid"));
                    record.setOpenid(rs.getString("openid"));
                    record.setAppid(rs.getString("appid"));
                    record.setGmtCreated(rs.getTimestamp("gmt_created"));
                    record.setGmtDate(rs.getTimestamp("gmt_date"));
                    record.setAgencyId(null == rs.getObject("agency_id") ? null : rs.getInt("agency_id"));
                    record.setAgencyName(rs.getString("agency_name"));
                    record.setQrCode(rs.getString("qr_code"));
                    record.setDeviceSn(rs.getString("device_sn"));
                    record.setDeviceName(rs.getString("device_name"));
                    record.setEvent(rs.getString("event"));
                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public List<ComponentGzhEvent> findByAppIdAndEvent(Date gmtDate, String appId, String event) {

        if (StringUtils.isAnyBlank(appId, event)) {
            logger.error("未指定公众号||关注事件");
            return Collections.emptyList();
        }

        String sql = "SELECT * FROM `zjb_component_gzh_event` WHERE `appid` = ?  AND `gmt_date` = ? AND `event` = ?";
        LocalDate localDate = DateUtils.toLocalDateTime(null == gmtDate ? new Date() : gmtDate).toLocalDate();

        Object[] args = {appId, localDate.toString(), event};
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

        return jdbcTemplate.query(sql, args, argTypes, new RowMapper<ComponentGzhEvent>() {
            @Override
            public ComponentGzhEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
                ComponentGzhEvent record = new ComponentGzhEvent();

                record.setId(rs.getInt("id"));
                record.setZjbOpenid(rs.getString("zjb_openid"));
                record.setOpenid(rs.getString("openid"));
                record.setAppid(rs.getString("appid"));
                record.setGmtCreated(rs.getTimestamp("gmt_created"));
                record.setGmtDate(rs.getTimestamp("gmt_date"));
                record.setEvent(rs.getString("event"));

                return record;
            }
        });

    }

    @Override
    public int updatePerfectZjbOpenId(ComponentGzhEvent componentGzhEvent) {

        if (null == componentGzhEvent || null == componentGzhEvent.getId() || StringUtils.isBlank(componentGzhEvent.getZjbOpenid())) {
            return 0;
        }

        String sql = "UPDATE `zjb_component_gzh_event` SET `zjb_openid` = ?  WHERE id = ?";

        Object[] args = {componentGzhEvent.getZjbOpenid(), componentGzhEvent.getId()};
        int[] argTypes = {Types.VARCHAR, Types.INTEGER};

        return jdbcTemplate.update(sql, args, argTypes);
    }

    @Override
    public int updatePerfectDeviceInfo(ComponentGzhEvent gzhEvent) {

        if (null == gzhEvent || null == gzhEvent.getId()) {
            return 0;
        }

        ComponentGzhEvent old = findById(gzhEvent.getId());

        if (null == old) {
            return 0;
        }

        StringBuffer sql = new StringBuffer();
        List<Object> args = new ArrayList<>(8);
        List<Integer> argTypes = new ArrayList<>(8);

        if (StringUtils.isNotBlank(gzhEvent.getQrCode()) && StringUtils.isBlank(old.getQrCode())) {
            old.setQrCode(gzhEvent.getQrCode());
            args.add(old.getQrCode());
            argTypes.add(Types.VARCHAR);
            sql.append("qr_code = ?,");
        }

        if (StringUtils.isNotBlank(gzhEvent.getDeviceName()) && StringUtils.isBlank(old.getDeviceName())) {
            old.setDeviceName(gzhEvent.getDeviceName());
            args.add(old.getDeviceName());
            argTypes.add(Types.VARCHAR);
            sql.append("device_name = ?,");
        }

        if (StringUtils.isNotBlank(gzhEvent.getDeviceSn()) && StringUtils.isBlank(old.getDeviceSn())) {
            old.setDeviceSn(gzhEvent.getDeviceSn());
            args.add(old.getDeviceSn());
            argTypes.add(Types.VARCHAR);
            sql.append("device_sn = ?,");
        }

        if (StringUtils.isNotBlank(gzhEvent.getAgencyName()) && StringUtils.isBlank(old.getAgencyName())) {
            old.setAgencyName(gzhEvent.getAgencyName());
            args.add(old.getAgencyName());
            argTypes.add(Types.VARCHAR);
            sql.append("agency_name = ?,");
        }

        boolean newAgencyIdValid = (null != gzhEvent.getAgencyId() && !gzhEvent.getAgencyId().equals(-1));
        boolean oldAgencyIdInValid = (null == old.getAgencyId() || old.getAgencyId().equals(-1));
        if (newAgencyIdValid && oldAgencyIdInValid) {
            old.setAgencyId(gzhEvent.getAgencyId());
            args.add(old.getAgencyId());
            argTypes.add(Types.INTEGER);
            sql.append("agency_id = ?,");
        }

        if (args.isEmpty()) {
            return 0;
        }

        /*删除最后一个英文逗号*/
        sql.deleteCharAt(sql.length() - 1);
        sql.insert(0, "UPDATE zjb_component_gzh_event SET ");
        sql.append(" WHERE id = ?");

        args.add(old.getId());
        argTypes.add(Types.INTEGER);
        int size = args.size();
        Object[] array = new Object[size];
        int[] argsType = new int[size];

        for (int i = 0; i < size; i++) {
            array[i] = args.get(i);
            argsType[i] = argTypes.get(i);
        }

        return jdbcTemplate.update(sql.toString(), array, argsType);
    }

    @Override
    public List<ComponentGzhEvent> selectDayRealAmount(String weChatAccount) {

        long start = System.currentTimeMillis();

        ComponentAuthorizationInfo authorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(weChatAccount);

        if (null == authorizationInfo) {
            logger.error("微信公众号【{}】不存在", weChatAccount);
            return Collections.emptyList();
        }

        String dateSql = "SELECT DISTINCT `gmt_date` FROM `zjb_component_gzh_event` WHERE `appid` = ?";
        List<Date> listDate = jdbcTemplate.queryForList(dateSql, new Object[]{weChatAccount}, new int[]{Types.VARCHAR}, Date.class);

        if (null == listDate || listDate.isEmpty()) {
            logger.warn("微信公众号【{}】未投放", weChatAccount);
            return Collections.emptyList();
        }

        List<ComponentGzhEvent> list = new ArrayList<>(30);

        String openIdSql;
        if (authorizationInfo.getComponentAuthorizationType().equals(MANUAL_ADD.getValue()) || authorizationInfo.getComponentAuthorizationType().equals(MANUAL_GROUND.getValue())) {
            openIdSql = "SELECT DISTINCT `zjb_openid` FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `gmt_date` = ? AND `event` = ?";
        } else {
            openIdSql = "SELECT DISTINCT `openid` FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `gmt_date` = ? AND `event` = ?";
        }


        int[] argTypes = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
        for (Date date : listDate) {
            ComponentGzhEvent gzhEvent = new ComponentGzhEvent();
            gzhEvent.setAppid(weChatAccount);
            String gmtDate = DateUtils.toLocalDateTime(date).toLocalDate().toString();
            gzhEvent.setDate(gmtDate);
            gzhEvent.setGmtDate(date);
            Object[] args = {weChatAccount, gmtDate, AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue()};
            List<String> openIdSubscribe = jdbcTemplate.queryForList(openIdSql, args, argTypes, String.class);
            gzhEvent.setSubscribeCount(openIdSubscribe.size());
            args[2] = AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue();
            List<String> openIdUnSubscribe = jdbcTemplate.queryForList(openIdSql, args, argTypes, String.class);
            gzhEvent.setUnSubscribeCount(openIdUnSubscribe.size());

            openIdSubscribe.retainAll(openIdUnSubscribe);
            gzhEvent.setSamedayUnSubscribeCount(openIdSubscribe.size());

            list.add(gzhEvent);

        }

        Collections.sort(list, new Comparator<ComponentGzhEvent>() {
            @Override
            public int compare(ComponentGzhEvent o1, ComponentGzhEvent o2) {
                return o2.getGmtDate().compareTo(o1.getGmtDate());
            }
        });

        logger.info("公众号【{}】的关注和取关数据统计耗时（秒）：{}", authorizationInfo.getNickName(), (System.currentTimeMillis() - start) / 1000);

        return list;
    }

    @Override
    public List<UserInfo> exportSubscribeUserInfo(String weChatAccount, Date date) {

        LocalDate gmtDate = DateUtils.toLocalDateTime(null == date ? new Date() : date).toLocalDate();

        ComponentAuthorizationInfo authorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(weChatAccount);

        if (null == authorizationInfo) {
            logger.error("微信公众号【{}】不存在", weChatAccount);
            return Collections.emptyList();
        }

        String sql = "SELECT `openid`, `appid`, `gmt_date`, `event`, scene_str, `zjb_openid` FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `gmt_date` = ? AND `event` = ? GROUP BY `openid`,`appid`,`gmt_date`,`event`,`zjb_openid`";
        Object[] args = {weChatAccount, gmtDate.toString(), AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue()};
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};

        List<UserInfo> list = jdbcTemplate.query(sql, args, argTypes, new RowMapper<UserInfo>() {
            @Override
            public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
                UserInfo record = new UserInfo();
                record.setGzhName(authorizationInfo.getNickName());
                setValues(rs, record);
                return record;
            }
        });

        for (UserInfo userInfo : list) {
            if (StringUtils.isBlank(userInfo.getZjbOpenId()) && StringUtils.isBlank(userInfo.getSceneStr())) {
                continue;
            }
            AppIdOpenIdIndex appIdOpenIdIndex = appIdOpenIdIndexService.selectByOpenIdAndAppId(userInfo.getOpenid(), weChatAccount);
            if (null == appIdOpenIdIndex) {
                continue;
            }
            if (StringUtils.isEmpty(userInfo.getSceneStr())) {
                userInfo.setSceneStr("zjb");
            }
            userInfo.setNickName(StringUtils.defaultString(appIdOpenIdIndex.getNickName()));
            userInfo.setSex(appIdOpenIdIndex.getSex());
            userInfo.setHeadImgUrl(StringUtils.defaultString(appIdOpenIdIndex.getHeadImgUrl()));
            userInfo.setCountry(StringUtils.defaultString(appIdOpenIdIndex.getCountry()));
            userInfo.setProvince(StringUtils.defaultString(appIdOpenIdIndex.getProvince()));
            userInfo.setCity(StringUtils.defaultString(appIdOpenIdIndex.getCity()));

        }

        for (UserInfo userInfo : list) {
            if (StringUtils.isBlank(userInfo.getZjbOpenId())) {
                continue;
            }

            AuthorizationUserInfoDTO user = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(userInfo.getZjbOpenId());
            if (null == user) {
                continue;
            }

            perfectUserInfo(userInfo, user);
        }

        return list;
    }

    /**
     * 完善授权用户信息
     *
     * @param userInfo
     * @param user
     */
    private void perfectUserInfo(UserInfo userInfo, AuthorizationUserInfoDTO user) {

        StringBuilder updateSql = new StringBuilder();
        List<Object> argList = new ArrayList<>();
        List<Integer> argTypeList = new ArrayList<>();

        if (StringUtils.isBlank(userInfo.getNickName()) && StringUtils.isNotBlank(user.getUserNick())) {
            userInfo.setNickName(user.getUserNick());
            Matcher matcher = PATTERN_NICK_NAME.matcher(user.getUserNick());
            StringBuffer sb = new StringBuffer();
            for (; matcher.find(); ) {
                sb.append(StringUtils.defaultIfBlank(matcher.group(), ""));
            }
            updateSql.append("`nick_name` = ?,");
            argList.add(sb.toString());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isBlank(userInfo.getCity()) && StringUtils.isNotBlank(user.getCity())) {
            userInfo.setCity(user.getCity());
            updateSql.append("`city` = ?,");
            argList.add(user.getCity());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isBlank(userInfo.getProvince()) && StringUtils.isNotBlank(user.getProvince())) {
            userInfo.setProvince(user.getProvince());
            updateSql.append("`province` = ?,");
            argList.add(user.getProvince());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isBlank(userInfo.getCountry()) && StringUtils.isNotBlank(user.getCountry())) {
            userInfo.setCountry(user.getCountry());
            updateSql.append("`country` = ?,");
            argList.add(user.getCountry());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isBlank(userInfo.getHeadImgUrl()) && StringUtils.isNotBlank(user.getHeadimgurl())) {
            userInfo.setHeadImgUrl(user.getHeadimgurl());
            updateSql.append("`head_img_url` = ?,");
            argList.add(user.getHeadimgurl());
            argTypeList.add(Types.VARCHAR);
        }

        if (null == userInfo.getSex() && null != user.getSex()) {
            userInfo.setSex(user.getSex());
            updateSql.append("`sex` = ?,");
            argList.add(user.getSex());
            argTypeList.add(Types.INTEGER);
        }

        if (updateSql.length() == 0) {
            return;
        }

        /*删除最后一个逗号*/
        updateSql.deleteCharAt(updateSql.length() - 1);
        updateSql.insert(0, "UPDATE `zjb_appid_openid_index` SET ");
        updateSql.append(" WHERE zjb_openid = '").append(userInfo.getZjbOpenId()).append('\'');
        Object[] array = new Object[argList.size()];
        for (int i = 0; i < argList.size(); i++) {
            array[i] = argList.get(i);
        }

        int[] arrayType = new int[argTypeList.size()];
        for (int i = 0; i < argTypeList.size(); i++) {
            arrayType[i] = argTypeList.get(i);
        }

        jdbcTemplate.update(updateSql.toString(), array, arrayType);
    }

    /**
     * 设置值
     *
     * @param rs
     * @param userInfo
     * @throws SQLException
     */
    private void setValues(ResultSet rs, UserInfo userInfo) throws SQLException {
        //userInfo.setId(rs.getInt("id"));
        userInfo.setZjbOpenId(rs.getString("zjb_openid"));
        userInfo.setOpenid(rs.getString("openid"));
        userInfo.setGmtDate(rs.getString("gmt_date"));
        userInfo.setSceneStr(rs.getString("scene_str"));
        //userInfo.setNickName(rs.getString("nick_name"));
        //userInfo.setSex(null == rs.getObject("sex") ? null : rs.getInt("sex"));
        //userInfo.setHeadImgUrl(rs.getString("head_img_url"));
        //userInfo.setCountry(rs.getString("country"));
        //userInfo.setProvince(rs.getString("province"));
        //userInfo.setCity(rs.getString("city"));
    }
}
