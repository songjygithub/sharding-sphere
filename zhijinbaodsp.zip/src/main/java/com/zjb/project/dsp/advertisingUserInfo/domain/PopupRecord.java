package com.zjb.project.dsp.advertisingUserInfo.domain;

import java.io.Serializable;

/**
 * @author ：guoj
 * @date ：Created in 2019/8/31 16:50
 * @description： 用户体系首页弹窗记录类
 */

public class PopupRecord implements Serializable {

    private static final long serialVersionUID = 2102271111320547813L;

    /**
     * 用户唯一标识
     */
    private String openId;

    /**
     * 环保等级上次推送等级
     */
    private Integer environmentalProtection;

    /**
     * 成就系统上次推送等级
     */
    private Integer achievement;

    /**
     * 上次推送的取纸次数
     */
    private Integer paperCount;

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Integer getEnvironmentalProtection() {
        return environmentalProtection;
    }

    public void setEnvironmentalProtection(Integer environmentalProtection) {
        this.environmentalProtection = environmentalProtection;
    }

    public Integer getAchievement() {
        return achievement;
    }

    public void setAchievement(Integer achievement) {
        this.achievement = achievement;
    }

    public Integer getPaperCount() {
        return paperCount;
    }

    public void setPaperCount(Integer paperCount) {
        this.paperCount = paperCount;
    }
}
