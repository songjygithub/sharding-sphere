package com.zjb.project.dsp.area.service;

import com.zjb.project.dsp.area.domain.Area;

/**
 * @author songjy
 * @Date 2019/12/09
 **/
public interface IAreaService {

    /**
     * 通过区域代码查询区域信息
     *
     * @param areaCode
     * @return
     */
    Area selectByAreaCode(Integer areaCode);
}
