package com.zjb.project.dsp.backupRecord.controller;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.backupRecord.domain.BackupRecord;
import com.zjb.project.dsp.backupRecord.service.IBackupRecordService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 数据备份记录 信息操作处理
 *
 * @author songjy
 * @date 2020-04-17
 */
@Controller
@RequestMapping("/dsp/backupRecord")
public class BackupRecordController extends BaseController {
    private String prefix = "dsp/backupRecord";

    @Autowired
    private IBackupRecordService backupRecordService;

    @RequiresPermissions("dsp:backupRecord:view")
    @GetMapping()
    public String backupRecord(ModelMap modelMap) {

        modelMap.put("fileDomain", ZjbConstants.File_Domain);

        return prefix + "/backupRecord";
    }

    /**
     * 查询数据备份记录列表
     */
    @RequiresPermissions("dsp:backupRecord:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(BackupRecord backupRecord) {
        startPage();
        List<BackupRecord> list = backupRecordService.selectBackupRecordList(backupRecord);
        return getDataTable(list);
    }

    /**
     * 新增数据备份记录
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存数据备份记录
     */
    @RequiresPermissions("dsp:backupRecord:add")
    @Log(title = "数据备份记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(BackupRecord backupRecord) {
        return toAjax(backupRecordService.insertBackupRecord(backupRecord));
    }

    /**
     * 修改数据备份记录
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        BackupRecord backupRecord = backupRecordService.selectBackupRecordById(id);
        mmap.put("backupRecord", backupRecord);
        return prefix + "/edit";
    }

    /**
     * 修改保存数据备份记录
     */
    @RequiresPermissions("dsp:backupRecord:edit")
    @Log(title = "数据备份记录", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(BackupRecord backupRecord) {
        return toAjax(backupRecordService.updateBackupRecord(backupRecord));
    }

    /**
     * 删除数据备份记录
     */
    @RequiresPermissions("dsp:backupRecord:remove")
    @Log(title = "数据备份记录", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(backupRecordService.deleteBackupRecordByIds(ids));
    }

    /**
     * 删除数据备份记录
     */
    @RequiresPermissions("dsp:backupRecord:add")
    @Log(title = "数据备份记录", businessType = BusinessType.DELETE)
    @PostMapping("/import")
    @ResponseBody
    public AjaxResult importBackup(String ids) {

        int r = 0;
        String[] arr = StringUtils.split(ids, ',');

        for (String id : arr) {
            BackupRecord backupRecord = backupRecordService.selectBackupRecordById(Long.parseLong(id));
            r += backupRecordService.importAdvertisingTargetInfo(backupRecord);
        }

        return toAjax(r);
    }

}
