package com.zjb.project.dsp.advertisingPlanPepole.service;

import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 广告投放人群定向 服务层
 *
 * @author songjy
 * @date 2019-07-12
 */
public interface IAdvertisingPlanPepoleService {
    /**
     * 查询广告投放人群定向信息
     *
     * @param id 广告投放人群定向ID
     * @return 广告投放人群定向信息
     */
    AdvertisingPlanPepole selectAdvertisingPlanPepoleById(Integer id);

    /**
     * 查询广告投放人群定向列表
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 广告投放人群定向集合
     */
    List<AdvertisingPlanPepole> selectAdvertisingPlanPepoleList(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 新增广告投放人群定向
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 结果
     */
    int insertAdvertisingPlanPepole(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 修改广告投放人群定向
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 结果
     */
    int updateAdvertisingPlanPepole(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 删除广告投放人群定向信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanPepoleByIds(String ids);

    /**
     * 人群定向正则对应的预编译类(Pattern)
     *
     * @return Map<regex , Pattern>
     */
    Map<String, Pattern> peopleRegexMapPattern();

    /**
     * 添加人群定向正则对应的预编译类(Pattern)
     *
     * @param advertisingPlanPepole
     */
    void addPattern(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 移除人群定向正则对应的预编译类(Pattern)
     *
     * @param advertisingPlanPepole
     */
    void removePattern(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 通过广告计划ID查询人群定向信息
     *
     * @param planId
     * @return
     */
    AdvertisingPlanPepole selectAdvertisingPlanPepoleByPlanId(String planId);

    /**
     * 重新载入正则及对应的广告计划
     */
    void reloadPatternPlan();

    /**
     * 广告计划对应的人群正则
     *
     * @param planId 广告计划
     * @return 正则
     */
    Pattern pattern(String planId);
}
