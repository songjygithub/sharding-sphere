package com.zjb.project.dsp.gzhxcxInfo.domain;

import com.zjb.framework.web.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 公众号小程序表 zjb_gzhxcx_info
 * 
 * @author zjb
 * @date 2018-09-14
 */
public class GzhxcxInfo extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	//公众号编号
	private String gzhId;
	/** 公众号名称 */
	private String name;
	/** 类型 */
	private Integer type;
	/** appid */
	private String appid;
	/** appsecret */
	private String appsecret;
	/** 临时二维码的内容 */
	private String showQrcodeUrl;
	/** 临时二维码的内容图片url */
	private String showQrcodeImgUrl;
	/** 关注后推送的消息 */
	private String subscribeMsg;

	public String getGzhId() {
		return gzhId;
	}

	public void setGzhId(String gzhId) {
		this.gzhId = gzhId;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setType(Integer type) 
	{
		this.type = type;
	}

	public Integer getType() 
	{
		return type;
	}
	public void setAppid(String appid) 
	{
		this.appid = appid;
	}

	public String getAppid() 
	{
		return appid;
	}
	public void setAppsecret(String appsecret) 
	{
		this.appsecret = appsecret;
	}

	public String getAppsecret() 
	{
		return appsecret;
	}

	public String getShowQrcodeImgUrl() {
		return showQrcodeImgUrl;
	}
	public void setSubscribeMsg(String subscribeMsg)
	{
		this.subscribeMsg = subscribeMsg;
	}

	public String getSubscribeMsg()
	{
		return subscribeMsg;
	}

	public void setShowQrcodeImgUrl(String showqrcode_imgurl) {
		this.showQrcodeImgUrl = showqrcode_imgurl;
	}

	public String getShowQrcodeUrl() {
		return showQrcodeUrl;
	}

	public void setShowQrcodeUrl(String showQrcodeUrl) {
		this.showQrcodeUrl = showQrcodeUrl;
	}

	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
				.append("id", getId())
				.append("name", getName())
				.append("type", getType())
				.append("appid", getAppid())
				.append("appsecret", getAppsecret())
				.append("subscribeMsg", getSubscribeMsg())
				.append("createrId", getCreaterId())
				.append("modifierId", getModifierId())
				.append("gmtCreated", getGmtCreated())
				.append("gmtModified", getGmtModified())
				.append("deleted", getDeleted())
				.toString();
	}
}
