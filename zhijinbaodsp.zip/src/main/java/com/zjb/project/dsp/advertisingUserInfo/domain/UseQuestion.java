package com.zjb.project.dsp.advertisingUserInfo.domain;

import java.io.Serializable;

/**
 * @author ：guoj
 * @date ：Created in 2019/8/21 16:39
 * @description： 新手展示问题
 */

public class UseQuestion implements Serializable {
    private static final long serialVersionUID = 185103114746331274L;

    /** 问题名称 */
    private String question;

    /** 跳转到帮助中心的章节位置 */
    private String helpCenterChapter;

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getHelpCenterChapter() {
        return helpCenterChapter;
    }

    public void setHelpCenterChapter(String helpCenterChapter) {
        this.helpCenterChapter = helpCenterChapter;
    }
}
