package com.zjb.project.dsp.autorizeCompany.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
									import java.util.Date;

/**
 * 授权公司主体表 zjb_autorize_company
 * 
 * @author jiangbingjie
 * @date 2020-02-28
 */
public class AutorizeCompany extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 主键 */
	private Integer id;
	/** 公司名称 */
	private String companyName;
	/** 开放平台APPID */
	private String appId;
	/** 开放平台密钥 */
	private String appSecret;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setCompanyName(String companyName) 
	{
		this.companyName = companyName;
	}

	public String getCompanyName() 
	{
		return companyName;
	}
	public void setAppId(String appId) 
	{
		this.appId = appId;
	}

	public String getAppId() 
	{
		return appId;
	}
	public void setAppSecret(String appSecret) 
	{
		this.appSecret = appSecret;
	}

	public String getAppSecret() 
	{
		return appSecret;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("companyName", getCompanyName())
            .append("appId", getAppId())
            .append("appSecret", getAppSecret())
            .append("createrId", getCreaterId())
            .append("modifierId", getModifierId())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("deleted", getDeleted())
            .toString();
    }
}
