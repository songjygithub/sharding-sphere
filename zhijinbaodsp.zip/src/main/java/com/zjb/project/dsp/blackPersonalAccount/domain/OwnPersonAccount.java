package com.zjb.project.dsp.blackPersonalAccount.domain;

import com.zjb.common.utils.StringUtils;

import java.io.Serializable;

/**
 * 纸巾宝平台个人号
 * @author jiangbingjie
 * @date 2020/3/21 1:24 下午
 */
public class OwnPersonAccount implements Serializable {
    private static final long serialVersionUID = 1L;
    /** 个人号唯一标识 */
    private String personalAppId;
    /** 个人号名称 */
    private String personalNickName;
    /** 个人号来源通道(参考字典) */
    private String personalSourceType;
    /**用户openid*/
    private String openId;
    /**扫码流水号*/
    private String randomNum;

    public String getPersonalAppId() {
        return personalAppId;
    }

    public void setPersonalAppId(String personalAppId) {
        this.personalAppId = personalAppId;
    }

    public String getPersonalNickName() {
        return personalNickName;
    }

    public void setPersonalNickName(String personalNickName) {
        this.personalNickName = personalNickName;
    }

    public String getPersonalSourceType() {
        return personalSourceType;
    }

    public void setPersonalSourceType(String personalSourceType) {
        this.personalSourceType = personalSourceType;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }
}
