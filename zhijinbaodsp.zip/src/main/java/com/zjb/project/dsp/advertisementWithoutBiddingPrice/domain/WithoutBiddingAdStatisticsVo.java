package com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain;

/**
 * 非竞价广告统计
 * @author jiangbingjie
 * @date 2020/4/2 4:43 下午
 */
public class WithoutBiddingAdStatisticsVo {

    /** 展示次数 */
    private Integer showCount;
    /** 展示人数 */
    private Integer showPersonCount;
    /** 转化点击次数 */
    private Integer clickCount;
    /** 转化点击人数 */
    private Integer clickPersonCount;

    public Integer getShowCount() {
        return showCount;
    }

    public void setShowCount(Integer showCount) {
        this.showCount = showCount;
    }

    public Integer getShowPersonCount() {
        return showPersonCount;
    }

    public void setShowPersonCount(Integer showPersonCount) {
        this.showPersonCount = showPersonCount;
    }

    public Integer getClickCount() {
        return clickCount;
    }

    public void setClickCount(Integer clickCount) {
        this.clickCount = clickCount;
    }

    public Integer getClickPersonCount() {
        return clickPersonCount;
    }

    public void setClickPersonCount(Integer clickPersonCount) {
        this.clickPersonCount = clickPersonCount;
    }
}
