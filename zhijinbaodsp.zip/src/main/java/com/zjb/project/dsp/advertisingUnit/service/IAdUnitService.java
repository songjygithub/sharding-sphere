package com.zjb.project.dsp.advertisingUnit.service;

import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;

import java.util.List;

/**
 * @author songjy
 * @date 2020-03-07
 */
public interface IAdUnitService {

    /**
     * 根据微信个号编号查询广告单元
     *
     * @param weChatPersonalId 微信个号编号
     * @return
     */
    List<AdvertisingUnit> findByWeChatPersonalId(String weChatPersonalId);
}
