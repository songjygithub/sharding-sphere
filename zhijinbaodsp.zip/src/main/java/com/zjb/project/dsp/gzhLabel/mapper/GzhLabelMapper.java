package com.zjb.project.dsp.gzhLabel.mapper;

import com.zjb.project.dsp.gzhLabel.domain.GzhLabel;
import java.util.List;	

/**
 * 公众号粉丝标签详情 数据层
 * 
 * @author shenlong
 * @date 2019-11-08
 */
public interface GzhLabelMapper 
{
	/**
     * 查询公众号粉丝标签详情信息
     * 
     * @param id 公众号粉丝标签详情ID
     * @return 公众号粉丝标签详情信息
     */
	public GzhLabel selectGzhLabelById(Integer id);
	
	/**
     * 查询公众号粉丝标签详情列表
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 公众号粉丝标签详情集合
     */
	public List<GzhLabel> selectGzhLabelList(GzhLabel gzhLabel);
	
	/**
     * 新增公众号粉丝标签详情
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 结果
     */
	public int insertGzhLabel(GzhLabel gzhLabel);
	
	/**
     * 修改公众号粉丝标签详情
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 结果
     */
	public int updateGzhLabel(GzhLabel gzhLabel);
	
	/**
     * 删除公众号粉丝标签详情
     * 
     * @param id 公众号粉丝标签详情ID
     * @return 结果
     */
	public int deleteGzhLabelById(Integer id);
	
	/**
     * 批量删除公众号粉丝标签详情
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhLabelByIds(String[] ids);
	
}