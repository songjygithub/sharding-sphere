package com.zjb.project.dsp.advertisingCombination.controller;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_OK;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.PerformanceSensitive;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.service.DictService;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombinationUnit;
import com.zjb.project.dsp.advertisingCombination.service.IAdvertisingCombinationService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;

/**
 * 广告方案-支付宝 信息操作处理
 *
 * @author zjb
 * @date 2019-07-13
 */
@Controller
@RequestMapping("/zjb/advertisingCombination")
public class AdvertisingCombinationController extends BaseController {
    private String prefix = "zjb/advertisingCombination";

    @Autowired
    private IAdvertisingCombinationService advertisingCombinationService;
    @Autowired
    private DictService dataService;
    @Autowired
    private IAdvertisingUnitService advertisingUnitService;
    @Autowired
    private IAdvertisingPlanService advertisingPlanService;

    @RequiresPermissions("zjb:advertisingCombination:view")
    @GetMapping()
    public String advertisingCombination() {
        return prefix + "/advertisingCombination";
    }

    /**
     * 查询广告方案列表
     */
    @RequiresPermissions("zjb:advertisingCombination:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingCombination advertisingCombination) {
        startPage();
        List<AdvertisingCombination> list = advertisingCombinationService.selectAdvertisingCombinationList(advertisingCombination);
        AdvertisingPlan advertisingPlan = new AdvertisingPlan();
        for (AdvertisingCombination advertisingCombination_db : list) {
            //已配置广告计划数量
            advertisingPlan.setCombinationId(advertisingCombination_db.getId());
            advertisingPlan.setAdvertisingStatus("1");
            List<AdvertisingPlan> advertisingPlans = advertisingPlanService.selectAdvertisingPlanList(advertisingPlan);
            advertisingCombination_db.setAdvertisingPlanNum(advertisingPlans.size());
        }
        return getDataTable(list);
    }

    /**
     * 新增广告方案
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告方案
     */
    @RequiresPermissions("zjb:advertisingCombination:add")
    @Log(title = "广告方案", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingCombination advertisingCombination) {
        advertisingCombination.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        return toAjax(advertisingCombinationService.insertAdvertisingCombination(advertisingCombination));
    }

    /**
     * 修改广告方案
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingCombination advertisingCombination = advertisingCombinationService.selectAdvertisingCombinationById(id);
        mmap.put("advertisingCombination", advertisingCombination);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告方案
     */
    @RequiresPermissions("zjb:advertisingCombination:edit")
    @Log(title = "广告方案", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingCombination advertisingCombination) {
        advertisingCombination.setUpdateBaseParams(getUserId().intValue());
        return toAjax(advertisingCombinationService.updateAdvertisingCombination(advertisingCombination));
    }

    /**
     * 删除广告方案
     */
    @RequiresPermissions("zjb:advertisingCombination:remove")
    @Log(title = "广告方案", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        //删除所属广告方案详情
        int result = advertisingCombinationService.deleteAdvertisingCombinationUnitByCombinationId(ids);
        result += advertisingCombinationService.deleteAdvertisingCombinationByIds(ids);
        return toAjax(result);
    }

    /**
     * 详情页面
     */
    @PerformanceSensitive("zjb:advertisingCombination:getDetails")
    @GetMapping("/getDetails")
    public String getDetails() {
        return prefix + "/getDetails";
    }

    /**
     * 广告方案详情
     */
    @PerformanceSensitive("zjb:advertisingCombination:combinationDetails")
    @PostMapping("/combinationDetails/{combinationId}")
    @ResponseBody
    public AjaxResult getCombinationDetails(@PathVariable("combinationId") Integer combinationId) {
        Map<String, Object> map = new HashMap<>();
        AdvertisingCombination advertisingCombination = advertisingCombinationService.selectAdvertisingCombinationById(combinationId);
        if (null != advertisingCombination) {
            if (null != advertisingCombination.getProgramType()) {
                String combinationTypeName = dataService.getLabel(ZjbDictionaryTypeEnum.PROGRAM_TYPE.getType(), advertisingCombination.getProgramType().toString());//广告方案名称
                advertisingCombination.setProgramTypeName(combinationTypeName);//广告方案类型
            }
            map.put("adDombination", advertisingCombination);//广告方案
            AdvertisingCombinationUnit advertisingCombinationUnit = new AdvertisingCombinationUnit();
            advertisingCombinationUnit.setCombinationId(combinationId);//广告方案id
            List<AdvertisingCombinationUnit> advertisingCombinationUnits = advertisingCombinationService.selectAdvertisingCombinationUnitList(advertisingCombinationUnit);
            Map<String, List<AdvertisingCombinationUnit>> adSpeaceMap = new HashMap<>();


            for (AdvertisingCombinationUnit advertisingCombinationUnit_db : advertisingCombinationUnits) {
                List<AdvertisingCombinationUnit> advertisingCombinationUnitList = new ArrayList<>();
                if ("0101".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    if (null != adSpeaceMap.get("0101")) {
                        advertisingCombinationUnitList = adSpeaceMap.get("0101");
                    }
                    advertisingCombinationUnitList.add(advertisingCombinationUnit_db);
                    adSpeaceMap.put("0101", advertisingCombinationUnitList);
                    map.put("lunbo", adSpeaceMap.get("0101"));
                } else if ("0102".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    if (null != adSpeaceMap.get("0102")) {
                        advertisingCombinationUnitList = adSpeaceMap.get("0102");
                    }
                    advertisingCombinationUnitList.add(advertisingCombinationUnit_db);
                    adSpeaceMap.put("0102", advertisingCombinationUnitList);
                    map.put("shouye", adSpeaceMap.get("0102"));
                } else if ("0103".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    map.put("xuanfu", advertisingCombinationUnit_db);
                } else if ("0104".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    map.put("saoma", advertisingCombinationUnit_db);
                } else if ("0105".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    if (null != adSpeaceMap.get("0105")) {
                        advertisingCombinationUnitList = adSpeaceMap.get("0105");
                    }
                    advertisingCombinationUnitList.add(advertisingCombinationUnit_db);
                    adSpeaceMap.put("0105", advertisingCombinationUnitList);
                    map.put("tab", adSpeaceMap.get("0105"));
                } else if ("0106".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    map.put("wenzilian", advertisingCombinationUnit_db);
                } else if ("0107".equals(advertisingCombinationUnit_db.getAdSpaceIdentifier())) {
                    map.put("banner", advertisingCombinationUnit_db);
                }
            }
            if (null == map.get("lunbo")) {
                map.put("lunbo", "");
            }
            if (null == map.get("shouye")) {
                map.put("shouye", "");
            }
            if (null == map.get("xuanfu")) {
                map.put("xuanfu", "");
            }
            if (null == map.get("saoma")) {
                map.put("saoma", "");
            }
            if (null == map.get("tab")) {
                map.put("tab", "");
            }
            if (null == map.get("wenzilian")) {
                map.put("wenzilian", "");
            }
            if (null == map.get("banner")) {
                map.put("banner", "");
            }
        }
        return success(map);
    }

    /**
     * 添加广告方案详情,拉取广告
     * */
	/*@GetMapping("/addDection/{combinationId}")
	public String addDection(@PathVariable("combinationId") Integer combinationId,ModelMap modelMap){
		modelMap.put("combinationId",combinationId);
		return prefix + "/addDection";
	}*/

    /**
     * 广告列表
     */
    @PostMapping("/getAdList")
    @ResponseBody
    public AjaxResult getAdList(AdvertisingUnit advertisingUnit) {
        advertisingUnit.setAdUseStatus(ZjbDictionaryEnum.AD_USE_YES.getValue());//启用状态
        //advertisingUnit.setAdUseType(1);//使用标识
        List<AdvertisingUnit> advertisingUnits = advertisingUnitService.selectAdvertisingUnitList(advertisingUnit);
        return success(advertisingUnits);
    }

    /**
     * 添加广告方案详情
     */
    @PerformanceSensitive("zjb:advertisingCombination:addDection")
    @PostMapping("/addDection")
    @ResponseBody
    public AjaxResult addDection(AdvertisingCombinationUnit advertisingCombinationUnit) {
        advertisingCombinationUnit.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        return toAjax(advertisingCombinationService.insertAdvertisingCombinationUnit(advertisingCombinationUnit));
    }

    /**
     * 删除广告方案详情
     */
    @RequiresPermissions("zjb:advertisingCombination:delDection")
    @Log(title = "广告方案详情", businessType = BusinessType.DELETE)
    @PostMapping("/delDection")
    @ResponseBody
    public AjaxResult delDection(String ids) {
        return toAjax(advertisingCombinationService.deleteAdvertisingCombinationUnitByIds(ids));
    }

    /**
     * 更换广告方案详情
     */
    @PostMapping("/modifyDection")
    @ResponseBody
    public AjaxResult modifyDection(AdvertisingCombinationUnit advertisingCombinationUnit) {

        int r = advertisingCombinationService.modifyDetails(advertisingCombinationUnit);

        restartAdvertisingPlan(advertisingCombinationUnit);

        advertisingPlanService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param advertisingCombinationUnit
     */
    private void restartAdvertisingPlan(AdvertisingCombinationUnit advertisingCombinationUnit) {
        List<AdvertisingCombinationUnit> list = advertisingCombinationService.selectByUnitId(advertisingCombinationUnit.getAdUnitId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnit combinationUnit : list) {

            AdvertisingPlan advertisingPlan = new AdvertisingPlan();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());

            List<AdvertisingPlan> advertisingPlans = advertisingPlanService.selectAdvertisingPlanList(advertisingPlan);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlan plan : advertisingPlans) {

                String adAppIdOld = plan.getAdAppId();

                List<ComponentAuthorizationInfo> componentAuthorizationInfos = advertisingCombinationService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
                if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
                    plan.setWeChatOfficialAccounts(String.join(",", componentAuthorizationInfos.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
                    if (null == plan.getRadioWeChatOfficialAccount()
                            || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(plan.getRadioWeChatOfficialAccount())) {
                        plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue());
                    }
                    plan.setAdAppId(componentAuthorizationInfos.get(0).getAppId());
                } else {
                    plan.setRadioWeChatOfficialAccount(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue());
                    plan.setWeChatOfficialAccounts(null);
                    plan.setAdAppId(null);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanService.updateAdvertisingPlan(plan);

                if (!StringUtils.equals(adAppIdOld, plan.getAdAppId()) && plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanService.reloadPattern(plan.getPlanId());
                }

            }

        }
    }

    /**
     * 根据主键ID查询广告方案信息
     */
    @GetMapping("/find/{id}")
    @ResponseBody
    public AjaxResult findById(@PathVariable("id") Integer id) {
        AdvertisingCombination advertisingCombination = advertisingCombinationService.selectAdvertisingCombinationById(id);
        List<ComponentAuthorizationInfo> list = advertisingCombinationService.isWeChatOfficialAccountOnSpacePaperOutput(id);

        AjaxResult ajaxResult = success(advertisingCombination);
        ajaxResult.put("componentAuthorizationInfos", list);

        return ajaxResult;
    }

}
