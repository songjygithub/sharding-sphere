package com.zjb.project.dsp.cfgDistrict.controller;

import java.util.List;

import com.zjb.project.dsp.cfgDistrict.domain.CfgDistrict;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.cfgDistrict.service.ICfgDistrictService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 省市区 信息操作处理
 * 
 * @author zjb
 * @date 2018-08-15
 */
@Controller
@RequestMapping("/zjbdsp/cfgDistrict")
public class CfgDistrictController extends BaseController
{
    private String prefix = "zjb/cfgDistrict";
	
	@Autowired
	private ICfgDistrictService cfgDistrictService;
	
	@RequiresPermissions("zjb:cfgDistrict:view")
	@GetMapping()
	public String cfgDistrict()
	{
	    return prefix + "/cfgDistrict";
	}
	
	/**
	 * 查询省市区列表
	 */
	//@RequiresPermissions("zjb:cfgDistrict:list")
	@GetMapping("/list")
	@ResponseBody
	public TableDataInfo list(CfgDistrict cfgDistrict)
	{
		startPage();
        List<CfgDistrict> list = cfgDistrictService.selectCfgDistrictList(cfgDistrict);
        //List<Map<Integer,String>>
		return getDataTable(list);
	}
	
	/**
	 * 新增省市区
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存省市区
	 */
	@RequiresPermissions("zjb:cfgDistrict:add")
	@Log(title = "省市区", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(CfgDistrict cfgDistrict)
	{		
		return toAjax(cfgDistrictService.insertCfgDistrict(cfgDistrict));
	}

	/**
	 * 修改省市区
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		CfgDistrict cfgDistrict = cfgDistrictService.selectCfgDistrictById(id);
		mmap.put("cfgDistrict", cfgDistrict);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存省市区
	 */
	@RequiresPermissions("zjb:cfgDistrict:edit")
	@Log(title = "省市区", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(CfgDistrict cfgDistrict)
	{		
		return toAjax(cfgDistrictService.updateCfgDistrict(cfgDistrict));
	}
	
	/**
	 * 删除省市区
	 */
	@RequiresPermissions("zjb:cfgDistrict:remove")
	@Log(title = "省市区", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(cfgDistrictService.deleteCfgDistrictByIds(ids));
	}
	
}
