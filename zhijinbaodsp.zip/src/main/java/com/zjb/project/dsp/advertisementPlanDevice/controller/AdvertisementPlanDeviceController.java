package com.zjb.project.dsp.advertisementPlanDevice.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import com.zjb.project.dsp.advertisementPlanDevice.service.IAdvertisementPlanDeviceService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 非竞价广告投放设备定向 信息操作处理
 * 
 * @author Nigel Yang
 * @date 2020-05-09
 */
@Controller
@RequestMapping("/dsp/advertisementPlanDevice")
public class AdvertisementPlanDeviceController extends BaseController
{
    private String prefix = "dsp/advertisementPlanDevice";
	
	@Autowired
	private IAdvertisementPlanDeviceService advertisementPlanDeviceService;
	
	@RequiresPermissions("dsp:advertisementPlanDevice:view")
	@GetMapping()
	public String advertisementPlanDevice()
	{
	    return prefix + "/advertisementPlanDevice";
	}
	
	/**
	 * 查询非竞价广告投放设备定向列表
	 */
	@RequiresPermissions("dsp:advertisementPlanDevice:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertisementPlanDevice advertisementPlanDevice)
	{
		startPage();
        List<AdvertisementPlanDevice> list = advertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
		return getDataTable(list);
	}
	
	/**
	 * 新增非竞价广告投放设备定向
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存非竞价广告投放设备定向
	 */
	@RequiresPermissions("dsp:advertisementPlanDevice:add")
	@Log(title = "非竞价广告投放设备定向", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AdvertisementPlanDevice advertisementPlanDevice)
	{		
		return toAjax(advertisementPlanDeviceService.insertAdvertisementPlanDevice(advertisementPlanDevice));
	}

	/**
	 * 修改非竞价广告投放设备定向
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AdvertisementPlanDevice advertisementPlanDevice = advertisementPlanDeviceService.selectAdvertisementPlanDeviceById(id);
		mmap.put("advertisementPlanDevice", advertisementPlanDevice);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存非竞价广告投放设备定向
	 */
	@RequiresPermissions("dsp:advertisementPlanDevice:edit")
	@Log(title = "非竞价广告投放设备定向", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AdvertisementPlanDevice advertisementPlanDevice)
	{		
		return toAjax(advertisementPlanDeviceService.updateAdvertisementPlanDevice(advertisementPlanDevice));
	}
	
	/**
	 * 删除非竞价广告投放设备定向
	 */
	@RequiresPermissions("dsp:advertisementPlanDevice:remove")
	@Log(title = "非竞价广告投放设备定向", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertisementPlanDeviceService.deleteAdvertisementPlanDeviceByIds(ids));
	}
	
}
