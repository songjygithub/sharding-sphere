package com.zjb.project.dsp.grhAppidOpenidIndex.service;

import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.grhAppidOpenidIndex.domain.GrhAppidOpenidIndex;

/**
 * @author jiangbingjie
 * @date 2020/3/20 4:30 下午
 */
public interface IGrhAppidOpenidIndexService {
    /**
     * 根据zjbOpenId和个人号查询记录
     *
     * @param zjbOpenId
     * @param personalAppid
     * @return
     */
   GrhAppidOpenidIndex selectByZjbOpenIdAndPersonalAppId(String zjbOpenId, String personalAppid);
}
