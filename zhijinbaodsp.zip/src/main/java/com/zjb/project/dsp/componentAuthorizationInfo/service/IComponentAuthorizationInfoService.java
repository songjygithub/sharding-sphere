package com.zjb.project.dsp.componentAuthorizationInfo.service;


import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;

import java.util.List;

/**
 * 公众号或小程序的授权
 * 服务层
 *
 * @author zjb
 * @date 2019-07-09
 */
public interface IComponentAuthorizationInfoService {

    /**
     * 查询公众号或小程序的授权
     * 信息
     *
     * @param id 公众号或小程序的授权
     *           ID
     * @return 公众号或小程序的授权
     * 信息
     */
    ComponentAuthorizationInfo selectComponentAuthorizationInfoById(Integer id);

    /**
     * 通过业务主键查询公众号或小程序的授权
     *
     * @param componentId
     * @return
     */
    ComponentAuthorizationInfo selectByComponentId(String componentId);

    /**
     * 查询公众号或小程序的授权信息
     *
     * @param appId 公众号或小程序的授权ID
     * @return 公众号或小程序的授权信息
     */
    ComponentAuthorizationInfo selectComponentAuthorizationInfoByAppId(String appId);

    /**
     * 查询公众号或小程序的授权
     * 列表
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 公众号或小程序的授权
     * 集合
     */
    List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoList(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 新增公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 结果
     */
    int insertComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 修改公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 结果
     */
    int updateComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo);

    int updateComponentAuthorizationInfoLabel(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 删除公众号或小程序的授权
     * 信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteComponentAuthorizationInfoByIds(String ids);

    /**
     * 通过主键ID集合查询公众号信息
     *
     * @param ids
     * @return
     */
    List<ComponentAuthorizationInfo> findByIds(Integer[] ids);

    /**
     * 日关注量清零且状态更新为生效中
     */
    void cleanDayFollowAmount();

    /**
     * @param componentAuthorizationInfo
     * @return
     */
    List<AdvertisingUnit> selectUnit(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 通过公众号名称查找记录
     *
     * @param nickName
     * @return
     */
    List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoByName(String nickName);

    /**
     * 清空本地缓存
     *
     * @param info
     */
    void clearLocalCache(ComponentAuthorizationInfo info);

    /**
     * 清空本地所有缓存
     */
    void clearAllLocalCache();

    int deleteComponentAuthorizationInfoPickPaperUrl(Integer id);

    /**
     * @param appId 微信公众号
     * @return 截至到昨日公众号关注数量
     */
    int countSubscribeBeforeToday(String appId);
}
