package com.zjb.project.dsp.advertisingUnitFans.service;

import com.zjb.project.dsp.advertisingUnit.service.IAdUnitService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 粉丝通广告池 服务层
 *
 * @author shenlong
 * @date 2019-11-22
 */
public interface IAdvertisingUnitFansService extends IAdUnitService {
    /**
     * 查询粉丝通广告池信息
     *
     * @param id 粉丝通广告池ID
     * @return 粉丝通广告池信息
     */
    AdvertisingUnitFans selectAdvertisingUnitFansById(Integer id);

    /**
     * 查询粉丝通广告池列表
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 粉丝通广告池集合
     */
    List<AdvertisingUnitFans> selectAdvertisingUnitFansList(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 新增粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    int insertAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 修改粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    int updateAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 删除粉丝通广告池信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingUnitFansByIds(String ids);

    /**
     * 通过广告方案ID查询广告单元
     *
     * @param id
     * @return
     */
    List<AdvertisingUnitFans> selectAdvertisingUnitListByCombinationId(Integer id);

    /**
     * @param weChatOfficialAccount 微信公众号
     * @return
     */
    List<AdvertisingUnitFans> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount);

    /**
     * 根据广告池业务主键ID查询粉丝通广告池信息
     *
     * @param adId 粉丝通广告池业务主键ID
     * @return 粉丝通广告池信息
     */
    AdvertisingUnitFans selectAdvertisingUnitFansByAdId(String adId);

    /**
     * 获取公众号关注后推送消息
     * @param appId appid
     * @return gzh_subscribe_msg
     * */
    String getSubMsg(String appId);
}
