package com.zjb.project.dsp.advertisingUserInfo.service;

import static com.zjb.common.constant.AdvertisingConstants.KEY_HANDLE_ALI_PAY_PLAN_TO_FANS_PLAN;
import static com.zjb.common.constant.ZjbConstantsRedis.FANS_WE_CHAT_ACCOUNT_NOTICE_INFO_DELAY;
import static com.zjb.common.constant.ZjbConstantsRedis.USER_CONSUMED_LEAF_SERIAL_NUM;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbConfigEnum.DOMAIN_ADDRESS_AUTH_THROUGH_TOP;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_DSP_LEAF_INDEX_URL;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_IN_EX_LEAF_REFUND;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PUBLIC_LEAF_COMBINATION_UNIT;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_UNIT_TYPE_FANS;
import static com.zjb.common.enums.ZjbDictionaryEnum.LEAF_CONSUME_WAY_PL;
import static com.zjb.common.enums.ZjbDictionaryEnum.LEAF_CONSUME_WAY_PR;
import static com.zjb.common.enums.ZjbDictionaryEnum.LEAF_INCOME_EXPENDITURE_PASS;
import static com.zjb.common.enums.ZjbDictionaryEnum.YES;
import static com.zjb.common.enums.ZjbDictionaryEnum.ZJB_PR_OUT_PAPER_FAIL;
import static com.zjb.common.enums.ZjbDictionaryEnum.ZJB_PR_OUT_PAPER_SUCCESS;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;
import static com.zjb.framework.config.RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON;
import static com.zjb.project.dsp.rpcrequest.service.IRpcRequestService.UK_EVENT_SERIAL_NUM;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alicloud.openservices.tablestore.model.Column;
import com.alicloud.openservices.tablestore.model.GetRangeRequest;
import com.alicloud.openservices.tablestore.model.GetRangeResponse;
import com.alicloud.openservices.tablestore.model.PrimaryKeyBuilder;
import com.alicloud.openservices.tablestore.model.PrimaryKeyValue;
import com.alicloud.openservices.tablestore.model.RangeRowQueryCriteria;
import com.alicloud.openservices.tablestore.model.Row;
import com.google.zxing.WriterException;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.constant.ZjbVipConstants;
import com.zjb.common.enums.ZjbConfigEnum;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.exception.base.BaseException;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.ZxingUtils;
import com.zjb.common.utils.bean.BeanUtils;
import com.zjb.common.utils.http.HttpClient;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.TableStoreClientUtils;
import com.zjb.framework.web.mgservice.BaseMongoDbServiceImpl;
import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.common.ad.domain.GeographicLocation;
import com.zjb.project.common.ad.domain.GeographicLocationResponse;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.common.miniConfig.domain.WeChatSms;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingTargetInfo.domain.ZjbPlRequest;
import com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserDayRecord;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.project.dsp.advertisingUserInfo.domain.PersonalAchievement;
import com.zjb.project.dsp.advertisingUserInfo.domain.PopupRecord;
import com.zjb.project.dsp.advertisingUserInfo.domain.UseQuestion;
import com.zjb.project.dsp.advertisingUserInfo.domain.WeChatAndAlipayOpenId;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.feign.service.IFeignAdminCoreService;
import com.zjb.project.dsp.leafIncomeExpenditureDetails.domain.LeafIncomeExpenditureDetails;
import com.zjb.project.dsp.leafIncomeExpenditureDetails.service.ILeafIncomeExpenditureDetailsService;
import com.zjb.project.dsp.leafTask.domain.LeafTask;
import com.zjb.project.dsp.leafTask.mapper.LeafTaskMapper;
import com.zjb.project.dsp.pushInfo.domain.PushInfo;
import com.zjb.project.dsp.pushInfo.service.IPushInfoService;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.qqPersonal.mapper.QqPersonalMapper;
import com.zjb.project.dsp.rpcrequest.domain.RpcRequest;
import com.zjb.project.dsp.scanUserBackup.domain.ScanUserBackup;
import com.zjb.project.dsp.scanUserBackup.mapper.ScanUserBackupMapper;
import com.zjb.project.dsp.userEnvironmentalProtection.domain.EnvironmentalProtection;
import com.zjb.project.dsp.userEnvironmentalProtection.service.IUserEnvironmentalProtectionService;
import com.zjb.project.dsp.vipidList.domain.UserFollowSubscription;
import com.zjb.project.dsp.vipidList.domain.UserVipOpenInfo;
import com.zjb.project.dsp.vipidList.domain.VipidList;
import com.zjb.project.dsp.vipidList.service.IVipidListService;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.mapper.WeChatPersonalMapper;
import com.zjb.project.dsp.zjbprresponse.domain.ZjbPrResponse;
import com.zjb.project.system.config.service.IConfigService;
import com.zjb.project.system.dict.domain.DictData;
import com.zjb.project.system.dict.service.IDictDataService;

import cn.hutool.extra.mail.MailUtil;

/**
 * @author songjy
 * @date 2019/08/08
 */
@Service
public class AdvertisingUserInfoServiceImpl extends BaseMongoDbServiceImpl<AdvertisingUserInfo> implements IAdvertisingUserInfoService, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 展示通广告数据迁移至粉丝通
     */
    private Map<String, String> aliPayToFansPlan = new HashMap<>();

    @Autowired
    private IDictDataService dictDataService;
    @Autowired
    private IVipidListService vipidListService;
    @Autowired
    private IUserEnvironmentalProtectionService userEnvironmentalProtectionService;
    @Autowired
    private IPushInfoService pushInfoService;
    @Autowired
    private LeafTaskMapper leafTaskMapper;
    @Autowired
    private IConfigService configService;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private WeChatPersonalMapper weChatPersonalMapper;
    @Autowired
    private QqPersonalMapper qqPersonalMapper;
    @Autowired
    private ScanUserBackupMapper scanUserBackupMapper;
    @Autowired
    private IFeignAdminCoreService feignAdminCoreService;

    /**
     * 普通取纸赠送小树叶数量
     */
    private int IN_LEAF_GENERAL_AMOUNT = 5;

    @Autowired
    private ILeafIncomeExpenditureDetailsService leafIncomeExpenditureDetailsService;

    @Override
    protected Class<AdvertisingUserInfo> getEntityClass() {
        return AdvertisingUserInfo.class;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        dataMigration();
    }

    /**
     * 微信小程序广告，原广告计划记录的数据迁移：展示通>>粉丝通
     */
    private void dataMigration() {
        aliPayToFansPlan.put("01123", "0234");
        aliPayToFansPlan.put("01160", "0229");
        aliPayToFansPlan.put("01161", "0228");
        aliPayToFansPlan.put("01203", "0219");
        aliPayToFansPlan.put("01211", "0214");
        aliPayToFansPlan.put("01219", "027");
    }

    @Override
    public void save(AdvertisingUserInfo userInfo) {

        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            return;
        }

        setHeadImgAndUserNick(userInfo.getOpenId(), userInfo);

        setGeographicLocation(userInfo);

        Query query = new Query(Criteria.where(PRIMARY_KEY_OPEN_ID).is(userInfo.getOpenId()));
        AdvertisingUserInfo userInfoOld = mongoTemplate.findOne(query, getEntityClass());

        if (null != userInfoOld) {
            updateByKey(userInfo, PRIMARY_KEY_OPEN_ID);
            return;
        }

        /*当日剩余取纸次数*/
        setTodayRemainderTakePaperNum(userInfo);

        super.save(userInfo);

        /*备份*/
        ScanUserBackup userBackup = new ScanUserBackup();
        userBackup.setOpenId(userInfo.getOpenId());
        userBackup.setDayBackup(LocalDate.now());
        userBackup.setTimeBackup(LocalTime.now());
        userBackup.setJson(JSON.toJSONString(userInfo));
        scanUserBackupMapper.insertScanUserBackup(userBackup);
    }

    /**
     * 设置用户扫码时所处地理位置信息
     *
     * @param userInfo
     */
    private void setGeographicLocation(AdvertisingUserInfo userInfo) {

        if (System.currentTimeMillis() > Integer.MIN_VALUE) {
            return;
        }

        if (null == userInfo || StringUtils.isBlank(userInfo.getIp())) {
            return;
        }


        String ip = userInfo.getIp();

        String url = Constants.IP_PARSE_URL + ip;

        GeographicLocationResponse response = HttpClient.getForObject(url, GeographicLocationResponse.class, HttpClient.HEADERS);

        if (null == response || null == response.getCode() || !response.getCode().equals(0)) {
            return;
        }

        GeographicLocation geographicLocation = response.getData();

        if (null == geographicLocation || StringUtils.isBlank(geographicLocation.getCountry())) {
            return;
        }

        userInfo.setGeographicLocation(geographicLocation);

    }

    @Override
    public AdvertisingUserInfo findByOpenId(String openId) {

        if (StringUtils.isBlank(openId)) {
            return null;
        }

        Query query = new Query(Criteria.where(PRIMARY_KEY_OPEN_ID).is(openId));

        AdvertisingUserInfo userInfo = mongoTemplate.findOne(query, getEntityClass());

        if (null == userInfo) {
            return null;
        }

        handleAliPayToFansPlan(userInfo);

        setTodayRemainderTakePaperNum(userInfo);

        return userInfo;
    }

    /**
     * 处理
     *
     * @param userInfo
     */
    private void handleAliPayToFansPlan(AdvertisingUserInfo userInfo) {

        if (null == userInfo || null == userInfo.getAdRecord()) {
            return;
        }

        HashMap<String, Integer> adRecord = userInfo.getAdRecord();
        int size = adRecord.size();

        for (Map.Entry<String, String> entry : aliPayToFansPlan.entrySet()) {
            String planIdAliPay = entry.getKey();
            String planIdFans = entry.getValue();
            if (adRecord.containsKey(planIdAliPay) && !adRecord.containsKey(planIdFans)) {
                adRecord.put(planIdFans, adRecord.get(planIdAliPay));
            }
        }

        if (adRecord.size() > size) {
            AdvertisingUserInfo advertisingUserInfo = new AdvertisingUserInfo();
            advertisingUserInfo.setOpenId(userInfo.getOpenId());
            advertisingUserInfo.setAdRecord(adRecord);
            Map<String, AdvertisingUserInfo> map = new HashMap<>(4);
            map.put(KEY_HANDLE_ALI_PAY_PLAN_TO_FANS_PLAN, advertisingUserInfo);
            JedisPoolCacheUtils.lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(map));
        }

    }

    @Override
    public AdvertisingUserInfo findByPhone(String phone) {

        if (StringUtils.isBlank(phone)) {
            return null;
        }

        Query query = new Query();
        query.addCriteria(Criteria.where(PRIMARY_KEY_PHONE).is(phone));

        AdvertisingUserInfo userInfo = mongoTemplate.findOne(query, getEntityClass());
        return userInfo;
    }

    @Override
    public List<AdvertisingUserInfo> findByUserId(Integer userId) {

        if (null == userId) {
            return null;
        }

        Query query = new Query();
        query.addCriteria(Criteria.where(PRIMARY_KEY_USER_ID).is(userId));

        List<AdvertisingUserInfo> userInfos = mongoTemplate.find(query, getEntityClass());
        return userInfos;
    }


    @Override
    public void totalPaperNumIncrement(AdvertisingUserInfo advertisingUserInfo) {

        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return;
        }

        String randomNum = advertisingUserInfo.getRandomNum();
        advertisingUserInfo.setGmtLastTakePaper(new Date());

        AdvertisingUserInfo userInfoOld = findByOpenId(advertisingUserInfo.getOpenId());
        AdvertisingTargetInfo targetInfo = mongoTemplate.findById(Long.parseLong(randomNum), AdvertisingTargetInfo.class);
        boolean isLeaf = (null != targetInfo && StringUtils.startsWith(targetInfo.getAdWinPlanId(), ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue()));


        if (null == userInfoOld) {
            advertisingUserInfo.setTodayPaperNum(1);
            advertisingUserInfo.setTotalPaperNum(1);
            advertisingUserInfo.setPaperTotalNum(isLeaf ? 1 : 0);
            save(advertisingUserInfo);
            return;
        }

        /*用户总取纸次数+1*/
        Integer totalPaperNum = userInfoOld.getTotalPaperNum();
        userInfoOld.setTotalPaperNum(null == totalPaperNum ? 1 : totalPaperNum + 1);

        /*用户已总取纸次数：从小树叶功能发布开始算起*/
        if (isLeaf) {
            Integer paperTotalNum = userInfoOld.getPaperTotalNum();
            userInfoOld.setPaperTotalNum(null == paperTotalNum ? 1 : paperTotalNum + 1);
            /*公众号消息推送*/
            if (userInfoOld.getPaperTotalNum().equals(7)) {
                String leafPrivateDomain = configService.selectConfigByKey(ZjbConfigEnum.ZJB_LEAF_PRIVATE_DOMAIN.getKey());
                WeChatSms wechatSms = new WeChatSms();
                wechatSms.setZjbOpenId(advertisingUserInfo.getOpenId());
                wechatSms.setType("小树叶任务开启");
                wechatSms.setResult("您可开始做任务领取小树叶，使用小树叶享免广告极速取纸");
                wechatSms.setRemark("立即领取小树叶>");
                wechatSms.setClickUrl(String.format(configService.selectConfigByKey(ZJB_DSP_LEAF_INDEX_URL.getKey()), leafPrivateDomain, userInfoOld.getOpenId()));
                wechatSms.setJump(true);
                feignAdminCoreService.weChatSmsSend(wechatSms);
            }
        }

        /*用户当日取纸次数+1：用户当日取纸次数在次日凌晨清空*/
        Date gmtLastTakePaper = userInfoOld.getGmtLastTakePaper();
        Integer todayPaperNum = userInfoOld.getTodayPaperNum();

        if (null == gmtLastTakePaper) {
            userInfoOld.setTodayPaperNum(1);
        } else {
            Calendar cal = Calendar.getInstance();
            cal.setTime(gmtLastTakePaper);
            if (Calendar.getInstance().get(Calendar.DAY_OF_MONTH) == cal.get(Calendar.DAY_OF_MONTH)) {
                /*同一天，取纸次数+1*/
                userInfoOld.setTodayPaperNum(null == todayPaperNum ? 1 : todayPaperNum + 1);
            } else {
                userInfoOld.setTodayPaperNum(1);
            }
        }

        /*最后一次取纸时间，也即$ZJBPR上报时间*/
        userInfoOld.setGmtLastTakePaper(new Date());

        /*增加小树叶数量*/
        if (isLeaf) {
            increaseLeafAmount(userInfoOld);
        }

        /*当日剩余取纸次数*/
        setTodayRemainderTakePaperNum(advertisingUserInfo);

        updateByKey(userInfoOld, PRIMARY_KEY_OPEN_ID);

        try {
            /*备份：同步更新*/
            ScanUserBackup userBackup = new ScanUserBackup();
            userBackup.setOpenId(userInfoOld.getOpenId());
            userBackup.setDayBackup(LocalDate.now());
            userBackup.setTimeBackup(LocalTime.now());
            userBackup.setJson(JSON.toJSONString(userInfoOld));
            scanUserBackupMapper.updateByOpenId(userBackup);
        } catch (UncategorizedSQLException e) {
            logger.warn("扫码用户【{}】信息备份失败：{}", userInfoOld.getOpenId(), e.getMessage());
        }

    }

    /**
     * 记录小树叶收入明细
     *
     * @param userInfoOld
     */
    private void insertLeafIncomeExpenditureDetails(AdvertisingUserInfo userInfoOld) {


        /*用户已总取纸次数：从小树叶功能发布开始算起*/
        Integer paperTotalNum = userInfoOld.getPaperTotalNum();
        LeafIncomeExpenditureDetails details = new LeafIncomeExpenditureDetails();
        details.setOpenId(userInfoOld.getOpenId());
        details.setVerifyId(-(System.currentTimeMillis()));
        details.setTaskId(ZjbDictionaryEnum.AD_PUBLIC_LEAF_COMBINATION_UNIT.getValue().toString() + 1);
        details.setTaskNodeId(paperTotalNum - 2L);
        details.setTaskName("第" + paperTotalNum + "次取纸奖励");
        details.setAmountIncomeExpenditure(IN_LEAF_GENERAL_AMOUNT);
        details.setTypeIncomeExpenditure(ZjbDictionaryEnum.AD_IN_EX_LEAF_GENERAL.getValue());
        details.setStatusIncomeExpenditure(ZjbDictionaryEnum.LEAF_INCOME_EXPENDITURE_PASS.getValue());
        details.setGmtCreated(new Date());

        leafIncomeExpenditureDetailsService.insertLeafIncomeExpenditureDetails(details);
    }

    /**
     * 增加小树叶数量
     * 单个用户，在完成第2次、第3次、第4次、第5次取纸时，每次赠送5个小树叶
     *
     * @param userInfo
     */
    @Deprecated
    private void increaseLeafAmount(AdvertisingUserInfo userInfo) {

        if (System.currentTimeMillis() > Integer.MIN_VALUE) {
            logger.debug("小树叶功能模块已作废，小树叶获取方式必须使用安卓APP");
            return;
        }

        if (null == userInfo.getAmountObtainedLeaf()) {
            userInfo.setAmountObtainedLeaf(0);
        }

        if (null == userInfo.getPaperTotalNum()) {
            return;
        }

        switch (userInfo.getPaperTotalNum()) {
            case 3:
            case 4:
            case 5:
            case 6:

                /*记录小树叶收入明细*/
                insertLeafIncomeExpenditureDetails(userInfo);

                /*消费数量递增*/
                LeafTask leafTask = leafTaskMapper.selectLeafTaskById(1L);
                if (null != leafTask) {
                    Integer todayConsumeAmount = leafTask.getTodayConsumeAmount();
                    Integer totalConsumeAmount = leafTask.getTotalConsumeAnount();

                    leafTask.setTodayConsumeAmount(null == todayConsumeAmount ? 1 : 1 + todayConsumeAmount);
                    leafTask.setTotalConsumeAnount(null == totalConsumeAmount ? 1 : 1 + totalConsumeAmount);
                    leafTaskMapper.updateLeafTask(leafTask);

                }

                /*第几次收到小树叶*/
                userInfo.setNumOfTimesGetLeaf(userInfo.getPaperTotalNum() - 2);
                /*已获得的小树叶数量*/
                userInfo.setAmountObtainedLeaf((userInfo.getPaperTotalNum() - 2) * IN_LEAF_GENERAL_AMOUNT);
                break;
            default:
        }

    }

    @Override
    public void updateAdvertisingDayRecord(AdvertisingUserInfo userInfo) {
        if (null == userInfo
                || StringUtils.isBlank(userInfo.getOpenId())
                || StringUtils.isBlank(userInfo.getLastPlanId())) {
            return;
        }

        String planId = userInfo.getLastPlanId();

        setAdvertisingRecord(userInfo, planId);
        setAdRecord(userInfo);

        AdvertisingUserInfo userInfoOld = findByOpenId(userInfo.getOpenId());

        if (null == userInfoOld) {
            save(userInfo);
            return;
        }

        HashMap<String, Integer> adRecordOld = userInfoOld.getAdRecord();

        if (null == adRecordOld) {
            userInfoOld.setAdRecord(userInfo.getAdRecord());
        } else {
            Integer count = adRecordOld.get(planId);
            adRecordOld.put(planId, null == count ? 1 : 1 + count);
        }

        AdvertisingUserDayRecord adUserDayRecord = userInfoOld.getAdUserDayRecord();

        if (null == adUserDayRecord) {
            userInfoOld.setAdUserDayRecord(userInfo.getAdUserDayRecord());
        } else {
            adUserDayRecord.setGmtLastAdvertising(new Date());
            adUserDayRecord.setLastPlanId(planId);
            HashMap<String, Integer> advertisingRecord = adUserDayRecord.getAdvertisingRecord();
            Integer count = advertisingRecord.get(planId);
            advertisingRecord.put(planId, null == count ? 1 : count + 1);
        }

        /*当日剩余取纸次数*/
        setTodayRemainderTakePaperNum(userInfoOld);

        updateByKey(userInfoOld, PRIMARY_KEY_OPEN_ID);

        try {
            /*备份：同步更新*/
            ScanUserBackup userBackup = new ScanUserBackup();
            userBackup.setOpenId(userInfoOld.getOpenId());
            userBackup.setDayBackup(LocalDate.now());
            userBackup.setTimeBackup(LocalTime.now());
            userBackup.setJson(JSON.toJSONString(userInfoOld));
            scanUserBackupMapper.updateByOpenId(userBackup);
        } catch (UncategorizedSQLException e) {
            logger.warn("扫码用户【{}】信息备份失败：{}", userInfoOld.getOpenId(), e.getMessage());
        }

    }

    @Override
    public void updateWeChatPersonalGroup(AdvertisingUserInfo userInfo, AdvertisingPlan plan) {
        if (null == userInfo || null == plan
                || StringUtils.isBlank(userInfo.getOpenId())) {
            return;
        }

        AdvertisingUserInfo userInfoOld = findByOpenId(userInfo.getOpenId());

        if (null == userInfoOld) {
            return;
        }

        if (StringUtils.isBlank(plan.getWeChatPersonalId())) {
            return;
        }

        WeChatPersonal weChatPersonal = weChatPersonalMapper.selectByPersonalId(plan.getWeChatPersonalId());

        if (null == weChatPersonal) {
            logger.error("根据微信个人编号{}查询记录失败", plan.getWeChatPersonalId());
            return;
        }

        HashMap<Integer, Set<String>> weChatPersonalGroup = userInfoOld.getWeChatPersonalGroup();

        if (null == weChatPersonalGroup) {
            weChatPersonalGroup = new HashMap<>(4);
        }

        Set<String> set = weChatPersonalGroup.computeIfAbsent(weChatPersonal.getPersonalGroup(), k -> new HashSet<>(4));
        set.add(weChatPersonal.getPersonalId());

        userInfoOld.setWeChatPersonalGroup(weChatPersonalGroup);

        updateByKey(userInfoOld, PRIMARY_KEY_OPEN_ID);

        try {
            /*备份：同步更新*/
            ScanUserBackup userBackup = new ScanUserBackup();
            userBackup.setOpenId(userInfoOld.getOpenId());
            userBackup.setDayBackup(LocalDate.now());
            userBackup.setTimeBackup(LocalTime.now());
            userBackup.setJson(JSON.toJSONString(userInfoOld));
            scanUserBackupMapper.updateByOpenId(userBackup);
        } catch (UncategorizedSQLException e) {
            logger.warn("扫码用户【{}】信息备份失败：{}", userInfoOld.getOpenId(), e.getMessage());
        }

    }

    @Override
    public void updateQqPersonalGroup(AdvertisingUserInfo userInfo, AdvertisingPlan plan) {
        if (null == userInfo || null == plan
                || StringUtils.isBlank(userInfo.getOpenId())) {
            return;
        }

        AdvertisingUserInfo userInfoOld = findByOpenId(userInfo.getOpenId());

        if (null == userInfoOld) {
            return;
        }

        if (StringUtils.isBlank(plan.getQqPersonalId())) {
            return;
        }

        QqPersonal qqPersonal = qqPersonalMapper.selectByPersonalId(plan.getQqPersonalId());

        if (null == qqPersonal) {
            logger.error("根据QQ个人编号{}查询记录失败", plan.getQqPersonalId());
            return;
        }

        HashMap<Integer, Set<String>> qqPersonalGroup = userInfoOld.getQqPersonalGroup();

        if (null == qqPersonalGroup) {
            qqPersonalGroup = new HashMap<>(4);
        }

        Set<String> set = qqPersonalGroup.computeIfAbsent(qqPersonal.getPersonalGroup(), k -> new HashSet<>(4));
        set.add(qqPersonal.getPersonalId());

        userInfoOld.setQqPersonalGroup(qqPersonalGroup);
        updateByKey(userInfoOld, PRIMARY_KEY_OPEN_ID);

        try {
            /*备份：同步更新*/
            ScanUserBackup userBackup = new ScanUserBackup();
            userBackup.setOpenId(userInfoOld.getOpenId());
            userBackup.setDayBackup(LocalDate.now());
            userBackup.setTimeBackup(LocalTime.now());
            userBackup.setJson(JSON.toJSONString(userInfoOld));
            scanUserBackupMapper.updateByOpenId(userBackup);
        } catch (UncategorizedSQLException e) {
            logger.warn("扫码用户【{}】信息备份失败：{}", userInfoOld.getOpenId(), e.getMessage());
        }

    }

    private void setAdRecord(AdvertisingUserInfo userInfo) {

        HashMap<String, Integer> adRecord = new HashMap<>();
        adRecord.put(userInfo.getLastPlanId(), 1);
        userInfo.setAdRecord(adRecord);
    }

    @Override
    public void clearAdvertisingDayRecord() {

        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);

        if (0 != hour) {
            /*必须是每天的0时0分执行，否则忽略*/
            return;
        }

        Map<String, Field> allField = BeanUtils.getAllField(getEntityClass());

        String key = "adUserDayRecord";

        if (!allField.containsKey(key)) {
            logger.error("类{}属性字段{}不存在", getEntityClass().getName(), key);
            return;
        }

        Update update = new Update();
        update.unset(key);
        mongoTemplate.updateMulti(new Query(), update, getEntityClass());
    }

    @Override
    public void clearTodayPaperNum() {
        Calendar now = Calendar.getInstance();
        int hour = now.get(Calendar.HOUR_OF_DAY);

        if (0 != hour) {
            /**必须是每天的0时执行，否则忽略*/
            return;
        }

        Map<String, Field> allField = BeanUtils.getAllField(getEntityClass());

        String key = "todayPaperNum";

        if (!allField.containsKey(key)) {
            logger.error("类{}属性字段{}不存在", getEntityClass().getName(), key);
            return;
        }

        Update update = new Update();
        update.unset(key);
        mongoTemplate.updateMulti(new Query(), update, getEntityClass());

    }

    @Override
    public AdvertisingUserInfo getUserInfo(String openId) {
        // 根据openId从mongoDB从查出用户信息
        AdvertisingUserInfo advertisingUserInfo = findByOpenId(openId);
        if (null == advertisingUserInfo) {
            return null;
        }
        setHeadImgAndUserNick(openId, advertisingUserInfo);
        return getUserLevelsInfo(advertisingUserInfo);
    }

    @Override
    public AdvertisingUserInfo getUserLevelsInfo(AdvertisingUserInfo advertisingUserInfo) {
        // 查询积分等级
        EnvironmentalProtection ep = userEnvironmentalProtectionService.getEnvironmentalProtection(advertisingUserInfo);
        if (null != ep && null != ep.getLevel()) {
            advertisingUserInfo.setEnvironmentalProtectionLevel(ep.getLevel());
        }
        // 积分通过另一个接口计算存入库中，成就实时计算
        // 成就计算方法为取出字典表数据，循环和取纸次数比较，每满足一个要求成就数量+1
        List<DictData> dictDatas = dictDataService.selectDictDataByType("sys_user_achievement");
        Integer paperTotalNum = (null == advertisingUserInfo.getPaperTotalNum() ? 0 : advertisingUserInfo.getPaperTotalNum());
        for (DictData dictData : dictDatas) {
            if (null != dictData.getDictValue() && StringUtils.isNotEmpty(dictData.getDictValue()) && paperTotalNum.intValue() >= Integer.parseInt(dictData.getDictValue())) {
                advertisingUserInfo.setAchievementCount((null == advertisingUserInfo.getAchievementCount() ? 0 : advertisingUserInfo.getAchievementCount()) + 1);
            }
        }
        return advertisingUserInfo;
    }

    @Override
    public List<PersonalAchievement> getPersonalAchievement(String openId) {
        // 根据openId从mongoDB从查出用户信息
        AdvertisingUserInfo advertisingUserInfo = findByOpenId(openId);
        if (null == advertisingUserInfo || null == advertisingUserInfo.getPaperTotalNum()) {
            return null;
        }
        // 根据取纸次数查出成就信息
        List<PersonalAchievement> dictDatas = dictDataService.getPersonalAchievement(advertisingUserInfo.getPaperTotalNum());
        for (PersonalAchievement dictData : dictDatas) {
            if (dictData.getDictSort() != null && dictData.getDictSort() == 1L) {
                dictData.setAchieveUrl(ZjbVipConstants.SILVERURL);
                dictData.setNoAchieveUrl(ZjbVipConstants.SILVERREALGLORY);
            } else if (dictData.getDictSort() != null && dictData.getDictSort() == 2L) {
                dictData.setAchieveUrl(ZjbVipConstants.GOLDURL);
                dictData.setNoAchieveUrl(ZjbVipConstants.GOLDREALGLORY);
            } else if (dictData.getDictSort() != null && dictData.getDictSort() == 3L) {
                dictData.setAchieveUrl(ZjbVipConstants.PLATINUMURL);
                dictData.setNoAchieveUrl(ZjbVipConstants.PLATINUMREALGLORY);
            } else if (dictData.getDictSort() != null && dictData.getDictSort() == 4L) {
                dictData.setAchieveUrl(ZjbVipConstants.DIAMONDSURL);
                dictData.setNoAchieveUrl(ZjbVipConstants.DIAMONDSREALGLORY);
            }
        }
        return dictDatas;
    }

    @Override
    public void setHeadImgAndUserNick(String openId, AdvertisingUserInfo advertisingUserInfo) {
        // 从ots中查出头像、昵称信息
        AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openId);
        if (null != authorizationUserInfo) {
            // 头像
            if (null != authorizationUserInfo.getHeadimgurl() && StringUtils.isNotBlank(authorizationUserInfo.getHeadimgurl())) {
                advertisingUserInfo.setHeadImgUrl(authorizationUserInfo.getHeadimgurl());
            }
            // 昵称
            if (null != authorizationUserInfo.getUserNick() && StringUtils.isNotBlank(authorizationUserInfo.getUserNick())) {
                advertisingUserInfo.setUserNick(authorizationUserInfo.getUserNick());
            }
        }
    }

    /**
     * 设置用户当天查看广告记录
     *
     * @param userInfoNew
     * @param adWinPlanId 胜出广告计划
     */
    private void setAdvertisingRecord(AdvertisingUserInfo userInfoNew, String adWinPlanId) {

        if (StringUtils.isBlank(adWinPlanId)) {
            return;
        }

        AdvertisingUserDayRecord adUserDayRecord = new AdvertisingUserDayRecord();
        adUserDayRecord.setGmtLastAdvertising(new Date());
        adUserDayRecord.setLastPlanId(adWinPlanId);

        HashMap<String, Integer> advertisingRecord = new HashMap<>();
        advertisingRecord.put(adWinPlanId, 1);
        adUserDayRecord.setAdvertisingRecord(advertisingRecord);

        userInfoNew.setAdUserDayRecord(adUserDayRecord);
    }

    @Override
    public void updateByKey(Object obj, String primaryKeyProperty) {

        if (null == obj || StringUtils.isBlank(primaryKeyProperty) || obj.getClass() != getEntityClass()) {
            return;
        }

        AdvertisingUserInfo userInfo = (AdvertisingUserInfo) obj;

        /*更新用户扫码时所处地理位置信息*/
        updateGeographicLocation(userInfo);


        super.updateByKey(userInfo, primaryKeyProperty);
    }

    /**
     * 更新用户扫码时所处地理位置信息
     *
     * @param userInfo
     */
    private void updateGeographicLocation(AdvertisingUserInfo userInfo) {
        String openId = userInfo.getOpenId();
        String ipNew = userInfo.getIp();

        if (StringUtils.isBlank(openId) || StringUtils.isBlank(ipNew)) {
            return;
        }

        AdvertisingUserInfo userInfoOld = findByOpenId(openId);

        if (null == userInfoOld) {
            return;
        }

        String ip = userInfoOld.getIp();

        /*IP相同时忽略更新*/
        if (StringUtils.isBlank(ipNew) || ipNew.equals(ip)) {
            return;
        }

        setGeographicLocation(userInfo);

    }

    /**
     * 当日剩余取纸次数
     */
    private void setTodayRemainderTakePaperNum(AdvertisingUserInfo userInfo) {

        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            return;
        }

        /*默认允许普通取纸总次数*/
        Integer defaultPaperCount = ZjbConfigEnum.DEVICE_OUTPAPER_MAX_COUNT.getValue();
        /*允许普通取纸总次数：核心系统缓存中获取*/
        String key = ZjbConstantsRedis.REDIS_CONFIG_INFO_KEY + "_" + ZjbConfigEnum.DEVICE_OUTPAPER_MAX_COUNT.getKey();
        String takePaperCount = JedisPoolCacheUtils.getVStr(key, ZjbConstantsRedis.ZJB_DB_6);
        Integer canPaperCount = StringUtils.isNumeric(takePaperCount) ? Integer.parseInt(takePaperCount) : defaultPaperCount;
        /*今日已取纸次数*/
        key = ZjbConstantsRedis.REDIS_MINI_OPENID_DAY_QRCOUNT + LocalDate.now() + userInfo.getOpenId();
        String paperTakenCount = JedisPoolCacheUtils.getVStr(key, ZjbConstantsRedis.ZJB_DB_1);
        /*设置当日剩余取纸次数*/
        Integer todayRemainderTakePaperNum = StringUtils.isNumeric(paperTakenCount) ? (canPaperCount - Integer.parseInt(paperTakenCount)) : canPaperCount;
        userInfo.setTodayRemainderTakePaperNum(todayRemainderTakePaperNum < 0 ? 0 : todayRemainderTakePaperNum);
    }

    @Override
    public byte[] generatorBindQrCode(String openId) {
        byte[] b;

        String v = configService.selectConfigByKey(DOMAIN_ADDRESS_AUTH_THROUGH_TOP.getKey());
        String address = StringUtils.defaultIfBlank(v, DOMAIN_ADDRESS_AUTH_THROUGH_TOP.getValue());
        String rootUrl = String.format("https://%s/h5/authtest/?openId=", address);

        try {
            //文件名
            String name = openId + ".png";
            //二维码内容
            String contents = rootUrl + openId + "#/zfbauth";
            ByteArrayOutputStream baos = ZxingUtils.genQrcode(contents);
            b = baos.toByteArray();
        } catch (IOException e) {
            throw new BaseException("生成绑定支付宝二维码失败，uid：" + openId, e.getMessage());
        } catch (WriterException e) {
            throw new BaseException("生成绑定支付宝二维码失败2，uid：" + openId, e.getMessage());
        } catch (Exception e) {
            throw new BaseException("生成绑定支付宝二维码失败3，uid：" + openId, e.getMessage());
        }

        return b;
    }

    @Override
    public Boolean weChatBindAlipay(WeChatAndAlipayOpenId weChatAndAlipayOpenId) {
        // 从mongoDB中查出该用户现在的等级
        // 支付宝用户校验
        AdvertisingUserInfo wechatUserInfo = findByOpenId(weChatAndAlipayOpenId.getWeChatOpenId());
        if (null == wechatUserInfo) {
            return false;
        }
        // 微信用户校验
        AdvertisingUserInfo alipayUserInfo = findByOpenId(weChatAndAlipayOpenId.getAlipayOpenId());
        if (null == alipayUserInfo) {
            return false;
        }
        // 从待使用vip表中获取id
        Integer userId = getVipId().getVipId();
        // 修改微信和支付宝用户的userId，确认绑定关系
        wechatUserInfo.setUserId(userId);
        alipayUserInfo.setUserId(userId);
        updateByKey(wechatUserInfo, PRIMARY_KEY_OPEN_ID);
        updateByKey(alipayUserInfo, PRIMARY_KEY_OPEN_ID);
        return true;
    }

    // 从待使用vipId表中随机获取一条数据
    @Override
    public synchronized VipidList getVipId() {
        // 获取总数
        Integer count = vipidListService.getCount();
        // 根据总数生产一个随机数
        Integer rownum = new Random().nextInt(count);
        // 用随机数当行号获取数据
        VipidList vipid = vipidListService.getVipId(rownum);
        // 从表里删除该条数据
        vipidListService.deleteVipidListById(vipid.getVipId());
        // 总数为20000和10000时需要发送告警邮件
        if ((count - 1) == 20000 || (count - 1) == 10000) {
            MailUtil.send("sunlifeng@sczj-inc.com,yewei@sczj-inc.com,lichuang@sczj-inc.com,renqiyao@sczj-inc.com,guojing@sczj-inc.com",
                    "纸巾宝会员编号库存不足预警", "纸巾宝会员编号库存不足预警：\n" +
                            "当前用于发放给纸巾宝新会员的编号数量只剩余：" + count + "，请及时补充！", false);
        }
        return vipid;
    }

    @Override
    public List<UseQuestion> getQuestions(Integer totalPaperNum) {
        return dictDataService.getQuestions(totalPaperNum);
    }

    @Override
    public PopupRecord getUserPopupRecord(String openId) {
        Query query = new Query();
        query.addCriteria(Criteria.where(PRIMARY_KEY_OPEN_ID).is(openId));
        return mongoTemplate.findOne(query, PopupRecord.class);
    }

    @Override
    public void setUserPopupRecord(PopupRecord popupRecord) {
        if (null == getUserPopupRecord(popupRecord.getOpenId())) {
            mongoTemplate.save(popupRecord);
        } else {
            updatePopupRecordByKey(popupRecord, PRIMARY_KEY_OPEN_ID);
        }
    }

    public void updatePopupRecordByKey(PopupRecord entity, String primaryKeyProperty) {
        if (null == entity || StringUtils.isBlank(primaryKeyProperty)) {
            return;
        }

        Map<String, Field> allField = BeanUtils.getAllField(PopupRecord.class);

        if (!allField.containsKey(primaryKeyProperty)) {
            return;
        }

        Query query = new Query();
        Update update = new Update();

        try {
            for (Map.Entry<String, Field> entry : allField.entrySet()) {
                String name = entry.getKey();
                Field field = entry.getValue();
                Object value = BeanUtils.PROPERTY_UTILS_BEAN.getProperty(entity, name);
                if (null == value) {
                    continue;
                }

                if (null != field.getAnnotation(Transient.class)) {
                    continue;
                }

                if (name.equals(primaryKeyProperty)) {
                    query.addCriteria(Criteria.where(primaryKeyProperty).is(value));
                    Object obj = mongoTemplate.findOne(query, PopupRecord.class);
                    if (null == obj) {
                        return;
                    }
                } else {
                    update.set(name, value);
                }

            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            logger.error(e.getMessage(), e);
            return;
        }

        mongoTemplate.updateFirst(query, update, PopupRecord.class);

    }

    @Override
    public synchronized AdvertisingUserInfo addAmountObtainedLeaf(AdvertisingUserInfo userInfo) {
        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            logger.error("缺失用户openId");
            return userInfo;
        }

        if (null == userInfo.getAmountObtainedLeaf()) {
            logger.error("缺失小树叶数量");
            return userInfo;
        }


        AdvertisingUserInfo user = findByOpenId(userInfo.getOpenId());

        if (null == user) {
            logger.error("用户【{}】不存在", userInfo.getOpenId());
            return userInfo;
        }

        /*已获得的小树叶数量*/
        Integer amountObtainedLeaf = user.getAmountObtainedLeaf();
        /*第几次收到小树叶*/
        Integer numOfTimesGetLeaf = user.getNumOfTimesGetLeaf();

        if (null == amountObtainedLeaf) {
            amountObtainedLeaf = 0;
        }

        if (null == numOfTimesGetLeaf) {
            numOfTimesGetLeaf = 0;
        }

        user.setAmountObtainedLeaf(amountObtainedLeaf + userInfo.getAmountObtainedLeaf());
        user.setNumOfTimesGetLeaf(numOfTimesGetLeaf + 1);

        updateByKey(user, PRIMARY_KEY_OPEN_ID);
        return user;

    }

    /**
     * 获取用户当前需要弹窗的信息
     * 1.从弹窗记录中获取用户的以往弹窗记录
     * 2.按优先级与用户的当前各信息比较，若需要弹窗显示set进实例化对象中并返回
     * 3.若没有需要弹窗的信息则不做任何操作
     *
     * @param userInfo
     */
    @Override
    public void getPopupInfo(AdvertisingUserInfo userInfo) {

        // 获取用户的推送记录
        PopupRecord popupRecord = getUserPopupRecord(userInfo.getOpenId());
        // 用户当前取纸次数和推送记录中次数不一致则需要判断是否需要弹窗
        if (null != userInfo.getPaperTotalNum() && (null == popupRecord || null == popupRecord.getPaperCount() || userInfo.getPaperTotalNum() > popupRecord.getPaperCount())) {
            // 从数据库中获取类型为取纸次数的推送信息
            PushInfo pushInfo = new PushInfo();
            pushInfo.setPushType(ZjbDictionaryEnum.PUSH_TYPE_FOR_PAPER_COUNT.getValue());
            List<PushInfo> pushInfos = pushInfoService.selectPushInfoList(pushInfo);
            if (pushInfos == null || pushInfos.size() == 0) {
                return;
            }
            // 判断取纸次数是否需要弹窗
            for (PushInfo info : pushInfos) {
                if (info.getPushRequire().equals(userInfo.getPaperTotalNum())) {
                    userInfo.setPushInfo(info);
                    // 插入记录
                    if (popupRecord == null) {
                        popupRecord = new PopupRecord();
                    }
                    // 更新记录
                    popupRecord.setOpenId(userInfo.getOpenId());
                    popupRecord.setPaperCount(userInfo.getPaperTotalNum());
                    setUserPopupRecord(popupRecord);
                    return;
                }
            }
        }
        // 判断环保等级是否需要弹窗
        if (null != userInfo.getEnvironmentalProtectionLevel() && userInfo.getEnvironmentalProtectionLevel().intValue() > 0 // 用户存在环保等级
                && ((null != popupRecord && null != popupRecord.getEnvironmentalProtection()
                && userInfo.getEnvironmentalProtectionLevel().intValue() > popupRecord.getEnvironmentalProtection().intValue()) //用户当前环保等级大于弹窗记录
                || null == popupRecord || null == popupRecord.getEnvironmentalProtection())) { // 用户没有环保等级弹窗记录
            // 从数据库中获取类型为环保等级的推送信息
            PushInfo pushInfo = new PushInfo();
            pushInfo.setPushType(ZjbDictionaryEnum.PUSH_TYPE_FOR_ENVIRONMENTALPROTECTION.getValue());
            // 防止跳级，一级一级弹
            if (popupRecord == null) {
                popupRecord = new PopupRecord();
                popupRecord.setEnvironmentalProtection(1);
                pushInfo.setPushRequire(1);
            } else {
                if (popupRecord.getEnvironmentalProtection() == null) {
                    popupRecord.setEnvironmentalProtection(1);
                    pushInfo.setPushRequire(1);
                } else {
                    pushInfo.setPushRequire(popupRecord.getEnvironmentalProtection() + 1);
                    popupRecord.setEnvironmentalProtection(popupRecord.getEnvironmentalProtection() + 1);
                }
            }
            // 获取对应等级的弹窗详情信息
            List<PushInfo> pushInfos = pushInfoService.selectPushInfoList(pushInfo);
            if (pushInfos == null || pushInfos.size() == 0) {
                return;
            }
            userInfo.setPushInfo(pushInfos.get(0));
            // 更新记录
            popupRecord.setOpenId(userInfo.getOpenId());
            setUserPopupRecord(popupRecord);
            return;
        }
        // 判断成就等级是否需要弹窗
        if (null != userInfo.getAchievementCount() && userInfo.getAchievementCount().intValue() > 0 // 用户存在成就
                && ((null != popupRecord && null != popupRecord.getAchievement()
                && userInfo.getAchievementCount().intValue() > popupRecord.getAchievement().intValue()) //用户当前成就大于弹窗记录
                || null == popupRecord || null == popupRecord.getAchievement())) { // 用户没有成就弹窗记录
            // 从数据库中获取类型为成就等级的推送信息
            PushInfo pushInfo = new PushInfo();
            pushInfo.setPushType(ZjbDictionaryEnum.PUSH_TYPE_FOR_ACHIEVEMENT.getValue());
            pushInfo.setPushRequire(userInfo.getAchievementCount().intValue());
            List<PushInfo> pushInfos = pushInfoService.selectPushInfoList(pushInfo);
            if (pushInfos == null || pushInfos.size() == 0) {
                return;
            }
            userInfo.setPushInfo(pushInfos.get(0));
            // 插入记录
            if (popupRecord == null) {
                popupRecord = new PopupRecord();
            }
            // 更新
            popupRecord.setOpenId(userInfo.getOpenId());
            popupRecord.setAchievement(userInfo.getAchievementCount());
            setUserPopupRecord(popupRecord);
            return;
        }
    }

    @Override
    public void completeUserInfo(AdvertisingUserInfo userInfo) {
        if (null == userInfo) {
            return;
        }

        userInfo.setPaperTotalNum(null == userInfo.getPaperTotalNum() ? 0 : userInfo.getPaperTotalNum());
        userInfo.setTotalPaperNum(null == userInfo.getTotalPaperNum() ? 0 : userInfo.getTotalPaperNum());
        userInfo.setTodayPaperNum(null == userInfo.getTodayPaperNum() ? 0 : userInfo.getTodayPaperNum());

        if (null == userInfo.getVip()) {
            userInfo.setVip(ZjbDictionaryEnum.NO.getValue());
        }

        if (null == userInfo.getAmountWaitReviewLeaf()) {
            userInfo.setAmountWaitReviewLeaf(0);
        }

        if (null == userInfo.getAmountObtainedLeaf()) {
            userInfo.setAmountObtainedLeaf(0);
        }

        if (null == userInfo.getAmountConsumedLeaf()) {
            userInfo.setAmountConsumedLeaf(0);
        }

        if (null == userInfo.getAchievementCount()) {
            userInfo.setAchievementCount(0);
        }

        /*可用小树叶数量*/
        int leafCount = (userInfo.getAmountObtainedLeaf() - userInfo.getAmountConsumedLeaf());
        userInfo.setLeafCount(leafCount < 0 ? 0 : leafCount);

        if (userInfo.getLeafCount() < 0) {
            userInfo.setLeafCount(0);
        }

        /*设置个人资料完善进度*/
        setPersonalInfoProgress(userInfo);

        /*完善头像信息和用户昵称*/
        if (StringUtils.isAnyBlank(userInfo.getUserNick(), userInfo.getHeadImgUrl())) {
            setHeadImgAndUserNick(userInfo.getOpenId(), userInfo);
        }

        /*新手使用时获取首页展示问题*/
        userInfo.setQuestions(getQuestions(userInfo.getPaperTotalNum()));

        // 获取用户当前环保等级和成就数量
        userInfo = getUserLevelsInfo(userInfo);
        Integer popup = userInfo.getPopup();
        if (null != popup && popup.equals(YES.getValue())) {
            // 获取弹框内容
            getPopupInfo(userInfo);
        }

    }

    /**
     * 设置个人资料完善进度
     *
     * @param userInfo
     */
    private void setPersonalInfoProgress(AdvertisingUserInfo userInfo) {
        if (null == userInfo) {
            return;
        }

        int personalInfoProgress = 0;

        if (null != userInfo.getSex()
                && (ZjbDictionaryEnum.AD_FACE_SEX_MALE.getValue().equals(userInfo.getSex()) || ZjbDictionaryEnum.AD_FACE_SEX_FEMALE.getValue().equals(userInfo.getSex()))) {
            personalInfoProgress += 20;
        }

        if (null != userInfo.getAge() && userInfo.getAge() > 0) {
            personalInfoProgress += 20;
        }

        if (StringUtils.isNotBlank(userInfo.getProfession())) {
            personalInfoProgress += 20;
        }

        if (null != userInfo.getHobby() && !userInfo.getHobby().isEmpty()) {
            personalInfoProgress += 20;
        }

        if (null != userInfo.getPersonalLabel() && !userInfo.getPersonalLabel().isEmpty()) {
            personalInfoProgress += 20;
        }

        userInfo.setPersonalInfoProgress(personalInfoProgress);

    }

    /**
     * 判断是否关注给定的公众号
     *
     * @param userVipOpenInfo
     * @return
     */
    @Override
    public boolean followSubscriptionCheck(UserVipOpenInfo userVipOpenInfo) {
        List<UserFollowSubscription> userFollowSubscriptions = new ArrayList<>();
        // 调用admin接口判断是否关注4个人公众号
        List<String> appids = new ArrayList<>();
        Integer amountFollow = 0;
        appids.add(ZjbVipConstants.LEAF_APPID);
        appids.add(ZjbVipConstants.VIP_CENTER_APPID);
        appids.add(ZjbVipConstants.WELFARE_CENTER_APPID);
        appids.add(ZjbVipConstants.READ_CENTER_APPID);
        Map<String, Object> paramsMap = new HashMap<String, Object>();
        paramsMap.put("openid", userVipOpenInfo.getOpenId());
        paramsMap.put("appids", appids);
        String data = JSON.toJSONString(paramsMap);
        String jsonResult = feignAdminCoreService.isSubscribe(data);
        JSONObject jsonObject = JSON.parseObject(jsonResult).getJSONObject("data");

        if (jsonObject == null) {
            jsonObject = new JSONObject();
        }
        // 纸巾宝小树叶
        UserFollowSubscription userFollowSubscription = new UserFollowSubscription();
        boolean leafFollow = jsonObject.getBooleanValue(ZjbVipConstants.LEAF_APPID);
        userFollowSubscription.setFollow(leafFollow);
        userFollowSubscription.setSubscriptionName(ZjbVipConstants.LEAF_NAME);
        userFollowSubscription.setSubscriptionIcon(ZjbVipConstants.LEAF_ICON);
        // 未关注，返回带参数的二维码
        if (!leafFollow) {
            userFollowSubscription.setSubscriptionAddress(jsonObject.getString(ZjbVipConstants.LEAF_APPID + "qrcodeImgUrl"));
        } else {
            amountFollow++;
        }

        userFollowSubscriptions.add(userFollowSubscription);

        // 纸巾宝会员中心
        userFollowSubscription = new UserFollowSubscription();
        boolean vipCenterFollow = jsonObject.getBooleanValue(ZjbVipConstants.VIP_CENTER_APPID);
        userFollowSubscription.setFollow(vipCenterFollow);
        userFollowSubscription.setSubscriptionName(ZjbVipConstants.VIP_CENTER_NAME);
        userFollowSubscription.setSubscriptionIcon(ZjbVipConstants.VIP_CENTER_ICON);
        // 未关注，返回带参数的二维码
        if (!vipCenterFollow) {
            userFollowSubscription.setSubscriptionAddress(ZjbVipConstants.VIP_CENTER_QRODEADDRESS);
            userFollowSubscription.setAppid(ZjbVipConstants.VIP_CENTER_APPID);
        } else {
            amountFollow++;
        }
        userFollowSubscriptions.add(userFollowSubscription);

        // 纸巾宝福利中心
        userFollowSubscription = new UserFollowSubscription();
        boolean welfareCenterFollow = jsonObject.getBooleanValue(ZjbVipConstants.WELFARE_CENTER_APPID);
        userFollowSubscription.setFollow(welfareCenterFollow);
        userFollowSubscription.setSubscriptionName(ZjbVipConstants.WELFARE_CENTER_NAME);
        userFollowSubscription.setSubscriptionIcon(ZjbVipConstants.WELFARE_CENTER_ICON);
        // 未关注，返回带参数的二维码
        if (!welfareCenterFollow) {
            userFollowSubscription.setSubscriptionAddress(jsonObject.getString(ZjbVipConstants.WELFARE_CENTER_APPID + "qrcodeImgUrl"));
        } else {
            amountFollow++;
        }
        userFollowSubscriptions.add(userFollowSubscription);

        // 纸巾宝阅读中心
        userFollowSubscription = new UserFollowSubscription();
        boolean readCenterFollow = jsonObject.getBooleanValue(ZjbVipConstants.READ_CENTER_APPID);
        userFollowSubscription.setFollow(readCenterFollow);
        userFollowSubscription.setSubscriptionName(ZjbVipConstants.READ_CENTER_NAME);
        userFollowSubscription.setSubscriptionIcon(ZjbVipConstants.READ_CENTER_ICON);
        // 未关注，返回二维码
        if (!readCenterFollow) {
            userFollowSubscription.setSubscriptionAddress(ZjbVipConstants.READ_CENTER_QRODEADDRESS);
            userFollowSubscription.setAppid(ZjbVipConstants.READ_CENTER_APPID);
        } else {
            amountFollow++;
        }
        userFollowSubscriptions.add(userFollowSubscription);

        userVipOpenInfo.setUserFollowSubscriptions(userFollowSubscriptions);
        userVipOpenInfo.setAmountFollow(amountFollow);

        return leafFollow && vipCenterFollow && welfareCenterFollow && readCenterFollow;
    }

    @Override
    public void speedPicking(AdvertisingUserInfo leafUserInfo) {

        if (null == leafUserInfo || StringUtils.isAnyBlank(leafUserInfo.getRandomNum(), leafUserInfo.getOpenId())) {
            return;
        }

        if (!StringUtils.isNumeric(leafUserInfo.getRandomNum())) {
            return;
        }

        String openId = leafUserInfo.getOpenId();

        AdvertisingUserInfo advertisingUserInfo = findByOpenId(openId);

        if (null == advertisingUserInfo) {
            logger.error("用户【{}】不存在！", openId);
            return;
        }

        Integer amountObtainedLeaf = advertisingUserInfo.getAmountObtainedLeaf();

        if (null == amountObtainedLeaf) {
            logger.error("用户{}未获得小树叶，流水号：{}", openId, leafUserInfo.getRandomNum());
            return;
        }

        /*记录小树叶支出明细*/
        LeafIncomeExpenditureDetails details = new LeafIncomeExpenditureDetails();
        details.setOpenId(openId);
        details.setVerifyId(-(System.currentTimeMillis()));
        details.setTaskId(ZjbDictionaryEnum.AD_PUBLIC_LEAF_COMBINATION_UNIT.getValue().toString() + 1);
        details.setTaskNodeId(details.getVerifyId());
        details.setTaskName("极速取纸");
        details.setAmountIncomeExpenditure(-20);
        details.setTypeIncomeExpenditure(ZjbDictionaryEnum.AD_IN_EX_LEAF_SKIP_AD.getValue());
        details.setStatusIncomeExpenditure(ZjbDictionaryEnum.LEAF_INCOME_EXPENDITURE_PASS.getValue());
        details.setGmtCreated(new Date());
        details.setRandomNum(Long.parseLong(leafUserInfo.getRandomNum()));

        leafIncomeExpenditureDetailsService.insertLeafIncomeExpenditureDetails(details);

    }

    @Override
    public void speedPickingRecover(AdvertisingUserInfo leafUserInfo) {
        if (null == leafUserInfo || StringUtils.isAnyBlank(leafUserInfo.getRandomNum(), leafUserInfo.getOpenId())) {
            return;
        }

        if (!StringUtils.isNumeric(leafUserInfo.getRandomNum())) {
            return;
        }

        String openId = leafUserInfo.getOpenId();
        AdvertisingUserInfo advertisingUserInfo = findByOpenId(openId);

        if (null == advertisingUserInfo) {
            logger.error("用户【{}】不存在！", openId);
            return;
        }

        Integer amountObtainedLeaf = advertisingUserInfo.getAmountObtainedLeaf();

        if (null == amountObtainedLeaf) {
            logger.error("用户{}未获得小树叶，流水号：{}", openId, leafUserInfo.getRandomNum());
            return;
        }

        Integer amountConsumedLeaf = advertisingUserInfo.getAmountConsumedLeaf();

        if (null == amountConsumedLeaf || amountConsumedLeaf < 20) {
            logger.error("用户{}未消费小树叶，流水号：{}", openId, leafUserInfo.getRandomNum());
            return;
        }

        LeafIncomeExpenditureDetails details = new LeafIncomeExpenditureDetails();
        details.setOpenId(openId);
        details.setRandomNum(Long.parseLong(leafUserInfo.getRandomNum()));

        /*恢复已消费的小树叶数量*/
        amountConsumedLeaf -= 20;
        advertisingUserInfo.setAmountConsumedLeaf(amountConsumedLeaf > amountObtainedLeaf ? amountObtainedLeaf : amountConsumedLeaf);
        super.updateByKey(advertisingUserInfo, PRIMARY_KEY_OPEN_ID);

        /*记录小树叶支出明细*/
        details.setVerifyId(-(System.currentTimeMillis()));
        details.setTaskId(AD_PUBLIC_LEAF_COMBINATION_UNIT.getValue().toString() + 1);
        details.setTaskNodeId(details.getVerifyId());
        details.setTaskName("极速取纸失败退回");
        details.setAmountIncomeExpenditure(20);
        details.setTypeIncomeExpenditure(AD_IN_EX_LEAF_REFUND.getValue());
        details.setStatusIncomeExpenditure(LEAF_INCOME_EXPENDITURE_PASS.getValue());
        details.setGmtCreated(new Date());
        details.setRandomNum(Long.parseLong(leafUserInfo.getRandomNum()));

        leafIncomeExpenditureDetailsService.insertLeafIncomeExpenditureDetails(details);
    }

    @Override
    public void handleZJBPR(ZjbPrResponse prResponse) {

        if (null == prResponse) {
            return;
        }

        if (StringUtils.isBlank(prResponse.getRandomNum())) {
            logger.warn("设备【{}】缺失用户扫码流水号", prResponse.getDeviceName());
            return;
        }

        if (!StringUtils.isNumeric(prResponse.getRandomNum())) {
            logger.warn("设备【{}】用户扫码流水号【{}】非数字", prResponse.getDeviceName(), prResponse.getRandomNum());
            return;
        }

        /*用户总取纸次数递增*/
        if (ZJB_PR_OUT_PAPER_SUCCESS.getValue().equals(prResponse.getOutPaperStatus())) {
            AdvertisingUserInfo userInfo = new AdvertisingUserInfo();
            userInfo.setRandomNum(prResponse.getRandomNum());
            userInfo.setOpenId(prResponse.getOpenId());
            totalPaperNumIncrement(userInfo);
        }

        /*极速取值扣减小树叶，即增加已消费的小树叶数量*/
        speedPicking(prResponse);

        /*$ZJBPR上报信息保存*/
        AdvertisingTargetInfo targetInfo = mongoTemplate.findById(Long.parseLong(prResponse.getRandomNum()), AdvertisingTargetInfo.class);
        if (null != targetInfo) {

            if (null != targetInfo.getPrResponse()) {
                logger.warn("用户{}扫码流水号{}之ZJBPR已存在：{}", prResponse.getOpenId(), prResponse.getRandomNum(), JSON.toJSONString(targetInfo.getPrResponse()));
            }

            targetInfo.setPrResponse(prResponse);
            super.updateByKey(targetInfo, IAdvertisingTargetInfoService.PRIMARY_KEY_ID);


        }

    }

    /**
     * 极速取值扣减小树叶，即增加已消费的小树叶数量
     *
     * @param pr
     */
    @Deprecated
    private void speedPicking(ZjbPrResponse pr) {

        if (System.currentTimeMillis() > Integer.MIN_VALUE) {
            //代码已作废
            return;
        }

        if (null == pr || !StringUtils.isNumeric(pr.getRandomNum()) || StringUtils.isBlank(pr.getOpenId())) {
            return;
        }

        String eventSerialNum = LocalDate.now() + "_$ZJBPL_" + pr.getDeviceName() + '_' + pr.getOutPaperSn();
        Query query = new Query(Criteria.where(UK_EVENT_SERIAL_NUM).is(eventSerialNum));
        RpcRequest rpcRequest = mongoTemplate.findOne(query, RpcRequest.class);

        if (null == rpcRequest) {
            logger.warn("Mongodb中$ZJBPL事件{}记录不存在", eventSerialNum);
            rpcRequest = findByEventSerialNumFromOTS(eventSerialNum);
        }

        if (null == rpcRequest) {
            logger.error("OTS中$ZJBPL事件{}记录不存在", eventSerialNum);
            return;
        }

        if (null == rpcRequest.getLeafSerialNum()) {
            logger.debug("用户【{}】在设备{}扫码流水号【{}】非小树叶极速取纸", pr.getOpenId(), pr.getDeviceName(), pr.getRandomNum());
            return;
        }

        /*从退回小树叶集合中删除序列号*/
        boolean remove = JedisPoolCacheUtils.srem(USER_CONSUMED_LEAF_SERIAL_NUM, ZJB_DB_50, rpcRequest.getLeafSerialNum().toString()) > 0;
        logger.info("扫码流水号【{}】小树叶取纸流水号{}移除{}", pr.getRandomNum(), rpcRequest.getLeafSerialNum(), remove ? "成功" : "失败");

        if (null == findByOpenId(pr.getOpenId())) {
            logger.error("用户【{}】不存在", pr.getOpenId());
            return;
        }

        AdvertisingUserInfo userInfo = new AdvertisingUserInfo();
        userInfo.setOpenId(pr.getOpenId());
        userInfo.setRandomNum(pr.getRandomNum());

        /*微信小树叶取纸成功公众号通知*/
        leafSuccessWeChatAccountNotice(pr, userInfo);
        /*粉丝通小树叶取纸成功余额变动通知（延迟x秒）*/
        boolean isFansNotice = fansLeafBalanceNotice(rpcRequest, pr);
        /*微信小树叶取纸成功公众号通知*/
        leafSuccessWeChatAccountNotice(pr, isFansNotice);
        /*微信小树叶取纸失败公众号通知*/
        leafFailWeChatAccountNotice(pr, rpcRequest, userInfo);
    }

    /**
     * 微信小树叶取纸成功公众号通知
     *
     * @param pr
     * @param userInfo
     */
    private void leafSuccessWeChatAccountNotice(ZjbPrResponse pr, AdvertisingUserInfo userInfo) {
        /*公众号消息推送地址*/
        String leafPrivateDomain = configService.selectConfigByKey(ZjbConfigEnum.ZJB_LEAF_PRIVATE_DOMAIN.getKey());

        String val = configService.selectConfigByKey(ZjbDictionaryTypeEnum.LEAF_SPEED_PICKING_CONSUME_WAY.getType());
        if (!LEAF_CONSUME_WAY_PR.getValue().equals(val) || !ZJB_PR_OUT_PAPER_SUCCESS.getValue().equals(pr.getOutPaperStatus())) {
            return;
        }

        /*极速取纸成功记录明细*/
        speedPicking(userInfo);
        /*极速取纸扣减小树叶*/
        AdvertisingUserInfo advertisingUserInfo = findByOpenId(userInfo.getOpenId());
        advertisingUserInfo.setAmountConsumedLeaf(null == advertisingUserInfo.getAmountConsumedLeaf() ? 20 : advertisingUserInfo.getAmountConsumedLeaf() + 20);
        super.updateByKey(advertisingUserInfo, PRIMARY_KEY_OPEN_ID);

        WeChatSms wechatSms = new WeChatSms();
        wechatSms.setZjbOpenId(userInfo.getOpenId());
        wechatSms.setType("小树叶取纸成功通知");
        wechatSms.setResult("您已支付20小树叶免广告取纸。您还有大量小树叶待领取，请及时领取噢~");
        wechatSms.setRemark("立即领取小树叶>");
        wechatSms.setClickUrl(String.format(configService.selectConfigByKey(ZJB_DSP_LEAF_INDEX_URL.getKey()), leafPrivateDomain, userInfo.getOpenId()));
        wechatSms.setJump(true);
        wechatSms.setRandomNum(pr.getRandomNum());
        feignAdminCoreService.weChatSmsSend(wechatSms);
    }

    /**
     * 微信小树叶取纸失败公众号通知
     *
     * @param pr
     * @param rpcRequest
     * @param userInfo
     */
    private void leafFailWeChatAccountNotice(ZjbPrResponse pr, RpcRequest rpcRequest, AdvertisingUserInfo userInfo) {

        String val = configService.selectConfigByKey(ZjbDictionaryTypeEnum.LEAF_SPEED_PICKING_CONSUME_WAY.getType());
        String leafPrivateDomain = configService.selectConfigByKey(ZjbConfigEnum.ZJB_LEAF_PRIVATE_DOMAIN.getKey());

        if (!LEAF_CONSUME_WAY_PL.getValue().equals(val) || !ZJB_PR_OUT_PAPER_FAIL.getValue().equals(pr.getOutPaperStatus())) {
            return;
        }

        /*极速取纸失败，恢复扣减的小树叶数量*/
        LeafIncomeExpenditureDetails details = new LeafIncomeExpenditureDetails();
        details.setOpenId(userInfo.getOpenId());
        details.setRandomNum(Long.parseLong(pr.getRandomNum()));
        List<LeafIncomeExpenditureDetails> list = leafIncomeExpenditureDetailsService.selectLeafIncomeExpenditureDetailsList(details);

        if (null == list || list.isEmpty()) {
            logger.error("用户【{}】不存在小树叶收支明细记录", userInfo.getOpenId());
            return;
        }

        speedPickingRecover(userInfo);

        String appDownUrl = configService.selectConfigByKey(ZjbConfigEnum.ZJB_DSP_APP_DOWN_URL.getKey());
        String leafUrl = String.format(configService.selectConfigByKey(ZJB_DSP_LEAF_INDEX_URL.getKey()), leafPrivateDomain, userInfo.getOpenId());
        AdvertisingTargetInfo targetInfo = StringUtils.isNumeric(rpcRequest.getRandomNum()) ? mongoTemplate.findById(Long.parseLong(rpcRequest.getRandomNum()), AdvertisingTargetInfo.class) : null;
        String adWinPlanId = (null != targetInfo ? targetInfo.getAdWinPlanId() : null);
        boolean isFans = StringUtils.startsWith(adWinPlanId, AD_UNIT_TYPE_FANS.getValue());
        WeChatSms wechatSms = new WeChatSms();
        wechatSms.setZjbOpenId(userInfo.getOpenId());
        wechatSms.setType(isFans ? "极速取纸失败通知" : "小树叶取纸失败通知");
        String result = "您在" + DateFormatUtils.format(rpcRequest.getGmtRequest(), "yyyy-MM-dd HH:mm:ss") + "发起的小树叶取纸已失败，系统已自动为您退回20小树叶";
        String resultFans = "您在" + DateFormatUtils.format(rpcRequest.getGmtRequest(), "yyyy-MM-dd HH:mm:ss") + "发起的极速取纸已失败，系统已自动为您退回20小树叶";
        wechatSms.setResult(isFans ? resultFans : result);
        wechatSms.setRemark(isFans ? "前往纸巾宝App查看>" : "立即前去查看>");
        wechatSms.setClickUrl(isFans ? appDownUrl : leafUrl);
        wechatSms.setJump(true);
        feignAdminCoreService.weChatSmsSend(wechatSms);
    }

    /**
     * 微信小树叶取纸公众号通知
     *
     * @param pr
     * @param isFansNotice 粉丝通是否已发送通知
     */
    private void leafSuccessWeChatAccountNotice(ZjbPrResponse pr, boolean isFansNotice) {

        String val = configService.selectConfigByKey(ZjbDictionaryTypeEnum.LEAF_SPEED_PICKING_CONSUME_WAY.getType());

        if (isFansNotice || !LEAF_CONSUME_WAY_PL.getValue().equals(val) || !ZJB_PR_OUT_PAPER_SUCCESS.getValue().equals(pr.getOutPaperStatus())) {
            return;
        }

        /*公众号消息推送地址*/
        String leafPrivateDomain = configService.selectConfigByKey(ZjbConfigEnum.ZJB_LEAF_PRIVATE_DOMAIN.getKey());
        WeChatSms wechatSms = new WeChatSms();
        wechatSms.setZjbOpenId(pr.getOpenId());
        wechatSms.setType("小树叶取纸成功通知");
        wechatSms.setResult("您已支付20小树叶免广告取纸。您还有大量小树叶待领取，请及时领取噢~");
        wechatSms.setRemark("立即领取小树叶>");
        wechatSms.setClickUrl(String.format(configService.selectConfigByKey(ZJB_DSP_LEAF_INDEX_URL.getKey()), leafPrivateDomain, pr.getOpenId()));
        wechatSms.setJump(true);
        wechatSms.setRandomNum(pr.getRandomNum());
        feignAdminCoreService.weChatSmsSend(wechatSms);
    }

    /**
     * 粉丝通小树叶取纸成功余额变动通知（延迟x秒）
     *
     * @param rpcRequest
     * @param pr
     */
    private boolean fansLeafBalanceNotice(RpcRequest rpcRequest, ZjbPrResponse pr) {

        String val = configService.selectConfigByKey(ZjbDictionaryTypeEnum.LEAF_SPEED_PICKING_CONSUME_WAY.getType());
        if (!LEAF_CONSUME_WAY_PL.getValue().equals(val) || !ZJB_PR_OUT_PAPER_SUCCESS.getValue().equals(pr.getOutPaperStatus())) {
            return false;
        }

        if (null == rpcRequest.getLeafSerialNum()) {
            logger.debug("用户【{}】在设备{}扫码流水号【{}】非小树叶极速取纸", pr.getOpenId(), pr.getDeviceName(), pr.getRandomNum());
            return false;
        }

        AdvertisingTargetInfo targetInfo = StringUtils.isNumeric(rpcRequest.getRandomNum()) ? mongoTemplate.findById(Long.parseLong(rpcRequest.getRandomNum()), AdvertisingTargetInfo.class) : null;
        String appDownUrl = configService.selectConfigByKey(ZjbConfigEnum.ZJB_DSP_APP_DOWN_URL.getKey());
        String adWinPlanId = (null != targetInfo ? targetInfo.getAdWinPlanId() : null);
        boolean isFans = StringUtils.startsWith(adWinPlanId, AD_UNIT_TYPE_FANS.getValue());

        if (!isFans) {
            return false;
        }

        Query query = new Query(Criteria.where(PRIMARY_KEY_OPEN_ID).is(rpcRequest.getOpenId()));

        AdvertisingUserInfo userInfo = mongoTemplate.findOne(query, getEntityClass());

        if (null == userInfo) {
            logger.error("用户【{}】不存在", rpcRequest.getOpenId());
            return false;
        }

        if (null == userInfo.getAmountObtainedLeaf()) {
            logger.error("用户【{}】未获得小树叶", rpcRequest.getOpenId());
            return false;
        }

        if (null == userInfo.getAmountConsumedLeaf()) {
            logger.error("用户【{}】未消费小树叶", rpcRequest.getOpenId());
            return false;
        }

        int leafBalance = userInfo.getAmountObtainedLeaf() - userInfo.getAmountConsumedLeaf();

        WeChatSms wechatSms = new WeChatSms();
        wechatSms.setZjbOpenId(rpcRequest.getOpenId());
        wechatSms.setType("小树叶余额变动通知");
        wechatSms.setResult("您已支付20小树叶免广告极速取纸，当前还剩余 " + (Math.max(leafBalance, 0)) + " 小树叶。每日使用纸巾宝App，可免费领取大量小树叶哦~");
        wechatSms.setRemark("立即前往纸巾宝App>");
        wechatSms.setClickUrl(appDownUrl);
        wechatSms.setJump(true);
        wechatSms.setId(rpcRequest.getGmtRequest().getTime());
        wechatSms.setRandomNum(rpcRequest.getRandomNum());

        JedisPoolCacheUtils.sadd(FANS_WE_CHAT_ACCOUNT_NOTICE_INFO_DELAY, ZJB_DB_50, EXRP_5_MINUTE, JSON.toJSONString(wechatSms));

        return true;

    }

    @Override
    public RpcRequest findByEventSerialNumFromOTS(String eventSerialNum) {

        String[] array = StringUtils.split(eventSerialNum, '_');
        if (null == array || 4 != array.length) {
            logger.warn("事件流水号格式错误");
            return null;
        }


        String tableName = "original_instruction";
        String type = "$ZJBPL";
        String deviceName = array[2];
        LocalDate localDateStart = LocalDate.parse(array[0]);
        LocalDate localDateEnd = localDateStart.plusDays(1L);

        RangeRowQueryCriteria rangeRowQueryCriteria = new RangeRowQueryCriteria(tableName);

        /*设置起始主键*/
        PrimaryKeyBuilder primaryKeyBuilder = PrimaryKeyBuilder.createPrimaryKeyBuilder();
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk1, PrimaryKeyValue.fromString(deviceName));
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk2, PrimaryKeyValue.fromString(type));
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk3, PrimaryKeyValue.fromString(localDateStart.toString()));
        rangeRowQueryCriteria.setInclusiveStartPrimaryKey(primaryKeyBuilder.build());

        /*设置结束主键*/
        primaryKeyBuilder = PrimaryKeyBuilder.createPrimaryKeyBuilder();
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk1, PrimaryKeyValue.fromString(deviceName));
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk2, PrimaryKeyValue.fromString(type));
        primaryKeyBuilder.addPrimaryKeyColumn(TableStoreClientUtils.pk3, PrimaryKeyValue.fromString(localDateEnd.toString()));
        rangeRowQueryCriteria.setExclusiveEndPrimaryKey(primaryKeyBuilder.build());

        /*显示最近的多少条数据*/
        rangeRowQueryCriteria.setMaxVersions(1000000);

        GetRangeResponse getRangeResponse = TableStoreClientUtils.getClient().getRange(new GetRangeRequest(rangeRowQueryCriteria));

        for (Row row : getRangeResponse.getRows()) {

            for (Column column : row.getColumn(TableStoreClientUtils.value)) {
                ZjbPlRequest pl = new ZjbPlRequest();
                pl.handleRequest(column.getValue().toString());

                if (null == pl.getOutPaperSerialNum() || !pl.getOutPaperSerialNum().toString().equals(array[3])) {
                    continue;
                }

                RpcRequest rpcRequest = new RpcRequest();
                rpcRequest.setZjbPl(pl);

                return rpcRequest;
            }
        }

        return null;
    }

    @Override
    public AdvertisingUserInfo findById(String id) {
        return mongoTemplate.findById(id, AdvertisingUserInfo.class);
    }

    @Override
    public int deleteAdvertisingUserInfoByIds(String ids) {

        String[] array = StringUtils.split(ids, ',');

        if (null != array && array.length > 0) {
            for (String id : array) {
                AdvertisingUserInfo userInfo = mongoTemplate.findById(id, AdvertisingUserInfo.class);
                if (null == userInfo) {
                    continue;
                }
                mongoTemplate.remove(userInfo);
            }
        }

        return 1;
    }

    @Override
    public List<AdvertisingUserInfo> selectAdvertisingUserInfoList(AdvertisingUserInfo userInfo) {

        Criteria criteria = new Criteria();

        if (StringUtils.isNotBlank(userInfo.getOpenId())) {
            criteria.and(PRIMARY_KEY_OPEN_ID).is(userInfo.getOpenId());
        }

        Query query = new Query(criteria);

        long count = mongoTemplate.count(query, getEntityClass());

        Pageable pageable = IMgBaseService.PAGEABLE_THREAD_LOCAL.get();
        if (null != pageable) {
            query.with(pageable);
        }

        List<AdvertisingUserInfo> list = mongoTemplate.find(query, getEntityClass());

        if (null != pageable && !list.isEmpty()) {
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(0);
            rspData.setRows(list);
            rspData.setTotal(count);
            IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.set(rspData);
        }

        return list;
    }
}
