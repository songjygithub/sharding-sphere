package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 公众号或小程序的第三方平台授权
 * 表 zjb_component_authorization_info
 *
 * @author shenlong
 * @date 2019-11-08
 */
public class ComponentAuthorizationInfo extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 自增主键
     */
    private Integer id;
    /**
     *
     */
    private String componentId;
    /**
     * 公众号appid
     */
    private String appId;
    /**
     * 广告主唯一标识
     */
    private String zjbAppId;

    /**
     * 授权公司主体ID
     */
    private Integer companyId;
    /**
     * 授权公司主体名称
     */
    private String companyName;
    /**
     * 授权公司主体第三方平台ID
     */
    private Integer thirdPlatformAppId;
    /**
     * 授权公司主体第三方平台名称
     */
    private String thirdPlatformAppName;
    /**
     * 公众号授权类型（参考字典）
     */
    private Integer componentAuthorizationType;
    /**
     * 公众号获取地址
     */
    private String publicPlatformUrl;
    /**
     * 授权方公众号的原始ID
     */
    private String userName;
    /**
     * 授权方昵称
     */
    private String nickName;
    /**
     * 授权方头像
     */
    private String headImg;
    /**
     * 授权方公众号类型，0代表订阅号，1代表由历史老帐号升级后的订阅号，2代表服务号
     */
    private String serviceTypeInfo;
    /**
     * 授权方认证类型，-1代表未认证，0代表微信认证，1代表新浪微博认证，2代表腾讯微博认证，3代表已资质认证通过但还未通过名称认证，4代表已资质认证通过、还未通过名称认证，但通过了新浪微博认证，5代表已资质认证通过、还未通过名称认证，但通过了腾讯微博认证
     */
    private String verifyTypeInfo;
    /**
     * 公众号的主体名称
     */
    private String principalName;
    /**
     * 授权方公众号所设置的微信号，可能为空
     */
    private String alias;
    /**
     * 二维码图片的URL，开发者最好自行也进行保存
     */
    private String qrcodeUrl;
    /**
     * 用以了解以下功能的开通状况（0代表未开通，1代表已开通）： open_store:是否开通微信门店功能 open_scan:是否开通微信扫商品功能 open_pay:是否开通微信支付功能 open_card:是否开通微信卡券功能 open_shake:是否开通微信摇一摇功能
     */
    private String businessInfo;
    /**
     * 公众号授权给开发者的权限集列表
     */
    private String funcInfo;
    /**
     * 授权状态
     */
    private String authorizationStatus;
    /**
     * 推送信息广告id
     */
    private String msgId;
    /**
     * 推送消息广告名称
     */
    private String msgName;
    /**
     * 日投放量
     */
    private Integer dayDeliveryLimit;
    /**
     * 日关注量
     */
    private Integer dayFollowAmount;
    /**
     * 总投放量
     */
    private Integer totalDeliveryLimit;
    /**
     * 总关注量
     */
    private Integer totalFollowAmount;
    /**
     * 投放状态，1：生效中：公众号状态正常，可正常调用展示给用户关注 2：手动停用：手动停止使用 3：日投放量不足停用：日投放量不足自动停用 总投放量不足停用：总投放量不足自动停用
     */
    private Integer deliveryStatus;
    /**
     * 标签ID
     */
    private Integer labelId;
    /**
     * 标签名称
     */
    private String labelName;
    /**
     * 标签状态
     */
    private Integer labelStatus;
    /**
     * 未认证的个人号是否记录openid
     */
    private Integer recordStatus;

    /**
     * 取纸二维码类型  1:自动生成  2:指定二维码
     */
    private Integer pickPaperType;
    /**
     * 指定取纸二维码链接
     */
    private String pickPaperUrl;


    // 直跳链接
    @Deprecated
    private String leapingLink;

    /**
     * 授权公司第三方平台APPID 非数据库映射字段
     */
    private String companyAppId;

    private Integer operationType;

    @Deprecated
    public String getLeapingLink() {
        return leapingLink;
    }

    @Deprecated
    public void setLeapingLink(String leapingLink) {
        this.leapingLink = leapingLink;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setComponentId(String componentId) {
        this.componentId = componentId;
    }

    public String getComponentId() {
        return componentId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppId() {
        return appId;
    }

    public String getZjbAppId() {
        return zjbAppId;
    }

    public void setZjbAppId(String zjbAppId) {
        this.zjbAppId = zjbAppId;
    }

    public Integer getCompanyId() {
        return companyId;
    }

    public void setCompanyId(Integer companyId) {
        this.companyId = companyId;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Integer getThirdPlatformAppId() {
        return thirdPlatformAppId;
    }

    public void setThirdPlatformAppId(Integer thirdPlatformAppId) {
        this.thirdPlatformAppId = thirdPlatformAppId;
    }

    public String getThirdPlatformAppName() {
        return thirdPlatformAppName;
    }

    public void setThirdPlatformAppName(String thirdPlatformAppName) {
        this.thirdPlatformAppName = thirdPlatformAppName;
    }

    public Integer getComponentAuthorizationType() {
        return componentAuthorizationType;
    }

    public void setComponentAuthorizationType(Integer componentAuthorizationType) {
        this.componentAuthorizationType = componentAuthorizationType;
    }

    public String getPublicPlatformUrl() {
        return publicPlatformUrl;
    }

    public void setPublicPlatformUrl(String publicPlatformUrl) {
        this.publicPlatformUrl = publicPlatformUrl;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName() {
        return userName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setHeadImg(String headImg) {
        this.headImg = headImg;
    }

    public String getHeadImg() {
        return headImg;
    }

    public void setServiceTypeInfo(String serviceTypeInfo) {
        this.serviceTypeInfo = serviceTypeInfo;
    }

    public String getServiceTypeInfo() {
        return serviceTypeInfo;
    }

    public void setVerifyTypeInfo(String verifyTypeInfo) {
        this.verifyTypeInfo = verifyTypeInfo;
    }

    public String getVerifyTypeInfo() {
        return verifyTypeInfo;
    }

    public void setPrincipalName(String principalName) {
        this.principalName = principalName;
    }

    public String getPrincipalName() {
        return principalName;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getAlias() {
        return alias;
    }

    public void setQrcodeUrl(String qrcodeUrl) {
        this.qrcodeUrl = qrcodeUrl;
    }

    public String getQrcodeUrl() {
        return qrcodeUrl;
    }

    public void setBusinessInfo(String businessInfo) {
        this.businessInfo = businessInfo;
    }

    public String getBusinessInfo() {
        return businessInfo;
    }

    public void setFuncInfo(String funcInfo) {
        this.funcInfo = funcInfo;
    }

    public String getFuncInfo() {
        return funcInfo;
    }

    public void setAuthorizationStatus(String authorizationStatus) {
        this.authorizationStatus = authorizationStatus;
    }

    public String getAuthorizationStatus() {
        return authorizationStatus;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getMsgId() {
        return msgId;
    }

    public void setMsgName(String msgName) {
        this.msgName = msgName;
    }

    public String getMsgName() {
        return msgName;
    }

    public void setDayDeliveryLimit(Integer dayDeliveryLimit) {
        this.dayDeliveryLimit = dayDeliveryLimit;
    }

    public Integer getDayDeliveryLimit() {
        return dayDeliveryLimit;
    }

    public void setDayFollowAmount(Integer dayFollowAmount) {
        this.dayFollowAmount = dayFollowAmount;
    }

    public Integer getDayFollowAmount() {
        return dayFollowAmount;
    }

    public void setTotalDeliveryLimit(Integer totalDeliveryLimit) {
        this.totalDeliveryLimit = totalDeliveryLimit;
    }

    public Integer getTotalDeliveryLimit() {
        return totalDeliveryLimit;
    }

    public void setTotalFollowAmount(Integer totalFollowAmount) {
        this.totalFollowAmount = totalFollowAmount;
    }

    public Integer getTotalFollowAmount() {
        return totalFollowAmount;
    }

    public void setDeliveryStatus(Integer deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    public Integer getDeliveryStatus() {
        return deliveryStatus;
    }

    public void setLabelId(Integer labelId) {
        this.labelId = labelId;
    }

    public Integer getLabelId() {
        return labelId;
    }

    public void setLabelName(String labelName) {
        this.labelName = labelName;
    }

    public String getLabelName() {
        return labelName;
    }

    public void setLabelStatus(Integer labelStatus) {
        this.labelStatus = labelStatus;
    }

    public Integer getLabelStatus() {
        return labelStatus;
    }

    public Integer getRecordStatus() {
        return recordStatus;
    }

    public void setRecordStatus(Integer recordStatus) {
        this.recordStatus = recordStatus;
    }

    public String getCompanyAppId() {
        return companyAppId;
    }

    public void setCompanyAppId(String companyAppId) {
        this.companyAppId = companyAppId;
    }

    public Integer getPickPaperType() {
        return pickPaperType;
    }

    public void setPickPaperType(Integer pickPaperType) {
        this.pickPaperType = pickPaperType;
    }

    public String getPickPaperUrl() {
        return pickPaperUrl;
    }

    public void setPickPaperUrl(String pickPaperUrl) {
        this.pickPaperUrl = pickPaperUrl;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }
}
