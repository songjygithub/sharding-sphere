package com.zjb.project.dsp.advertisingPlan.service;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_OK;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_USE_YES;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombinationUnit;
import com.zjb.project.dsp.advertisingCombination.mapper.AdvertisingCombinationMapper;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.mapper.AdvertisingPlanMapper;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;

/**
 * 广告投放计划 服务层实现
 *
 * @author songjy
 * @date 2019-07-13
 */
@Service
public class AdvertisingPlanServiceImpl extends AdPlanServiceImpl implements IAdvertisingPlanService {
    private static final Logger logger = LoggerFactory.getLogger(AdvertisingPlanServiceImpl.class);
    @Autowired
    private AdvertisingPlanMapper advertisingPlanMapper;
    @Autowired
    private AdvertisingCombinationMapper advertisingCombinationMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;

    /**
     * 查询广告投放计划信息
     *
     * @param id 广告投放计划ID或planId
     * @return 广告投放计划信息
     */
    @Override
    public AdvertisingPlan selectAdvertisingPlanById(Serializable id) {

        if (null == id) {
            return null;
        }

        if (String.class == id.getClass() && id.toString().startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())) {
            return advertisingPlanMapper.selectAdvertisingPlanByPlanId((String) id);
        }

        if (id.getClass() == Integer.class || id.getClass() == int.class) {
            return advertisingPlanMapper.selectAdvertisingPlanById((Integer) id);
        }

        return null;
    }


    /**
     * 查询广告投放计划列表
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 广告投放计划集合
     */
    @Override
    public List<AdvertisingPlan> selectAdvertisingPlanList(AdvertisingPlan advertisingPlan) {

        return advertisingPlanMapper.selectAdvertisingPlanList(advertisingPlan);
    }

    /**
     * 新增广告投放计划
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingPlan(AdvertisingPlan advertisingPlan) {
        advertisingPlan.setGmtCreated(new Date());
        advertisingPlan.setGmtModified(advertisingPlan.getGmtCreated());
        advertisingPlan.setModifierId(advertisingPlan.getCreaterId());
        if(StringUtils.isNotEmpty(advertisingPlan.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlan);
        }

        int r = advertisingPlanMapper.insertAdvertisingPlan(advertisingPlan);


        if (r <= 0) {
            return r;
        }

        handleComponentAuthorizationType(advertisingPlan);


        /*业务标识自增主键，且必须是01开头，即01 + id*/
        advertisingPlan.setPlanId(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue().toString() + advertisingPlan.getId());
        r += advertisingPlanMapper.updateAdvertisingPlan(advertisingPlan);

        /*保存广告投放定向信息*/
        r += insertTargetingInfo(advertisingPlan);

        synchronizeRedis(advertisingPlanMapper.selectAdvertisingPlanById(advertisingPlan.getId()));

        return r;
    }

    /**
     * 修改广告投放计划
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingPlan(AdvertisingPlan advertisingPlan) {

        AdvertisingPlan advertisingPlanOld = advertisingPlanMapper.selectAdvertisingPlanById(advertisingPlan.getId());

        if (null == advertisingPlanOld) {
            return 0;
        }

        if(StringUtils.isNotEmpty(advertisingPlan.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlan);
        }

        setAdvertisingStatus(advertisingPlan, advertisingPlanOld);

        handleComponentAuthorizationType(advertisingPlan);

        int r = advertisingPlanMapper.updateAdvertisingPlan(advertisingPlan);

        if (r <= 0) {
            return r;
        }

        synchronizeAdvertisingStatus(advertisingPlan);

        if (null != advertisingPlan.getAdvertisingStatus() && !advertisingPlan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            /*该广告投放暂停*/
            clearLocalCacheRegex(advertisingPlanOld.getPlanId());
        }

        if (null != advertisingPlan.getAdvertisingStatus()
                && advertisingPlan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_PAUSE_MANUAL.getValue())) {
            /*该广告投放恢复*/
            reloadPattern(advertisingPlanOld.getPlanId());
        }

        /*修改广告投放定向信息*/
        r += updateTargetingInfo(advertisingPlan);

        AdvertisingPlan advertisingPlanNew = advertisingPlanMapper.selectAdvertisingPlanById(advertisingPlan.getId());
        synchronizeRedis(advertisingPlanNew);
        /*Redis中数据保存到数据库中*/
        advertisingPlanMapper.updateAdvertisingPlan(advertisingPlanNew);

        return r;
    }

    /**
     * 同步Redis数据
     *
     * @param plan
     */
    public static void synchronizeRedis(AdvertisingPlan plan) {

        if (null == plan) {
            return;
        }

        String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + plan.getPlanId();
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null != planFromRedis) {
            /*今日花费*/
            plan.setTodaySpend(planFromRedis.getTodaySpend());
            /*今日胜出次数*/
            plan.setTodayWinNum(planFromRedis.getTodayWinNum());
            /*总胜出次数*/
            plan.setTotalWinNum(planFromRedis.getTotalWinNum());
            /*总花费*/
            plan.setTotalSpend(planFromRedis.getTotalSpend());
            /*竞价胜出次数*/
            plan.setBidWinNum(planFromRedis.getBidWinNum());
            /*参与竞价次数*/
            plan.setParticipateBidNum(planFromRedis.getParticipateBidNum());
            /*广告投放状态*/
            if (!ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue().equals(planFromRedis.getAdvertisingStatus())) {
                logger.info("广告计划【{}】暂停", plan.getPlanId());
            }
            plan.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());

        }

        if (ZjbDictionaryEnum.YES.getValue().equals(plan.getDeleted())) {
            JedisPoolCacheUtils.setVExpire(key, "", JedisPoolCacheUtils.EXRP_SECOND, ZJB_DB_50);
            return;
        }

        JedisPoolCacheUtils.setVExpire(key, plan, JedisPoolCacheUtils.EXRP_MONTH, ZJB_DB_50);
    }

    /**
     * 删除广告投放计划对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingPlanByIds(String ids) {
        return advertisingPlanMapper.deleteAdvertisingPlanByIds(Convert.toStrArray(ids));
    }

    @Override
    public int logicDeleteAdvertisingPlanByIds(String ids) {

        String[] array = Convert.toStrArray(ids);
        int r = advertisingPlanMapper.logicDeleteAdvertisingPlanByIds(Convert.toStrArray(ids));

        /*清空缓存对应数据*/
        for (String id : array) {
            id = id.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue()) ? id : (ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue() + id);
            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + id;
            clearLocalCacheRegex(id);
            JedisPoolCacheUtils.setVExpire(key, "", JedisPoolCacheUtils.EXRP_SECOND, ZJB_DB_50);
        }

        return r;
    }

    @Override
    public List<AdvertisingPlan> selectByAdAppId(String adAppId) {
        return advertisingPlanMapper.selectByAdAppId(adAppId);
    }

    @Override
    public List<AdvertisingPlan> selectByUnitId(Integer unitId) {

        if (null == unitId) {
            return Collections.emptyList();
        }

        List<AdvertisingCombinationUnit> combinationUnits = advertisingCombinationMapper.selectByUnitId(unitId);

        if (null == combinationUnits || combinationUnits.isEmpty()) {
            return Collections.emptyList();
        }

        List<AdvertisingPlan> list = new ArrayList<>();

        for (AdvertisingCombinationUnit combinationUnit : combinationUnits) {
            AdvertisingPlan advertisingPlan = new AdvertisingPlan();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());
            List<AdvertisingPlan> planList = advertisingPlanMapper.selectAdvertisingPlanList(advertisingPlan);
            if (null != planList && !planList.isEmpty()) {
                list.addAll(planList);
            }
        }

        return list;
    }

    private void handleComponentAuthorizationType(AdvertisingPlan advertisingPlan){
        if(advertisingPlan == null || null == advertisingPlan.getCombinationId()){
            return;
        }
        AdvertisingCombination advertisingCombination = advertisingCombinationMapper.selectAdvertisingCombinationById(advertisingPlan.getCombinationId());
        if(advertisingCombination == null || null == advertisingCombination.getId()){
            return;
        }
        AdvertisingCombinationUnit unit = new AdvertisingCombinationUnit();
        unit.setCombinationId(advertisingCombination.getId());

        List<AdvertisingCombinationUnit> advertisingCombinationUnitList = advertisingCombinationMapper.selectAdvertisingCombinationUnitList(unit);
        if(advertisingCombinationUnitList == null || advertisingCombinationUnitList.size() <=0){
            return;
        }
        advertisingCombinationUnitList = advertisingCombinationUnitList.stream().filter(e->e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT.getValue())).collect(Collectors.toList());

        if(advertisingCombinationUnitList.size() != 1){
            return;
        }
        AdvertisingUnit advertisingUnit = advertisingUnitMapper.selectAdvertisingUnitById(advertisingCombinationUnitList.get(0).getAdUnitId());
        if(advertisingUnit == null || null == advertisingUnit.getAdUseStatus() || !AD_USE_YES.getValue().equals(advertisingUnit.getAdUseStatus()) || StringUtils.isEmpty(advertisingUnit.getWeChatAccount())){
            return;
        }
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(advertisingUnit.getWeChatAccount());
        if(componentAuthorizationInfo == null){
            return;
        }
        advertisingPlan.setComponentAuthorizationType(componentAuthorizationInfo.getComponentAuthorizationType());
    }

    private void handleDeviceInstallScene(AdvertisingPlan advertisingPlan){
        if(StringUtils.isEmpty(advertisingPlan.getInstallSceneIds())){
            return;
        }
        Set<String> set = new HashSet<>();
        String[] sceneIds = advertisingPlan.getInstallSceneIds().split(",");
        if(sceneIds == null || sceneIds.length<=0){
            return;
        }
        for(String sceneId : sceneIds){
            DeviceInstallScene deviceInstallScene = deviceInstallSceneService.getDeviceInstallSceneById(sceneId);
            if(deviceInstallScene != null && StringUtils.isNotEmpty(deviceInstallScene.getSceneCode())){
                set.add(deviceInstallScene.getSceneCode());
            }
        }
        if(set.size() == 0){
            return;
        }
        advertisingPlan.setDeviceScene(String.join(",", set));

    }
}
