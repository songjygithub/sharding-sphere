package com.zjb.project.dsp.advertisingUnitWx.controller;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_REDIRECT_WE_CHAT_ACCOUNT;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT_WX;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MONTH;

import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.service.IAdvertisingUnitWxService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.service.IGzhGroupService;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.service.IScanTaskService;

/**
 * 广告池-微信 信息操作处理
 *
 * @author ZH
 * @date 2019-08-13
 */
@Controller
@RequestMapping("/dsp/advertisingUnitWx")
public class AdvertisingUnitWxController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "zjb/advertisingUnitWx";

    @Autowired
    private IAdvertisingUnitWxService advertisingUnitWxService;
    @Autowired
    private IScanTaskService scanTaskService;
    @Autowired
    private IGzhGroupService gzhGroupService;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IAdvertisingPlanWxService advertisingPlanWxService;

    @RequiresPermissions("dsp:advertisingUnitWx:view")
    @GetMapping()
    public String advertisingUnitWx() {
        return prefix + "/advertisingUnitWx";
    }

    /**
     * 查询广告池列表
     */
    @RequiresPermissions("dsp:advertisingUnitWx:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingUnitWx advertisingUnitWx) {
        startPage();
        List<AdvertisingUnitWx> list = advertisingUnitWxService.selectAdvertisingUnitWxList(advertisingUnitWx);
        return getDataTable(list);
    }

    /**
     * 新增广告池
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }


    /**
     * 新增保存广告池
     */
    @RequiresPermissions("dsp:advertisingUnitWx:add")
    @Log(title = "广告池", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingUnitWx advertisingUnitWx) {
        advertisingUnitWx.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());

        if (!AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(advertisingUnitWx.getAdSpaceIdentifier())) {
            advertisingUnitWx.setWeChatAccount(null);
            advertisingUnitWx.setWeChatAccountName(null);
        }

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnitWx.getRedirectUrlType())) {
            advertisingUnitWx.setRedirectUrl(advertisingUnitWx.getWeChatAccountName());
        }

        return toAjax(advertisingUnitWxService.insertAdvertisingUnitWx(advertisingUnitWx));
    }

    /**
     * 修改广告池
     */
    @GetMapping("/edit")
    public String edit() {
        return prefix + "/edit";
    }

    /**
     * 获取广告信息
     */
    @PostMapping("/getAdvertisingUnitWx/{id}")
    @ResponseBody
    public AjaxResult advertisingUnit(@PathVariable("id") Integer id) {
        AdvertisingUnitWx advertisingUnitWx = advertisingUnitWxService.selectAdvertisingUnitWxById(id);
        if (null != advertisingUnitWx) {
            return success(advertisingUnitWx);
        }
        return error();
    }

    /**
     * 修改保存广告池
     */
    @RequiresPermissions("dsp:advertisingUnitWx:edit")
    @Log(title = "广告池", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingUnitWx advertisingUnitWx) {
        advertisingUnitWx.setUpdateBaseParams(getUserId().intValue());
        //置空
        if (StringUtils.isEmpty(advertisingUnitWx.getSupplementParam1())) {
            advertisingUnitWx.setSupplementParam1("-1");
        }
        if (StringUtils.isEmpty(advertisingUnitWx.getSupplementParam2())) {
            advertisingUnitWx.setSupplementParam2("-1");
        }

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnitWx.getRedirectUrlType())) {
            advertisingUnitWx.setRedirectUrl(advertisingUnitWx.getWeChatAccountName());
        }

        boolean stop = weChatOfficialAccountIsStop(advertisingUnitWx);

        if (stop) {
            return error("该取纸广告中配置的公众号已停用，如需启用请先至公众号开放平台将对应公众号改为生效状态。");
        }

        int r = advertisingUnitWxService.updateAdvertisingUnitWx(advertisingUnitWx);

        restartAdvertisingPlanWx(advertisingUnitWx);
        stopAdvertisingPlan(advertisingUnitWx);

        advertisingPlanWxService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 取纸广告停用暂停对应的广告计划
     *
     * @param advertisingUnit
     */
    private void stopAdvertisingPlan(AdvertisingUnitWx advertisingUnit) {
        if (null == advertisingUnit
                || null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(ZjbDictionaryEnum.AD_USE_NO.getValue())) {
            return;
        }

        if (!AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(advertisingUnit.getAdSpaceIdentifier())) {
            return;
        }

        List<AdvertisingPlanWx> planList = advertisingPlanWxService.selectByUnitId(advertisingUnit.getId());

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlanWx advertisingPlan : planList) {

            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + advertisingPlan.getPlanId();
            AdvertisingPlanWx planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlanWx.class);
            planFromRedis.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);
            logger.warn("扫码取纸位【{}】停用", advertisingUnit.getAdName());
            advertisingPlanService.clearLocalCacheRegex(advertisingPlan.getPlanId());
        }

    }

    /**
     * 广告取纸位关联的公众号是否已停止
     *
     * @param advertisingUnitWx
     * @return
     */
    private boolean weChatOfficialAccountIsStop(AdvertisingUnitWx advertisingUnitWx) {

        if (null == advertisingUnitWx.getAdUseStatus()
                || !advertisingUnitWx.getAdUseStatus().equals(ZjbDictionaryEnum.AD_USE_YES.getValue())
                || !AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(advertisingUnitWx.getAdSpaceIdentifier())
                || !StringUtils.isNumeric(advertisingUnitWx.getAppId())
                || !ZjbDictionaryEnum.AD_REDIRECT_TASK.getValue().equals(advertisingUnitWx.getRedirectUrlType())) {
            return false;
        }

        ScanTask scanTask = scanTaskService.selectScanTaskById(Integer.parseInt(advertisingUnitWx.getAppId()));

        if (null == scanTask || !StringUtils.isNumeric(scanTask.getExpansionA())) {
            return false;
        }

        GzhGroup gzhGroup = gzhGroupService.selectGzhGroupById(Integer.parseInt(scanTask.getExpansionA()));
        if (null == gzhGroup || StringUtils.isBlank(gzhGroup.getGzhList())) {
            return false;
        }

        String[] arr = StringUtils.split(gzhGroup.getGzhList(), ',');

        for (String id : arr) {
            if (!StringUtils.isNumeric(id)) {
                continue;
            }

            ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(Integer.parseInt(id));

            if (null == componentAuthorizationInfo || null == componentAuthorizationInfo.getDeliveryStatus()) {
                continue;
            }

            if (!componentAuthorizationInfo.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue())) {
                logger.warn("公众号【{}】状态：{}", componentAuthorizationInfo.getNickName(), componentAuthorizationInfo.getDeliveryStatus());
                return true;
            }

        }

        return false;
    }

    /**
     * 删除广告池
     */
    @RequiresPermissions("dsp:advertisingUnitWx:remove")
    @Log(title = "广告池", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {

        String[] array = StringUtils.split(ids, ',');
        for (String idStr : array) {
            AdvertisingUnitWx advertisingUnitWx = advertisingUnitWxService.selectAdvertisingUnitWxById(Integer.parseInt(idStr));
            advertisingUnitWx.setAdUseStatus(ZjbDictionaryEnum.AD_USE_NO.getValue());
            stopAdvertisingPlan(advertisingUnitWx);
        }

        int r = advertisingUnitWxService.deleteAdvertisingUnitWxByIds(ids);
        //删除广告方案的广告
        r += advertisingCombinationWxService.deleteAdvertisingCombinationUnitWxByUnitId(ids);
        return toAjax(r);

    }

}
