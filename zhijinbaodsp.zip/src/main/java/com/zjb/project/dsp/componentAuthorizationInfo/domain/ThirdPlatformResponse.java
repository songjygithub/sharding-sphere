package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import java.io.Serializable;

/**
 * 调用第三方公众号返回结果
 *
 * @author jiangbingjie
 */
public class ThirdPlatformResponse implements Serializable{
    private static final long serialVersionUID = -1358929458634765166L;

    /**
     * 状态码
     */
    private Integer code;

    /**
     * 返回调用结果
     */
    private String msg;

    /**
     * 调用第三方公众号返回数据
     */
    private ThirdPlatformData data;

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public ThirdPlatformData getData() {
        return data;
    }

    public void setData(ThirdPlatformData data) {
        this.data = data;
    }
}
