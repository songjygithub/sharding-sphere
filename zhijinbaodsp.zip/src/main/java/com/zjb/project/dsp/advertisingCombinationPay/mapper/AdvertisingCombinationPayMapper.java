package com.zjb.project.dsp.advertisingCombinationPay.mapper;

import com.zjb.project.dsp.advertisingCombinationPay.domain.AdvertisingCombinationPay;
import java.util.List;	

/**
 * 广告方案-支付 数据层
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
public interface AdvertisingCombinationPayMapper 
{
	/**
     * 查询广告方案-支付信息
     * 
     * @param id 广告方案-支付ID
     * @return 广告方案-支付信息
     */
	public AdvertisingCombinationPay selectAdvertisingCombinationPayById(Integer id);
	
	/**
     * 查询广告方案-支付列表
     * 
     * @param advertisingCombinationPay 广告方案-支付信息
     * @return 广告方案-支付集合
     */
	public List<AdvertisingCombinationPay> selectAdvertisingCombinationPayList(AdvertisingCombinationPay advertisingCombinationPay);
	
	/**
     * 新增广告方案-支付
     * 
     * @param advertisingCombinationPay 广告方案-支付信息
     * @return 结果
     */
	public int insertAdvertisingCombinationPay(AdvertisingCombinationPay advertisingCombinationPay);
	
	/**
     * 修改广告方案-支付
     * 
     * @param advertisingCombinationPay 广告方案-支付信息
     * @return 结果
     */
	public int updateAdvertisingCombinationPay(AdvertisingCombinationPay advertisingCombinationPay);
	
	/**
     * 删除广告方案-支付
     * 
     * @param id 广告方案-支付ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationPayById(Integer id);
	
	/**
     * 批量删除广告方案-支付
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationPayByIds(String[] ids);
	
}