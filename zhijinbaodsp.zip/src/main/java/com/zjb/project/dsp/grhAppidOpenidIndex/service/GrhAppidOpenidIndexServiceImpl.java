package com.zjb.project.dsp.grhAppidOpenidIndex.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.zjb.common.constant.Constants;
import com.zjb.project.dsp.grhAppidOpenidIndex.domain.GrhAppidOpenidIndex;

/**
 * @author jiangbingjie
 * @date 2020/3/20 4:30 下午
 */
@Service
public class GrhAppidOpenidIndexServiceImpl implements IGrhAppidOpenidIndexService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Override
    public GrhAppidOpenidIndex selectByZjbOpenIdAndPersonalAppId(String zjbOpenId, String personalAppid) {
        String sql = "SELECT * FROM `zjb_grh_appid_openid_index` WHERE `zjb_openid` = ? AND personal_appid = ? LIMIT 1";
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR};
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{zjbOpenId, personalAppid}, argTypes, new RowMapper<GrhAppidOpenidIndex>() {
                @Override
                public GrhAppidOpenidIndex mapRow(ResultSet rs, int rowNum) throws SQLException {
                    GrhAppidOpenidIndex record = new GrhAppidOpenidIndex();
                    setValues(rs, record);
                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * 设置值
     *
     * @param rs
     * @param record
     * @throws SQLException
     */
    private void setValues(ResultSet rs, GrhAppidOpenidIndex record) throws SQLException {
        record.setId(rs.getInt("id"));
        record.setZjbOpenid(rs.getString("zjb_openid"));
        record.setOpenid(rs.getString("openid"));
        record.setPersonalAppid(rs.getString("personal_appid"));
        record.setNickName(rs.getString("nick_name"));
        record.setSex(rs.getInt("sex"));
        record.setHeadImgUrl(rs.getString("head_img_url"));
        record.setCountry(rs.getString("country"));
        record.setProvince(rs.getString("province"));
        record.setCity(rs.getString("city"));
        record.setEvent(rs.getString("event"));
    }
}
