package com.zjb.project.dsp.advertisementPlanDevice.service;

import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import java.util.List;

/**
 * 非竞价广告投放设备定向 服务层
 * 
 * @author Nigel Yang
 * @date 2020-05-09
 */
public interface IAdvertisementPlanDeviceService 
{
	/**
     * 查询非竞价广告投放设备定向信息
     * 
     * @param id 非竞价广告投放设备定向ID
     * @return 非竞价广告投放设备定向信息
     */
	public AdvertisementPlanDevice selectAdvertisementPlanDeviceById(Integer id);
	
	/**
     * 查询非竞价广告投放设备定向列表
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 非竞价广告投放设备定向集合
     */
	public List<AdvertisementPlanDevice> selectAdvertisementPlanDeviceList(AdvertisementPlanDevice advertisementPlanDevice);
	
	/**
     * 新增非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	public int insertAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice);
	
	/**
     * 修改非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	public int updateAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice);
		
	/**
     * 删除非竞价广告投放设备定向信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisementPlanDeviceByIds(String ids);

	/**
	 * 删除设备定向
	 * @param toStrArray
	 */
    void deleteAdvertisementPlanDeviceByAdvertisementPlanIds(String[] toStrArray);
}
