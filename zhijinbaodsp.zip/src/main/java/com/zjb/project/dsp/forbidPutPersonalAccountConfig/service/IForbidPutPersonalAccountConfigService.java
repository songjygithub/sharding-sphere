package com.zjb.project.dsp.forbidPutPersonalAccountConfig.service;

import java.util.List;

import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.domain.ForbidPutPersonalAccountConfig;

/**
 * 指定次数禁投个人号广告配置 服务层
 * 
 * @author jiangbingjie
 * @date 2020-04-22
 */
public interface IForbidPutPersonalAccountConfigService 
{
	/**
     * 查询指定次数禁投个人号广告配置信息
     * 
     * @param configId 指定次数禁投个人号广告配置ID
     * @return 指定次数禁投个人号广告配置信息
     */
	public ForbidPutPersonalAccountConfig selectForbidPutPersonalAccountConfigById(Integer configId);
	
	/**
     * 查询指定次数禁投个人号广告配置列表
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 指定次数禁投个人号广告配置集合
     */
	public List<ForbidPutPersonalAccountConfig> selectForbidPutPersonalAccountConfigList(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
	
	/**
     * 新增指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	public int insertForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
	
	/**
     * 修改指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	public int updateForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
		
	/**
     * 删除指定次数禁投个人号广告配置信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteForbidPutPersonalAccountConfigByIds(String ids);

	/**
	 * 添加个人号屏蔽正则匹配
	 *
	 * @param config
	 */
	void addPattern(ForbidPutPersonalAccountConfig config);

	/**
	 * 个人号屏蔽记录是否生效
	 *
	 * @param config
	 * @return
	 */
	boolean effective(ForbidPutPersonalAccountConfig config);

	/**
	 * 移除个人号屏蔽正则
	 *
	 * @param config
	 */
	void removePattern(ForbidPutPersonalAccountConfig config);

	/**
	 * 个人号屏蔽正则
	 *
	 * @param deviceInfo
	 * @param peopleInfo
	 * @return
	 */
	boolean matcher(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo);

	/**
	 * 查询自动失效记录
	 *
	 * @return
	 */
	List<ForbidPutPersonalAccountConfig> selectAutomaticInvalid();

	/**
	 * 获取配置状态为空的配置信息
	 *
	 * @return
	 */
	List<ForbidPutPersonalAccountConfig> getForbidPutPersonalAccountListWithoutStatus();
	
}
