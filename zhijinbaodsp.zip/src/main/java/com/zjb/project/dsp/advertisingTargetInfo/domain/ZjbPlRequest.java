package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.common.utils.StringUtils;

import java.io.Serializable;

/**
 * @author songjy
 * @date 2019/10/17
 */
public class ZjbPlRequest implements Serializable {
    private static final long serialVersionUID = -1227642374195192446L;

    /**
     * $ZJBPL,<出纸流水号>,<纸巾长度>,<时间戳>,<下一次二维码内容>,<出纸成功语音>,<MD5校验值>,@
     * <p>
     * 一代机：$ZJBPL,70,14,2019-10-15 21:04:27,1E2DC77E3486B28DB82798A19ADB3299,@
     * <p>
     * 二代机：$ZJBPL,1,16,2019-10-17 11:42:45,https://m.zhijinbao.net/device/v2/s/865373046005687_26E22ECFFBF3ACE32AE337C299E7DD7E,74F707B9830299CAA199831795897773,@
     */
    private String request;

    /**
     * 出纸流水号
     */
    private Integer outPaperSerialNum;

    /**
     * 纸巾长度
     */
    private Long outPaperLen;

    /**
     * 时间戳，yyyy-MM-dd HH:mm:ss
     */
    private String timestamp;

    /**
     * 下一次二维码内容,该字段仅对2代机有效。为具体的地址链接字符串
     */
    private String qrCode;

    /**
     * 出纸成功语音,该字段仅对2代机有效。文本格式。默认“#”，表示采用默认的语音。
     */
    private String outPaperSuccessVoice;

    /**
     * MD5校验值
     */
    private String md5;

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public Integer getOutPaperSerialNum() {
        return outPaperSerialNum;
    }

    public void setOutPaperSerialNum(Integer outPaperSerialNum) {
        this.outPaperSerialNum = outPaperSerialNum;
    }

    public Long getOutPaperLen() {
        return outPaperLen;
    }

    public void setOutPaperLen(Long outPaperLen) {
        this.outPaperLen = outPaperLen;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getOutPaperSuccessVoice() {
        return outPaperSuccessVoice;
    }

    public void setOutPaperSuccessVoice(String outPaperSuccessVoice) {
        this.outPaperSuccessVoice = outPaperSuccessVoice;
    }

    public String getMd5() {
        return md5;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public void handleRequest(String request) {

        if (StringUtils.isBlank(request)) {
            return;
        }

        this.request = request;
        String[] arr = StringUtils.split(request , ',');
        int len = arr.length;

        this.outPaperSerialNum = Integer.parseInt(arr[1]);
        this.outPaperLen = Long.parseLong(arr[2]);
        this.timestamp = arr[3];
        this.qrCode = len > 6 ? arr[4] : null;
        this.outPaperSuccessVoice = len > 7 ? arr[6] : null;
        this.md5 = arr[len - 2];

    }
}
