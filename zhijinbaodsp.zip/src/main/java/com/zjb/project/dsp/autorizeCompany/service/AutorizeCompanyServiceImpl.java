package com.zjb.project.dsp.autorizeCompany.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.autorizeCompany.mapper.AutorizeCompanyMapper;
import com.zjb.project.dsp.autorizeCompany.domain.AutorizeCompany;
import com.zjb.project.dsp.autorizeCompany.service.IAutorizeCompanyService;
import com.zjb.common.support.Convert;

/**
 * 授权公司主体 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-02-28
 */
@Service
public class AutorizeCompanyServiceImpl implements IAutorizeCompanyService 
{
	@Autowired
	private AutorizeCompanyMapper autorizeCompanyMapper;

	/**
     * 查询授权公司主体信息
     * 
     * @param id 授权公司主体ID
     * @return 授权公司主体信息
     */
    @Override
	public AutorizeCompany selectAutorizeCompanyById(Integer id)
	{
	    return autorizeCompanyMapper.selectAutorizeCompanyById(id);
	}
	
	/**
     * 查询授权公司主体列表
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 授权公司主体集合
     */
	@Override
	public List<AutorizeCompany> selectAutorizeCompanyList(AutorizeCompany autorizeCompany)
	{
	    return autorizeCompanyMapper.selectAutorizeCompanyList(autorizeCompany);
	}
	
    /**
     * 新增授权公司主体
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 结果
     */
	@Override
	public int insertAutorizeCompany(AutorizeCompany autorizeCompany)
	{
	    return autorizeCompanyMapper.insertAutorizeCompany(autorizeCompany);
	}
	
	/**
     * 修改授权公司主体
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 结果
     */
	@Override
	public int updateAutorizeCompany(AutorizeCompany autorizeCompany)
	{
	    return autorizeCompanyMapper.updateAutorizeCompany(autorizeCompany);
	}

	/**
     * 删除授权公司主体对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAutorizeCompanyByIds(String ids)
	{
		return autorizeCompanyMapper.deleteAutorizeCompanyByIds(Convert.toStrArray(ids));
	}

	/**
	 * 根据appId获取授权公司主体信息
	 * @param appId
	 * @return
	 */
	@Override
	public AutorizeCompany selectAutorizeCompanyByAppId(String appId) {
		return autorizeCompanyMapper.selectAutorizeCompanyByAppId(appId);
	}

}
