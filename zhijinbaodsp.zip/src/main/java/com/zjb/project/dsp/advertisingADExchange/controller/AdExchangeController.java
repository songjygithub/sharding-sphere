package com.zjb.project.dsp.advertisingADExchange.controller;

import static com.zjb.common.constant.AdvertisingConstants.KEY_AD_COMBINATION_INFO_WIN_THIRD_EVENT;
import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.DSP_GUARANTEE_PLAN_COMBINATION_ID;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_AD_COMBINATION_INFO;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_57;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_GZH_QRCODE_NEW_UV;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_GZH_QRCODE_OLD_UV;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_GZH_QRCODE_PV;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_GZH_TAKE_THE_PAPER_PROCESS;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_DSP_APP_DOWN_URL;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_FANS_CARD_ALIPAY;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_FANS_CARD_WECHAT;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;
import static com.zjb.project.dsp.advertisingADExchange.service.IAdExchangeService.COMBINATION_REQUEST_THREAD_LOCAL;
import static com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService.MEDIUM_SELL_RULES_FILTER_PLAN_ID;
import static com.zjb.project.system.config.service.IConfigService.GUARANTEE_AD_PLAN_ID;

import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSON;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.blackPersonalAccount.domain.PersonAccount;
import com.zjb.project.dsp.deviceSpecial.domain.DeviceSpecial;
import com.zjb.project.dsp.deviceSpecial.service.IDeviceSpecialService;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.AdUnit;
import com.zjb.qrcodego.domain.CombinationRequest;
import com.zjb.qrcodego.domain.ViewCard;
import com.zjb.qrcodego.domain.WeChatAccountTaskInfo;

import cn.hutool.core.date.DateUtil;
import cn.hutool.extra.mail.MailUtil;

import javax.servlet.http.HttpServletRequest;

/**
 * @author songjy
 * @date 2019/07/26
 */
@Controller
@RequestMapping(value = {"/adx", "/dsp/adx", "/zjb/adx"})
public class AdExchangeController extends BaseController implements InitializingBean {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 扫码流水号为空出现次数
     */
    private int randomNumEmptyCount = 0;

    @Autowired
    private IAdvertisingTargetInfoService advertisingTargetInfoService;
    @Autowired
    private IDeviceSpecialService deviceSpecialService;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;

    @Override
    public void afterPropertiesSet() throws Exception {

        /*缓存保底广告*/
        for (String planId : GUARANTEE_AD_PLAN_ID) {
            String key = AD_PLAN_ID_PREFIX + '_' + planId;
            AdvertisingPlan win = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            AdCombinationInfo combination = adExchangeService.advertisingCombination(win);
            key = DSP_GUARANTEE_PLAN_COMBINATION_ID + '_' + planId;
            JedisPoolCacheUtils.setVExpire(key, combination, JedisPoolCacheUtils.EXRP_MONTH, ZJB_DB_50);
        }
    }

    /**
     * 根据广告计划ID获取投放广告方案信息
     *
     * @param combination
     * @return
     */
    @PostMapping("/combination")
    @ResponseBody
    public AdCombinationInfo advertisingCombination(@RequestBody CombinationRequest combination) {

        String keyCombination = ZJB_AD_COMBINATION_INFO + '_' + combination.getRandomNum();

        AdCombinationInfo adCombinationInfo = null;

        try {

            adCombinationInfo = JedisPoolCacheUtils.getV(keyCombination, ZJB_DB_50, AdCombinationInfo.class);

            if (null != adCombinationInfo) {
                return adCombinationInfo;
            }

            COMBINATION_REQUEST_THREAD_LOCAL.set(combination);

            if (StringUtils.isBlank(combination.getPlanId()) || null == combination.getRandomNum()) {
                logger.warn("广告计划ID||扫码流水号为空");
                adCombinationInfo = adExchangeService.guaranteed(StringUtils.isNumeric(combination.getRandomNum()) ? Long.parseLong(combination.getRandomNum()) : null);
                return adCombinationInfo;
            }


            String key = AD_PLAN_ID_PREFIX + '_' + combination.getPlanId();
            AdvertisingPlan win = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            win.setRandomNum(combination.getRandomNum());
            if (null != combination.getDevice()) {
            	DeviceDTO device = combination.getDevice();
                if (null != device) {
                    win.setDeviceId(device.getId());
                }
            }
            adCombinationInfo = adExchangeService.advertisingCombination(win);

            AdvertisingPeopleInfo peopleInfo = combination.getPeopleInfo();
            String withoutBiddingOpenId = configService.selectConfigByKey("zjb_without_bidding_openid");

            //非竞价广告/付费取纸成功广告/极速取纸成功广告/个人中心广告
            if (null != peopleInfo && StringUtils.isNotEmpty(peopleInfo.getOpenId())) {
                if (StringUtils.isNotEmpty(withoutBiddingOpenId) && !("0".equals(withoutBiddingOpenId))) {
                    if ((peopleInfo.getOpenId()).equals(withoutBiddingOpenId)) {
                        adExchangeService.withoutBiddingPriceAdvertising(adCombinationInfo, peopleInfo.getOpenId(), win.getRandomNum(), combination);
                    }
                } else {
                    adExchangeService.withoutBiddingPriceAdvertising(adCombinationInfo, peopleInfo.getOpenId(), win.getRandomNum(), combination);
                }
            }


            if (StringUtils.startsWith(combination.getPlanId(), AD_UNIT_TYPE_PAY.getValue())) {
                //新版付费特殊设备
                AdvertisingDeviceInfo deviceInfo = combination.getDeviceInfo();
                adExchangeService.paySpecialDevice(adCombinationInfo, deviceInfo);
                logger.debug("纯付费取纸无需配置任务");
                return adCombinationInfo;
            }

            List<AdUnit> scanner = adCombinationInfo.getScan();
            if (null == scanner || scanner.isEmpty()) {
                logger.error("广告计划【{}】未配置扫码取纸位", combination.getPlanId());
                return adCombinationInfo;
            }

            /*问卷调查/激励视频*/
            if (questionnaire(adCombinationInfo)) {
                return adCombinationInfo;
            }

            /*首次胜出广告计划是否第三方平台任务*/
            boolean isThirdPartyPlatformTaskInfo = MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(win.getPlanId());
            WeChatAccountTaskInfo taskInfo = isThirdPartyPlatformTaskInfo ? adExchangeService.getWeChatAccountTaskInfo(adCombinationInfo) : null;
            /*第三方平台公众号任务是否有效*/
            boolean valid = isThirdPartyPlatformTaskInfo && adExchangeService.isValid(taskInfo);

            /*首次胜出广告计划是否人工授权公众号*/
            WeChatAccountTaskInfo manualTaskInfo = null;
            if ((MANUAL_ADD.getValue().equals(win.getComponentAuthorizationType())) && StringUtils.isNotBlank(win.getAdAppId())) {
                manualTaskInfo = adExchangeService.manualWeChatAccount(combination, win);
            }

            /*首次胜出广告计划是否直配置公众号*/
            boolean isDirectWeChatAccount = adExchangeService.directWeChatAccount(win, adCombinationInfo);

            /*第三方平台二次竞价*/
            boolean onceAgainBiddingThird = (isThirdPartyPlatformTaskInfo && !valid);
            /*授权公众号二次竞价*/
            boolean onceAgainBiddingWeChatAccount = !isThirdPartyPlatformTaskInfo
                    && (AUTHORIZE_ADD.getValue().equals(win.getComponentAuthorizationType())
                    && isDirectWeChatAccount
                    && StringUtils.isNotBlank(win.getAdAppId())
                    && !adExchangeService.isEventMatch(combination, win));
            /*人工公众号二次竞价*/
            boolean onceAgainBidManualWeChatAccount = !isThirdPartyPlatformTaskInfo
                    && isDirectWeChatAccount
                    && StringUtils.isNotBlank(win.getAdAppId())
                    && (MANUAL_ADD.getValue().equals(win.getComponentAuthorizationType()))
                    && (null == manualTaskInfo);

            if (onceAgainBiddingThird || onceAgainBiddingWeChatAccount || onceAgainBidManualWeChatAccount) {

                logger.info("扫码流水号{}{}广告计划{}参与二次竞价", combination.getRandomNum(), (onceAgainBiddingThird ? "第三方" : (onceAgainBiddingWeChatAccount ? "授权公众号" : "人工公众号")), adCombinationInfo.getPlanId());

                /*二次竞价*/
                win = adExchangeService.secondBid(StringUtils.isNumeric(combination.getRandomNum()) ? Long.parseLong(combination.getRandomNum()) : null);

                if (null == win) {
                    logger.info("扫码流水号【{}】二次竞价无胜出广告计划", combination.getRandomNum());
                    adCombinationInfo = adExchangeService.guaranteed(StringUtils.isNumeric(combination.getRandomNum()) ? Long.parseLong(combination.getRandomNum()) : null);
                    return adCombinationInfo;
                }

                win.setRandomNum(combination.getRandomNum().toString());

                /*三次竞价：校验二次竞价计划是否有效*/
                adCombinationInfo = adExchangeService.thirdBid(combination, win);
                return adCombinationInfo;
            }

            if (valid) {
                /*成功拉取到第三方平台公众号信息*/
                adCombinationInfo.setWeChatAccountTaskInfo(taskInfo);
            } else if ((MANUAL_ADD.getValue().equals(win.getComponentAuthorizationType())) && (null != manualTaskInfo)) {

                /*成功拉取到人工授权公众号信息*/
                List<AdUnit> scan = adCombinationInfo.getScan();
                AdUnit map = scan.get(0);
                map.setFrom_type(FROM_TYPE_MANUAL_WE_CHAT_ACCOUNT.getValue());
                adCombinationInfo.setScan(scan);
                adCombinationInfo.setWeChatAccountTaskInfo(manualTaskInfo);

            }

            return adCombinationInfo;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            adCombinationInfo = adExchangeService.guaranteed(StringUtils.isNumeric(combination.getRandomNum()) ? Long.parseLong(combination.getRandomNum()) : null);
            return adCombinationInfo;
        } finally {
            List<AdUnit> adUnits = adCombinationInfo.getScan();
            if (!adUnits.isEmpty()){
                String gzhSubscribeMsg = "";
                for (AdUnit adunt:adUnits) {
                    if (StringUtils.isNotBlank(adunt.getGzhSubscribeMsg())) {
                        gzhSubscribeMsg= adunt.getGzhSubscribeMsg();
                        logger.info("gzh_subscribe_msg_{}:{}","gzh_subscribe_msg_", combination.getRandomNum(),gzhSubscribeMsg);
                        JedisPoolCacheUtils.setNotRExpire("gzh_subscribe_msg_" + combination.getRandomNum(), gzhSubscribeMsg, EXRP_5_MINUTE, ZjbConstantsRedis.ZJB_DB_19);
                    }
                }
            }
            adCombinationInfo.setOpenId(combination.getOpenId());
            if (null == adCombinationInfo.getRandomNum() && null != combination.getRandomNum()) {
                adCombinationInfo.setRandomNum(StringUtils.isNumeric(combination.getRandomNum()) ? Long.parseLong(combination.getRandomNum()) : null);
            }
            adCombinationInfo.setAppDownUrl(configService.selectConfigByKey(ZJB_DSP_APP_DOWN_URL.getKey()));

            // 将公众号最终随机到的出纸方式缓存,方便在核心系统中调用
            List<AdUnit> scan = adCombinationInfo.getScan();
            if (CollectionUtils.isNotEmpty(scan)) {
                AdUnit scanMap = scan.get(0);
                Object redirectUrlType = scanMap.getRedirectUrlType();
                if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(redirectUrlType)) {
                    String scanKey = ZJB_GZH_TAKE_THE_PAPER_PROCESS + "_" + scanMap.getAppid() + "_" + combination.getOpenId();
                    String takeThePaperProcess = scanMap.getTakeThePaperProcess();
                    JedisPoolCacheUtils.setRExpire(scanKey, takeThePaperProcess, EXRP_5_MINUTE * 2, ZJB_DB_50);
                    handleGzhQrCodePvAndUv(scanMap.getAppid(), combination.getOpenId());
                }
            }
            //调取第三方展示次数
            if (null != adCombinationInfo.getWeChatAccountTaskInfo()) {
                if (null != adCombinationInfo.getWeChatAccountTaskInfo().getTaskId()) {
                    thirdPartyShow(adCombinationInfo.getWeChatAccountTaskInfo().getTaskId());
                }
            }
            COMBINATION_REQUEST_THREAD_LOCAL.remove();
            setAuthWeChatInfo(adCombinationInfo);
            /*粉丝通页面卡片控制*/
            if (StringUtils.startsWith(adCombinationInfo.getPlanId(), AD_UNIT_TYPE_FANS.getValue())) {
                fansCardHandle(adCombinationInfo, combination.getDeviceSn());
            }
            JedisPoolCacheUtils.setVExpire(keyCombination, adCombinationInfo, EXRP_5_MINUTE, ZJB_DB_50);
            if (adCombinationInfo != null && adCombinationInfo.getWeChatAccountTaskInfo() != null) {
                WeChatAccountTaskInfo weChatAccountTaskInfo = adCombinationInfo.getWeChatAccountTaskInfo();
                if (weChatAccountTaskInfo.getData() != null && !(weChatAccountTaskInfo.getData().isEmpty())) {
                    WeChatAccountTaskInfo.Data data = weChatAccountTaskInfo.getData().get(0);
                    if (data != null && StringUtils.isNotEmpty(data.getAddFriend()) && "1".equals(data.getAddFriend())) {
                        if (null != combination.getRandomNum()) {
                            /*广告计划胜出事件发布*/
                            Map<String, Object> map = new HashMap<>(6);
                            PersonAccount personAccount = new PersonAccount();
                            personAccount.setOpenId(combination.getOpenId());
                            personAccount.setPersonalAppId(data.getAppid());
                            //获取该个人号的渠道
                            String personalAccountChannel = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_CHANNEL + "_" + data.getAppid(), ZjbConstantsRedis.ZJB_DB_58);
                            //获取该个人号的名称
                            String personalAccountName = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_NAME + "_" + data.getAppid(), ZjbConstantsRedis.ZJB_DB_58);
                            personAccount.setPersonalSourceType(personalAccountChannel);
                            personAccount.setPersonalNickName(personalAccountName);
                            personAccount.setRandomNum(combination.getRandomNum().toString());
                            map.put(KEY_AD_COMBINATION_INFO_WIN_THIRD_EVENT, personAccount);
                            JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(map));
                        }
                    }
                }
            }
        }
    }

    /**
     * 授权直配公众号设置
     *
     * @param adCombinationInfo
     */
    private void setAuthWeChatInfo(AdCombinationInfo adCombinationInfo) {
        if (null != adCombinationInfo.getWeChatAccountTaskInfo()) {
            return;
        }

        String key = AD_PLAN_ID_PREFIX + '_' + adCombinationInfo.getPlanId();
        AdvertisingPlan win = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
        if (null == win) {
            logger.error("广告计划【{}】不存在", key);
            return;
        }
        List<AdUnit> scan = adCombinationInfo.getScan();

        if (null == scan || scan.isEmpty()) {
            return;
        }
        AdUnit scanMap = scan.get(0);
        if (!AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(scanMap.getRedirectUrlType())
                || StringUtils.isBlank(win.getAdAppId())) {
            logger.debug("广告计划【{}】未关联授权微信公众号", key);
            return;
        }
        WeChatAccountTaskInfo authTaskInfo = adExchangeService.getAuthWeChatAccountTaskInfo(adCombinationInfo);
        if (!adExchangeService.isValid(authTaskInfo)) {
            return;
        }
        adCombinationInfo.setWeChatAccountTaskInfo(authTaskInfo);
    }

    /**
     * 胜出广告计划方案是否问卷调查/激励视频
     *
     * @param adCombinationInfo
     * @return
     */
    private boolean questionnaire(AdCombinationInfo adCombinationInfo) {

        List<AdUnit> scanner = adCombinationInfo.getScan();
        if (null == scanner || scanner.isEmpty()) {
            logger.error("广告计划【{}】未配置扫码取纸位", adCombinationInfo.getPlanId());
            return false;
        }

        AdUnit mapUnit = scanner.get(0);
        String taskId = mapUnit.getAppid();

        if (null == taskId || !("80".equals(taskId) || "91".equals(taskId))) {
            return false;
        }

        logger.info("问卷调查/激励视频任务ID：{}", taskId);

        WeChatAccountTaskInfo taskInfo = adExchangeService.getWeChatAccountTaskInfo(adCombinationInfo);
        adCombinationInfo.setWeChatAccountTaskInfo(taskInfo);

        if (taskInfo == null || taskInfo.getData() == null || taskInfo.getData().isEmpty()) {
            return true;
        }

        WeChatAccountTaskInfo.Data data = taskInfo.getData().get(0);
        if (data == null || StringUtils.isBlank(data.getInvestigateUrl())) {
            return true;
        }

        for (AdUnit a : scanner) {
            a.setInvestigateUrl(data.getInvestigateUrl());
        }

        return true;
    }

    /**
     * 粉丝通C端页面卡片展示控制
     *
     * @param combinationInfo
     */
    private void fansCardHandle(AdCombinationInfo combinationInfo, String deviceSn) {
        Date date = new Date();
        ViewCard viewCard = new ViewCard();
        try {
            if (null == combinationInfo.getRandomNum()) {
                if ((randomNumEmptyCount++ % 30) == 0) {
                    List<String> tos = Collections.singletonList("lichuang@sczj-inc.com");
                    String subject = "DSP:扫码流水号为空出现次数:" + randomNumEmptyCount;
                    MailUtil.send(tos, subject, subject, false);
                }
                logger.warn("扫码流水号为空");
                return;
            }

            AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(combinationInfo.getRandomNum());

            if (null == targetInfo || null == targetInfo.getPeopleInfo()) {
                logger.error("扫码流水号【{}】对应的交易数据不存在", combinationInfo.getRandomNum());
                return;
            }

            AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
            if (null != peopleInfo && null != peopleInfo.getScanTool()) {
                if (AD_SCAN_TOOL_WX.getValue().equals(peopleInfo.getScanTool())) {
                    // 微信端
                    String wechat = configService.selectConfigByKey(ZJB_FANS_CARD_WECHAT.getKey());
                    if (StringUtils.isBlank(wechat)) {
                        return;
                    }

                    if (wechat.contains(FANS_SAOMA.getValue())) {
                        viewCard.setSaoma(true);
                    }
                    if (wechat.contains(FANS_PAY.getValue())) {
                        //判断该设备是否显示支付模块
                        if (StringUtils.isNotEmpty(deviceSn)) {
                            DeviceSpecial deviceSpecial = deviceSpecialService.selectDeviceSpecialInfoBySn(deviceSn, SPECIAL_WX_NOPAY.getValue(), ZJB_DEVICE_SPECIAL_OUT_PAPER_TYPE_PAY.getValue());
                            if (deviceSpecial != null && null != deviceSpecial.getEffectiveTime() && null != deviceSpecial.getLoseEfficacyTime() && DEVICE_SPECIAL_STATUS_HAND_STOP.getValue() != deviceSpecial.getDeviceSpecialStatus()) {
                                if (DateUtils.getDateBetweenStartAndEndDate(date, deviceSpecial.getEffectiveTime(), deviceSpecial.getLoseEfficacyTime())) {
                                    viewCard.setPay(false);
                                } else {
                                    viewCard.setPay(true);
                                }
                            } else {
                                viewCard.setPay(true);
                            }
                        } else {
                            viewCard.setPay(true);
                        }
                    }
                    if (wechat.contains(FANS_JISU.getValue())) {
                        //判断该设备是否显示极速模块
                        if(StringUtils.isNotEmpty(deviceSn)){
                            DeviceSpecial deviceSpecial = deviceSpecialService.selectDeviceSpecialInfoBySn(deviceSn,SPECIAL_WX_NOPAY.getValue(), ZJB_DEVICE_SPECIAL_OUT_PAPER_TYPE_LEAF.getValue());
                            if (deviceSpecial != null && null != deviceSpecial.getEffectiveTime() && null != deviceSpecial.getLoseEfficacyTime() && DEVICE_SPECIAL_STATUS_HAND_STOP.getValue() != deviceSpecial.getDeviceSpecialStatus()) {
                                if (DateUtils.getDateBetweenStartAndEndDate(date, deviceSpecial.getEffectiveTime(), deviceSpecial.getLoseEfficacyTime())) {
                                    viewCard.setJisu(false);
                                } else {
                                    viewCard.setJisu(true);
                                }
                            } else {
                                viewCard.setJisu(true);
                            }
                        }else{
                            viewCard.setJisu(true);
                        }

                    }

                } else if (AD_SCAN_TOOL_ALI_PAY.getValue().equals(peopleInfo.getScanTool())) {
                    // 支付宝端
                    String alipay = configService.selectConfigByKey(ZJB_FANS_CARD_ALIPAY.getKey());
                    if (StringUtils.isBlank(alipay)) {
                        return;
                    }
                    if (alipay.contains(FANS_SAOMA.getValue())) {
                        viewCard.setSaoma(true);
                    }
                    if (alipay.contains(FANS_PAY.getValue())) {
                        //判断该设备是否显示支付模块
                        if (StringUtils.isNotEmpty(deviceSn)) {
                            DeviceSpecial deviceSpecial = deviceSpecialService.selectDeviceSpecialInfoBySn(deviceSn, SPECIAL_ZFB_NOPAY.getValue(), ZJB_DEVICE_SPECIAL_OUT_PAPER_TYPE_PAY.getValue());
                            if (deviceSpecial != null && null != deviceSpecial.getEffectiveTime() && null != deviceSpecial.getLoseEfficacyTime() && DEVICE_SPECIAL_STATUS_HAND_STOP.getValue() != deviceSpecial.getDeviceSpecialStatus()) {
                                if (DateUtils.getDateBetweenStartAndEndDate(date, deviceSpecial.getEffectiveTime(), deviceSpecial.getLoseEfficacyTime())) {
                                    viewCard.setPay(false);
                                } else {
                                    viewCard.setPay(true);
                                }
                            } else {
                                viewCard.setPay(true);
                            }
                        } else {
                            viewCard.setPay(true);
                        }
                    }
                    if (alipay.contains(FANS_JISU.getValue())) {
                        //判断该设备是否显示支付模块
                        if (StringUtils.isNotEmpty(deviceSn)) {
                            DeviceSpecial deviceSpecial = deviceSpecialService.selectDeviceSpecialInfoBySn(deviceSn, SPECIAL_ZFB_NOPAY.getValue(), ZJB_DEVICE_SPECIAL_OUT_PAPER_TYPE_LEAF.getValue());
                            if (deviceSpecial != null && null != deviceSpecial.getEffectiveTime() && null != deviceSpecial.getLoseEfficacyTime() && DEVICE_SPECIAL_STATUS_HAND_STOP.getValue() != deviceSpecial.getDeviceSpecialStatus()) {
                                if (DateUtils.getDateBetweenStartAndEndDate(date, deviceSpecial.getEffectiveTime(), deviceSpecial.getLoseEfficacyTime())) {
                                    viewCard.setJisu(false);
                                } else {
                                    viewCard.setJisu(true);
                                }
                            } else {
                                viewCard.setJisu(true);
                            }
                        } else {
                            viewCard.setJisu(true);
                        }
                    }

                }

            }

        } catch (DataAccessResourceFailureException e) {
            logger.warn("处理粉丝通卡片是否显示异常：{}", e.getMessage());
        } catch (Exception e) {
            logger.error("处理粉丝通卡片是否显示异常:" + e.getMessage(), e);
        } finally {
            combinationInfo.setIsViewCard(viewCard);
        }
    }

    /**
     * 处理公众号二维码图片相关数据
     *
     * @param appId  公众号appid
     * @param openId 用户openid
     */
    private void handleGzhQrCodePvAndUv(String appId, String openId) {
        if (StringUtils.isBlank(appId) || StringUtils.isBlank(openId)) {
            return;
        }
        // 今天日期
        String date = DateUtils.getDate();
        // pv
        String pvKey = ZJB_GZH_QRCODE_PV + "_" + appId + "_" + date;
        String pvValue = JedisPoolCacheUtils.getVStr(pvKey, ZJB_DB_57);
        if (StringUtils.isBlank(pvValue)) {
            JedisPoolCacheUtils.setRExpire(pvKey, "1", JedisPoolCacheUtils.EXRP_HALF_YEAR, ZJB_DB_57);
        } else {
            int i = Integer.parseInt(pvValue) + 1;
            JedisPoolCacheUtils.setRExpire(pvKey, i + "", JedisPoolCacheUtils.EXRP_HALF_YEAR, ZJB_DB_57);
        }

        // UV
        String uvNewKey = ZJB_GZH_QRCODE_NEW_UV + "_" + appId + "_" + date;
        String uvOldKey = ZJB_GZH_QRCODE_OLD_UV + "_" + appId + "_" + date;
        AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openId);
        if (null != authorizationUserInfo) {
            if (null != authorizationUserInfo.getGmtCreated()) {
                if (DateUtil.isSameDay(authorizationUserInfo.getGmtCreated(), new Date())) {
                    // 用户第一次授权日期是今天,说明是新用户
                    JedisPoolCacheUtils.sadd(uvNewKey, ZJB_DB_57, JedisPoolCacheUtils.EXRP_HALF_YEAR, openId);
                    return;
                }
            }
        }
        JedisPoolCacheUtils.sadd(uvOldKey, ZJB_DB_57, JedisPoolCacheUtils.EXRP_HALF_YEAR, openId);
    }

    /**
     * 处理第三方公众号胜出次数
     */
    public void thirdPartyShow(Integer taskId) {
        logger.info("第三方展示次数{}", taskId);
        String date = DateUtils.getDate();
        //第三方标识
        String taskKey = ZjbConstantsRedis.THIRD_PARTY_CLENT_COUNT + taskId + date + "_show";
        JedisPoolCacheUtils.incrBy(taskKey, 1, JedisPoolCacheUtils.EXRP_THREE_DAY, ZjbConstantsRedis.ZJB_DB_19);
    }

}