package com.zjb.project.dsp.feign.interceptor;

import cn.hutool.core.util.NetUtil;
import feign.Logger;
import feign.RequestInterceptor;
import org.apache.commons.lang3.SystemUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 权限校验信息拦截器
 *
 * @author songjy
 * @date 2020-05-15
 */
@Configuration
public class FeignZjbAuthConfiguration {

    /**
     * 本机IP
     */
    private String localIP = NetUtil.getLocalhostStr();

    @Value("${spring.application.name}")
    private String springApplicationName;

    /**
     * Feign权限校验信息拦截器，将自生一些信息自动添加到每次请求的头部（Header）中，若接收方要做一些必要的权限校验，
     * 可从请求的头部（Header）中获取权限校验信息
     *
     * @return 拦截器
     */
    @Bean
    public RequestInterceptor requestInterceptor() {
        RequestInterceptor requestInterceptor = (requestTemplate) -> {
            /*调用方系统用户名*/
            requestTemplate.header("feignSystemUserName", SystemUtils.USER_NAME);
            /*调用方系统IP*/
            requestTemplate.header("feignLocalIP", localIP);
            /*调用方当前时间戳*/
            requestTemplate.header("feignTimeMillis", String.valueOf(System.currentTimeMillis()));
            /*调用方系统类型*/
            requestTemplate.header("feignApplicationName", springApplicationName);
        };
        return requestInterceptor;
    }

    @Bean
    public feign.Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }
}