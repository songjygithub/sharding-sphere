package com.zjb.project.dsp.backupFileRecord.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 消息队列表 zjb_mq
 *
 * @author songjy
 * @date 2019-10-21
 */
public class Mq extends BaseEntity {
    private static final long serialVersionUID = -1253057836054320222L;

    /**
     * 用户id
     */
    private Integer id;
    /**
     * 名称 消息队列中的Consumer ID
     */
    private String consumerId;
    /**
     * 名称 消息队列中的Topic
     */
    private String topicName;
    /**
     * 状态 参考字典的 消息队列状态 MQ_STATUS
     */
    private Integer status;
    /**
     * 描述
     */
    private String description;
    /**
     * 环境标识符ZjbConstants.java的ZJB_CURRENT_EVN
     */
    private String env;

    /**
     * topci对应的服务器域名
     */
    private String domain;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    public String getConsumerId() {
        return consumerId;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }
}
