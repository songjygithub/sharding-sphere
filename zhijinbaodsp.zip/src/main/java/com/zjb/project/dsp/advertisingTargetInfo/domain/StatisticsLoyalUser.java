package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.util.Date;

/**
 * @author songjy
 * @Date 2019/12/03
 **/
public class StatisticsLoyalUser implements Serializable {
    private static final long serialVersionUID = 6898775738901335084L;

    /**
     * 统计日期
     */

    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date adRequestDate;

    /**
     * 统计日期
     */
    @Excel(name = "统计日期")
    private String dateAdRequest;

    /**
     * 微信公众号
     */
    @Excel(name = "微信公众号")
    private String weChatAccount;

    /**
     * 微信公众号名称
     */
    @Excel(name = "微信公众号名称")
    private String weChatAccountName;

    /**
     * 分界数字,取纸次数超过或等于该数字则为重度用户，否则轻度用户
     */
    private Integer cutoffNum;

    /**
     * 重度用户数量
     */
    @Excel(name = "重度用户数量")
    private Integer loyalUserCount;

    /**
     * 轻度用户数量
     */
    @Excel(name = "轻度用户数量")
    private Integer soUserCount;

    /**
     * 用户微信|支付宝唯一标识
     */
    private String openId;

    /**
     * 用户取纸次数
     */
    private Integer takePaperCount;

    public Date getAdRequestDate() {
        return adRequestDate;
    }

    public String getDateAdRequest() {
        return dateAdRequest;
    }

    public void setDateAdRequest(String dateAdRequest) {
        this.dateAdRequest = dateAdRequest;
    }

    public void setAdRequestDate(Date adRequestDate) {
        this.adRequestDate = adRequestDate;
    }

    public String getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccount(String weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public String getWeChatAccountName() {
        return weChatAccountName;
    }

    public void setWeChatAccountName(String weChatAccountName) {
        this.weChatAccountName = weChatAccountName;
    }

    public Integer getCutoffNum() {
        return cutoffNum;
    }

    public void setCutoffNum(Integer cutoffNum) {
        this.cutoffNum = cutoffNum;
    }

    public Integer getLoyalUserCount() {
        return loyalUserCount;
    }

    public void setLoyalUserCount(Integer loyalUserCount) {
        this.loyalUserCount = loyalUserCount;
    }

    public Integer getSoUserCount() {
        return soUserCount;
    }

    public void setSoUserCount(Integer soUserCount) {
        this.soUserCount = soUserCount;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Integer getTakePaperCount() {
        return takePaperCount;
    }

    public void setTakePaperCount(Integer takePaperCount) {
        this.takePaperCount = takePaperCount;
    }
}
