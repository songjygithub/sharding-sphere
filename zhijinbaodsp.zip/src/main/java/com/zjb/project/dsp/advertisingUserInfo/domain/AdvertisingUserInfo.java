package com.zjb.project.dsp.advertisingUserInfo.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.pushInfo.domain.PushInfo;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.*;

/**
 * @author songjy
 * @date 2019/08/08
 */
@Document(collection = "ad_user_info")
public class AdvertisingUserInfo extends AdvertisingPeopleInfo {
    private static final long serialVersionUID = 4804481826513730610L;

    /**
     * 主键
     */
    private String id;

    /**
     * 用户ID,内部统一用户ID
     */
    private Integer userId;

    /**
     * 用户当天查看广告记录
     */
    private AdvertisingUserDayRecord adUserDayRecord;

    /**
     * 开通vip时间
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date vipDay;

    /**
     * 可用小树叶数量
     */
    private Integer leafCount;

    /**
     * 环保等级
     */
    private Integer environmentalProtectionLevel;

    /**
     * 成就数量
     */
    private Integer achievementCount;

    /**
     * 今日可普通取纸次数
     */
    private Integer todaySurplusPaperNum;

    /**
     * 用户已查看的所有广告记录
     * HashMap<广告计划ID, 投放次数>
     */
    private HashMap<String, Integer> adRecord;

    /**
     * 用户已添加的微信个人号
     * HashMap<微信个人号分组编号, 用户已添加的微信个人号集合>
     */
    private HashMap<Integer, Set<String>> weChatPersonalGroup;

    /**
     * 用户已添加的QQ个人号
     * HashMap<QQ个人号分组编号, 用户已添加的QQ个人号集合>
     */
    private HashMap<Integer, Set<String>> qqPersonalGroup;

    /**
     * 第几次收到小树叶
     */
    private Integer numOfTimesGetLeaf;

    /**
     * 已获得的小树叶数量
     */
    private Integer amountObtainedLeaf;

    /**
     * 已消费的小树叶数量
     */
    private Integer amountConsumedLeaf;

    /**
     * 等待审核的小树叶数量
     */
    private Integer amountWaitReviewLeaf;

    /**
     * 可领取小树叶数量
     */
    private Integer amountAvailableCanLeaf;

    /**
     * 当日剩余普通取纸次数
     */
    private Integer todayRemainderTakePaperNum;

    /**
     * 所属职业
     */
    private String profession;

    /**
     * 所属职业名称
     */
    private String professionName;

    /**
     * 兴趣爱好
     */
    private ArrayList<String> hobby;

    /**
     * 个人标签
     */
    private ArrayList<String> personalLabel;

    /**
     * 个人资料完善进度
     */
    private Integer personalInfoProgress;

    /**
     * 用户手机号码
     */
    private String phone;

    /**
     * 弹窗信息
     */
    @Transient
    private PushInfo pushInfo;

    /**
     * 新手使用时获取首页展示问题
     */
    @Transient
    private List<UseQuestion> questions;

    /**
     * 付费取纸入口是否显示，0：否 1：是
     */
    private Integer payTakePaperDisplay;

    /**
     * 是否获取弹窗, 1:是
     */
    @Transient
    private Integer popup;

    /**
     * 1:极速取纸，否则其它
     */
    @Transient
    private String speedPick;

    /**
     * 小树叶极速取纸流水号
     */
    @Transient
    private Long leafSerialNum;

    /**
     * 第一次进入小树叶
     */
    private Date gmtFirstViewLeaf;

    /**
     * 是否开启自动出纸按钮
     */
    private String autoOutPaper;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAutoOutPaper() {
        return autoOutPaper;
    }

    public void setAutoOutPaper(String autoOutPaper) {
        this.autoOutPaper = autoOutPaper;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public AdvertisingUserDayRecord getAdUserDayRecord() {
        return adUserDayRecord;
    }

    public void setAdUserDayRecord(AdvertisingUserDayRecord adUserDayRecord) {
        this.adUserDayRecord = adUserDayRecord;
    }

    public Integer getLeafCount() {
        return leafCount;
    }

    public void setLeafCount(Integer leafCount) {
        this.leafCount = leafCount;
    }

    public Integer getEnvironmentalProtectionLevel() {
        return environmentalProtectionLevel;
    }

    public void setEnvironmentalProtectionLevel(Integer environmentalProtectionLevel) {
        this.environmentalProtectionLevel = environmentalProtectionLevel;
    }

    public Integer getAchievementCount() {
        return achievementCount;
    }

    public void setAchievementCount(Integer achievementCount) {
        this.achievementCount = achievementCount;
    }

    public Integer getTodaySurplusPaperNum() {
        return todaySurplusPaperNum;
    }

    public void setTodaySurplusPaperNum(Integer todaySurplusPaperNum) {
        this.todaySurplusPaperNum = todaySurplusPaperNum;
    }

    public HashMap<String, Integer> getAdRecord() {
        return adRecord;
    }

    public void setAdRecord(HashMap<String, Integer> adRecord) {
        this.adRecord = adRecord;
    }

    public Integer getNumOfTimesGetLeaf() {
        return numOfTimesGetLeaf;
    }

    public void setNumOfTimesGetLeaf(Integer numOfTimesGetLeaf) {
        this.numOfTimesGetLeaf = numOfTimesGetLeaf;
    }

    public Integer getAmountObtainedLeaf() {
        return amountObtainedLeaf;
    }

    public void setAmountObtainedLeaf(Integer amountObtainedLeaf) {
        this.amountObtainedLeaf = amountObtainedLeaf;
    }

    public Integer getAmountConsumedLeaf() {
        return amountConsumedLeaf;
    }

    public void setAmountConsumedLeaf(Integer amountConsumedLeaf) {
        this.amountConsumedLeaf = amountConsumedLeaf;
    }

    public Integer getAmountWaitReviewLeaf() {
        return amountWaitReviewLeaf;
    }

    public void setAmountWaitReviewLeaf(Integer amountWaitReviewLeaf) {
        this.amountWaitReviewLeaf = amountWaitReviewLeaf;
    }

    public Integer getAmountAvailableCanLeaf() {
        return amountAvailableCanLeaf;
    }

    public void setAmountAvailableCanLeaf(Integer amountAvailableCanLeaf) {
        this.amountAvailableCanLeaf = amountAvailableCanLeaf;
    }

    public Integer getTodayRemainderTakePaperNum() {
        return todayRemainderTakePaperNum;
    }

    public void setTodayRemainderTakePaperNum(Integer todayRemainderTakePaperNum) {
        this.todayRemainderTakePaperNum = todayRemainderTakePaperNum;
    }

    public String getProfession() {
        return profession;
    }

    public void setProfession(String profession) {
        this.profession = profession;
    }

    public String getProfessionName() {
        return professionName;
    }

    public void setProfessionName(String professionName) {
        this.professionName = professionName;
    }

    public ArrayList<String> getHobby() {
        return hobby;
    }

    public void setHobby(ArrayList<String> hobby) {
        this.hobby = hobby;
    }

    public ArrayList<String> getPersonalLabel() {
        return personalLabel;
    }

    public void setPersonalLabel(ArrayList<String> personalLabel) {
        this.personalLabel = personalLabel;
    }

    public Integer getPersonalInfoProgress() {
        return personalInfoProgress;
    }

    public void setPersonalInfoProgress(Integer personalInfoProgress) {
        this.personalInfoProgress = personalInfoProgress;
    }

    public PushInfo getPushInfo() {
        return pushInfo;
    }

    public void setPushInfo(PushInfo pushInfo) {
        this.pushInfo = pushInfo;
    }

    public List<UseQuestion> getQuestions() {
        return questions;
    }

    public void setQuestions(List<UseQuestion> questions) {
        this.questions = questions;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Integer getPayTakePaperDisplay() {
        return payTakePaperDisplay;
    }

    public void setPayTakePaperDisplay(Integer payTakePaperDisplay) {
        this.payTakePaperDisplay = payTakePaperDisplay;
    }

    public Date getVipDay() {
        return vipDay;
    }

    public void setVipDay(Date vipDay) {
        this.vipDay = vipDay;
    }

    public Integer getPopup() {
        return popup;
    }

    public void setPopup(Integer popup) {
        this.popup = popup;
    }

    public String getSpeedPick() {
        return speedPick;
    }

    public void setSpeedPick(String speedPick) {
        this.speedPick = speedPick;
    }

    public Long getLeafSerialNum() {
        return leafSerialNum;
    }

    public void setLeafSerialNum(Long leafSerialNum) {
        this.leafSerialNum = leafSerialNum;
    }

    public Date getGmtFirstViewLeaf() {
        return gmtFirstViewLeaf;
    }

    public void setGmtFirstViewLeaf(Date gmtFirstViewLeaf) {
        this.gmtFirstViewLeaf = gmtFirstViewLeaf;
    }

    public HashMap<Integer, Set<String>> getWeChatPersonalGroup() {
        return weChatPersonalGroup;
    }

    public void setWeChatPersonalGroup(HashMap<Integer, Set<String>> weChatPersonalGroup) {
        this.weChatPersonalGroup = weChatPersonalGroup;
    }

    public HashMap<Integer, Set<String>> getQqPersonalGroup() {
        return qqPersonalGroup;
    }

    public void setQqPersonalGroup(HashMap<Integer, Set<String>> qqPersonalGroup) {
        this.qqPersonalGroup = qqPersonalGroup;
    }
}
