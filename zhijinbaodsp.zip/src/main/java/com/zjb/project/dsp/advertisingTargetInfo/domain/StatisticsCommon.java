package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Set;

/**
 * @author songjy
 * @date 2019/10/29
 */
public class StatisticsCommon implements Serializable {
    private static final long serialVersionUID = 1455344820116475698L;

    /**
     * 胜出广告计划ID
     */
    @Excel(name = "胜出广告计划ID")
    private String adWinPlanId;

    /**
     * 胜出广告计划名称
     */
    @Excel(name = "胜出广告计划名称")
    private String adWinPlanName;

    /**
     * 广告计划胜出次数
     */
    @Excel(name = "广告计划胜出次数")
    private Float countAdWinPlanId;

    /**
     * 广告计划胜出次数
     */
    @Excel(name = "广告计划请求出纸次数")
    private Float countOutPaper;

    /**
     * 广告出纸成功次数
     *
     * @return
     */
    @Excel(name = "广告出纸成功次数")
    private Float countSuccessOutPaper;

    /**
     * 查看广告微信用户数：去重
     */
    @Excel(name = "查看广告微信用户数")
    private Float countOpenIdWeChat;

    /**
     * 查看广告支付宝用户数：去重
     */
    @Excel(name = "查看广告支付宝用户数")
    private Float countOpenIdAliPay;

    /**
     * 查看广告其他用户数：去重
     */
    @Excel(name = "查看广告其他用户数")
    private Float countOpenIdOther;

    /**
     * 取纸类型
     */
    private Integer takePaperSource;

    /**
     * 取纸类型次数
     */
    private Float countPaperSource;

    /**
     * 查看广告用户数：去重
     */
    private Float countOpenId;

    /**
     * 用户支付宝|微信唯一标识
     */
    private String openId;

    /**
     * 用户支付宝|微信唯一标识集合
     */
    private Set<String> openIds;

    /**
     * 广告投放扫码环境(zjb_scan_tool)，1:微信 2:支付宝 9：其它
     */
    private Integer scanTool;

    /**
     * 广告收益（元）
     */
    @Excel(name = "广告收益（元）")
    private BigDecimal income;

    /**
     * 代理商分成（元）
     */
    @Excel(name = "代理商分成（元）")
    private BigDecimal smbtAccount;

    /**
     * 利润（元）
     */
    @Excel(name = "利润（元）")
    private BigDecimal profit;

    public String getAdWinPlanId() {
        return adWinPlanId;
    }

    public void setAdWinPlanId(String adWinPlanId) {
        this.adWinPlanId = adWinPlanId;
    }

    public String getAdWinPlanName() {
        return adWinPlanName;
    }

    public void setAdWinPlanName(String adWinPlanName) {
        this.adWinPlanName = adWinPlanName;
    }

    public Float getCountAdWinPlanId() {
        return countAdWinPlanId;
    }

    public void setCountAdWinPlanId(Float countAdWinPlanId) {
        this.countAdWinPlanId = countAdWinPlanId;
    }

    public Float getCountOutPaper() {
        return countOutPaper;
    }

    public void setCountOutPaper(Float countOutPaper) {
        this.countOutPaper = countOutPaper;
    }

    public Float getCountSuccessOutPaper() {
        return countSuccessOutPaper;
    }

    public void setCountSuccessOutPaper(Float countSuccessOutPaper) {
        this.countSuccessOutPaper = countSuccessOutPaper;
    }

    public Float getCountOpenIdWeChat() {
        return countOpenIdWeChat;
    }

    public void setCountOpenIdWeChat(Float countOpenIdWeChat) {
        this.countOpenIdWeChat = countOpenIdWeChat;
    }

    public Float getCountOpenIdAliPay() {
        return countOpenIdAliPay;
    }

    public void setCountOpenIdAliPay(Float countOpenIdAliPay) {
        this.countOpenIdAliPay = countOpenIdAliPay;
    }

    public Float getCountOpenIdOther() {
        return countOpenIdOther;
    }

    public void setCountOpenIdOther(Float countOpenIdOther) {
        this.countOpenIdOther = countOpenIdOther;
    }

    public Integer getTakePaperSource() {
        return takePaperSource;
    }

    public void setTakePaperSource(Integer takePaperSource) {
        this.takePaperSource = takePaperSource;
    }

    public Float getCountPaperSource() {
        return countPaperSource;
    }

    public void setCountPaperSource(Float countPaperSource) {
        this.countPaperSource = countPaperSource;
    }

    public Float getCountOpenId() {
        return countOpenId;
    }

    public void setCountOpenId(Float countOpenId) {
        this.countOpenId = countOpenId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Set<String> getOpenIds() {
        return openIds;
    }

    public void setOpenIds(Set<String> openIds) {
        this.openIds = openIds;
    }

    public Integer getScanTool() {
        return scanTool;
    }

    public void setScanTool(Integer scanTool) {
        this.scanTool = scanTool;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getSmbtAccount() {
        return smbtAccount;
    }

    public void setSmbtAccount(BigDecimal smbtAccount) {
        this.smbtAccount = smbtAccount;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }
}
