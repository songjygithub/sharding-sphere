package com.zjb.project.dsp.gzhLabel.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.gzhLabel.mapper.GzhLabelMapper;
import com.zjb.project.dsp.gzhLabel.domain.GzhLabel;
import com.zjb.project.dsp.gzhLabel.service.IGzhLabelService;
import com.zjb.common.support.Convert;

/**
 * 公众号粉丝标签详情 服务层实现
 * 
 * @author shenlong
 * @date 2019-11-08
 */
@Service
public class GzhLabelServiceImpl implements IGzhLabelService 
{
	@Autowired
	private GzhLabelMapper gzhLabelMapper;

	/**
     * 查询公众号粉丝标签详情信息
     * 
     * @param id 公众号粉丝标签详情ID
     * @return 公众号粉丝标签详情信息
     */
    @Override
	public GzhLabel selectGzhLabelById(Integer id)
	{
	    return gzhLabelMapper.selectGzhLabelById(id);
	}
	
	/**
     * 查询公众号粉丝标签详情列表
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 公众号粉丝标签详情集合
     */
	@Override
	public List<GzhLabel> selectGzhLabelList(GzhLabel gzhLabel)
	{
	    return gzhLabelMapper.selectGzhLabelList(gzhLabel);
	}
	
    /**
     * 新增公众号粉丝标签详情
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 结果
     */
	@Override
	public int insertGzhLabel(GzhLabel gzhLabel)
	{
	    return gzhLabelMapper.insertGzhLabel(gzhLabel);
	}
	
	/**
     * 修改公众号粉丝标签详情
     * 
     * @param gzhLabel 公众号粉丝标签详情信息
     * @return 结果
     */
	@Override
	public int updateGzhLabel(GzhLabel gzhLabel)
	{
	    return gzhLabelMapper.updateGzhLabel(gzhLabel);
	}

	/**
     * 删除公众号粉丝标签详情对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGzhLabelByIds(String ids)
	{
		return gzhLabelMapper.deleteGzhLabelByIds(Convert.toStrArray(ids));
	}
	
}
