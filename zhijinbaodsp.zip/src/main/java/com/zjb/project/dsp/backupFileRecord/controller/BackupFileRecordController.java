package com.zjb.project.dsp.backupFileRecord.controller;

import com.zjb.common.utils.IpUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.backupFileRecord.domain.BackupFileRecord;
import com.zjb.project.dsp.backupFileRecord.service.IBackupFileRecordService;
import com.zjb.project.system.user.domain.User;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.*;
import java.util.Date;
import java.util.List;

/**
 * 文件备份记录 信息操作处理
 *
 * @author songjy
 * @date 2019-08-27
 */
@Controller
@RequestMapping("/dsp/backupFileRecord")
public class BackupFileRecordController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "dsp/backupFileRecord";

    @Autowired
    private IBackupFileRecordService backupFileRecordService;

    @RequiresPermissions("dsp:backupFileRecord:view")
    @GetMapping()
    public String backupFileRecord(ModelMap mmap) {

        mmap.put("warMD5", jarMD5());
        mmap.put("localIp", IpUtils.getLocalIP());
        mmap.put("releaseTime", releaseTime());

        return prefix + "/backupFileRecord";
    }

    /**
     * 发布(解压时间)
     *
     * @return
     */
    private static Date releaseTime() {
        String className = BackupFileRecordController.class.getName();
        String filePath = StringUtils.replaceChars(className, '.', '/') + ".class";
        ClassPathResource resource = new ClassPathResource(filePath);

        try {
            return new Date(resource.lastModified());
        } catch (IOException e) {
            return new Date();
        }
    }

    /**
     * 发布包jar的MD5值
     *
     * @return
     */
    private String jarMD5() {
        String catalinaHome = System.getProperty("catalina.home");

        if (StringUtils.isBlank(catalinaHome)) {
            return null;
        }

        for (File jar : new File(catalinaHome).listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return FilenameUtils.getExtension(name).equals("jar");
            }
        })) {
            try (FileInputStream fis = new FileInputStream(jar)) {
                return DigestUtils.md5Hex(fis);
            } catch (IOException e) {
                logger.warn(e.getMessage(), e);
                return null;
            }
        }

        return null;

    }

    /**
     * 查询文件备份记录列表
     */
    @RequiresPermissions("dsp:backupFileRecord:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(BackupFileRecord backupFileRecord) {

        String searchVal = backupFileRecord.getSearchValue();
        if (StringUtils.isNumeric(searchVal)) {
            backupFileRecord.setId(Integer.parseInt(searchVal));
        } else if (StringUtils.isNotBlank(searchVal) && 32 == searchVal.length()) {
            backupFileRecord.setMd5(searchVal);
        }

        if (!SystemUtils.IS_OS_WINDOWS) {
            backupFileRecord.setLocalIp(IpUtils.getLocalIP());
        }

        startPage();
        List<BackupFileRecord> list = backupFileRecordService.selectBackupFileRecordList(backupFileRecord);

        for (BackupFileRecord record : list) {
            User user = getUser(record.getCreaterId());
            record.setCreateBy(null == user ? "-" : user.getUserName());
        }

        return getDataTable(list);
    }

    /**
     * 新增文件备份记录
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存文件备份记录
     */
    @RequiresPermissions("dsp:backupFileRecord:add")
    @Log(title = "文件备份记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(BackupFileRecord backupFileRecord) {
        return toAjax(backupFileRecordService.insertBackupFileRecord(backupFileRecord));
    }

    /**
     * 修改文件备份记录
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        BackupFileRecord backupFileRecord = backupFileRecordService.selectBackupFileRecordById(id);
        mmap.put("backupFileRecord", backupFileRecord);
        return prefix + "/edit";
    }

    /**
     * 修改保存文件备份记录
     */
    @RequiresPermissions("dsp:backupFileRecord:edit")
    @Log(title = "文件备份记录", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(BackupFileRecord backupFileRecord) {
        return toAjax(backupFileRecordService.updateBackupFileRecord(backupFileRecord));
    }

    /**
     * 删除文件备份记录
     */
    @RequiresPermissions("dsp:backupFileRecord:remove")
    @Log(title = "文件备份记录", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(backupFileRecordService.deleteBackupFileRecordByIds(ids));
    }

    /**
     * war文件上传
     */
    @PostMapping("/uploadWar")
    @ResponseBody
    public AjaxResult uploadWar(@RequestParam("file") MultipartFile file) {

        String catalinaHome = System.getProperty("catalina.home");

        if (StringUtils.isBlank(catalinaHome)) {
            return error();
        }

        File work = new File(catalinaHome, "work");

        if (!work.exists() || !work.isDirectory()) {
            logger.warn("目录【{}】不存在", work.getAbsolutePath());
            return error();
        }

        if (file.isEmpty()) {
            return error();
        }

        File war = new File(work, "ROOT.war");

        if (war.exists()) {
            war.delete();
        }

        try (InputStream inputStream = file.getInputStream();
             BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
             BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(war))) {

            byte[] buff = new byte[8096];

            for (int len = 0; (len = bufferedInputStream.read(buff)) > 0; ) {
                bufferedOutputStream.write(buff, 0, len);
            }


        } catch (Exception e) {
            logger.error("War文件上传失败！", e);
            return error();
        }

        AjaxResult ajaxResult = success();

        try (FileInputStream fis = new FileInputStream(war)) {
            ajaxResult.put("md5", DigestUtils.md5Hex(fis));
        } catch (IOException e) {
            logger.error("MD5校验失败！", e);
            return error();
        }

        ajaxResult.put("ip", IpUtils.getLocalIP());
        ajaxResult.put("filePath", war.getAbsolutePath());

        return ajaxResult;
    }

}
