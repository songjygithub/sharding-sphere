package com.zjb.project.dsp.cfgDistrict.mapper;

import com.zjb.project.dsp.cfgDistrict.domain.CfgDistrict;

import java.util.List;

/**
 * 省市区 数据层
 * 
 * @author zjb
 * @date 2018-08-15
 */
public interface CfgDistrictMapper 
{
	/**
     * 查询省市区信息
     * 
     * @param id 省市区ID
     * @return 省市区信息
     */
	public CfgDistrict selectCfgDistrictById(Integer id);
	
	/**
     * 查询省市区列表
     * 
     * @param cfgDistrict 省市区信息
     * @return 省市区集合
     */
	public List<CfgDistrict> selectCfgDistrictList(CfgDistrict cfgDistrict);
	
	/**
     * 新增省市区
     * 
     * @param cfgDistrict 省市区信息
     * @return 结果
     */
	public int insertCfgDistrict(CfgDistrict cfgDistrict);
	
	/**
     * 修改省市区
     * 
     * @param cfgDistrict 省市区信息
     * @return 结果
     */
	public int updateCfgDistrict(CfgDistrict cfgDistrict);
	
	/**
     * 删除省市区
     * 
     * @param id 省市区ID
     * @return 结果
     */
	public int deleteCfgDistrictById(Integer id);
	
	/**
     * 批量删除省市区
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteCfgDistrictByIds(String[] ids);
	
}