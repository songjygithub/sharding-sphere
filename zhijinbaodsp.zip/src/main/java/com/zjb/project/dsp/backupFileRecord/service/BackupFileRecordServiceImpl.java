package com.zjb.project.dsp.backupFileRecord.service;

import cn.hutool.core.util.ZipUtil;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.IpUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.dsp.backupFileRecord.domain.BackupFileRecord;
import com.zjb.project.dsp.backupFileRecord.mapper.BackupFileRecordMapper;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.SystemUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 文件备份记录 服务层实现
 *
 * @author songjy
 * @date 2019-08-27
 */
@Service
public class BackupFileRecordServiceImpl implements IBackupFileRecordService, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 文件日志匹配正则
     */
    private static final Pattern PATTERN_FILE_LOG = Pattern.compile(".+\56(\\d{4}-\\d{2}-\\d{2})\56log");

    @Autowired
    private BackupFileRecordMapper backupFileRecordMapper;

    @Override
    public void afterPropertiesSet() throws Exception {

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {
                backupJar();
                cleanBackupFile();
                cleanTomcatLog();
            }
        });
    }

    /**
     * 清理tomcat下logs目录中超过10天的日志文件
     */
    private void cleanTomcatLog() {
        String catalinaHome = System.getProperty("catalina.home");

        if (StringUtils.isBlank(catalinaHome)) {
            return;
        }

        File logs = new File(catalinaHome, "logs");

        if (!logs.exists() || !logs.isDirectory()) {
            logger.warn("目录{}不存在", logs.getAbsolutePath());
            return;
        }

        long diff = DateUtils.MILLIS_PER_DAY * 10;

        for (File file : Objects.requireNonNull(logs.listFiles())) {
            if (!file.isFile()) {
                continue;
            }

            Matcher matcher = PATTERN_FILE_LOG.matcher(file.getName());
            /*当天日志不压缩*/
            if (matcher.matches() && !matcher.group(1).equals(LocalDate.now().toString())) {
                ZipUtil.zip(file);
                boolean b = file.delete();
                logger.warn("文件{}删除{}", file.getAbsolutePath(), b ? "成功" : "失败");
                continue;
            }

            /*文件最后修改时间*/
            long lastModifiedTime = file.lastModified();
            if ((System.currentTimeMillis() - lastModifiedTime) <= diff) {
                /*未超过指定天数，不清理*/
                continue;
            }

            boolean b = file.delete();

            logger.warn("文件{}删除{}", file.getAbsolutePath(), b ? "成功" : "失败");

        }
    }

    /**
     * 清理备份文件(jar)
     */
    private void cleanBackupFile() {
        /*保留15天内的记录*/
        LocalDate localDateEnd = LocalDate.now().minusDays(15L);
        BackupFileRecord backupFileRecord = new BackupFileRecord();
        backupFileRecord.setDeleted(ZjbDictionaryEnum.NO.getValue());

        if (!SystemUtils.IS_OS_WINDOWS && !SystemUtils.IS_OS_MAC) {
            backupFileRecord.setLocalIp(IpUtils.getLocalIP());
        }

        List<BackupFileRecord> list = backupFileRecordMapper.selectBackupFileRecordList(backupFileRecord);

        if (null == list || list.isEmpty()) {
            return;
        }

        if (list.size() <= 4) {
            /*至少保留最新的四个文件*/
            return;
        }

        for (BackupFileRecord record : list) {

            File file = new File(record.getBackupFileName());

            if (!file.exists()) {
                record.setDeleted(ZjbDictionaryEnum.YES.getValue());
                backupFileRecordMapper.updateBackupFileRecord(record);
                continue;
            }

            if (com.zjb.common.utils.DateUtils.toLocalDateTime(record.getGmtFileCreate()).toLocalDate().isAfter(localDateEnd)) {
                continue;
            }

            if (file.delete()) {
                record.setDeleted(ZjbDictionaryEnum.YES.getValue());
                backupFileRecordMapper.updateBackupFileRecord(record);
                logger.warn("文件{}已删除", record.getBackupFileName());
            }

        }

    }

    /**
     * 备份所有jar包
     */
    private void backupJar() {
        String catalinaHome = System.getProperty("catalina.home");

        if (StringUtils.isBlank(catalinaHome)) {
            return;
        }

        for (File jar : Objects.requireNonNull(new File(catalinaHome).listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return "jar".equals(FilenameUtils.getExtension(name));
            }
        }))) {
            backup(jar);
        }


    }

    /**
     * 备份文件
     *
     * @param srcFileName 源文件
     */
    private void backup(File srcFileName) {

        if (!srcFileName.exists()) {
            return;
        }

        String md5hexNew;
        String md5hexOld = null;

        try (FileInputStream fis = new FileInputStream(srcFileName)) {
            md5hexNew = DigestUtils.md5Hex(fis);
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return;
        }

        BackupFileRecord record = new BackupFileRecord();
        record.setCreaterId(1);
        record.setGmtCreated(new Date());
        record.setSrcFileName(srcFileName.getAbsolutePath());
        record.setMd5(md5hexNew);

        if (null != backupFileRecordMapper.selectByMD5(md5hexNew)) {
            logger.warn("文件{}已备份", srcFileName.getAbsolutePath());
            return;
        }

        Path srcPath = Paths.get(srcFileName.getAbsolutePath());
        try {
            BasicFileAttributes basic = Files.readAttributes(srcPath, BasicFileAttributes.class);
            /*源文件创建时间*/
            record.setGmtFileCreate(new Date(basic.creationTime().to(TimeUnit.MILLISECONDS)));
            /*源文件修改时间*/
            record.setGmtFileModify(new Date(basic.lastModifiedTime().to(TimeUnit.MILLISECONDS)));

        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

        File backupFileName = new File(FileUtils.getTempDirectory(), StringUtils.remove(LocalDateTime.now().toString(), ':') + '.' + srcFileName.getName());

        if (backupFileName.exists()) {
            try (FileInputStream fis = new FileInputStream(backupFileName)) {
                md5hexOld = DigestUtils.md5Hex(fis);
            } catch (IOException e) {
                logger.error(e.getMessage(), e);
                return;
            }
        }

        if (md5hexNew.equalsIgnoreCase(md5hexOld)) {
            return;
        }

        record.setBackupFileName(backupFileName.getAbsolutePath());
        record.setLocalIp(IpUtils.getLocalIP());

        try {
            FileUtils.copyFile(srcFileName, backupFileName);
            int r = backupFileRecordMapper.insertBackupFileRecord(record);

            if (r > 0) {
                logger.warn("文件【{}】备份至【{}】成功", srcFileName.getAbsolutePath(), backupFileName.getAbsolutePath());
            }

        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        }

    }

    /**
     * 查询文件备份记录信息
     *
     * @param id 文件备份记录ID
     * @return 文件备份记录信息
     */
    @Override
    public BackupFileRecord selectBackupFileRecordById(Integer id) {
        return backupFileRecordMapper.selectBackupFileRecordById(id);
    }

    /**
     * 查询文件备份记录列表
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 文件备份记录集合
     */
    @Override
    public List<BackupFileRecord> selectBackupFileRecordList(BackupFileRecord backupFileRecord) {
        return backupFileRecordMapper.selectBackupFileRecordList(backupFileRecord);
    }

    /**
     * 新增文件备份记录
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 结果
     */
    @Override
    public int insertBackupFileRecord(BackupFileRecord backupFileRecord) {

        backupFileRecord.setLocalIp(IpUtils.getLocalIP());

        return backupFileRecordMapper.insertBackupFileRecord(backupFileRecord);
    }

    /**
     * 修改文件备份记录
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 结果
     */
    @Override
    public int updateBackupFileRecord(BackupFileRecord backupFileRecord) {
        return backupFileRecordMapper.updateBackupFileRecord(backupFileRecord);
    }

    /**
     * 删除文件备份记录对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteBackupFileRecordByIds(String ids) {

        String[] arr = Convert.toStrArray(ids);

        for (String id : arr) {
            BackupFileRecord record = backupFileRecordMapper.selectBackupFileRecordById(Integer.parseInt(id));
            File backupFileName = new File(record.getBackupFileName());

            if (!backupFileName.exists()) {
                continue;
            }

            boolean b = backupFileName.delete();

            if (b) {
                logger.warn("文件【{}】已删除", backupFileName.getAbsolutePath());
            }

        }

        return backupFileRecordMapper.deleteBackupFileRecordByIds(arr);
    }

}
