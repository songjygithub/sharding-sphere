package com.zjb.project.dsp.fileExport.service;

import com.zjb.project.dsp.fileExport.domain.FileExport;

import java.util.List;

/**
 * 导出文件记录 服务层
 *
 * @author songjy
 * @date 2020-06-20
 */
public interface IFileExportService {
    /**
     * 查询导出文件记录信息
     *
     * @param id 导出文件记录ID
     * @return 导出文件记录信息
     */
    FileExport selectFileExportById(Integer id);

    /**
     * 查询导出文件记录列表
     *
     * @param fileExport 导出文件记录信息
     * @return 导出文件记录集合
     */
    List<FileExport> selectFileExportList(FileExport fileExport);

    /**
     * 新增导出文件记录
     *
     * @param fileExport 导出文件记录信息
     * @return 结果
     */
    int insertFileExport(FileExport fileExport);

    /**
     * 修改导出文件记录
     *
     * @param fileExport 导出文件记录信息
     * @return 结果
     */
    int updateFileExport(FileExport fileExport);

    /**
     * 删除导出文件记录信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteFileExportByIds(String ids);

}
