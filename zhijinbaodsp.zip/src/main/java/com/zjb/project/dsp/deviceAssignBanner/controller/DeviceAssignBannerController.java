package com.zjb.project.dsp.deviceAssignBanner.controller;

import java.io.InputStream;
import java.util.*;

import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallInfo.domain.DeviceInstallInfo;
import com.zjb.project.dsp.deviceInstallInfo.service.IDeviceInstallInfoService;
import com.zjb.project.system.user.domain.User;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.deviceAssignBanner.domain.DeviceAssignBanner;
import com.zjb.project.dsp.deviceAssignBanner.service.IDeviceAssignBannerService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_USE_YES;

/**
 * 定向投放展示广告 信息操作处理
 *
 * @author jiangbingjie
 * @date 2020-02-12
 */
@Controller
@RequestMapping("/dsp/deviceAssignBanner")
public class DeviceAssignBannerController extends BaseController
{
	private String prefix = "dsp/deviceAssignBanner";
	private static final Logger log = LoggerFactory.getLogger(DeviceAssignBannerController.class);

	@Autowired
	private IDeviceAssignBannerService deviceAssignBannerService;
	@Autowired
	private IAdvertisingUnitFansService advertisingUnitFansService;
	@Autowired
	private IDeviceService deviceService;
	@Autowired
	private IDeviceInstallInfoService deviceInstallInfoService;
	@Autowired
	private IAgencyService agencyService;

	@RequiresPermissions("dsp:deviceAssignBanner:view")
	@GetMapping()
	public String deviceAssignBanner(ModelMap mmap)
	{
		//除去子代理商的所有代理商列表
		List<Agency> agencyList = new ArrayList<Agency>();
		Agency agency = new Agency();
		agencyList = agencyService.selectAgencyList(agency);
		mmap.put("agencyList", agencyList);
		return prefix + "/deviceAssignBanner";
	}

	/**
	 * 查询定向投放展示广告列表
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(DeviceAssignBanner deviceAssignBanner)
	{
		startPage();
		List<DeviceAssignBanner> list = deviceAssignBannerService.selectDeviceAssignBannerList(deviceAssignBanner);
		if(list != null && list.size()>0){
			for(DeviceAssignBanner d : list){
				//创建人员
				Integer user_id = d.getCreaterId();
				if (user_id != null) {
					User user = getUser(user_id);
					if (user != null) {
						d.setCreateBy(user.getUserName());
					}
				}

				//修改人员
				user_id = d.getModifierId();
				if (user_id != null) {
					User user = getUser(user_id);
					if (user != null) {
						d.setUpdateBy(user.getUserName());
					}
				}
			}
		}
		return getDataTable(list);
	}

	/**
	 * 新增定向投放展示广告
	 */
	@GetMapping("/add")
	public String add()
	{
		return prefix + "/add";
	}

	/**
	 * 新增保存定向投放展示广告
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:add")
	@Log(title = "定向投放展示广告", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(DeviceAssignBanner deviceAssignBanner)
	{
		return toAjax(deviceAssignBannerService.insertDeviceAssignBanner(deviceAssignBanner));
	}

	/**
	 * 修改定向投放展示广告
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		DeviceAssignBanner deviceAssignBanner = deviceAssignBannerService.selectDeviceAssignBannerById(id);
		mmap.put("deviceAssignBanner", deviceAssignBanner);
		return prefix + "/edit";
	}

	/**
	 * 修改保存定向投放展示广告
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:edit")
	@Log(title = "定向投放展示广告", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(DeviceAssignBanner deviceAssignBanner)
	{
		return toAjax(deviceAssignBannerService.updateDeviceAssignBanner(deviceAssignBanner));
	}

	/**
	 * 删除定向投放展示广告
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:remove")
	@Log(title = "定向投放展示广告", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{
		return toAjax(deviceAssignBannerService.deleteDeviceAssignBannerByIds(ids));
	}

	/**
	 * 导入定向投放展示广告
	 * @return
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:import")
	@GetMapping("/importDeviceAssignBannerView")
	public String importDeviceAssignBannerView()
	{
		return prefix + "/importDeviceBanner";
	}

	/**
	 * 导入定向投放展示广告
	 * @param file
	 * @return
	 */
	@RequiresPermissions("dsp:deviceAssignBanner:import")
	@PostMapping("/importDeviceAssignBanner")
	@ResponseBody
	public AjaxResult importDeviceAssignBanner(@RequestParam("fileExcel") MultipartFile file,DeviceAssignBanner deviceAssignBanner){
		Integer modifierId = getUserId().intValue();
		Date date = new Date();
		
		if(deviceAssignBanner == null || deviceAssignBanner.getAdId() == null){
			return error("配置广告不能为空");
		}
		AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansService.selectAdvertisingUnitFansByAdId(deviceAssignBanner.getAdId());
		if(advertisingUnitFans == null){
			return error("配置广告不存在");
		}
		if(advertisingUnitFans != null && !(AD_USE_YES.getValue() == advertisingUnitFans.getAdUseStatus())){
			return error("配置广告已停用");
		}
		if (null == file || file.isEmpty()) {
			return error("导入的设备不能为空");
		}
		StringBuffer sb = new StringBuffer();
		try (InputStream is = file.getInputStream()){
			ExcelUtil<DeviceAssignBanner> util = new ExcelUtil<DeviceAssignBanner>(DeviceAssignBanner.class);
			List<DeviceAssignBanner> list = util.importExcel(is);
			if (null == list || list.isEmpty()) {
				log.warn("文件格式错误或空文件");
				return error("文件格式错误或空文件");
			}
			Set<String> invalidSn= new HashSet<>();
			Set<String> replaceSn = new HashSet<>();
			for (DeviceAssignBanner e : list) {
				if(StringUtils.isNotEmpty(e.getMixId())){
					String mixId = StringUtils.trim(e.getMixId().replaceAll("\\xa0", "").replaceAll("\u00A0", ""));
					Integer agencyId = e.getAgencyId();
					DeviceDTO device = deviceService.selectDeviceByMixId(mixId);
					if (null != device && StringUtils.isNotBlank(device.getSn()) && agencyId != null && device.getAgencyId() != null && agencyId.equals(device.getAgencyId())) {
						//获取设备安装信息
						DeviceInstallInfo deviceInstallInfo = deviceInstallInfoService.findByDeviceId(device.getId());
						//判断该设备是否已配置过广告
						DeviceAssignBanner deviceAssignBanner1 = new DeviceAssignBanner();
						deviceAssignBanner1.setDeviceId(device.getId());
						deviceAssignBanner1.setAdPosition(deviceAssignBanner.getAdPosition());
						List<DeviceAssignBanner> deviceAssignBannerList = deviceAssignBannerService.selectDeviceAssignBannerList(deviceAssignBanner1);
						if(deviceAssignBannerList == null || deviceAssignBannerList.isEmpty()){
							DeviceAssignBanner model = new DeviceAssignBanner();
							model.setDeviceId(device.getId());
							model.setDeviceName(device.getName());
							model.setDeviceSn(device.getSn());
							model.setAgencyId(device.getAgencyId());
							model.setAgencyName(device.getAgencyName());
							if(deviceInstallInfo != null){
								model.setInstallCode(deviceInstallInfo.getInstallLocationCode());
							}
							model.setAdId(advertisingUnitFans.getAdId());
							model.setAdName(advertisingUnitFans.getAdName());
							model.setAdPosition(deviceAssignBanner.getAdPosition());
							model.setModifierId(modifierId);
							model.setGmtModified(date);
							model.setCreaterId(modifierId);
							model.setGmtCreated(date);
							deviceAssignBannerService.insertDeviceAssignBanner(model);
						}else{
							replaceSn.add(mixId);
							for(DeviceAssignBanner model : deviceAssignBannerList){
								model.setAdId(advertisingUnitFans.getAdId());
								model.setAdName(advertisingUnitFans.getAdName());
								model.setAdPosition(deviceAssignBanner.getAdPosition());
								model.setModifierId(modifierId);
								model.setGmtModified(date);
								deviceAssignBannerService.updateDeviceAssignBanner(model);
							}
						}
					} else {
						invalidSn.add(mixId);
						log.warn("无效mixId：【{}】", e.getMixId());
					}
				}
			}
			if(invalidSn.size() > 0){
				sb.append("导入失败的设备：");
				sb.append(String.join(",", invalidSn));
				sb.append(";");
			}
			if(replaceSn.size() > 0){
				sb.append("广告被覆盖的设备：");
				sb.append(String.join(",", replaceSn));
			}

		}catch(Exception e){
			log.error(e.getMessage(), e);
			return error("导入失败");
		}
		if(sb != null && sb.length()>0){
			return success(sb.toString());
		}
		return success();

	}

}
