package com.zjb.project.dsp.forbidPutOfficialAccountConfig.mapper;

import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;

import java.util.Date;
import java.util.List;

/**
 * 指定次数禁投公众号广告配置 数据层
 *
 * @author jiangbingjie
 * @date 2020-02-20
 */
public interface ForbidPutOfficialAccountConfigMapper {
    /**
     * 查询指定次数禁投公众号广告配置信息
     *
     * @param configId 指定次数禁投公众号广告配置ID
     * @return 指定次数禁投公众号广告配置信息
     */
    ForbidPutOfficialAccountConfig selectForbidPutOfficialAccountConfigById(Integer configId);

    /**
     * 查询指定次数禁投公众号广告配置列表
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 指定次数禁投公众号广告配置集合
     */
    List<ForbidPutOfficialAccountConfig> selectForbidPutOfficialAccountConfigList(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 新增指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    int insertForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 修改指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    int updateForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 删除指定次数禁投公众号广告配置
     *
     * @param configId 指定次数禁投公众号广告配置ID
     * @return 结果
     */
    int deleteForbidPutOfficialAccountConfigById(Integer configId);

    /**
     * 批量删除指定次数禁投公众号广告配置
     *
     * @param configIds 需要删除的数据ID
     * @return 结果
     */
    int deleteForbidPutOfficialAccountConfigByIds(String[] configIds);

    /**
     * 获取用户通过某台设备在某次取纸是是否屏蔽公众号
     *
     * @return 返回值大于0屏蔽，否则不屏蔽
     */
    int getForbidPutOfficialAccountCount(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 获取配置状态为空的配置信息
     *
     * @return
     */
    List<ForbidPutOfficialAccountConfig> getForbidPutOfficialAccountListWithoutStatus();

    /**
     * 查询自动失效记录
     *
     * @return
     */
    List<ForbidPutOfficialAccountConfig> selectAutomaticInvalid();
}