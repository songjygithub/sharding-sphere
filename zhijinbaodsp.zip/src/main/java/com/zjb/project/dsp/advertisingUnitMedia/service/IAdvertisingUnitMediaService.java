package com.zjb.project.dsp.advertisingUnitMedia.service;

import com.zjb.project.dsp.advertisingUnitMedia.domain.AdvertisingUnitMedia;
import java.util.List;

/**
 * 媒体矩阵广告池 服务层
 * 
 * @author 17854
 * @date 2020-03-19
 */
public interface IAdvertisingUnitMediaService 
{
	/**
     * 查询媒体矩阵广告池信息
     * 
     * @param id 媒体矩阵广告池ID
     * @return 媒体矩阵广告池信息
     */
	public AdvertisingUnitMedia selectAdvertisingUnitMediaById(Integer id);
	
	/**
     * 查询媒体矩阵广告池列表
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 媒体矩阵广告池集合
     */
	public List<AdvertisingUnitMedia> selectAdvertisingUnitMediaList(AdvertisingUnitMedia advertisingUnitMedia);
	
	/**
     * 新增媒体矩阵广告池
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 结果
     */
	public int insertAdvertisingUnitMedia(AdvertisingUnitMedia advertisingUnitMedia);
	
	/**
     * 修改媒体矩阵广告池
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 结果
     */
	public int updateAdvertisingUnitMedia(AdvertisingUnitMedia advertisingUnitMedia);
		
	/**
     * 删除媒体矩阵广告池信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisingUnitMediaByIds(String ids);
	
}
