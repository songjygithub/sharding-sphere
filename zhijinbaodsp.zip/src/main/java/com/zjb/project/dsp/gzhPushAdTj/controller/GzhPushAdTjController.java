package com.zjb.project.dsp.gzhPushAdTj.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.gzhPushAdTj.domain.GzhPushAdTj;
import com.zjb.project.dsp.gzhPushAdTj.service.IGzhPushAdTjService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 消息广告点击统计 信息操作处理
 * 
 * @author shenlong
 * @date 2019-08-26
 */
@Controller
@RequestMapping("/dsp/gzhPushAdTj")
public class GzhPushAdTjController extends BaseController
{
    private String prefix = "dsp/gzhPushAdTj";
	
	@Autowired
	private IGzhPushAdTjService gzhPushAdTjService;
	
	@RequiresPermissions("dsp:gzhPushAdTj:view")
	@GetMapping()
	public String gzhPushAdTj()
	{
	    return prefix + "/gzhPushAdTj";
	}
	
	/**
	 * 查询消息广告点击统计列表
	 */
	@RequiresPermissions("dsp:gzhPushAdTj:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(GzhPushAdTj gzhPushAdTj)
	{
		startPage();
        List<GzhPushAdTj> list = gzhPushAdTjService.selectGzhPushAdTjList(gzhPushAdTj);
		return getDataTable(list);
	}
	
	/**
	 * 新增消息广告点击统计
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存消息广告点击统计
	 */
	@RequiresPermissions("dsp:gzhPushAdTj:add")
	@Log(title = "消息广告点击统计", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(GzhPushAdTj gzhPushAdTj)
	{		
		return toAjax(gzhPushAdTjService.insertGzhPushAdTj(gzhPushAdTj));
	}

	/**
	 * 修改消息广告点击统计
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		GzhPushAdTj gzhPushAdTj = gzhPushAdTjService.selectGzhPushAdTjById(id);
		mmap.put("gzhPushAdTj", gzhPushAdTj);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存消息广告点击统计
	 */
	@RequiresPermissions("dsp:gzhPushAdTj:edit")
	@Log(title = "消息广告点击统计", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(GzhPushAdTj gzhPushAdTj)
	{		
		return toAjax(gzhPushAdTjService.updateGzhPushAdTj(gzhPushAdTj));
	}
	
	/**
	 * 删除消息广告点击统计
	 */
	@RequiresPermissions("dsp:gzhPushAdTj:remove")
	@Log(title = "消息广告点击统计", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(gzhPushAdTjService.deleteGzhPushAdTjByIds(ids));
	}
	
}
