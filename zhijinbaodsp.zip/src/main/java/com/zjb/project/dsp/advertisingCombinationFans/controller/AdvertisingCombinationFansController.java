package com.zjb.project.dsp.advertisingCombinationFans.controller;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.service.DictService;
import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationFans.service.IAdvertisingCombinationFansService;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingCombinationUnitFans.service.IAdvertisingCombinationUnitFansService;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import org.apache.logging.log4j.util.PerformanceSensitive;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 粉丝通广告方案 信息操作处理
 *
 * @author shenlong
 * @date 2019-11-22
 */
@Controller
@RequestMapping("/dsp/advertisingCombinationFans")
public class AdvertisingCombinationFansController extends BaseController {
    private String prefix = "dsp/advertisingCombinationFans";

    @Autowired
    private IAdvertisingCombinationFansService advertisingCombinationFansService;
    @Autowired
    private IAdvertisingCombinationUnitFansService advertisingCombinationUnitFansService;
    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    private DictService dataService;
    @Autowired
    private IAdvertisingPlanFansService advertisingPlanFansService;
    /**
     * banner 广告位
     */
    private String BANNER = "0202";
    /**
     * 扫码出纸位
     */
    private String PAPER = "0201";
    /**
     * 豆腐块
     * */
    private String BEANCURD = "0203";
    /**
     * 豆腐块位置
     * */
    private Integer BEANCURD1 = 1;
    private Integer BEANCURD2 = 2;

    /**
     *
     */
    private String BANNER_PARAM = "banner";
    private String PAPER_PARAM = "saoma";
    private String BEANCURD_PARAM1 = "position1";
    private String BEANCURD_PARAM2 = "position2";

    @RequiresPermissions("dsp:advertisingCombinationFans:view")
    @GetMapping()
    public String advertisingCombinationFans() {
        return prefix + "/advertisingCombinationFans";
    }

    /**
     * 查询粉丝通广告方案列表
     */
    @RequiresPermissions("dsp:advertisingCombinationFans:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingCombinationFans advertisingCombinationFans) {
        startPage();
        List<AdvertisingCombinationFans> list = advertisingCombinationFansService.selectAdvertisingCombinationFansList(advertisingCombinationFans);
        return getDataTable(list);
    }

    /**
     * 新增粉丝通广告方案
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存粉丝通广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationFans:add")
    @Log(title = "粉丝通广告方案", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingCombinationFans advertisingCombinationFans) {
        advertisingCombinationFans.setInsertBaseParamsBySys();
        return toAjax(advertisingCombinationFansService.insertAdvertisingCombinationFans(advertisingCombinationFans));
    }

    /**
     * 修改粉丝通广告方案
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingCombinationFans advertisingCombinationFans = advertisingCombinationFansService.selectAdvertisingCombinationFansById(id);
        mmap.put("advertisingCombinationFans", advertisingCombinationFans);
        return prefix + "/edit";
    }

    /**
     * 修改保存粉丝通广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationFans:edit")
    @Log(title = "粉丝通广告方案", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingCombinationFans advertisingCombinationFans) {
        return toAjax(advertisingCombinationFansService.updateAdvertisingCombinationFans(advertisingCombinationFans));
    }

    /**
     * 删除粉丝通广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationFans:remove")
    @Log(title = "粉丝通广告方案", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingCombinationFansService.deleteAdvertisingCombinationFansByIds(ids));
    }

    /**
     * 详情页面
     */
    @PerformanceSensitive("zjb:advertisingCombinationFans:getDetails")
    @GetMapping("/getDetails")
    public String getDetails() {
        return prefix + "/getDetails";
    }

    /**
     * 广告方案详情
     */
    @PostMapping("/combinationDetails/{combinationId}")
    @ResponseBody
    public AjaxResult getCombinationDetails(@PathVariable("combinationId") Integer combinationId) {
        Map<String, Object> map = new HashMap<>();
        AdvertisingCombinationFans advertisingCombinationFans = advertisingCombinationFansService.selectAdvertisingCombinationFansById(combinationId);
        if (null != advertisingCombinationFans) {
            if (null != advertisingCombinationFans.getProgramType()) {
                // 广告方案名称
                String combinationTypeName = dataService.getLabel(ZjbDictionaryTypeEnum.PROGRAM_TYPE.getType(), advertisingCombinationFans.getProgramType().toString());
                // 广告方案类型
                advertisingCombinationFans.setProgramTypeName(combinationTypeName);
            }
            // 广告方案
            map.put("adDombination", advertisingCombinationFans);
            AdvertisingCombinationUnitFans advertisingCombinationUnitFans = new AdvertisingCombinationUnitFans();
            // 广告方案id
            advertisingCombinationUnitFans.setCombinationId(combinationId);
            List<AdvertisingCombinationUnitFans> advertisingUnitFans = advertisingCombinationFansService.selectAdvertisingCombinationUnitFansList(advertisingCombinationUnitFans);
            Map<String, List<AdvertisingCombinationUnitFans>> adSpeaceMap = new HashMap<>();

            for (AdvertisingCombinationUnitFans advertisingUnitFans_db : advertisingUnitFans) {
                List<AdvertisingCombinationUnitFans> advertisingCombinationUnitList = new ArrayList<>();
                if (PAPER.equals(advertisingUnitFans_db.getAdSpaceIdentifier())) {
                    //扫码出纸位
                    map.put(PAPER_PARAM, advertisingUnitFans_db);
                } else if (BANNER.equals(advertisingUnitFans_db.getAdSpaceIdentifier())) {
                    //首页-banner
                    if (null != adSpeaceMap.get(BANNER)) {
                        advertisingCombinationUnitList = adSpeaceMap.get(BANNER);
                    }
                    advertisingCombinationUnitList.add(advertisingUnitFans_db);
                    adSpeaceMap.put(BANNER, advertisingCombinationUnitList);
                    map.put(BANNER_PARAM, adSpeaceMap.get(BANNER));
                }else if (BEANCURD.equals(advertisingUnitFans_db.getAdSpaceIdentifier())){
                    //首页-豆腐块
                    if (BEANCURD1.equals(advertisingUnitFans_db.getPosition())){
                        map.put(BEANCURD_PARAM1,advertisingUnitFans_db);
                    }else if (BEANCURD2.equals(advertisingUnitFans_db.getPosition())){
                        map.put(BEANCURD_PARAM2,advertisingUnitFans_db);
                    }
                }
            }
            map.putIfAbsent(BANNER_PARAM, "");

        }
        return success(map);
    }

    /**
     * 广告列表
     */
    @PostMapping("/getAdList")
    @ResponseBody
    public AjaxResult getAdList(AdvertisingUnitFans advertisingUnitFans) {
        // 启用状态
        advertisingUnitFans.setAdUseStatus(ZjbDictionaryEnum.AD_USE_YES.getValue());
        List<AdvertisingUnitFans> advertisingUnits = advertisingUnitFansService.selectAdvertisingUnitFansList(advertisingUnitFans);
        return success(advertisingUnits);
    }

    /**
     * 添加广告方案详情
     */
//	@PerformanceSensitive("zjb:advertisingCombination:addDection")
    @PostMapping("/addDection")
    @ResponseBody
    public AjaxResult addDection(AdvertisingCombinationUnitFans advertisingCombinationUnitFans) {
        advertisingCombinationUnitFans.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        return toAjax(advertisingCombinationUnitFansService.insertAdvertisingCombinationUnitFans(advertisingCombinationUnitFans));
    }

    /**
     * 更换广告方案详情
     */
    @PostMapping("/modifyDection")
    @ResponseBody
    public AjaxResult modifyDection(AdvertisingCombinationUnitFans advertisingCombinationUnitFans) {

        int r = advertisingCombinationFansService.modifyDetails(advertisingCombinationUnitFans);

        AdvertisingUnitFans unitFans = advertisingUnitFansService.selectAdvertisingUnitFansById(advertisingCombinationUnitFans.getAdUnitId());

        restartAdvertisingPlanFans(unitFans);

        advertisingPlanFansService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 删除广告方案详情
     */
//	@RequiresPermissions("zjb:advertisingCombination:delDection")
    @Log(title = "广告方案详情", businessType = BusinessType.DELETE)
    @PostMapping("/delDection")
    @ResponseBody
    public AjaxResult delDection(String ids) {
        return toAjax(advertisingCombinationFansService.deleteAdvertisingCombinationUnitFansByUnitId(ids));
    }

    /**
     * 根据主键ID查询广告方案信息
     */
    @GetMapping("/find/{id}")
    @ResponseBody
    public AjaxResult findById(@PathVariable("id") Integer id) {
        AdvertisingCombinationFans advertisingCombination = advertisingCombinationFansService.selectAdvertisingCombinationFansById(id);
        List<ComponentAuthorizationInfo> list = advertisingCombinationFansService.isWeChatOfficialAccountOnSpacePaperOutput(id);

        AjaxResult ajaxResult = success(advertisingCombination);
        ajaxResult.put("componentAuthorizationInfos", list);

        return ajaxResult;
    }

}
