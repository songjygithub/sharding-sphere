package com.zjb.project.dsp.autorizeCompany.mapper;

import com.zjb.project.dsp.autorizeCompany.domain.AutorizeCompany;
import java.util.List;	

/**
 * 授权公司主体 数据层
 * 
 * @author jiangbingjie
 * @date 2020-02-28
 */
public interface AutorizeCompanyMapper 
{
	/**
     * 查询授权公司主体信息
     * 
     * @param id 授权公司主体ID
     * @return 授权公司主体信息
     */
	public AutorizeCompany selectAutorizeCompanyById(Integer id);
	
	/**
     * 查询授权公司主体列表
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 授权公司主体集合
     */
	public List<AutorizeCompany> selectAutorizeCompanyList(AutorizeCompany autorizeCompany);
	
	/**
     * 新增授权公司主体
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 结果
     */
	public int insertAutorizeCompany(AutorizeCompany autorizeCompany);
	
	/**
     * 修改授权公司主体
     * 
     * @param autorizeCompany 授权公司主体信息
     * @return 结果
     */
	public int updateAutorizeCompany(AutorizeCompany autorizeCompany);
	
	/**
     * 删除授权公司主体
     * 
     * @param id 授权公司主体ID
     * @return 结果
     */
	public int deleteAutorizeCompanyById(Integer id);
	
	/**
     * 批量删除授权公司主体
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAutorizeCompanyByIds(String[] ids);

	/**
	 * 根据appId获取授权公司主体信息
	 * @param appId
	 * @return
	 */
	public AutorizeCompany selectAutorizeCompanyByAppId(String appId);
	
}