package com.zjb.project.dsp.advertisingTargetInfo.service;

import com.mongodb.client.AggregateIterable;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.MongoCursor;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.framework.web.mgservice.BaseMongoDbServiceImpl;
import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.*;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService;
import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.appidOpenidIndex.service.IAppidOpenidIndexService;
import com.zjb.project.dsp.area.domain.Area;
import com.zjb.project.dsp.area.service.IAreaService;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;
import com.zjb.project.dsp.componentgzhevent.service.IComponentGzhEventService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallInfo.domain.DeviceInstallInfo;
import com.zjb.project.dsp.deviceInstallInfo.service.IDeviceInstallInfoService;
import com.zjb.project.dsp.rpcrequest.domain.RpcRequest;
import com.zjb.project.dsp.zjbprresponse.domain.ZjbPrResponse;
import org.bson.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.mapreduce.GroupBy;
import org.springframework.data.mongodb.core.mapreduce.GroupByResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorCompletionService;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService.PRIMARY_KEY_OPEN_ID;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;
import static org.apache.commons.lang3.time.DateUtils.MILLIS_PER_SECOND;
import static org.springframework.data.mongodb.core.query.Criteria.where;

/**
 * @author songjy
 * @date 2019/08/07
 */
@Service
public class AdvertisingTargetInfoServiceImpl extends BaseMongoDbServiceImpl<AdvertisingTargetInfo> implements IAdvertisingTargetInfoService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private IDeviceInstallInfoService deviceInstallInfoService;
    @Autowired
    private IAppidOpenidIndexService appIdOpenIdIndexService;
    @Autowired
    private IComponentGzhEventService componentGzhEventService;
    @Autowired
    private IAreaService areaService;
    @Autowired
    private IAdvertisingPlanService advertisingPlanService;

    @Override
    protected Class<AdvertisingTargetInfo> getEntityClass() {
        return AdvertisingTargetInfo.class;
    }

    @Override
    public void save(AdvertisingTargetInfo targetInfo) {

        targetInfo.setTakePaperSource(ZjbDictionaryEnum.TAKE_PAPER_FREE.getValue());
        super.save(targetInfo);

        saveOrUpdateUser(targetInfo);
    }

    /**
     * 用户信息存储或更新
     *
     * @param targetInfo
     */
    private void saveOrUpdateUser(AdvertisingTargetInfo targetInfo) {

        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
        AdvertisingUserInfo userInfoNew = new AdvertisingUserInfo();
        com.zjb.common.utils.bean.BeanUtils.copyProperties(peopleInfo, userInfoNew);

        String openId = userInfoNew.getOpenId();
        if (StringUtils.isBlank(openId)) {
            return;
        }

        userInfoNew.setTodayPaperNum(null);
        userInfoNew.setTotalPaperNum(null);

        Query query = new Query(where(IAdvertisingUserInfoService.PRIMARY_KEY_OPEN_ID).is(openId));
        AdvertisingUserInfo userInfoOld = mongoTemplate.findOne(query, AdvertisingUserInfo.class);

        if (null == userInfoOld) {
            if (null != targetInfo.getAdWinPlanId() && targetInfo.getAdWinPlanId().startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())) {
                userInfoNew.setGmtFirstViewLeaf(new Date());
            }
            mongoTemplate.save(userInfoNew);
        } else {
            if (null == userInfoOld.getGmtFirstViewLeaf() && null != targetInfo.getAdWinPlanId()
                    && targetInfo.getAdWinPlanId().startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())) {
                userInfoNew.setGmtFirstViewLeaf(new Date());
            }
            super.updateByKey(userInfoNew, IAdvertisingUserInfoService.PRIMARY_KEY_OPEN_ID);
        }
    }

    @Override
    public List<AdvertisingTargetInfo> selectAdvertisingTargetInfoList(AdvertisingTargetInfo targetInfo) {

        Criteria criteria = new Criteria();

        ZjbPrResponse prResponse = targetInfo.getPrResponse();
        targetInfo.setGmtAdRequestTimeStart(null == targetInfo.getGmtAdRequestTimeStart() ? DateUtils.toDate(LocalDate.now()) : targetInfo.getGmtAdRequestTimeStart());
        targetInfo.setGmtAdRequestTimeEnd(null == targetInfo.getGmtAdRequestTimeEnd() ? DateUtils.toDate(LocalDate.now()) : targetInfo.getGmtAdRequestTimeEnd());

        criteria.and("adRequestDate").gte(targetInfo.getGmtAdRequestTimeStart()).lte(targetInfo.getGmtAdRequestTimeEnd());

        if (null != targetInfo.getId()) {
            criteria.and("id").is(targetInfo.getId());
        }

        // 用户Id
        if (StringUtils.isNotBlank(targetInfo.getOpenId())) {
            criteria.and("openId").is(targetInfo.getOpenId());
        }

        // 胜出广告计划Id
        if (StringUtils.isNotBlank(targetInfo.getAdWinPlanId())) {
            criteria.and("adWinPlanId").is(targetInfo.getAdWinPlanId());
        }

        // 胜出广告池Id
        if (StringUtils.isNotBlank(targetInfo.getAdWinCombinationId())) {
            criteria.and("adWinCombinationId").is(targetInfo.getAdWinCombinationId());
        }

        // 参与竞价的广告计划ID
        if (targetInfo.getParticipateBidPlanId() != null && targetInfo.getParticipateBidPlanId().size() > 0) {
            criteria.and("participateBidPlanId").in(targetInfo.getParticipateBidPlanId());
        }

        if (null != prResponse && StringUtils.isNotBlank(prResponse.getOutPaperStatus())) {
            criteria.and("prResponse.outPaperStatus").is(prResponse.getOutPaperStatus());
        }

        // 设备信息
        if (null != targetInfo.getDeviceInfo()) {
            if (StringUtils.isNotBlank(targetInfo.getDeviceInfo().getDeviceSn())) {
                criteria.and("deviceInfo.deviceSn").is(targetInfo.getDeviceInfo().getDeviceSn());
            }
            if (StringUtils.isNotBlank(targetInfo.getDeviceInfo().getQrcode())) {
                criteria.and("deviceInfo.qrcode").is(targetInfo.getDeviceInfo().getQrcode());
            }
        }

        if (null != targetInfo.getPeopleInfo()) {
            // 性别
            if (null != targetInfo.getPeopleInfo().getSex()) {
                criteria.and("peopleInfo.sex").is(targetInfo.getPeopleInfo().getSex());
            }
            // 平台类型
            if (null != targetInfo.getPeopleInfo().getScanTool()) {
                criteria.and("peopleInfo.scanTool").is(targetInfo.getPeopleInfo().getScanTool());
            }
            // 扫码环境
            if (null != targetInfo.getPeopleInfo().getPlatformType()) {
                criteria.and("peopleInfo.platformType").is(targetInfo.getPeopleInfo().getPlatformType());
            }
        }

        Query query = new Query(criteria);

        long count = mongoTemplate.count(query, getEntityClass());

        if (0 == count) {
            return Collections.emptyList();
        }

        Pageable pageable = IMgBaseService.PAGEABLE_THREAD_LOCAL.get();
        if (null != pageable) {
            query.with(pageable);
        }

        query.with(Sort.by(Sort.Direction.DESC, "adRequestDate"));

        List<AdvertisingTargetInfo> list = mongoTemplate.find(query, getEntityClass());

        if (null != pageable && !list.isEmpty()) {
            TableDataInfo rspData = new TableDataInfo();
            rspData.setCode(0);
            rspData.setRows(list);
            rspData.setTotal(count);
            IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.set(rspData);
        }

        return list;
    }

    @Override
    public List<StatisticsDeviceAdPlan> findGroupByDeviceSnAndPlanId(Date startAdRequestDate, Date endAdRequestDate, List<String> adWinPlanIds) {

        long start = System.currentTimeMillis();
        List<StatisticsDeviceAdPlan> list = new ArrayList<>();
        LocalDate localDateStart = DateUtils.toLocalDateTime(null == startAdRequestDate ? new Date() : startAdRequestDate).toLocalDate();
        LocalDate localDateEnd = DateUtils.toLocalDateTime(null == endAdRequestDate ? new Date() : endAdRequestDate).toLocalDate();
        Date adRequestDateStart = DateUtils.toDate(localDateStart);
        Date adRequestDateEnd = DateUtils.toDate(localDateEnd);


        if (adWinPlanIds.isEmpty()) {
            return Collections.emptyList();
        }

        logger.info("查询胜出计划【{}】时间段{}至{}所关联的设备信息", adWinPlanIds, localDateStart, localDateEnd);

        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);

        Criteria successOutPaper = where("adRequestDate").gte(adRequestDateStart).lte(adRequestDateEnd)
                .and("adWinPlanId").in(adWinPlanIds)
                .and("prResponse.outPaperStatus").is("0");

        GroupBy groupBy = GroupBy.key("adWinPlanId", "deviceInfo.deviceSn")
                .initialDocument("{countAdWinPlanId:0, deviceSn:''}")
                .reduceFunction("function(doc,prev) {prev.countAdWinPlanId += 1; prev.deviceSn = doc.deviceInfo.deviceSn}");

        GroupByResults<StatisticsDeviceAdPlan> groupByResults = mongoTemplate.group(successOutPaper, collectionName, groupBy, StatisticsDeviceAdPlan.class);

        for (Iterator<StatisticsDeviceAdPlan> statisticsDeviceAdPlanIterator = groupByResults.iterator(); statisticsDeviceAdPlanIterator.hasNext(); ) {
            StatisticsDeviceAdPlan statisticsDeviceAdPlan = statisticsDeviceAdPlanIterator.next();
            list.add(statisticsDeviceAdPlan);
        }

        List<ZjbDictionaryEnum> dictionaryEnumList = ZjbDictionaryEnum.getByType(ZjbDictionaryTypeEnum.DEVICE_SCENE);

        for (StatisticsDeviceAdPlan deviceAdPlan : list) {
            DeviceDTO device = deviceService.selectDeviceBySn(deviceAdPlan.getDeviceSn());
            if (null == device) {
                logger.error("根据设备SN【{}】查询设备信息失败！", deviceAdPlan.getDeviceSn());
                continue;
            }

            DeviceInstallInfo deviceInstallInfo = deviceInstallInfoService.findByDeviceId(device.getId());

            if (null == deviceInstallInfo) {
                logger.error("根据设备ID【{}】查询设备安裝信息失败！", device.getId());
                continue;
            }

            deviceAdPlan.setInstallAddressName(deviceInstallInfo.getProvinceName() + deviceInstallInfo.getCityName() + deviceInstallInfo.getAreaName());
            deviceAdPlan.setAgencyName(device.getAgencyName());
            deviceAdPlan.setSex(deviceInstallInfo.getSex());
            Optional<ZjbDictionaryEnum> optional = dictionaryEnumList.stream().filter(e -> e.getValue().equals(deviceInstallInfo.getInstallLocationCode())).findFirst();
            deviceAdPlan.setDeviceSceneName(optional.isPresent() ? optional.get().getName() : deviceInstallInfo.getInstallLocationCode());

            String key = AD_PLAN_ID_PREFIX + '_' + deviceAdPlan.getAdWinPlanId();
            AdvertisingPlan plan = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

            if (null == plan) {
                logger.error("根据计划ID【】查询计划信息失败");
                continue;
            }

            deviceAdPlan.setAdWinPlanName(plan.getPlanName());
        }

        logger.info("查询胜出计划【{}】时间段{}至{}所关联的设备信息共{}条，耗时(秒)：{}", adWinPlanIds, localDateStart, localDateEnd, list.size(), (System.currentTimeMillis() - start) / MILLIS_PER_SECOND);
        return list;
    }


    @Override
    public StatisticsLoyalUser loyalUsersCount(StatisticsLoyalUser loyalUser) {

        if (StringUtils.isBlank(loyalUser.getWeChatAccount())) {
            logger.error("未指定公众号");
            return loyalUser;
        }

        loyalUser.setLoyalUserCount(0);
        loyalUser.setSoUserCount(0);
        loyalUser.setAdRequestDate(null == loyalUser.getAdRequestDate() ? new Date() : loyalUser.getAdRequestDate());
        loyalUser.setDateAdRequest(ISO_8601_EXTENDED_DATE_FORMAT.format(loyalUser.getAdRequestDate()));
        loyalUser.setCutoffNum(null == loyalUser.getCutoffNum() ? 10 : loyalUser.getCutoffNum());

        List<ComponentGzhEvent> gzhEventList = componentGzhEventService.findByAppIdAndEvent(loyalUser.getAdRequestDate(), loyalUser.getWeChatAccount(), AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue());

        if (null == gzhEventList) {
            logger.error("公众号【{}】{}号无取关记录", loyalUser.getWeChatAccount(), DateUtils.toLocalDateTime(loyalUser.getAdRequestDate()).toLocalDate());
            return loyalUser;
        }

        /*补充缺失的纸巾宝openId*/
        perfectZjbOpenId(gzhEventList);

        /*所有取关用户纸巾宝openId*/
        Set<String> zjbOpenIdSet = gzhEventList.stream()
                .filter(e -> StringUtils.isNotBlank(e.getZjbOpenid()))
                .map(ComponentGzhEvent::getZjbOpenid)
                .collect(Collectors.toSet());

        if (zjbOpenIdSet.isEmpty()) {
            logger.error("缺失纸巾宝用户openId");
            return loyalUser;
        }

        List<BsonString> values = new ArrayList<>(zjbOpenIdSet.size());

        for (String openId : zjbOpenIdSet) {
            values.add(new BsonString(openId));
        }

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选*/

        BsonDocument match = new BsonDocument("$match", new BsonDocument("openId", new BsonDocument("$in", new BsonArray(values))));
        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("openId", new BsonString("$openId"));
        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id).append("takePaperCount", new BsonDocument("$sum", new BsonInt32(1))));
        pipeline.add(group);

        String collectionName = mongoTemplate.getCollectionName(ZjbPrResponse.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);

        for (MongoCursor<BsonDocument> mongoCursor = aggregateIterable.iterator(); mongoCursor.hasNext(); ) {
            BsonDocument document = mongoCursor.next();
            int takePaperCount = document.get("takePaperCount").asInt32().getValue();
            if (takePaperCount >= loyalUser.getCutoffNum()) {
                loyalUser.setLoyalUserCount(loyalUser.getLoyalUserCount() + 1);
            } else {
                loyalUser.setSoUserCount(loyalUser.getSoUserCount() + 1);
            }
        }

        return loyalUser;
    }

    /**
     * 补充缺失的纸巾宝openId
     *
     * @param gzhEventList
     */
    private void perfectZjbOpenId(List<ComponentGzhEvent> gzhEventList) {

        if (null == gzhEventList || gzhEventList.isEmpty()) {
            return;
        }

        for (ComponentGzhEvent gzhEvent : gzhEventList) {

            if (StringUtils.isNotBlank(gzhEvent.getZjbOpenid())) {
                continue;
            }

            AppIdOpenIdIndex appIdOpenIdIndex = appIdOpenIdIndexService.selectByOpenIdAndAppId(gzhEvent.getOpenid(), gzhEvent.getAppid());

            if (null == appIdOpenIdIndex || StringUtils.isBlank(appIdOpenIdIndex.getZjbOpenid())) {
                continue;
            }

            gzhEvent.setZjbOpenid(appIdOpenIdIndex.getZjbOpenid());
            componentGzhEventService.updatePerfectZjbOpenId(gzhEvent);
        }
    }

    @Override
    public List<StatisticsAreaInfo> statisticsAreaInfo(Date startAdRequestDate, Date endAdRequestDate) {

        LocalDate localDateStart = DateUtils.toLocalDateTime(null == startAdRequestDate ? new Date() : startAdRequestDate).toLocalDate();
        LocalDate localDateEnd = DateUtils.toLocalDateTime(null == endAdRequestDate ? new Date() : endAdRequestDate).toLocalDate();
        Date adRequestDateStart = DateUtils.toDate(localDateStart);
        Date adRequestDateEnd = DateUtils.toDate(localDateEnd);

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选*/
        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(adRequestDateStart.getTime()));
        dateBetween.append("$lte", new BsonDateTime(adRequestDateEnd.getTime()));
        BsonDocument match = new BsonDocument("$match", new BsonDocument("adRequestDate", dateBetween)
                .append("prResponse.outPaperStatus", new BsonString("0"))
                .append("peopleInfo.scanTool", new BsonInt32(1))
        );

        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("installAddressCode", new BsonString("$deviceInfo.installAddressCode"))
                .append("adRequestDate", new BsonString("$adRequestDate"))
                .append("deviceScene", new BsonString("$deviceInfo.deviceScene"));

        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id)
                .append("paperSuccessCount", new BsonDocument("$sum", new BsonInt32(1)))
                .append("openIdArray", new BsonDocument("$addToSet", new BsonString("$peopleInfo.openId")))
                .append("deviceSnArray", new BsonDocument("$addToSet", new BsonString("$deviceInfo.deviceSn")))
        );

        pipeline.add(group);

        List<ZjbDictionaryEnum> allDeviceScene = ZjbDictionaryEnum.getByType(ZjbDictionaryTypeEnum.DEVICE_SCENE);
        Map<String, ZjbDictionaryEnum> mapDeviceScene = allDeviceScene.stream().collect(Collectors.toMap(ZjbDictionaryEnum::getValue, Function.identity()));
        List<StatisticsAreaInfo> list = new ArrayList<>(200);
        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);

        for (MongoCursor<BsonDocument> mongoCursor = aggregateIterable.iterator(); mongoCursor.hasNext(); ) {
            StatisticsAreaInfo areaInfo = new StatisticsAreaInfo();
            BsonDocument document = mongoCursor.next();
            BsonDocument _id = document.getDocument("_id");
            String areaCode = _id.get("installAddressCode").asString().getValue();

            areaInfo.setDateStatistics(new Date(_id.getDateTime("adRequestDate").getValue()));
            areaInfo.setStatisticsDate(ISO_8601_EXTENDED_DATE_FORMAT.format(areaInfo.getDateStatistics()));
            areaInfo.setPaperSuccessCount(document.get("paperSuccessCount").asInt32().getValue());
            areaInfo.setAreaCode(areaCode);
            areaInfo.setAreaId(Integer.parseInt(areaCode));
            areaInfo.setPaperUserCount(document.get("openIdArray").asArray().size());
            areaInfo.setDeviceCount(document.get("deviceSnArray").asArray().size());
            BsonValue deviceScene = _id.get("deviceScene");
            areaInfo.setDeviceScene(null == deviceScene ? "" : deviceScene.asString().getValue());
            ZjbDictionaryEnum dict = mapDeviceScene.get(areaInfo.getDeviceScene());

            if (null == dict) {
                logger.info("场景【{}】字典缺失", areaInfo.getDeviceScene());
            }

            areaInfo.setSceneName(null == dict ? "其它" : dict.getName());

            Area area = areaService.selectByAreaCode(areaInfo.getAreaId());
            areaInfo.setAreaName(null == area ? "其它" : area.getAreaName());

            area = areaService.selectByAreaCode(Integer.parseInt(areaCode.substring(0, 4) + "00"));
            areaInfo.setCityName(null == area ? "其它" : area.getAreaName());

            area = areaService.selectByAreaCode(Integer.parseInt(areaCode.substring(0, 2) + "0000"));
            areaInfo.setProvinceName(null == area ? "其它" : area.getAreaName());

            list.add(areaInfo);
        }

        /*原始数据副本*/
        List<StatisticsAreaInfo> listCity = list.stream().filter(e -> !e.getAreaCode().equals("000000")).collect(Collectors.toList());
        List<StatisticsAreaInfo> listProvince = list.stream().filter(e -> !e.getAreaCode().equals("000000")).collect(Collectors.toList());

        /*市地区数据统计*/
        summaryStatisticsCity(listCity);
        list.addAll(listCity);

        /*省地区数据统计*/
        summaryStatisticsProvince(listProvince);
        list.addAll(listProvince);

        /*排序*/
        Collections.sort(list, new Comparator<StatisticsAreaInfo>() {
            @Override
            public int compare(StatisticsAreaInfo o1, StatisticsAreaInfo o2) {

                String code1 = StringUtils.defaultIfBlank(o1.getAreaCode(), StringUtils.defaultIfBlank(o1.getCityCode(), o1.getProvinceCode()));
                String code2 = StringUtils.defaultIfBlank(o2.getAreaCode(), StringUtils.defaultIfBlank(o2.getCityCode(), o2.getProvinceCode()));

                return code1.compareTo(code2);
            }
        });

        return list;
    }

    /**
     * 市地区数据统计
     *
     * @param list
     */
    private void summaryStatisticsCity(List<StatisticsAreaInfo> list) {
        /*分组求和:出纸成功次数:市*/
        Map<String, IntSummaryStatistics> mapPaperSuccessArea = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 4) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getPaperSuccessCount)));

        /*分组求和:出纸人数：市*/
        Map<String, IntSummaryStatistics> mapPaperUserArea = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 4) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getPaperUserCount)));

        /*分组求和:设备数：市*/
        Map<String, IntSummaryStatistics> mapDeviceCount = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 4) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getDeviceCount)));

        list.clear();

        List<ZjbDictionaryEnum> allDeviceScene = ZjbDictionaryEnum.getByType(ZjbDictionaryTypeEnum.DEVICE_SCENE);
        Map<String, ZjbDictionaryEnum> mapDeviceScene = allDeviceScene.stream().collect(Collectors.toMap(ZjbDictionaryEnum::getValue, Function.identity()));

        for (Map.Entry<String, IntSummaryStatistics> entry : mapPaperSuccessArea.entrySet()) {

            String[] keys = StringUtils.split(entry.getKey(), '|');

            StatisticsAreaInfo areaInfo = new StatisticsAreaInfo();
            areaInfo.setCityCode(keys[0] + "00");
            areaInfo.setCityId(Integer.parseInt(areaInfo.getCityCode()));
            areaInfo.setPaperSuccessCount((int) entry.getValue().getSum());
            areaInfo.setStatisticsDate(keys[1]);
            areaInfo.setDeviceScene(keys[2]);

            ZjbDictionaryEnum dict = mapDeviceScene.get(areaInfo.getDeviceScene());

            if (null == dict) {
                logger.warn("场景【{}】字典缺失", areaInfo.getDeviceScene());
            }
            areaInfo.setSceneName(null == dict ? "其它" : dict.getName());

            Area area = areaService.selectByAreaCode(areaInfo.getCityId());

            if (null == area) {
                logger.warn("市【{}】代码缺失", areaInfo.getCityId());
            }
            areaInfo.setCityName(null == area ? "其它" : area.getAreaName());

            area = areaService.selectByAreaCode(Integer.parseInt(areaInfo.getCityCode().substring(0, 2) + "0000"));
            if (null == area) {
                logger.warn("省【{}】代码缺失", Integer.parseInt(areaInfo.getCityCode().substring(0, 2) + "0000"));
            }
            areaInfo.setProvinceName(null == area ? "其它" : area.getAreaName());

            list.add(areaInfo);

            IntSummaryStatistics summaryStatistics = mapPaperUserArea.get(entry.getKey());
            areaInfo.setPaperUserCount(null == summaryStatistics ? 0 : (int) summaryStatistics.getSum());

            IntSummaryStatistics summaryDeviceCount = mapDeviceCount.get(entry.getKey());
            areaInfo.setDeviceCount(null == summaryDeviceCount ? 0 : (int) summaryDeviceCount.getSum());

        }

        mapPaperSuccessArea.clear();
        mapPaperUserArea.clear();
    }

    /**
     * 省地区数据统计
     *
     * @param list
     */
    private void summaryStatisticsProvince(List<StatisticsAreaInfo> list) {
        /*分组求和:出纸成功次数：省*/
        Map<String, IntSummaryStatistics> mapPaperSuccessProvince = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 2) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getPaperSuccessCount)));

        /*分组求和:出纸人数：省*/
        Map<String, IntSummaryStatistics> mapPaperUserProvince = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 2) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getPaperUserCount)));

        /*分组求和:出纸人数：省*/
        Map<String, IntSummaryStatistics> deviceCountProvince = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getAreaCode().substring(0, 2) + '|' + e.getStatisticsDate() + '|' + e.getDeviceScene();
                        },
                        Collectors.summarizingInt(StatisticsAreaInfo::getDeviceCount)));

        list.clear();

        List<ZjbDictionaryEnum> allDeviceScene = ZjbDictionaryEnum.getByType(ZjbDictionaryTypeEnum.DEVICE_SCENE);
        Map<String, ZjbDictionaryEnum> mapDeviceScene = allDeviceScene.stream().collect(Collectors.toMap(ZjbDictionaryEnum::getValue, Function.identity()));

        for (Map.Entry<String, IntSummaryStatistics> entry : mapPaperSuccessProvince.entrySet()) {
            StatisticsAreaInfo areaInfo = new StatisticsAreaInfo();

            String[] keys = StringUtils.split(entry.getKey(), '|');

            areaInfo.setProvinceCode(keys[0] + "0000");
            areaInfo.setProvinceId(Integer.parseInt(areaInfo.getProvinceCode()));
            areaInfo.setPaperSuccessCount((int) entry.getValue().getSum());
            areaInfo.setStatisticsDate(keys[1]);
            areaInfo.setDeviceScene(keys[2]);

            ZjbDictionaryEnum dict = mapDeviceScene.get(areaInfo.getDeviceScene());
            areaInfo.setSceneName(null == dict ? "其它" : dict.getName());

            Area area = areaService.selectByAreaCode(areaInfo.getProvinceId());
            areaInfo.setProvinceName(null == area ? "其它" : area.getAreaName());

            list.add(areaInfo);

            IntSummaryStatistics summaryStatistics = mapPaperUserProvince.get(entry.getKey());
            areaInfo.setPaperUserCount(null == summaryStatistics ? 0 : (int) summaryStatistics.getSum());

            IntSummaryStatistics summaryDeviceCount = deviceCountProvince.get(entry.getKey());
            areaInfo.setDeviceCount(null == summaryDeviceCount ? 0 : (int) summaryDeviceCount.getSum());

        }

        mapPaperSuccessProvince.clear();
        mapPaperUserProvince.clear();
    }

    @Override
    public List<StatisticsCommon> statisticsPlanUniqueVisitor(Date startAdRequestDate, Date endAdRequestDate) {
        LocalDate localDateStart = DateUtils.toLocalDateTime(null == startAdRequestDate ? new Date() : startAdRequestDate).toLocalDate();
        LocalDate localDateEnd = DateUtils.toLocalDateTime(null == endAdRequestDate ? new Date() : endAdRequestDate).toLocalDate();
        Date adRequestDateStart = DateUtils.toDate(localDateStart);
        Date adRequestDateEnd = DateUtils.toDate(localDateEnd);

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选*/
        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(adRequestDateStart.getTime()));
        dateBetween.append("$lte", new BsonDateTime(adRequestDateEnd.getTime()));
        BsonDocument match = new BsonDocument("$match", new BsonDocument("adRequestDate", dateBetween)
                //.append("prResponse.outPaperStatus", new BsonString("0"))
                //.append("peopleInfo.scanTool", new BsonInt32(1))
        );

        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("adWinPlanId", new BsonString("$adWinPlanId"))
                .append("scanTool", new BsonString("$peopleInfo.scanTool"));

        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id)
                .append("pvSum", new BsonDocument("$sum", new BsonInt32(1)))
                .append("openIds", new BsonDocument("$addToSet", new BsonString("$peopleInfo.openId")))
        );

        pipeline.add(group);

        List<StatisticsCommon> list = new ArrayList<>(200);
        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);
        for (BsonDocument bsonDocument : aggregateIterable) {
            StatisticsCommon statisticsCommon = new StatisticsCommon();
            BsonDocument _id = bsonDocument.getDocument("_id");
            BsonValue scanTool = _id.get("scanTool");
            statisticsCommon.setScanTool(null == scanTool ? 9 : scanTool.asInt32().getValue());
            BsonValue adWinPlanId = _id.get("adWinPlanId");
            statisticsCommon.setAdWinPlanId(null == adWinPlanId ? null : adWinPlanId.asString().getValue());
            int size = bsonDocument.get("openIds").asArray().size();
            switch (statisticsCommon.getScanTool()) {
                case 1:
                    statisticsCommon.setCountOpenIdWeChat((float) size);
                    break;
                case 2:
                    statisticsCommon.setCountOpenIdAliPay((float) size);
                    break;
                default:
                    statisticsCommon.setCountOpenIdOther((float) size);
                    break;
            }

            list.add(statisticsCommon);
        }

        return list;
    }

    @Override
    public List<StatisticsCommon> statisticsSuccessOutPaper(Date startAdRequestDate, Date endAdRequestDate) {
        LocalDate localDateStart = DateUtils.toLocalDateTime(null == startAdRequestDate ? new Date() : startAdRequestDate).toLocalDate();
        LocalDate localDateEnd = DateUtils.toLocalDateTime(null == endAdRequestDate ? new Date() : endAdRequestDate).toLocalDate();
        Date adRequestDateStart = DateUtils.toDate(localDateStart);
        Date adRequestDateEnd = DateUtils.toDate(localDateEnd);

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选：时间段*/
        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(adRequestDateStart.getTime()));
        dateBetween.append("$lte", new BsonDateTime(adRequestDateEnd.getTime()));

        /*筛选：必须是免费取纸*/
        BsonDocument takePaperSourceBetween = new BsonDocument("$gte", new BsonInt32(TAKE_PAPER_FREE.getValue()));
        takePaperSourceBetween.append("$lte", new BsonInt32(TAKE_PAPER_FREE_ALI_PAY.getValue()));

        BsonDocument match = new BsonDocument("$match", new BsonDocument("responseDate", dateBetween)
                .append("planId", new BsonDocument("$exists", new BsonBoolean(true)))
                .append("takePaperSource", takePaperSourceBetween)
                .append("outPaperStatus", new BsonString(ZJB_PR_OUT_PAPER_SUCCESS.getValue()))
        );

        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("planId", new BsonString("$planId"));

        /*本次补贴总额，单位分*/
        List<BsonValue> smbtAccountList = new ArrayList<>(4);
        smbtAccountList.add(new BsonString("$smbtAccount"));
        smbtAccountList.add(new BsonInt32(0));

        /*广告收益（厘）*/
        List<BsonValue> incomeList = new ArrayList<>(4);
        incomeList.add(new BsonString("$income"));
        incomeList.add(new BsonInt32(0));

        /*利润（分）*/
        List<BsonValue> profitList = new ArrayList<>(4);
        profitList.add(new BsonString("$profit"));
        profitList.add(new BsonInt32(0));

        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id)
                .append("countSuccessOutPaper", new BsonDocument("$sum", new BsonInt32(1)))
                .append("smbtAccount", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(smbtAccountList))))
                .append("income", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(incomeList))))
                .append("profit", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(profitList))))
        );

        pipeline.add(group);

        List<StatisticsCommon> list = new ArrayList<>(200);
        String collectionName = mongoTemplate.getCollectionName(ZjbPrResponse.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);
        for (BsonDocument bsonDocument : aggregateIterable) {
            StatisticsCommon statisticsCommon = new StatisticsCommon();
            BsonDocument _id = bsonDocument.getDocument("_id");
            statisticsCommon.setCountSuccessOutPaper(Float.valueOf(bsonDocument.get("countSuccessOutPaper").asInt32().getValue()));
            statisticsCommon.setAdWinPlanId(_id.get("planId").asString().getValue());
            BigDecimal smbtAccount = new BigDecimal("" + bsonDocument.get("smbtAccount").asInt32().getValue());
            statisticsCommon.setSmbtAccount(smbtAccount.divide(new BigDecimal("100")));
            BigDecimal income = new BigDecimal("" + toInt(bsonDocument.get("income")));
            statisticsCommon.setIncome(income.divide(new BigDecimal("1000")));
            BigDecimal profit = new BigDecimal("" + bsonDocument.get("profit").asInt32().getValue());
            statisticsCommon.setProfit(profit.divide(new BigDecimal("100")));

            list.add(statisticsCommon);
        }

        return list;
    }

    @Override
    public List<StatisticsCommon> statisticsCountOutPaper(Date start, Date end) {

        if (null == start || null == end) {
            logger.error("开始||结束时间不能为空");
            return Collections.emptyList();
        }

        if (start.after(end)) {
            logger.error("开始时间不能大于结束时间");
            return Collections.emptyList();
        }

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选：时间范围*/
        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(start.getTime()));
        dateBetween.append("$lte", new BsonDateTime(end.getTime()));

        /*筛选：必须是免费取纸*/
        BsonDocument takePaperSourceBetween = new BsonDocument("$gte", new BsonInt32(TAKE_PAPER_FREE.getValue()));
        takePaperSourceBetween.append("$lte", new BsonInt32(TAKE_PAPER_FREE_ALI_PAY.getValue()));

        BsonDocument match = new BsonDocument("$match", new BsonDocument("dayRequest", dateBetween)
                .append("planId", new BsonDocument("$exists", new BsonBoolean(true)))
                .append("takePaperSource", takePaperSourceBetween)
        );

        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("planId", new BsonString("$planId"));

        /*本次补贴总额，单位分*/
        List<BsonValue> smbtAccountList = new ArrayList<>(4);
        smbtAccountList.add(new BsonString("$smbtAccount"));
        smbtAccountList.add(new BsonInt32(0));

        /*广告收益（厘）*/
        List<BsonValue> incomeList = new ArrayList<>(4);
        incomeList.add(new BsonString("$income"));
        incomeList.add(new BsonInt32(0));

        /*利润（分）*/
        List<BsonValue> profitList = new ArrayList<>(4);
        profitList.add(new BsonString("$profit"));
        profitList.add(new BsonInt32(0));

        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id)
                .append("countOutPaper", new BsonDocument("$sum", new BsonInt32(1)))
                .append("smbtAccount", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(smbtAccountList))))
                .append("income", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(incomeList))))
                .append("profit", new BsonDocument("$sum", new BsonDocument("$ifNull", new BsonArray(profitList))))
        );

        pipeline.add(group);

        for (BsonDocument bsonDocument : pipeline) {
            System.out.println(bsonDocument.toJson());
        }

        List<StatisticsCommon> list = new ArrayList<>(200);
        String collectionName = mongoTemplate.getCollectionName(RpcRequest.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);

        try (MongoCursor<BsonDocument> mongoCursor = aggregateIterable.iterator()) {
            for (; mongoCursor.hasNext(); ) {
                StatisticsCommon statisticsCommon = new StatisticsCommon();
                BsonDocument document = mongoCursor.next();
                BsonDocument _id = document.getDocument("_id");
                statisticsCommon.setCountOutPaper((float) document.get("countOutPaper").asInt32().getValue());
                statisticsCommon.setAdWinPlanId(_id.get("planId").asString().getValue());
                BigDecimal smbtAccount = new BigDecimal("" + document.get("smbtAccount").asInt32().getValue());
                statisticsCommon.setSmbtAccount(smbtAccount.divide(new BigDecimal("100")));
                BigDecimal income = new BigDecimal("" + toInt(document.get("income")));
                statisticsCommon.setIncome(income.divide(new BigDecimal("1000")));
                BigDecimal profit = new BigDecimal("" + document.get("profit").asInt32().getValue());
                statisticsCommon.setProfit(profit.divide(new BigDecimal("100")));
                list.add(statisticsCommon);
            }
        }

        logger.info("{}至{}广告计划请求出纸次数查询记录条数：{}", DateUtils.toLocalDateTime(start), DateUtils.toLocalDateTime(end), list.size());

        return list;
    }

    @Override
    public StatisticsCommon countUsers(Date start, Date end) {

        StatisticsCommon record = new StatisticsCommon();
        String startStr = DateUtils.DATE_FORMAT.format(null == start ? new Date() : start);
        String endStr = DateUtils.DATE_FORMAT.format(null == end ? new Date() : end);
        Date dateStart = DateUtils.toDate(LocalDate.parse(startStr));
        Date dateEnd = DateUtils.toDate(LocalDate.parse(endStr));
        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        CompletionService<Integer> completionService = new ExecutorCompletionService<>(AsyncManager.me().getExecutor());

        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(dateStart.getTime()));
        dateBetween.append("$lte", new BsonDateTime(dateEnd.getTime()));

        int threadCount = 0;
        completionService.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                /*扫码用户总数量*/
                int countOpenId = 0;
                BsonDocument filter = new BsonDocument("adRequestDate", dateBetween);
                DistinctIterable<String> distinctIterable = mongoTemplate.getCollection(collectionName).distinct(PRIMARY_KEY_OPEN_ID, filter, String.class);

                for (String s : distinctIterable) {
                    countOpenId += StringUtils.isNotBlank(s) ? 1 : 0;
                }

                record.setCountOpenId((float) countOpenId);

                return countOpenId;
            }
        });
        threadCount += 1;

        completionService.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                /*扫码微信用户数量*/
                int countOpenIdWeChat = 0;
                BsonDocument filter = new BsonDocument("adRequestDate", dateBetween);
                filter.append("peopleInfo.scanTool", new BsonInt32(AD_SCAN_TOOL_WX.getValue()));
                DistinctIterable<String> distinctIterable = mongoTemplate.getCollection(collectionName).distinct(PRIMARY_KEY_OPEN_ID, filter, String.class);

                for (String s : distinctIterable) {
                    countOpenIdWeChat += StringUtils.isNotBlank(s) ? 1 : 0;
                }

                record.setCountOpenIdWeChat((float) countOpenIdWeChat);

                return countOpenIdWeChat;
            }
        });
        threadCount += 1;

        completionService.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                BsonDocument filter = new BsonDocument("adRequestDate", dateBetween);
                filter.append("peopleInfo.scanTool", new BsonInt32(AD_SCAN_TOOL_ALI_PAY.getValue()));
                DistinctIterable<String> distinctIterable = mongoTemplate.getCollection(collectionName).distinct(PRIMARY_KEY_OPEN_ID, filter, String.class);

                int countOpenIdAliPay = 0;
                for (String s : distinctIterable) {
                    countOpenIdAliPay += StringUtils.isNotBlank(s) ? 1 : 0;
                }

                record.setCountOpenIdAliPay((float) countOpenIdAliPay);
                return countOpenIdAliPay;
            }
        });
        threadCount += 1;

        completionService.submit(new Callable<Integer>() {
            @Override
            public Integer call() throws Exception {
                int countOpenIdOther = 0;
                BsonDocument filter = new BsonDocument("adRequestDate", dateBetween);
                filter.append("peopleInfo.scanTool", new BsonInt32(AD_SCAN_TOOL_OTHER.getValue()));
                DistinctIterable<String> distinctIterable = mongoTemplate.getCollection(collectionName).distinct(PRIMARY_KEY_OPEN_ID, filter, String.class);

                for (String s : distinctIterable) {
                    countOpenIdOther += StringUtils.isNotBlank(s) ? 1 : 0;
                }
                record.setCountOpenIdOther((float) countOpenIdOther);
                return countOpenIdOther;
            }
        });
        threadCount += 1;

        try {
            for (int i = 0; i < threadCount; i++) {
                completionService.take().get();
            }
        } catch (InterruptedException | ExecutionException e) {
            logger.error(e.getMessage(), e);
        }

        return record;
    }

    @Override
    public List<StatisticsDevicePvUv> statisticsDevicePvUv(Date start, Date end, Integer scanTool) {
        List<StatisticsDevicePvUv> list = new ArrayList<>(5000);
        String startStr = DateUtils.DATE_FORMAT.format(null == start ? new Date() : start);
        String endStr = DateUtils.DATE_FORMAT.format(null == end ? new Date() : end);
        Date dateStart = DateUtils.toDate(LocalDate.parse(startStr));
        Date dateEnd = DateUtils.toDate(LocalDate.parse(endStr));
        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);

        List<BsonDocument> pipeline = new ArrayList<>();

        /*筛选*/
        BsonDocument dateBetween = new BsonDocument("$gte", new BsonDateTime(dateStart.getTime()));
        dateBetween.append("$lte", new BsonDateTime(dateEnd.getTime()));
        BsonDocument match = new BsonDocument("$match", new BsonDocument("adRequestDate", dateBetween)
                .append("peopleInfo.scanTool", new BsonInt32(null == scanTool ? AD_SCAN_TOOL_ALI_PAY.getValue() : scanTool))
                //.append("peopleInfo.scanTool", new BsonInt32(1))
        );

        pipeline.add(match);

        /*分组*/
        BsonDocument id = new BsonDocument("deviceSn", new BsonString("$deviceInfo.deviceSn"));
        //.append("scanTool", new BsonString("$peopleInfo.scanTool"));

        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", id)
                .append("pv", new BsonDocument("$sum", new BsonInt32(1)))
                .append("openIds", new BsonDocument("$addToSet", new BsonString("$peopleInfo.openId")))
        );

        pipeline.add(group);

        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);

        try (MongoCursor<BsonDocument> mongoCursor = aggregateIterable.iterator()) {

            List<ZjbDictionaryEnum> allDeviceScene = ZjbDictionaryEnum.getByType(ZjbDictionaryTypeEnum.DEVICE_SCENE);
            Map<String, ZjbDictionaryEnum> mapDeviceScene = allDeviceScene.stream().collect(Collectors.toMap(ZjbDictionaryEnum::getValue, Function.identity()));

            for (; mongoCursor.hasNext(); ) {
                BsonDocument document = mongoCursor.next();
                BsonDocument _id = document.getDocument("_id");
                StatisticsDevicePvUv record = new StatisticsDevicePvUv();
                record.setDeviceSn(_id.get("deviceSn").asString().getValue());
                DeviceDTO device = deviceService.selectDeviceBySn(record.getDeviceSn());
                if (null == device) {
                    continue;
                }

                DeviceInstallInfo installInfo = deviceInstallInfoService.findByDeviceId(device.getId());
                ZjbDictionaryEnum dict = (null == installInfo) ? null : mapDeviceScene.get(installInfo.getInstallLocationCode());
                record.setAgencyId(device.getAgencyId());
                record.setAgencyName(device.getAgencyName());
                record.setProvinceName(null == installInfo ? "未知" : installInfo.getProvinceName());
                record.setCityName(null == installInfo ? "未知" : installInfo.getCityName());
                record.setAreaName(null == installInfo ? "未知" : installInfo.getAreaName());
                record.setInstallAddress(null == installInfo ? "未知" : installInfo.getDetailAddress());
                record.setSceneName(null == dict ? "" : dict.getName());
                record.setPv(document.get("pv").asInt32().getValue());
                record.setUv(document.get("openIds").asArray().size());

                list.add(record);
            }
        }
        return list;
    }

    @Override
    public List<StatisticsCommon> statisticsAdWinCount(Date start, Date end) {

        if (null == start || null == end) {
            logger.error("开始||结束时间不能为空");
            return Collections.emptyList();
        }

        if (start.after(end)) {
            logger.error("开始不能大于结束时间");
            return Collections.emptyList();
        }

        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        List<StatisticsCommon> listCommon = new ArrayList<>(200);
        Criteria statisticsCommon = Criteria.where("adRequestDate").gte(start).lte(end);

        GroupByResults<StatisticsCommon> resultsCommon = mongoTemplate.group(statisticsCommon, collectionName, GroupBy.key("adWinPlanId").initialDocument("{countAdWinPlanId:0}").reduceFunction("function(doc,prev) {prev.countAdWinPlanId += 1}"), StatisticsCommon.class);
        for (StatisticsCommon common : resultsCommon) {
            AdvertisingPlan advertisingPlan = StringUtils.isBlank(common.getAdWinPlanId()) ? null : advertisingPlanService.findByPlanId(common.getAdWinPlanId());
            if (null != advertisingPlan) {
                common.setAdWinPlanName(advertisingPlan.getPlanName());
            }
            listCommon.add(common);
        }

        return listCommon;
    }
}
