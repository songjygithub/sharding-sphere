package com.zjb.project.dsp.fileExport.service;

import com.zjb.common.support.Convert;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.fileExport.domain.FileExport;
import com.zjb.project.dsp.fileExport.mapper.FileExportMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 导出文件记录 服务层实现
 *
 * @author songjy
 * @date 2020-06-20
 */
@Service
public class FileExportServiceImpl implements IFileExportService {
    @Autowired
    private FileExportMapper fileExportMapper;

    /**
     * 查询导出文件记录信息
     *
     * @param id 导出文件记录ID
     * @return 导出文件记录信息
     */
    @Override
    public FileExport selectFileExportById(Integer id) {
        return fileExportMapper.selectFileExportById(id);
    }

    /**
     * 查询导出文件记录列表
     *
     * @param fileExport 导出文件记录信息
     * @return 导出文件记录集合
     */
    @Override
    public List<FileExport> selectFileExportList(FileExport fileExport) {
        return fileExportMapper.selectFileExportList(fileExport);
    }

    /**
     * 新增导出文件记录
     *
     * @param fileExport 导出文件记录信息
     * @return 结果
     */
    @Override
    public int insertFileExport(FileExport fileExport) {
        return fileExportMapper.insertFileExport(fileExport);
    }

    /**
     * 修改导出文件记录
     *
     * @param fileExport 导出文件记录信息
     * @return 结果
     */
    @Override
    public int updateFileExport(FileExport fileExport) {
        return fileExportMapper.updateFileExport(fileExport);
    }

    /**
     * 删除导出文件记录对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteFileExportByIds(String ids) {

        String[] arr = StringUtils.split(ids, ',');

        for (String id : arr) {
            FileExport record = fileExportMapper.selectFileExportById(Integer.parseInt(id));
            OssUtil.deleted(record.getFileKey());
        }

        return fileExportMapper.deleteFileExportByIds(Convert.toStrArray(ids));
    }

}
