package com.zjb.project.dsp.blackPersonalAccount.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
											import java.util.Date;

/**
 * 个人号黑名单表 zjb_black_personal_account
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
public class BlackPersonalAccount extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 自增主键 */
	private Integer id;
	/** 个人号唯一标识 */
	private String personalAppId;
	/** 个人号名称 */
	private String personalNickName;
	/** 个人号来源通道(参考字典) */
	private String personalSourceType;
	/** 本次进入黑名单时间 */
	private Date joinBlackTime;
	/** 累计进入黑名单次数 */
	private Integer joinBlackCount;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setPersonalAppId(String personalAppId) 
	{
		this.personalAppId = personalAppId;
	}

	public String getPersonalAppId() 
	{
		return personalAppId;
	}
	public void setPersonalNickName(String personalNickName) 
	{
		this.personalNickName = personalNickName;
	}

	public String getPersonalNickName() 
	{
		return personalNickName;
	}
	public void setPersonalSourceType(String personalSourceType) 
	{
		this.personalSourceType = personalSourceType;
	}

	public String getPersonalSourceType() 
	{
		return personalSourceType;
	}
	public void setJoinBlackTime(Date joinBlackTime) 
	{
		this.joinBlackTime = joinBlackTime;
	}

	public Date getJoinBlackTime() 
	{
		return joinBlackTime;
	}
	public void setJoinBlackCount(Integer joinBlackCount) 
	{
		this.joinBlackCount = joinBlackCount;
	}

	public Integer getJoinBlackCount() 
	{
		return joinBlackCount;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("personalAppId", getPersonalAppId())
            .append("personalNickName", getPersonalNickName())
            .append("personalSourceType", getPersonalSourceType())
            .append("joinBlackTime", getJoinBlackTime())
            .append("joinBlackCount", getJoinBlackCount())
            .append("gmtCreated", getGmtCreated())
            .append("createrId", getCreaterId())
            .append("gmtModified", getGmtModified())
            .append("modifierId", getModifierId())
            .append("deleted", getDeleted())
            .toString();
    }
}
