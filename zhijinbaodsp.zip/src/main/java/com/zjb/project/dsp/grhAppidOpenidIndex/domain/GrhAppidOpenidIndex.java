package com.zjb.project.dsp.grhAppidOpenidIndex.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * @author jiangbingjie
 * @date 2020/3/20 4:27 下午
 */
public class GrhAppidOpenidIndex extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /** 主键 */
    private Integer id;
    /** 用户微信unionid */
    private String zjbOpenid;
    /** 用户openid */
    private String openid;
    /** 个人号appid */
    private String personalAppid;
    /** 用户昵称 */
    private String nickName;
    /** 性别 0:未知,1:男,2:女 */
    private Integer sex;
    /** 头像地址 */
    private String headImgUrl;
    /** 国家 */
    private String country;
    /** 省份 */
    private String province;
    /** 城市 */
    private String city;
    /** 事件，subscribe：关注订阅  unsubscribe：取消关注订阅 */
    private String event;
    /** 个人号类型(参考字典) */
    private Integer personalType;
    /** 备注 */
    private String remark;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getZjbOpenid() {
        return zjbOpenid;
    }

    public void setZjbOpenid(String zjbOpenid) {
        this.zjbOpenid = zjbOpenid;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getPersonalAppid() {
        return personalAppid;
    }

    public void setPersonalAppid(String personalAppid) {
        this.personalAppid = personalAppid;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Integer getPersonalType() {
        return personalType;
    }

    public void setPersonalType(Integer personalType) {
        this.personalType = personalType;
    }

    @Override
    public String getRemark() {
        return remark;
    }

    @Override
    public void setRemark(String remark) {
        this.remark = remark;
    }
}
