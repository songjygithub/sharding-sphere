package com.zjb.project.dsp.advertisingUnit.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 广告池-支付宝表 zjb_advertising_unit
 *
 * @author zjb
 * @date 2019-07-12
 */
public class AdvertisingUnit extends BaseEntity {
    private static final long serialVersionUID = -7554603169992991700L;

    /**
     * 主键
     */
    private Integer id;
    /**
     * 业务主键id 格式 “01+id”
     */
    private String adId;
    /**
     * 广告产品单元类型，参阅字典：zjb_ad_unit_type
     */
    private String adUnitType;
    /**
     * 广告位标识  zjb_ad_space_identifier
     */
    private String adSpaceIdentifier;
    /**
     * 广告名称
     */
    private String adName;
    /**
     * 信息来源 zjb_information_source
     */
    private Integer informationSource;
    /**
     * 广告图片链接
     */
    private String adPhotoUrl;
    /**
     * tab/文字链 名称
     */
    private String generalName;
    /**
     * 跳转类型  zjb_redirect_url_type
     */
    private Integer redirectUrlType;
    /**
     * 跳转路径
     */
    private String redirectUrl;
    /**
     * 来源标识,手动输入
     */
    private String adFrom;
    /**
     * 使用状态 zjb_ad_use_status
     */
    private Integer adUseStatus;
    /**
     * 补充id1,跳转辅助参数等,如：广点通身份标识ID
     */
    private String supplementParam1;
    /**
     * 补充id2，跳转辅助参数等,如：广点通广告位ID
     */
    private String supplementParam2;
    /**
     * 广告方案中待添加表示
     */
    private Integer adUnitId;
    /**
     * 广告方案添加、编辑拉取标识
     */
    private Integer adUseType;
    /**
     * 广告方案id
     */
    private Integer combinationId;
    /**
     * 小程序标识
     */
    private String appId;
    /**
     * 标题
     */
    private String titile;
    /**
     * 出纸延迟时间 单位毫秒
     */
    private Integer outPaperDelay;
    /**
     * 过渡页跳转小程序或生活号URL
     */
    private String programUrl;

    /**
     * 微信公众号ID，即表【zjb_component_authorization_info】字段【component_id】
     */
    private String weChatAccount;

    /**
     * 微信公众号名称
     */
    private String weChatAccountName;

    /**
     * 取纸流程
     */
    private String takeThePaperProcess;
    /**
     * 公众号点击消息出纸概率
     */
    private Integer probability;

    /**
     * 微信个人号名称
     */
    private String weChatPersonalNickName;

    /**
     * 微信个人号编号
     */
    private String weChatPersonalId;

    /**
     * 图文消息落地页链接
     */
    private String adUrl;

    /**
     * QQ个人号名称
     */
    private String qqPersonalNickName;

    /**
     * QQ个人号编号
     */
    private String qqPersonalId;

    /**
     * 广告位位置
     * */
    private Integer position;

    /**
     * 广告类型ID，即表【zjb_advertising_type】主键【id】
     */
    private Integer adTypeId;


    /**
     * 广告类型名称 非数据库映射字段
     */
    private String adTypeName;

    /**
     * 公众号关注回复消息
     * */
    private String gzhSubscribeMsg;

    public Integer getProbability() {
        return probability;
    }

    public void setProbability(Integer probability) {
        this.probability = probability;
    }

    public void setWeChatAccount(String weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public String getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccountName(String weChatAccountName) {
        this.weChatAccountName = weChatAccountName;
    }

    public String getWeChatAccountName() {
        return weChatAccountName;
    }


    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdUnitType(String adUnitType) {
        this.adUnitType = adUnitType;
    }

    public String getAdUnitType() {
        return adUnitType;
    }

    public void setAdSpaceIdentifier(String adSpaceIdentifier) {
        this.adSpaceIdentifier = adSpaceIdentifier;
    }

    public String getAdSpaceIdentifier() {
        return adSpaceIdentifier;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    public String getAdName() {
        return adName;
    }

    public void setInformationSource(Integer informationSource) {
        this.informationSource = informationSource;
    }

    public Integer getInformationSource() {
        return informationSource;
    }

    public void setAdPhotoUrl(String adPhotoUrl) {
        this.adPhotoUrl = adPhotoUrl;
    }

    public String getAdPhotoUrl() {
        return adPhotoUrl;
    }

    public String getGeneralName() {
        return generalName;
    }

    public void setGeneralName(String generalName) {
        this.generalName = generalName;
    }

    public void setRedirectUrlType(Integer redirectUrlType) {
        this.redirectUrlType = redirectUrlType;
    }

    public Integer getRedirectUrlType() {
        return redirectUrlType;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setAdFrom(String adFrom) {
        this.adFrom = adFrom;
    }

    public String getAdFrom() {
        return adFrom;
    }

    public void setAdUseStatus(Integer adUseStatus) {
        this.adUseStatus = adUseStatus;
    }

    public Integer getAdUseStatus() {
        return adUseStatus;
    }

    public void setSupplementParam1(String supplementParam1) {
        this.supplementParam1 = supplementParam1;
    }

    public String getSupplementParam1() {
        return supplementParam1;
    }

    public void setSupplementParam2(String supplementParam2) {
        this.supplementParam2 = supplementParam2;
    }

    public String getSupplementParam2() {
        return supplementParam2;
    }

    public Integer getAdUnitId() {
        return adUnitId;
    }

    public void setAdUnitId(Integer adUnitId) {
        this.adUnitId = adUnitId;
    }

    public Integer getAdUseType() {
        return adUseType;
    }

    public void setAdUseType(Integer adUseType) {
        this.adUseType = adUseType;
    }

    public Integer getCombinationId() {
        return combinationId;
    }

    public void setCombinationId(Integer combinationId) {
        this.combinationId = combinationId;
    }

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getTitile() {
        return titile;
    }

    public void setTitile(String titile) {
        this.titile = titile;
    }

    public Integer getOutPaperDelay() {
        return outPaperDelay;
    }

    public void setOutPaperDelay(Integer outPaperDelay) {
        this.outPaperDelay = outPaperDelay;
    }

    public String getProgramUrl() {
        return programUrl;
    }

    public void setProgramUrl(String programUrl) {
        this.programUrl = programUrl;
    }

    public String getTakeThePaperProcess() {
        return takeThePaperProcess;
    }

    public void setTakeThePaperProcess(String takeThePaperProcess) {
        this.takeThePaperProcess = takeThePaperProcess;
    }

    public String getWeChatPersonalNickName() {
        return weChatPersonalNickName;
    }

    public void setWeChatPersonalNickName(String weChatPersonalNickName) {
        this.weChatPersonalNickName = weChatPersonalNickName;
    }

    public String getWeChatPersonalId() {
        return weChatPersonalId;
    }

    public void setWeChatPersonalId(String weChatPersonalId) {
        this.weChatPersonalId = weChatPersonalId;
    }

    public String getAdUrl() {
        return adUrl;
    }

    public void setAdUrl(String adUrl) {
        this.adUrl = adUrl;
    }

    public String getQqPersonalNickName() {
        return qqPersonalNickName;
    }

    public void setQqPersonalNickName(String qqPersonalNickName) {
        this.qqPersonalNickName = qqPersonalNickName;
    }

    public String getQqPersonalId() {
        return qqPersonalId;
    }

    public void setQqPersonalId(String qqPersonalId) {
        this.qqPersonalId = qqPersonalId;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }

    public Integer getAdTypeId() {
        return adTypeId;
    }

    public void setAdTypeId(Integer adTypeId) {
        this.adTypeId = adTypeId;
    }

    public String getAdTypeName() {
        return adTypeName;
    }

    public void setAdTypeName(String adTypeName) {
        this.adTypeName = adTypeName;
    }

    public String getGzhSubscribeMsg() {
        return gzhSubscribeMsg;
    }

    public void setGzhSubscribeMsg(String gzhSubscribeMsg) {
        this.gzhSubscribeMsg = gzhSubscribeMsg;
    }
}
