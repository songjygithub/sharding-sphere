package com.zjb.project.dsp.advertisingADExchange.domain;

import java.util.List;

/**
 * 非竞价广告
 * @author jiangbingjie
 * @date 2020/4/2 3:02 上午
 */
public class WithoutBiddingAd {
    //广告ID
    private List<Integer> adIdList;
    //非竞价广告状态
    private Integer advertisementStatus;
    //广告池使用状态
    private Integer adUseStatus;
    //非竞价广告类型
    private String adSpaceIdentifier;

    public List<Integer> getAdIdList() {
        return adIdList;
    }

    public void setAdIdList(List<Integer> adIdList) {
        this.adIdList = adIdList;
    }

    public Integer getAdvertisementStatus() {
        return advertisementStatus;
    }

    public void setAdvertisementStatus(Integer advertisementStatus) {
        this.advertisementStatus = advertisementStatus;
    }

    public Integer getAdUseStatus() {
        return adUseStatus;
    }

    public void setAdUseStatus(Integer adUseStatus) {
        this.adUseStatus = adUseStatus;
    }

    public String getAdSpaceIdentifier() {
        return adSpaceIdentifier;
    }

    public void setAdSpaceIdentifier(String adSpaceIdentifier) {
        this.adSpaceIdentifier = adSpaceIdentifier;
    }
}
