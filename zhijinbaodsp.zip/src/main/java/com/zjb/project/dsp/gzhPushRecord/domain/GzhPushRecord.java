package com.zjb.project.dsp.gzhPushRecord.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
							import java.util.Date;

/**
 * 公众号推送记录表 zjb_gzh_push_record
 * 
 * @author shenlong
 * @date 2020-01-15
 */
public class GzhPushRecord extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** appid */
	private String appId;
	/** openid */
	private String openId;
	/** 展示次数 */
	private Integer viewCount;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setAppId(String appId) 
	{
		this.appId = appId;
	}

	public String getAppId() 
	{
		return appId;
	}
	public void setOpenId(String openId) 
	{
		this.openId = openId;
	}

	public String getOpenId() 
	{
		return openId;
	}
	public void setViewCount(Integer viewCount) 
	{
		this.viewCount = viewCount;
	}

	public Integer getViewCount() 
	{
		return viewCount;
	}

	@Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("appId", getAppId())
            .append("openId", getOpenId())
            .append("viewCount", getViewCount())
            .append("createTime", getCreateTime())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .toString();
    }
}
