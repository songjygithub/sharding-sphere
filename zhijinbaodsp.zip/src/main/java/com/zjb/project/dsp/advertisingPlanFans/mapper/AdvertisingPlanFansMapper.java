package com.zjb.project.dsp.advertisingPlanFans.mapper;

import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;

import java.util.List;

/**
 * 粉丝通广告投放计划 数据层
 *
 * @author shenlong
 * @date 2019-11-22
 */
public interface AdvertisingPlanFansMapper {
    /**
     * 查询粉丝通广告投放计划信息
     *
     * @param id 粉丝通广告投放计划ID
     * @return 粉丝通广告投放计划信息
     */
    AdvertisingPlanFans selectAdvertisingPlanFansById(Integer id);

    /**
     * 查询粉丝通广告投放计划列表
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 粉丝通广告投放计划集合
     */
    List<AdvertisingPlanFans> selectAdvertisingPlanFansList(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 新增粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    public int insertAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 修改粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    int updateAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 删除粉丝通广告投放计划
     *
     * @param id 粉丝通广告投放计划ID
     * @return 结果
     */
    public int deleteAdvertisingPlanFansById(Integer id);

    /**
     * 批量删除粉丝通广告投放计划
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteAdvertisingPlanFansByIds(String[] ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param arr
     * @return
     */
    int logicDeleteAdvertisingPlanPayByIds(String[] arr);

    /**
     * 根据广告计划ID查询记录
     *
     * @param planId
     * @return
     */
    AdvertisingPlanFans selectAdvertisingPlanFansByPlanId(String planId);

    /**
     * 根据公众号查询广告投放计划
     *
     * @param adAppId
     * @return
     */
    List<AdvertisingPlanFans> selectByAdAppId(String adAppId);

    /**
     * 根据微信个人号编号查询广告计划
     *
     * @param weChatPersonalId 微信个人号编号
     * @return
     */
    List<AdvertisingPlanFans> findByWeChatPersonalId(String weChatPersonalId);

    /**
     * 根据QQ个人号编号查询广告计划
     *
     * @param qqPersonalId QQ个人号编号
     * @return 粉丝通广告投放计划信息
     */
    List<AdvertisingPlanFans> findByQQPersonalId(String qqPersonalId);
}