package com.zjb.project.dsp.area.service;

import com.zjb.common.constant.Constants;
import com.zjb.project.dsp.area.domain.Area;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

/**
 * @author songjy
 * @Date 2019/12/09
 **/
@Service
public class AreaServiceImpl implements IAreaService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Override
    public Area selectByAreaCode(Integer areaCode) {

        if (null == areaCode) {
            logger.error("区域代码为NULL");
            return null;
        }

        try {
            String sql = "SELECT * FROM sys_area WHERE area_code = ? LIMIT 1";
            Object[] args = {areaCode};
            int[] argTypes = {Types.INTEGER};
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<Area>() {
                @Override
                public Area mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Area area = new Area();
                    area.setId(rs.getInt("id"));
                    area.setAreaCode(rs.getInt("area_code"));
                    area.setAreaName(rs.getString("area_name"));
                    area.setLevel(rs.getInt("level"));
                    area.setCityCode(rs.getString("city_code"));
                    area.setCenter(rs.getString("center"));
                    area.setParentId(rs.getString("parent_id"));
                    return area;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}
