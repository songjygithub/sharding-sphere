package com.zjb.project.dsp.deviceSmbt.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.math.BigDecimal;

/**
 * 设备扫码补贴表 zjb_device_smbt
 *
 * @author zjb
 * @date 2018-10-14
 */
public class DeviceSmbt extends BaseEntity {
    private static final long serialVersionUID = 1349219453696226167L;

    /**
     * 自增主键
     */
    private Integer id;
    /**
     * 设备id
     */
    private Integer deviceId;
    /**
     * 设备sn
     */
    private String deviceSn;
    /**
     * 符合条件的扫码补贴的所有配置id
     */
    private String smbtIds;
    private String smbtIdslike;//查询用
    /**
     * 符合条件的扫码补贴的所有分成产品id(新版分成配置功能)
     */
    private String benefitProductIds;
    /**
     * 本次补贴总额，单位元
     */
    private BigDecimal smbtAccount;
    /**
     * 本次补贴详情
     */
    private String smbtAccountDetail;
    /**
     * 代理商id
     */
    private Integer agencyId;
    /**
     * 代理商Name
     */
    private String agencyName;
    /**
     * 创建日期 检所用
     */
    private String createDate;
    /**
     * 是否存在子代理商id，1：存在
     */
    private Integer hasAgencysonId;
    /**
     * 子代理商id
     */
    private Integer agencySonId;
    /**
     * 子代理商Name
     */
    private String agencySonName;
    /**
     * 子代理商本次扫码补贴金额
     */
    private BigDecimal agencySonBtAmount;
    /**
     * 开始日期 检所用
     */
    private String startDate;
    /**
     * 结束日期 检所用
     */
    private String endDate;

    private String appType;

    private String agencySource;

    /**
     * 本次分成对应的ZJBPR的流水号SN
     */
    private String zjbprSn;
    /**
     * PR生成时间
     */
    private String bornTimestamp;

    /**
     * 扫码日期 YYYYMMDD
     */
    private Integer smbtDate;

    public String getAgencySource() {
        return agencySource;
    }

    public void setAgencySource(String agencySource) {
        this.agencySource = agencySource;
    }

    /*合伙人ID:当为服务商时,与字段agency_id不相等*/
    private Integer partnerId;

    /**
     * 搜索条件 代理商id
     */
    private Integer agencyIdTmp;

    /**
     * 取纸方式
     */
    private Integer takePaperSource;

    /**
     * 取纸方式(代理商) 100: 免费取纸 200： 小树叶取纸 300：付费取纸
     */
    private Integer takePaperSourceAgency;

    public Integer getAgencyIdTmp() {
        return agencyIdTmp;
    }

    public void setAgencyIdTmp(Integer agencyIdTmp) {
        this.agencyIdTmp = agencyIdTmp;
    }

    public String getAppType() {
        return appType;
    }

    public void setAppType(String appType) {
        this.appType = appType;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public BigDecimal getSmbtAccount() {
        return smbtAccount;
    }

    public void setSmbtAccount(BigDecimal smbtAccount) {
        this.smbtAccount = smbtAccount;
    }

    public String getSmbtAccountDetail() {
        return smbtAccountDetail;
    }

    public void setSmbtAccountDetail(String smbtAccountDetail) {
        this.smbtAccountDetail = smbtAccountDetail;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getCreateDate() {
        return createDate;
    }

    public void setCreateDate(String createDate) {
        this.createDate = createDate;
    }

    public void setSmbtIds(String smbtIds) {
        this.smbtIds = smbtIds;
    }

    public String getSmbtIds() {
        return smbtIds;
    }

    public String getSmbtIdslike() {
        return smbtIdslike;
    }

    public void setSmbtIdslike(String smbtIdslike) {
        this.smbtIdslike = smbtIdslike;
    }

    public String getBenefitProductIds() {
        return benefitProductIds;
    }

    public void setBenefitProductIds(String benefitProductIds) {
        this.benefitProductIds = benefitProductIds;
    }

    public Integer getAgencySonId() {
        return agencySonId;
    }

    public void setAgencySonId(Integer agencySonId) {
        this.agencySonId = agencySonId;
    }

    public Integer getHasAgencysonId() {
        return hasAgencysonId;
    }

    public void setHasAgencysonId(Integer hasAgencysonId) {
        this.hasAgencysonId = hasAgencysonId;
    }

    public String getAgencySonName() {
        return agencySonName;
    }

    public void setAgencySonName(String agencySonName) {
        this.agencySonName = agencySonName;
    }

    public BigDecimal getAgencySonBtAmount() {
        return agencySonBtAmount;
    }

    public void setAgencySonBtAmount(BigDecimal agencySonBtAmount) {
        this.agencySonBtAmount = agencySonBtAmount;
    }

    public Integer getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(Integer partnerId) {
        this.partnerId = partnerId;
    }

    public String getZjbprSn() {
        return zjbprSn;
    }

    public void setZjbprSn(String zjbprSn) {
        this.zjbprSn = zjbprSn;
    }

    public String getBornTimestamp() {
        return bornTimestamp;
    }

    public void setBornTimestamp(String bornTimestamp) {
        this.bornTimestamp = bornTimestamp;
    }

    public Integer getSmbtDate() {
        return smbtDate;
    }

    public void setSmbtDate(Integer smbtDate) {
        this.smbtDate = smbtDate;
    }

    public Integer getTakePaperSource() {
        return takePaperSource;
    }

    public void setTakePaperSource(Integer takePaperSource) {
        this.takePaperSource = takePaperSource;
    }

    public Integer getTakePaperSourceAgency() {
        return takePaperSourceAgency;
    }

    public void setTakePaperSourceAgency(Integer takePaperSourceAgency) {
        this.takePaperSourceAgency = takePaperSourceAgency;
    }
}
