package com.zjb.project.dsp.gzhPushAdInfo.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 关注公众号推送广告表 zjb_gzh_push_ad_info
 *
 * @author shenlong
 * @date 2019-08-24
 */
public class GzhPushAdInfo extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    private Integer id;
    /**
     * 编号
     */
    private String adId;
    /**
     * 广告名称
     */
    private String adName;
    /**
     * 广告描述
     */
    private String adDesc;
    /**
     * 推送消息
     */
    private String adPushMsg;
    /**
     * 外链
     */
    private String adOutUrl;
    /**
     * 内部跳转标识
     */
    private String adInsideUri;
    //跳转类型
    private String adType;
    //微信小程序appid
    private String appid;
    //微信小程序跳转路径
    private String pageIndex;
    /**
     * 状态
     */
    private Integer status;

    public String getAdType() {
        return adType;
    }

    public void setAdType(String adType) {
        this.adType = adType;
    }

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getPageIndex() {
        return pageIndex;
    }

    public void setPageIndex(String pageIndex) {
        this.pageIndex = pageIndex;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    public String getAdName() {
        return adName;
    }

    public void setAdDesc(String adDesc) {
        this.adDesc = adDesc;
    }

    public String getAdDesc() {
        return adDesc;
    }

    public void setAdPushMsg(String adPushMsg) {
        this.adPushMsg = adPushMsg;
    }

    public String getAdPushMsg() {
        return adPushMsg;
    }

    public void setAdOutUrl(String adOutUrl) {
        this.adOutUrl = adOutUrl;
    }

    public String getAdOutUrl() {
        return adOutUrl;
    }

    public void setAdInsideUri(String adInsideUri) {
        this.adInsideUri = adInsideUri;
    }

    public String getAdInsideUri() {
        return adInsideUri;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }
}
