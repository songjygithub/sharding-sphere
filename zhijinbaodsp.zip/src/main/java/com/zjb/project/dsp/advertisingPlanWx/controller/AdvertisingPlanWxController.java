package com.zjb.project.dsp.advertisingPlanWx.controller;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingADExchange.service.IAdExchangeService;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationWx;
import com.zjb.project.dsp.advertisingCombinationWx.service.IAdvertisingCombinationWxService;
import com.zjb.project.dsp.advertisingPlan.controller.AdvertisingPlanController;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import com.zjb.project.system.user.domain.User;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.AdUnit;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_USE_NO;
import static com.zjb.common.enums.ZjbDictionaryEnum.NO;

/**
 * 广告投放计划 信息操作处理
 *
 * @author songjy
 * @date 2019-08-19
 */
@Controller
@RequestMapping("/dsp/advertisingPlanWx")
public class AdvertisingPlanWxController extends BaseController {
    private String prefix = "dsp/advertisingPlanWx";
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IAgencyService agencyService;
    @Autowired
    private IAdvertisingCombinationWxService advertisingCombinationWxService;
    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    private IAdExchangeService adExchangeService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;

    @RequiresPermissions("dsp:advertisingPlanWx:view")
    @GetMapping()
    public String advertisingPlan(ModelMap mmap) {
        AdvertisingCombinationWx advertisingCombination = new AdvertisingCombinationWx();
        List<AdvertisingCombinationWx> advertisingCombinations = advertisingCombinationWxService.selectAdvertisingCombinationWxList(advertisingCombination);
        mmap.put("advertisingCombinations", advertisingCombinations);

        return prefix + "/advertisingPlanWx";
    }

    /**
     * 查询广告投放计划列表
     */
    @RequiresPermissions("dsp:advertisingPlanWx:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingPlanWx advertisingPlan) {

        String searchVal = advertisingPlan.getSearchValue();
        if (StringUtils.isNumeric(searchVal)) {
            advertisingPlan.setId(Integer.parseInt(searchVal));
        }

        startPage();
        List<AdvertisingPlanWx> list = advertisingPlanWxService.selectAdvertisingPlanWxList(advertisingPlan);

        DecimalFormat decimalFormat = new DecimalFormat("0%");
        for (AdvertisingPlanWx e : list) {

            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + e.getPlanId();
            AdvertisingPlanWx planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlanWx.class);
            if (null != planFromRedis) {
                /*今日花费*/
                e.setTodaySpend(planFromRedis.getTodaySpend());
                /*今日胜出次数*/
                e.setTodayWinNum(planFromRedis.getTodayWinNum());
                /*总胜出次数*/
                e.setTotalWinNum(planFromRedis.getTotalWinNum());
                /*总花费*/
                e.setTotalSpend(planFromRedis.getTotalSpend());
                /*竞价胜出次数*/
                e.setBidWinNum(planFromRedis.getBidWinNum());
                /*参与竞价次数*/
                e.setParticipateBidNum(planFromRedis.getParticipateBidNum());
            }

            boolean zero = (null == e.getBidWinNum() || 0 == e.getBidWinNum() || null == e.getParticipateBidNum()
                    || 0 == e.getParticipateBidNum());
            e.setWinRate(zero ? "--" : decimalFormat.format(1F * e.getBidWinNum() / e.getParticipateBidNum()));

            User user = getUser(e.getCreaterId());
            e.setCreateBy(null == user ? null : user.getUserName());

            user = getUser(e.getModifierId());
            e.setUpdateBy(null == user ? null : user.getUserName());

            AdvertisingCombinationWx advertisingCombination = advertisingCombinationWxService.selectAdvertisingCombinationWxById(e.getCombinationId());
            e.setCombinationName(null == advertisingCombination ? null : advertisingCombination.getName());
        }

        return getDataTable(list);
    }

    /**
     * 新增广告投放计划
     */
    @GetMapping("/add")
    public String add(ModelMap map) {

        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /** 过滤掉子代理商 */
        for (Iterator<Agency> iterator = agencyList.iterator(); iterator.hasNext(); ) {
            if (null != iterator.next().getParentAgencyId()) {
                iterator.remove();
            }
        }

        AdvertisingCombinationWx advertisingCombination = new AdvertisingCombinationWx();
        List<AdvertisingCombinationWx> advertisingCombinations = advertisingCombinationWxService.selectAdvertisingCombinationWxList(advertisingCombination);

        map.put("agencyList", agencyList);
        map.put("advertisingCombinations", advertisingCombinations);
        map.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});

        return prefix + "/add";
    }

    /**
     * 新增保存广告投放计划
     */
    @RequiresPermissions("dsp:advertisingPlanWx:add")
    @Log(title = "广告投放计划", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanWx advertisingPlan) {

        AjaxResult ajaxResult = AdvertisingPlanController.check(advertisingPlan);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        AdvertisingPlanController.handleFile(file, advertisingPlan, deviceService);

        User user = getUser();
        advertisingPlan.setCreaterId(user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationWxService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlan.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlan.getRadioWeChatOfficialAccount() || ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlan.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }
        }

        int r = advertisingPlanWxService.insertAdvertisingPlanWx(advertisingPlan);

        advertisingPlanWxService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 修改广告投放计划
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {

        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /** 过滤掉子代理商 */
        for (Iterator<Agency> iterator = agencyList.iterator(); iterator.hasNext(); ) {
            if (null != iterator.next().getParentAgencyId()) {
                iterator.remove();
            }
        }

        AdvertisingPlanWx advertisingPlan = advertisingPlanWxService.selectAdvertisingPlanWxById(id);
        AdvertisingCombinationWx advertisingCombination = new AdvertisingCombinationWx();
        List<AdvertisingCombinationWx> advertisingCombinations = advertisingCombinationWxService.selectAdvertisingCombinationWxList(advertisingCombination);

        if(StringUtils.isNotEmpty(advertisingPlan.getDeviceScene())){
            String deviceSceneIds = deviceInstallSceneService.getSceneIdsByCode(advertisingPlan.getDeviceScene());
            mmap.put("deviceSceneIds",deviceSceneIds);
        }

        mmap.put("deviceSceneSelected", StringUtils.split(advertisingPlan.getDeviceScene(), ','));
        mmap.put("agencyIdSelected", null == advertisingPlan.getAgencyIdArray() ? null : Convert.toIntArray(advertisingPlan.getAgencyIdArray()));
        mmap.put("agencyList", agencyList);
        mmap.put("advertisingCombinations", advertisingCombinations);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
        mmap.put("paperTodayNumSelected", StringUtils.isBlank(advertisingPlan.getPaperTodayNum()) ? null : Convert.toIntArray(advertisingPlan.getPaperTodayNum()));
        return prefix + "/edit";
    }

    /**
     * 边界广告投放计划权重
     */
    @GetMapping("/weight/{id}")
    public String weight(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlanWx advertisingPlan = advertisingPlanWxService.selectAdvertisingPlanWxById(id);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("planWeightArray", new int[]{1, 2, 3, 4, 5});
        return prefix + "/weight";
    }

    /**
     * 边界广告投放计划权重
     */
    @RequiresPermissions("dsp:advertisingPlanWx:weight")
    @Log(title = "广告投放计划权重设置", businessType = BusinessType.UPDATE)
    @PostMapping("/weight")
    @ResponseBody
    public AjaxResult weight(AdvertisingPlanWx advertisingPlan, ModelMap mmap) {

        User user = getUser();
        advertisingPlan.setModifierId(user.getUserId().intValue());
        advertisingPlan.setGmtModified(new Date());
        advertisingPlanWxService.updateAdvertisingPlanWx(advertisingPlan);

        return success();
    }

    /**
     * 广告投放计划手动暂停
     */
    @RequiresPermissions("dsp:advertisingPlanWx:pause")
    @Log(title = "广告投放计划手动暂停", businessType = BusinessType.UPDATE)
    @PostMapping("/pause")
    @ResponseBody
    public AjaxResult pause(String ids) {

        for (String id : StringUtils.split(ids)) {
            AdvertisingPlanWx advertisingPlan = advertisingPlanWxService.selectAdvertisingPlanWxById(Integer.parseInt(id));
            advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlanWxService.updateAdvertisingPlanWx(advertisingPlan);
        }

        return success();
    }

    /**
     * 广告投放计划手动恢复
     */
    @RequiresPermissions("dsp:advertisingPlanWx:resume")
    @Log(title = "广告投放计划手动恢复", businessType = BusinessType.UPDATE)
    @PostMapping("/resume")
    @ResponseBody
    public AjaxResult resume(String ids) {

        for (String id : StringUtils.split(ids)) {
            AdvertisingPlanWx advertisingPlan = advertisingPlanWxService.selectAdvertisingPlanWxById(Integer.parseInt(id));

            if (null == advertisingPlan) {
                return error("广告计划不存在");
            }

            AdCombinationInfo combinationInfo = adExchangeService.advertisingCombination(advertisingPlan);

            if (null == combinationInfo || null == combinationInfo.getScan() || combinationInfo.getScan().isEmpty()) {
                return error("该广告计划定向的广告方案中，扫码取纸广告位为空，请补充后再进行恢复操作。");
            }

            for (AdUnit u : combinationInfo.getScan()) {
                String adId = u.getId().substring(ZjbDictionaryEnum.AD_COMBINATION_UNIT_PREFIX_WX.getValue().toString().length());
                AdvertisingUnitWx advertisingUnit = advertisingUnitWxService.selectAdvertisingUnitWxById(Integer.parseInt(adId));
                if (null == advertisingUnit || null == advertisingUnit.getAdUseStatus() || advertisingUnit.getAdUseStatus().equals(AD_USE_NO.getValue())) {
                    return error("该广告计划对应的扫码取纸广告已停用，如需恢复请先至广告池中将对应扫码取纸广告启用。");
                }
            }

            advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlanWxService.updateAdvertisingPlanWx(advertisingPlan);
            advertisingPlanWxService.reloadPattern(advertisingPlan.getPlanId());

        }

        return success();
    }

    /**
     * 修改保存广告投放计划
     */
    /**
     * @param file
     * @param advertisingPlan
     * @return
     */
    @RequiresPermissions("dsp:advertisingPlanWx:edit")
    @Log(title = "广告投放计划", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanWx advertisingPlan) {

        AdvertisingPlanWx advertisingPlanOld = advertisingPlanWxService.selectAdvertisingPlanWxById(advertisingPlan.getId());

        if (null == advertisingPlanOld) {
            return error("记录不存在");
        }

        AjaxResult ajaxResult = AdvertisingPlanController.check(advertisingPlan);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        AdvertisingPlanController.handleFile(file, advertisingPlan, deviceService);

        User user = getUser();
        advertisingPlan.setModifierId(null == user ? null : user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationWxService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlan.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlan.getRadioWeChatOfficialAccount() || ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlan.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }
            advertisingPlan.setAdAppId(list.get(0).getAppId());
        } else {
            advertisingPlan.setAdAppId(null);
        }

        if (null != advertisingPlan.getOperationType() && advertisingPlan.getOperationType().equals(IAdPlanService.OPERATION_TYPE_UPDATE)) {
            advertisingPlan.setCategoryFinance(null == advertisingPlan.getCategoryFinance() ? NO.getValue() : advertisingPlan.getCategoryFinance());
            advertisingPlan.setWeChatAccount(null == advertisingPlan.getWeChatAccount() ? NO.getValue() : advertisingPlan.getWeChatAccount());
        }

        advertisingPlan.setGmtModified(new Date());
        int r = advertisingPlanWxService.updateAdvertisingPlanWx(advertisingPlan);
        advertisingPlanWxService.mediumSellRuleThreeNotice();
        return toAjax(r);
    }

    /**
     * 删除广告投放计划
     */
    @RequiresPermissions("dsp:advertisingPlanWx:remove")
    @Log(title = "广告投放计划", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingPlanWxService.logicDeleteAdvertisingPlanWxByIds(ids));
    }

    @Log(title = "广告投放计划", businessType = BusinessType.EXPORT)
    @PostMapping("/export/sn")
    @ResponseBody
    public AjaxResult exportDeviceSn(AdvertisingPlanWx advertisingPlan) {

        List<AdvertisingPlan> list = new ArrayList<>();
        ExcelUtil<AdvertisingPlan> util = new ExcelUtil<>(AdvertisingPlan.class);
        /*sheetName必须是：addevice，否则无法直接上传导入分成配置*/
        String sheetName = "addevice";

        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceService.selectAdvertisingPlanDeviceByPlanId(advertisingPlan.getPlanId());

        if (null == advertisingPlanDevice) {
            return util.exportExcel(list, sheetName);
        }

        String[] array = StringUtils.split(advertisingPlanDevice.getDeviceSn(), ',');

        if (null == array || array.length == 0) {
            return util.exportExcel(list, sheetName);
        }

        for (String sn : array) {
            AdvertisingPlan record = new AdvertisingPlan();
            record.setMixId(sn);
            list.add(record);
        }

        return util.exportExcel(list, sheetName);
    }

    /**
     * 文件上传
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return error("文件为空");
        }

        String fileName = FilenameUtils.getName(file.getOriginalFilename());
        String ext = FilenameUtils.getExtension(fileName);
        String md5 = DigestUtils.md5Hex(fileName);
        String fileKey = zjbConfig.getAdPlanDeviceFileUrl() + LocalDate.now()
                + '/' + md5 + '.' + ext;

        try {
            OssUtil.uploadFile(fileKey, file.getInputStream());
            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            logger.warn("文件OSS路径：{}", fileUrl);
            AjaxResult ajaxResult = success();
            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);
            return ajaxResult;
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return error(e.getMessage());
        }
    }
}
