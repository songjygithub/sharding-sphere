package com.zjb.project.dsp.device.service;


import java.util.List;

import com.zjb.project.common.device.domain.DeviceDTO;

/**
 * 设备信息操作处理
 *
 * @author songjy
 * @date 2019-07-27
 */
public interface IDeviceService {
    /**
     * 查询设备信息
     *
     * @param id 主键
     * @return
     */
	DeviceDTO selectDeviceById(Integer id);

    /**
     * 根据sn查询设备信息
     *
     * @param sn 设备sn
     * @return 设备信息
     */
	DeviceDTO selectDeviceBySn(String sn);

    /**
     * 根据设备名称查询设备信息
     *
     * @param deviceName
     * @return
     */
	DeviceDTO selectByDeviceName(String deviceName);

    /**
     * 根据设备二维码查询设备信息
     *
     * @param qrCode
     * @return
     */
	DeviceDTO selectByQrCode(String qrCode);

    /**
     * 根据qrcode查询设备信息
     *
     * @param qrcode 设备码qrcode
     * @return 设备信息
     */
	DeviceDTO selectDeviceByQrcode(String qrcode);


    /**
     * 根据qrcodeb查询设备信息
     *
     * @param qrcodeb 设备码qrcodeb
     * @return 设备信息
     */
	DeviceDTO selectDeviceByQrcodeb(String qrcodeb);

    /**
     * 根据设备唯一标识查询设备信息
     *
     * @param mixId 设备唯一标识，如：id，qrcode，sn
     * @return 设备信息
     */
	DeviceDTO selectDeviceByMixId(String mixId);

    /**
     * 根据代理商id获取设备信息
     * @param agencyId
     * @return
     */
    List<String> selectDeviceSnByAgencyId(Integer agencyId);
}