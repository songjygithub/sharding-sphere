package com.zjb.project.dsp.advertisingPlan.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;
import com.zjb.framework.web.domain.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 广告投放计划表 zjb_advertising_plan
 *
 * @author songjy
 * @date 2019-07-13
 */
public class AdvertisingPlan extends BaseEntity {

    private static final long serialVersionUID = -4848852778563162369L;

    /**
     * 主键,广告计划ID
     */
    private Integer id;
    /**
     * 业务标识自增主键，且必须是01开头，即01 + id
     */
    private String planId;
    /**
     * 广告计划名称
     */
    private String planName;
    /**
     * 广告计划所属广告组(zjb_plan_group),0：通用广告组
     */
    private String planGroup;
    /**
     * 广告方案定向，即表[zjb_advertising_combination]主键ID
     */
    private Integer combinationId;
    /**
     * 出价(元)
     */
    private BigDecimal planBid;
    /**
     * 投放权重
     */
    private Integer planWeight;
    /**
     * 日预算(元)
     */
    private BigDecimal dayBudget;
    /**
     * 总预算(元)
     */
    private BigDecimal totalBudget;
    /**
     * 今日胜出次数
     */
    private Integer todayWinNum;
    /**
     * 今日花费(元)
     */
    private BigDecimal todaySpend;
    /**
     * 总胜出次数
     */
    private Integer totalWinNum;
    /**
     * 总花费(元)
     */
    private BigDecimal totalSpend;
    /**
     * 参与竞价次数
     */
    private Integer participateBidNum;
    /**
     * 竞价胜出次数
     */
    private Integer bidWinNum;
    /**
     * 投放开始时间
     */
    private Date gmtShowStart;
    /**
     * 投放结束时间
     */
    private Date gmtShowEnd;
    /**
     * 投放长期有效(zjb_long_term_effective)，0：否 1：是
     */
    private String longTermEffective;
    /**
     * 投放状态(zjb_advertising_status)，1：投放中(正常投放) 2：手动暂停(手动暂停投放) 3：投放时间截至暂停 4：日预算不足暂停 5：总预算不足暂停
     */
    private String advertisingStatus;
    /**
     * 行业分类(zjb_advertising_category)，0：其它 1：金融
     */
    @Deprecated
    private String category;

    /**
     * 是否第三方平台，0：否 1：是
     */
    private Integer thirdPlatform;

    /**
     * 公众号授权类型（参考字典）
     */
    private Integer componentAuthorizationType;

    /**
     * 单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每个用户每日仅投一次 2：每个用户(openId)仅投一次
     */
    private Integer adSingleUserFrequency;

    /**
     * 参与竞价概率
     */
    private Integer participateBidPercentage;

    /**
     * 广告投放指定设备文件名
     */
    private String adPlanDeviceExcel;

    /**
     * 广告投放指定设备文件路径
     */
    private String adPlanDeviceUrl;

    /**
     * 广告投放投放计划关联的微信公众号（订阅号）
     */
    private String adAppId;

    /**
     * 广告收益单价(元)
     */
    private BigDecimal unitPrice;

    /**
     * 微信个人号编号
     */
    private String weChatPersonalId;

    /**
     * QQ个人号编号
     */
    private String qqPersonalId;

    /**
     * 广告计划胜出间隔频率（秒）
     */
    private Long winFrequency;

    /**========以下非数据库映射字段========*/

    /**
     * 广告计划最近胜出时间戳（毫秒）
     */
    private Long recentWinTimestamp;

    /**
     * 是否金融行业，0：否 1：是
     */
    private Integer categoryFinance;

    /**
     * 是否公众号，0：否 1：是
     */
    private Integer weChatAccount;

    /**
     * 是否个人号，0：否 1：是
     */
    private Integer personalAccount;

    /**
     * 广告方案定向名称
     */
    private String combinationName;
    /**
     * 胜出率
     */
    private String winRate;

    /**
     * 设备定向ID主键，即表【zjb_advertising_plan_device】的主键ID
     */
    private Integer planDeviceId;

    /**
     * 设备SN定向，0：不限 1：指定设备 2：不投设备
     */
    private Integer radioDeviceSn;

    /**
     * 投放指定设备SN，多个之间用;分隔
     */
    private String deviceSn;

    /**
     * 设备安装面向人群(zjb_face_sex) 0：男 1：女 2：综合
     */
    private Integer deviceFaceSex;

    /**
     * 指定投放设备安装地址编码,多个之间用,分隔，如：330000,330482,...
     */
    private String deviceInstallCode;
    /**
     * 指定投放设备安装地址,多个之间用,分隔，如：北京市北京城区东城区,江苏省无锡市惠山区
     */
    private String deviceInstallZone;

    /**
     * 0:不限 1:指定安装场景 2:不投安装场景
     */
    Integer radioDeviceScene;

    /**
     * 指定投放设备安装场合code 参考 字典 安装场合 SCENE，多个之间用,分隔
     */
    private String deviceScene;

    /**
     * 代理商定向，0:不限 1:指定代理商 2:不投代理商
     */
    Integer radioAgencyId;

    /**
     * 指定投放代理商ID集合，多个之间用,分隔
     */
    private String agencyIdArray;

    /**
     * 人群定向信息主键ID，即表【zjb_advertising_plan_pepole】的主键ID
     */
    private Integer pepolePlanId;

    /**
     * 广告投放总取纸上限次数
     */
    private Integer paperUpperNum;
    /**
     * 广告投放总取纸下限次数
     */
    private Integer paperLowerNum;

    /**
     * 广告投放当日取纸次数，多个之间用,分隔
     */
    private String paperTodayNum;

    /**
     * 广告投放当日取纸下限次数
     */
    private Integer paperTodayLowerNum;

    /**
     * 广告投放当日取纸上限次数
     */
    private Integer paperTodayUpperNum;

    /**
     * 面向人群(zjb_face_sex) 0：男 1：女 2：综合
     */
    private Integer pepoleSex;

    /**
     * 指定投放年龄
     */
    private Integer age;

    /**
     * 广告投放平台类型(zjb_platform_type)，如：1:Android 2:IOS, 9:其它
     */
    private Integer platformType;
    /**
     * 广告投放扫码环境(zjb_scan_tool)，1:微信 2:支付宝 9：其它
     */
    private Integer scanTool;
    /**
     * 广告投放网络类型(zjb_network_type)，1：WIFI 2：4G 3：3G 4：2G 9：其它
     */
    private Integer networkType;
    /**
     * 广告投放运营商(zjb_operator_type)，1：移动 2：联通 3：电信 9：其它
     */
    private Integer operatorType;
    /**
     * 广告投放黑名单用户(zjb_black_user_enable)，0：不限 1：不投 2：只投
     */
    private Integer blackUserEnable;

    /**
     * 公众号定向，0：不限 1：仅投从未关注过的用户 2：可投已关注且已取关用户
     */
    private Integer radioWeChatOfficialAccount;

    /**
     * 公众号，多个之间用英文逗号分隔
     */
    private String weChatOfficialAccounts;

    /**
     * 设备SN
     * 设备ID
     * 设备qrcode
     */
    @Excel(name = "mixId")
    private String mixId;

    /**
     * 域名地址
     */
    private String domainAddress;

    /**
     * 指定设备(qrcode)小树叶广告落地页跳转路径
     */
    private String loc;

    /**
     * 用户扫码流水号
     */
    private String randomNum;

    /**
     * 设备id，非数据库映射字段
     */
    private Integer deviceId;

    /**
     * 设备安装场景Id 非数据库字段
     */
    private String installSceneIds;

    /**
     * 用户位置,多个之间用,分隔，省和市之间用_隔开，如：北京市_北京城区,江苏省_无锡市
     */
    private String userZone;

    private Integer operationType;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getPlanId() {
        return planId;
    }

    public void setPlanId(String planId) {
        this.planId = planId;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanGroup(String planGroup) {
        this.planGroup = planGroup;
    }

    public String getPlanGroup() {
        return planGroup;
    }

    public void setCombinationId(Integer combinationId) {
        this.combinationId = combinationId;
    }

    public Integer getCombinationId() {
        return combinationId;
    }

    public void setPlanBid(BigDecimal planBid) {
        this.planBid = planBid;
    }

    public BigDecimal getPlanBid() {
        return planBid;
    }

    public void setPlanWeight(Integer planWeight) {
        this.planWeight = planWeight;
    }

    public Integer getPlanWeight() {
        return planWeight;
    }

    public void setDayBudget(BigDecimal dayBudget) {
        this.dayBudget = dayBudget;
    }

    public BigDecimal getDayBudget() {
        return dayBudget;
    }

    public void setTotalBudget(BigDecimal totalBudget) {
        this.totalBudget = totalBudget;
    }

    public BigDecimal getTotalBudget() {
        return totalBudget;
    }

    public void setTodayWinNum(Integer todayWinNum) {
        this.todayWinNum = todayWinNum;
    }

    public Integer getTodayWinNum() {
        return todayWinNum;
    }

    public void setTodaySpend(BigDecimal todaySpend) {
        this.todaySpend = todaySpend;
    }

    public BigDecimal getTodaySpend() {
        return todaySpend;
    }

    public void setTotalWinNum(Integer totalWinNum) {
        this.totalWinNum = totalWinNum;
    }

    public Integer getTotalWinNum() {
        return totalWinNum;
    }

    public void setTotalSpend(BigDecimal totalSpend) {
        this.totalSpend = totalSpend;
    }

    public BigDecimal getTotalSpend() {
        return totalSpend;
    }

    public void setParticipateBidNum(Integer participateBidNum) {
        this.participateBidNum = participateBidNum;
    }

    public Integer getParticipateBidNum() {
        return participateBidNum;
    }

    public void setBidWinNum(Integer bidWinNum) {
        this.bidWinNum = bidWinNum;
    }

    public Integer getBidWinNum() {
        return bidWinNum;
    }

    public void setGmtShowStart(Date gmtShowStart) {
        this.gmtShowStart = gmtShowStart;
    }

    public Date getGmtShowStart() {
        return gmtShowStart;
    }

    public void setGmtShowEnd(Date gmtShowEnd) {
        this.gmtShowEnd = gmtShowEnd;
    }

    public Date getGmtShowEnd() {
        return gmtShowEnd;
    }

    public void setLongTermEffective(String longTermEffective) {
        this.longTermEffective = longTermEffective;
    }

    public String getLongTermEffective() {
        return longTermEffective;
    }

    public void setAdvertisingStatus(String advertisingStatus) {
        this.advertisingStatus = advertisingStatus;
    }

    public String getAdvertisingStatus() {
        return advertisingStatus;
    }

    @Deprecated
    public void setCategory(String category) {
        this.category = category;
    }

    @Deprecated
    public String getCategory() {
        return category;
    }

    public Integer getCategoryFinance() {
        return categoryFinance;
    }

    public void setCategoryFinance(Integer categoryFinance) {
        this.categoryFinance = categoryFinance;
    }

    public Integer getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccount(Integer weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public Integer getThirdPlatform() {
        return thirdPlatform;
    }

    public void setThirdPlatform(Integer thirdPlatform) {
        this.thirdPlatform = thirdPlatform;
    }

    public Integer getComponentAuthorizationType() {
        return componentAuthorizationType;
    }

    public void setComponentAuthorizationType(Integer componentAuthorizationType) {
        this.componentAuthorizationType = componentAuthorizationType;
    }

    public Integer getAdSingleUserFrequency() {
        return adSingleUserFrequency;
    }

    public void setAdSingleUserFrequency(Integer adSingleUserFrequency) {
        this.adSingleUserFrequency = adSingleUserFrequency;
    }

    public Integer getParticipateBidPercentage() {
        return participateBidPercentage;
    }

    public void setParticipateBidPercentage(Integer participateBidPercentage) {
        this.participateBidPercentage = participateBidPercentage;
    }

    public String getAdPlanDeviceExcel() {
        return adPlanDeviceExcel;
    }

    public void setAdPlanDeviceExcel(String adPlanDeviceExcel) {
        this.adPlanDeviceExcel = adPlanDeviceExcel;
    }

    public String getAdPlanDeviceUrl() {
        return adPlanDeviceUrl;
    }

    public void setAdPlanDeviceUrl(String adPlanDeviceUrl) {
        this.adPlanDeviceUrl = adPlanDeviceUrl;
    }

    public String getCombinationName() {
        return combinationName;
    }

    public void setCombinationName(String combinationName) {
        this.combinationName = combinationName;
    }

    public String getWinRate() {
        return winRate;
    }

    public void setWinRate(String winRate) {
        this.winRate = winRate;
    }


    public Integer getPlanDeviceId() {
        return planDeviceId;
    }

    public void setPlanDeviceId(Integer planDeviceId) {
        this.planDeviceId = planDeviceId;
    }

    public Integer getRadioDeviceSn() {
        return radioDeviceSn;
    }

    public void setRadioDeviceSn(Integer radioDeviceSn) {
        this.radioDeviceSn = radioDeviceSn;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public Integer getDeviceFaceSex() {
        return deviceFaceSex;
    }

    public void setDeviceFaceSex(Integer deviceFaceSex) {
        this.deviceFaceSex = deviceFaceSex;
    }

    public String getDeviceInstallCode() {
        return deviceInstallCode;
    }

    public void setDeviceInstallCode(String deviceInstallCode) {
        this.deviceInstallCode = deviceInstallCode;
    }

    public String getDeviceInstallZone() {
        return deviceInstallZone;
    }

    public void setDeviceInstallZone(String deviceInstallZone) {
        this.deviceInstallZone = deviceInstallZone;
    }

    public Integer getRadioDeviceScene() {
        return radioDeviceScene;
    }

    public void setRadioDeviceScene(Integer radioDeviceScene) {
        this.radioDeviceScene = radioDeviceScene;
    }

    public String getDeviceScene() {
        return deviceScene;
    }

    public void setDeviceScene(String deviceScene) {
        this.deviceScene = deviceScene;
    }

    public Integer getRadioAgencyId() {
        return radioAgencyId;
    }

    public void setRadioAgencyId(Integer radioAgencyId) {
        this.radioAgencyId = radioAgencyId;
    }

    public String getAgencyIdArray() {
        return agencyIdArray;
    }

    public void setAgencyIdArray(String agencyIdArray) {
        this.agencyIdArray = agencyIdArray;
    }

    public Integer getPepolePlanId() {
        return pepolePlanId;
    }

    public void setPepolePlanId(Integer pepolePlanId) {
        this.pepolePlanId = pepolePlanId;
    }

    public Integer getPaperUpperNum() {
        return paperUpperNum;
    }

    public void setPaperUpperNum(Integer paperUpperNum) {
        this.paperUpperNum = paperUpperNum;
    }

    public Integer getPaperLowerNum() {
        return paperLowerNum;
    }

    public void setPaperLowerNum(Integer paperLowerNum) {
        this.paperLowerNum = paperLowerNum;
    }

    public String getPaperTodayNum() {
        return paperTodayNum;
    }

    public void setPaperTodayNum(String paperTodayNum) {
        this.paperTodayNum = paperTodayNum;
    }

    public Integer getPaperTodayLowerNum() {
        return paperTodayLowerNum;
    }

    public void setPaperTodayLowerNum(Integer paperTodayLowerNum) {
        this.paperTodayLowerNum = paperTodayLowerNum;
    }

    public Integer getPaperTodayUpperNum() {
        return paperTodayUpperNum;
    }

    public void setPaperTodayUpperNum(Integer paperTodayUpperNum) {
        this.paperTodayUpperNum = paperTodayUpperNum;
    }

    public Integer getPepoleSex() {
        return pepoleSex;
    }

    public void setPepoleSex(Integer pepoleSex) {
        this.pepoleSex = pepoleSex;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getPlatformType() {
        return platformType;
    }

    public void setPlatformType(Integer platformType) {
        this.platformType = platformType;
    }

    public Integer getScanTool() {
        return scanTool;
    }

    public void setScanTool(Integer scanTool) {
        this.scanTool = scanTool;
    }

    public Integer getNetworkType() {
        return networkType;
    }

    public void setNetworkType(Integer networkType) {
        this.networkType = networkType;
    }

    public Integer getOperatorType() {
        return operatorType;
    }

    public void setOperatorType(Integer operatorType) {
        this.operatorType = operatorType;
    }

    public Integer getBlackUserEnable() {
        return blackUserEnable;
    }

    public void setBlackUserEnable(Integer blackUserEnable) {
        this.blackUserEnable = blackUserEnable;
    }

    public String getMixId() {
        return mixId;
    }

    public void setMixId(String mixId) {
        this.mixId = mixId;
    }

    public String getDomainAddress() {
        return domainAddress;
    }

    public void setDomainAddress(String domainAddress) {
        this.domainAddress = domainAddress;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public Integer getRadioWeChatOfficialAccount() {
        return radioWeChatOfficialAccount;
    }

    public void setRadioWeChatOfficialAccount(Integer radioWeChatOfficialAccount) {
        this.radioWeChatOfficialAccount = radioWeChatOfficialAccount;
    }

    public String getWeChatOfficialAccounts() {
        return weChatOfficialAccounts;
    }

    public void setWeChatOfficialAccounts(String weChatOfficialAccounts) {
        this.weChatOfficialAccounts = weChatOfficialAccounts;
    }

    public String getAdAppId() {
        return adAppId;
    }

    public void setAdAppId(String adAppId) {
        this.adAppId = adAppId;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getInstallSceneIds() {
        return installSceneIds;
    }

    public void setInstallSceneIds(String installSceneIds) {
        this.installSceneIds = installSceneIds;
    }

    public String getWeChatPersonalId() {
        return weChatPersonalId;
    }

    public void setWeChatPersonalId(String weChatPersonalId) {
        this.weChatPersonalId = weChatPersonalId;
    }

    public Long getWinFrequency() {
        return winFrequency;
    }

    public void setWinFrequency(Long winFrequency) {
        this.winFrequency = winFrequency;
    }

    public Long getRecentWinTimestamp() {
        return recentWinTimestamp;
    }

    public void setRecentWinTimestamp(Long recentWinTimestamp) {
        this.recentWinTimestamp = recentWinTimestamp;
    }

    public String getQqPersonalId() {
        return qqPersonalId;
    }

    public void setQqPersonalId(String qqPersonalId) {
        this.qqPersonalId = qqPersonalId;
    }

    public String getUserZone() {
        return userZone;
    }

    public void setUserZone(String userZone) {
        this.userZone = userZone;
    }

    public Integer getPersonalAccount() {
        return personalAccount;
    }

    public void setPersonalAccount(Integer personalAccount) {
        this.personalAccount = personalAccount;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }
}
