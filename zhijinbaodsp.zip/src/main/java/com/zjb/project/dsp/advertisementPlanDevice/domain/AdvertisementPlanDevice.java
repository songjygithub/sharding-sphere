package com.zjb.project.dsp.advertisementPlanDevice.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;

import java.util.List;

/**
 * 非竞价广告投放设备定向表 zjb_advertisement_plan_device
 * 
 * @author Nigel Yang
 * @date 2020-05-09
 */
public class AdvertisementPlanDevice extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 主键 */
	private Integer id;
	/** 广告池id,即表【zjb_advertising_unit_fans】主键id */
	private Integer advertisingUnitId;
	private List<Integer> advertisingUnitIdList;
	/** 非竞价广告投放计划主键，即表[zjb_advertisement_without_bidding_price]的主键[id] */
	private String advertisementPlanId;
	/** 设备SN定向，0：不限 1：指定设备 2：不投设备 */
	private Integer radioDeviceSn;
	/** 投放指定设备SN，多个之间用,分隔 */
	private String deviceSn;
	/** 正则表达式 */
	private String regex;
	/** 广告投放指定设备文件名 */
	private String adPlanDeviceExcel;
	/** 广告投放指定设备文件路径 */
	private String adPlanDeviceUrl;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setAdvertisingUnitId(Integer advertisingUnitId) 
	{
		this.advertisingUnitId = advertisingUnitId;
	}

	public List<Integer> getAdvertisingUnitIdList() {
		return advertisingUnitIdList;
	}

	public void setAdvertisingUnitIdList(List<Integer> advertisingUnitIdList) {
		this.advertisingUnitIdList = advertisingUnitIdList;
	}

	public Integer getAdvertisingUnitId()
	{
		return advertisingUnitId;
	}
	public void setAdvertisementPlanId(String advertisementPlanId) 
	{
		this.advertisementPlanId = advertisementPlanId;
	}

	public String getAdvertisementPlanId() 
	{
		return advertisementPlanId;
	}
	public void setRadioDeviceSn(Integer radioDeviceSn) 
	{
		this.radioDeviceSn = radioDeviceSn;
	}

	public Integer getRadioDeviceSn() 
	{
		return radioDeviceSn;
	}
	public void setDeviceSn(String deviceSn) 
	{
		this.deviceSn = deviceSn;
	}

	public String getDeviceSn() 
	{
		return deviceSn;
	}
	public void setRegex(String regex) 
	{
		this.regex = regex;
	}

	public String getRegex() 
	{
		return regex;
	}
	public void setAdPlanDeviceExcel(String adPlanDeviceExcel) 
	{
		this.adPlanDeviceExcel = adPlanDeviceExcel;
	}

	public String getAdPlanDeviceExcel() 
	{
		return adPlanDeviceExcel;
	}
	public void setAdPlanDeviceUrl(String adPlanDeviceUrl) 
	{
		this.adPlanDeviceUrl = adPlanDeviceUrl;
	}

	public String getAdPlanDeviceUrl() 
	{
		return adPlanDeviceUrl;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("advertisingUnitId", getAdvertisingUnitId())
            .append("advertisementPlanId", getAdvertisementPlanId())
            .append("radioDeviceSn", getRadioDeviceSn())
            .append("deviceSn", getDeviceSn())
            .append("regex", getRegex())
            .append("adPlanDeviceExcel", getAdPlanDeviceExcel())
            .append("adPlanDeviceUrl", getAdPlanDeviceUrl())
            .toString();
    }
}
