package com.zjb.project.dsp.advertisingCombinationUnitFans.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisingCombinationUnitFans.mapper.AdvertisingCombinationUnitFansMapper;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingCombinationUnitFans.service.IAdvertisingCombinationUnitFansService;
import com.zjb.common.support.Convert;

/**
 * 广告方案/广告池 中间 服务层实现
 * 
 * @author shenlong
 * @date 2019-11-26
 */
@Service
public class AdvertisingCombinationUnitFansServiceImpl implements IAdvertisingCombinationUnitFansService 
{
	@Autowired
	private AdvertisingCombinationUnitFansMapper advertisingCombinationUnitFansMapper;

	/**
     * 查询广告方案/广告池 中间信息
     * 
     * @param id 广告方案/广告池 中间ID
     * @return 广告方案/广告池 中间信息
     */
    @Override
	public AdvertisingCombinationUnitFans selectAdvertisingCombinationUnitFansById(Integer id)
	{
	    return advertisingCombinationUnitFansMapper.selectAdvertisingCombinationUnitFansById(id);
	}
	
	/**
     * 查询广告方案/广告池 中间列表
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 广告方案/广告池 中间集合
     */
	@Override
	public List<AdvertisingCombinationUnitFans> selectAdvertisingCombinationUnitFansList(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{
	    return advertisingCombinationUnitFansMapper.selectAdvertisingCombinationUnitFansList(advertisingCombinationUnitFans);
	}
	
    /**
     * 新增广告方案/广告池 中间
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 结果
     */
	@Override
	public int insertAdvertisingCombinationUnitFans(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{
	    return advertisingCombinationUnitFansMapper.insertAdvertisingCombinationUnitFans(advertisingCombinationUnitFans);
	}
	
	/**
     * 修改广告方案/广告池 中间
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 结果
     */
	@Override
	public int updateAdvertisingCombinationUnitFans(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{
	    return advertisingCombinationUnitFansMapper.updateAdvertisingCombinationUnitFans(advertisingCombinationUnitFans);
	}

	/**
     * 删除广告方案/广告池 中间对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisingCombinationUnitFansByIds(String ids)
	{
		return advertisingCombinationUnitFansMapper.deleteAdvertisingCombinationUnitFansByIds(Convert.toStrArray(ids));
	}
	
}
