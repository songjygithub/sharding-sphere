package com.zjb.project.dsp.advertisingCombinationFans.mapper;

import java.util.List;

import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;

/**
 * 粉丝通广告方案 数据层
 * 
 * @author shenlong
 * @date 2019-11-22
 */
public interface AdvertisingCombinationFansMapper 
{
	/**
     * 查询粉丝通广告方案信息
     * 
     * @param id 粉丝通广告方案ID
     * @return 粉丝通广告方案信息
     */
	public AdvertisingCombinationFans selectAdvertisingCombinationFansById(Integer id);
	
	/**
     * 查询粉丝通广告方案列表
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 粉丝通广告方案集合
     */
	public List<AdvertisingCombinationFans> selectAdvertisingCombinationFansList(AdvertisingCombinationFans advertisingCombinationFans);

	/**
     * 查询粉丝通广告方案列表
     *
     * @param advertisingCombinationUnitFans 粉丝通广告方案信息
     * @return 粉丝通广告方案集合
     */
	public List<AdvertisingCombinationUnitFans> selectAdvertisingCombinationUnitFansList(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);

	
	/**
     * 新增粉丝通广告方案
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
	public int insertAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans);
	
	/**
     * 修改粉丝通广告方案
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
	public int updateAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans);
	
	/**
     * 删除粉丝通广告方案
     * 
     * @param id 粉丝通广告方案ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationFansById(Integer id);
	
	/**
     * 批量删除粉丝通广告方案
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationFansByIds(String[] ids);

	/**
	 *
	 *删除广告方案中的广告
	 *
	 * @param adUnitId 广告池id集
	 * @return 结果
	 */
	int deleteAdvertisingCombinationUnitFansByUnitId(String[] adUnitId);

	int modifyDetails(AdvertisingCombinationUnitFans advertisingCombinationUnitFans) ;

	/**
	 * 过广告单元ID查询所有记录
	 * @param id
	 * @return
	 */
	List<AdvertisingCombinationUnitFans> selectByUnitId(Integer id);
}