package com.zjb.project.dsp.advertisingPlanFans.service;

import java.io.Serializable;
import java.util.List;

import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;

/**
 * 粉丝通广告投放计划 服务层
 *
 * @author shenlong
 * @date 2019-11-22
 */
public interface IAdvertisingPlanFansService extends IAdPlanService {
    /**
     * 查询粉丝通广告投放计划信息
     *
     * @param id 粉丝通广告投放计划ID
     * @return 粉丝通广告投放计划信息
     */
    AdvertisingPlanFans selectAdvertisingPlanFansById(Serializable id);

    /**
     * 查询粉丝通广告投放计划列表
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 粉丝通广告投放计划集合
     */
    List<AdvertisingPlanFans> selectAdvertisingPlanFansList(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 新增粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    public int insertAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 修改粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    int updateAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans);

    /**
     * 删除粉丝通广告投放计划信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteAdvertisingPlanFansByIds(String ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param ids
     * @return
     */
    int logicDeleteAdvertisingPlanPayByIds(String ids);

    /**
     * 根据公众号查询广告投放计划
     *
     * @param appId
     * @return
     */
    List<AdvertisingPlanFans> selectByAdAppId(String appId);

    /**
     * 根据广告池单元ID查询关联的广告投放计划
     *
     * @param unitId
     * @return
     */
    List<AdvertisingPlanFans> selectByUnitId(Integer unitId);
}
