package com.zjb.project.dsp.advertisingCombinationWx.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationUnitWx;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationWx;
import com.zjb.project.dsp.advertisingCombinationWx.mapper.AdvertisingCombinationWxMapper;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.mapper.AdvertisingUnitWxMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.mapper.ScanTaskMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 广告方案-微信 服务层实现
 *
 * @author ZH
 * @date 2019-08-13
 */
@Service
public class AdvertisingCombinationWxServiceImpl implements IAdvertisingCombinationWxService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AdvertisingCombinationWxMapper advertisingCombinationWxMapper;
    @Autowired
    private AdvertisingUnitWxMapper advertisingUnitWxMapper;
    @Autowired
    private ScanTaskMapper scanTaskMapper;
    @Autowired
    private GzhGroupMapper gzhGroupMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;

    /**
     * 查询广告方案信息
     *
     * @param id 广告方案ID
     * @return 广告方案信息
     */
    @Override
    public AdvertisingCombinationWx selectAdvertisingCombinationWxById(Integer id) {
        return advertisingCombinationWxMapper.selectAdvertisingCombinationWxById(id);
    }

    /**
     * 查询广告方案列表
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 广告方案集合
     */
    @Override
    public List<AdvertisingCombinationWx> selectAdvertisingCombinationWxList(AdvertisingCombinationWx advertisingCombinationWx) {
        return advertisingCombinationWxMapper.selectAdvertisingCombinationWxList(advertisingCombinationWx);
    }

    /**
     * 新增广告方案
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingCombinationWx(AdvertisingCombinationWx advertisingCombinationWx) {
        int result = advertisingCombinationWxMapper.insertAdvertisingCombinationWx(advertisingCombinationWx);
        if (result > 0) {
            advertisingCombinationWx.setComId(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue().toString() + advertisingCombinationWx.getId());
            result += advertisingCombinationWxMapper.updateAdvertisingCombinationWx(advertisingCombinationWx);
        }
        return result;
    }

    /**
     * 修改广告方案
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingCombinationWx(AdvertisingCombinationWx advertisingCombinationWx) {
        return advertisingCombinationWxMapper.updateAdvertisingCombinationWx(advertisingCombinationWx);
    }

    /**
     * 删除广告方案对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationWxByIds(String ids) {
        return advertisingCombinationWxMapper.deleteAdvertisingCombinationWxByIds(Convert.toStrArray(ids));
    }

    /**
     * 查询广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情信息
     * @return 广告方案详情集合
     */
    @Override
    public List<AdvertisingCombinationUnitWx> selectAdvertisingCombinationUnitWxList(AdvertisingCombinationUnitWx advertisingCombinationUnitWx) {
        return advertisingCombinationWxMapper.selectAdvertisingCombinationUnitWxList(advertisingCombinationUnitWx);
    }

    /**
     * 新增广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingCombinationUnitWx(AdvertisingCombinationUnitWx advertisingCombinationUnitWx) {

        removeOldOutPaper(advertisingCombinationUnitWx);

        return advertisingCombinationWxMapper.insertAdvertisingCombinationUnitWx(advertisingCombinationUnitWx);
    }

    /**
     * 扫码取纸位在一个方案中只能出现一次，即需要删除旧的扫码取纸位
     *
     * @param combinationUnitWx
     */
    private void removeOldOutPaper(AdvertisingCombinationUnitWx combinationUnitWx) {
        if (null == combinationUnitWx
                || null == combinationUnitWx.getCombinationId()
                || null == combinationUnitWx.getAdUnitId()) {
            return;
        }

        AdvertisingUnitWx unitWx = advertisingUnitWxMapper.selectAdvertisingUnitWxById(combinationUnitWx.getAdUnitId());

        if (null == unitWx
                || null == unitWx.getAdSpaceIdentifier()
                || !unitWx.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT_WX.getValue())) {
            return;
        }

        AdvertisingCombinationUnitWx query = new AdvertisingCombinationUnitWx();
        query.setCombinationId(combinationUnitWx.getCombinationId());
        List<AdvertisingCombinationUnitWx> list = advertisingCombinationWxMapper.selectAdvertisingCombinationUnitWxList(query);

        if (null == list || list.isEmpty()) {
            return;
        }

        List<AdvertisingCombinationUnitWx> unitWxList = list.stream()
                .filter(e -> e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT_WX.getValue()))
                .collect(Collectors.toList());

        if (null == unitWxList || unitWxList.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitWx wx : unitWxList) {
            advertisingCombinationWxMapper.deleteByCombinationIdAndAdUnitId(wx);
            logger.info("方案【{}】移除旧的扫码广告位【{}:{}】成功", wx.getCombinationId(), wx.getAdUnitId(), wx.getAdName());
        }
    }

    /**
     * 修改广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情
     * @return 结果
     */
    @Override
    public int modifyDetailsWx(AdvertisingCombinationUnitWx advertisingCombinationUnitWx) {
        return advertisingCombinationWxMapper.modifyDetailsWx(advertisingCombinationUnitWx);
    }

    /**
     * 删除广告方案详情
     *
     * @param ids 需删除的数据id
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitWxByIds(String ids) {
        return advertisingCombinationWxMapper.deleteAdvertisingCombinationUnitWxByIds(Convert.toStrArray(ids));
    }

    /**
     * 删除广告方案详情
     *
     * @param combinationId 广告方案id集
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitWxByCombinationId(String combinationId) {
        return advertisingCombinationWxMapper.deleteAdvertisingCombinationUnitWxByCombinationId(Convert.toStrArray(combinationId));
    }

    /**
     * 删除广告方案详情
     *
     * @param adUnitId 广告池id集
     * @return 结果
     */
    @Override
    public int deleteAdvertisingCombinationUnitWxByUnitId(String adUnitId) {
        return advertisingCombinationWxMapper.deleteAdvertisingCombinationUnitWxByUnitId(Convert.toStrArray(adUnitId));
    }

    @Override
    public List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer combinationId) {
        AdvertisingCombinationUnitWx combinationUnit = new AdvertisingCombinationUnitWx();
        combinationUnit.setCombinationId(combinationId);
        List<AdvertisingCombinationUnitWx> list = advertisingCombinationWxMapper.selectAdvertisingCombinationUnitWxList(combinationUnit);
        if (null == list || list.isEmpty()) {
            return Collections.emptyList();
        }

        List<ComponentAuthorizationInfo> all = new ArrayList<>();

        for (AdvertisingCombinationUnitWx advertisingCombinationUnit : list) {
            AdvertisingUnitWx advertisingUnit = advertisingUnitWxMapper.selectAdvertisingUnitWxById(advertisingCombinationUnit.getAdUnitId());

            if (null != advertisingUnit
                    && AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                    && AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())
                    && StringUtils.isNotBlank(advertisingUnit.getWeChatAccount())
                    && advertisingUnit.getWeChatAccount().startsWith(AD_ZJB_OPEN_PLATFORM_PREFIX.getValue())) {
                ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(advertisingUnit.getWeChatAccount());

                if (null != componentAuthorizationInfo) {
                    all.add(componentAuthorizationInfo);
                }

                continue;
            }

            if (null == advertisingUnit
                    || !ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                    || !ZjbDictionaryEnum.AD_REDIRECT_TASK.getValue().equals(advertisingUnit.getRedirectUrlType())
                    || !StringUtils.isNumeric(advertisingUnit.getAppId())) {
                continue;
            }

            ScanTask scanTask = scanTaskMapper.selectScanTaskById(Integer.parseInt(advertisingUnit.getAppId()));

            if (null == scanTask || !StringUtils.isNumeric(scanTask.getExpansionA())) {
                continue;
            }

            GzhGroup gzhGroup = gzhGroupMapper.selectGzhGroupById(Integer.parseInt(scanTask.getExpansionA()));

            if (null == gzhGroup || StringUtils.isBlank(gzhGroup.getGzhList())) {
                continue;
            }

            String[] arr = StringUtils.split(gzhGroup.getGzhList(), ',');

            for (String str : arr) {
                ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(Integer.parseInt(str));

                if (null != componentAuthorizationInfo) {
                    all.add(componentAuthorizationInfo);
                }
            }
        }

        return all;
    }

    @Override
    public List<AdvertisingCombinationUnitWx> selectByUnitId(Integer unitId) {
        return advertisingCombinationWxMapper.selectByUnitId(unitId);
    }
}
