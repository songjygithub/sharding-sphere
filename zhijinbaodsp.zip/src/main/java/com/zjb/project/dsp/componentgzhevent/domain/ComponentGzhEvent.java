package com.zjb.project.dsp.componentgzhevent.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 第三方平台授权公众号关注用户数表 zjb_component_gzh_event
 *
 * @author zjb
 * @date 2019-07-30
 */
public class ComponentGzhEvent extends BaseEntity {
    private static final long serialVersionUID = 7689165177449190196L;

    /**
     * 自增主键
     */
    private Integer id;
    /**
     * 公众号appid
     */
    private String appid;
    /**
     * 公众号openid
     */
    private String openid;
    /**
     * 纸巾宝公众号openid
     */
    private String zjbOpenid;
    /**
     * 事件
     */
    private String event;

    /**
     * 日期  检索用
     */
    private String date;

    /**
     * 关注数
     */
    private Integer subscribeCount;
    /**
     * 取关数
     */
    private Integer unSubscribeCount;
    /**
     * 当日取关数
     */
    private Integer SamedayUnSubscribeCount;

    /**
     * 统计数字，辅助字段
     */
    private Integer count;

    /**
     * 创建时间 年月日
     */
    private Date gmtDate;

    /**
     * 设备二维码
     */
    private String qrCode;

    /**
     * 设备名称
     */
    private String deviceName;

    /**
     * 设备SN
     */
    private String deviceSn;

    /**
     * 代理商ID
     */
    private Integer agencyId;

    /**
     * 代理商名称
     */
    private String agencyName;

    public Integer getSubscribeCount() {
        return subscribeCount;
    }

    public void setSubscribeCount(Integer subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public Integer getUnSubscribeCount() {
        return unSubscribeCount;
    }

    public void setUnSubscribeCount(Integer unSubscribeCount) {
        this.unSubscribeCount = unSubscribeCount;
    }

    public Integer getSamedayUnSubscribeCount() {
        return SamedayUnSubscribeCount;
    }

    public void setSamedayUnSubscribeCount(Integer samedayUnSubscribeCount) {
        SamedayUnSubscribeCount = samedayUnSubscribeCount;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getAppid() {
        return appid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getOpenid() {
        return openid;
    }

    public void setZjbOpenid(String zjbOpenid) {
        this.zjbOpenid = zjbOpenid;
    }

    public String getZjbOpenid() {
        return zjbOpenid;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getEvent() {
        return event;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Date getGmtDate() {
        return gmtDate;
    }

    public void setGmtDate(Date gmtDate) {
        this.gmtDate = gmtDate;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }
}
