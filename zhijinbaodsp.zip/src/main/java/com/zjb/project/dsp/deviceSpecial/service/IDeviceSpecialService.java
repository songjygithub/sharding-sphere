package com.zjb.project.dsp.deviceSpecial.service;

import com.zjb.project.dsp.deviceSpecial.domain.DeviceSpecial;

import static com.zjb.common.enums.ZjbDictionaryEnum.SPECIAL_ZFB_NOPAY;

/**
 * 查询该设备是否屏蔽付费取纸
 * @author zhanghuan
 */

public interface IDeviceSpecialService {
    /**
     * 查询该设备微信端是否屏蔽付费取纸
     * */
    int countByWx(String deviceSn);

    /**
     * 查询该设备支付宝端是否屏蔽付费取纸
     * */
    int countByZfb(String deviceSn);

    /**
     *  查询设备屏蔽付费取纸信息
     * @param deviceSn
     * @param specialType
     * @return
     */
    DeviceSpecial selectDeviceSpecialInfoBySn(String deviceSn,Integer specialType,Integer outPaperType);
}
