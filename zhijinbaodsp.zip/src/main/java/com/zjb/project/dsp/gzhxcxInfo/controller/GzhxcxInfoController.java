package com.zjb.project.dsp.gzhxcxInfo.controller;


import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;
import com.zjb.project.dsp.gzhxcxInfo.service.IGzhxcxInfoService;
import com.zjb.project.system.user.domain.User;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 公众号小程序 信息操作处理
 * 
 * @author zjb
 * @date 2018-09-14
 */
@Controller
@RequestMapping("/zjb/gzhxcxInfo")
public class GzhxcxInfoController extends BaseController
{
    private String prefix = "zjb/gzhxcxInfo";
	
	@Autowired
	private IGzhxcxInfoService gzhxcxInfoService;
	
	@RequiresPermissions("zjb:gzhxcxInfo:view")
	@GetMapping()
	public String gzhxcxInfo()
	{
	    return prefix + "/gzhxcxInfo";
	}
	
	/**
	 * 查询公众号小程序列表
	 */
	@RequiresPermissions("zjb:gzhxcxInfo:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(GzhxcxInfo gzhxcxInfo)
	{
		startPage();
        List<GzhxcxInfo> list = gzhxcxInfoService.selectGzhxcxInfoList(gzhxcxInfo);
		for (GzhxcxInfo gzhxcx: list) {

			if (gzhxcx.getCreaterId() != null){
				User user = getUser(gzhxcx.getCreaterId());
				if (user != null){
					gzhxcx.setCreateBy(user.getUserName());
				}
			}
			//修改人员
			if (gzhxcx.getModifierId() != null){
				User user = getUser(gzhxcx.getModifierId());
				if (user != null){
					gzhxcx.setUpdateBy(user.getUserName());
				}
			}

		}
		return getDataTable(list);
	}
	
	/**
	 * 新增公众号小程序
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存公众号小程序
	 */
	@RequiresPermissions("zjb:gzhxcxInfo:add")
	@Log(title = "公众号小程序", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(GzhxcxInfo gzhxcxInfo)
	{		
		gzhxcxInfo.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
		return toAjax(gzhxcxInfoService.insertGzhxcxInfo(gzhxcxInfo));
	}

	/**
	 * 修改公众号小程序
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		GzhxcxInfo gzhxcxInfo = gzhxcxInfoService.selectGzhxcxInfoById(id);
		mmap.put("gzhxcxInfo", gzhxcxInfo);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存公众号小程序
	 */
	@RequiresPermissions("zjb:gzhxcxInfo:edit")
	@Log(title = "公众号小程序", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(GzhxcxInfo gzhxcxInfo)
	{
		gzhxcxInfo.setUpdateBaseParams(getUserId().intValue());
		return toAjax(gzhxcxInfoService.updateGzhxcxInfo(gzhxcxInfo));
	}
	
	/**
	 * 删除公众号小程序
	 */
	@RequiresPermissions("zjb:gzhxcxInfo:remove")
	@Log(title = "公众号小程序", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(gzhxcxInfoService.deleteGzhxcxInfoByIds(ids));
	}
	
}
