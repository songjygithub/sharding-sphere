package com.zjb.project.dsp.advertisingPlanDevice.controller;

import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 广告投放设备定向 信息操作处理
 *
 * @author songjy
 * @date 2019-07-12
 */
@Controller
@RequestMapping("/zjb/advertisingPlanDevice")
public class AdvertisingPlanDeviceController extends BaseController {
    private String prefix = "zjb/advertisingPlanDevice";

    @Autowired
    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;

    @RequiresPermissions("zjb:advertisingPlanDevice:view")
    @GetMapping()
    public String advertisingPlanDevice() {
        return prefix + "/advertisingPlanDevice";
    }

    /**
     * 查询广告投放设备定向列表
     */
    @RequiresPermissions("zjb:advertisingPlanDevice:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingPlanDevice advertisingPlanDevice) {
        startPage();
        List<AdvertisingPlanDevice> list = advertisingPlanDeviceService.selectAdvertisingPlanDeviceList(advertisingPlanDevice);
        return getDataTable(list);
    }

    /**
     * 新增广告投放设备定向
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告投放设备定向
     */
    @RequiresPermissions("zjb:advertisingPlanDevice:add")
    @Log(title = "广告投放设备定向", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingPlanDevice advertisingPlanDevice) {
        return toAjax(advertisingPlanDeviceService.insertAdvertisingPlanDevice(advertisingPlanDevice));
    }

    /**
     * 修改广告投放设备定向
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceService.selectAdvertisingPlanDeviceById(id);
        mmap.put("advertisingPlanDevice", advertisingPlanDevice);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告投放设备定向
     */
    @RequiresPermissions("zjb:advertisingPlanDevice:edit")
    @Log(title = "广告投放设备定向", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingPlanDevice advertisingPlanDevice) {
        return toAjax(advertisingPlanDeviceService.updateAdvertisingPlanDevice(advertisingPlanDevice));
    }

    /**
     * 删除广告投放设备定向
     */
    @RequiresPermissions("zjb:advertisingPlanDevice:remove")
    @Log(title = "广告投放设备定向", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingPlanDeviceService.deleteAdvertisingPlanDeviceByIds(ids));
    }

    /**
     * 设备定向正则对应的预编译类(Pattern
     *
     * @return
     */
    @GetMapping("/deviceRegexMapPattern")
    @ResponseBody
    public Map<String, Pattern> deviceRegexMapPattern() {
        return advertisingPlanDeviceService.deviceRegexMapPattern();
    }
}
