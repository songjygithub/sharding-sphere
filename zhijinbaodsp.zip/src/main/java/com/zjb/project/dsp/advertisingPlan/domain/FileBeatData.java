package com.zjb.project.dsp.advertisingPlan.domain;

import java.io.Serializable;
import java.util.List;

/**
 * @author songjy
 * @date 2019/10/08
 */
public class FileBeatData implements Serializable {
    private static final long serialVersionUID = 2324953400873444847L;

    private Host host;
    private String message;
    private Log log;

    public Host getHost() {
        return host;
    }

    public void setHost(Host host) {
        this.host = host;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Log getLog() {
        return log;
    }

    public void setLog(Log log) {
        this.log = log;
    }

    public static class Host implements Serializable {
		
		private static final long serialVersionUID = 624176589077597476L;
		
		private List<String> ip;

        public List<String> getIp() {
            return ip;
        }

        public void setIp(List<String> ip) {
            this.ip = ip;
        }
    }

    public static class Log implements Serializable {
        private static final long serialVersionUID = 8700520863755918934L;

        /**
         * 文件信息
         */
        private File file;

        public File getFile() {
            return file;
        }

        public void setFile(File file) {
            this.file = file;
        }

        public static class File implements Serializable {
            private static final long serialVersionUID = 4778443679176548416L;
            /**
             * 文件路径
             */
            private String path;

            public String getPath() {
                return path;
            }

            public void setPath(String path) {
                this.path = path;
            }
        }
    }
}
