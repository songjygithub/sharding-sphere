package com.zjb.project.dsp.autorizeCompanyThirdPlatform.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
												import java.util.Date;

/**
 * 授权公司第三方平台表 zjb_autorize_company_third_platform
 * 
 * @author jiangbingjie
 * @date 2020-03-05
 */
public class AutorizeCompanyThirdPlatform extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 主键 */
	private Integer id;
	/** 授权公司主体ID */
	private Integer companyId;
	/** 授权公司主体名称 */
	private String companyName;
	/** 开放平台APPID */
	private String appId;
	/** 开放平台密钥 */
	private String appSecret;
	/** 开放平台名称 */
	private String appName;
	/** 授权域名 */
	private String domainName;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setCompanyId(Integer companyId) 
	{
		this.companyId = companyId;
	}

	public Integer getCompanyId() 
	{
		return companyId;
	}
	public void setCompanyName(String companyName) 
	{
		this.companyName = companyName;
	}

	public String getCompanyName() 
	{
		return companyName;
	}
	public void setAppId(String appId) 
	{
		this.appId = appId;
	}

	public String getAppId() 
	{
		return appId;
	}
	public void setAppSecret(String appSecret) 
	{
		this.appSecret = appSecret;
	}

	public String getAppSecret() 
	{
		return appSecret;
	}
	public void setAppName(String appName) 
	{
		this.appName = appName;
	}

	public String getAppName() 
	{
		return appName;
	}
	public void setDomainName(String domainName) 
	{
		this.domainName = domainName;
	}

	public String getDomainName() 
	{
		return domainName;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("companyId", getCompanyId())
            .append("companyName", getCompanyName())
            .append("appId", getAppId())
            .append("appSecret", getAppSecret())
            .append("appName", getAppName())
            .append("domainName", getDomainName())
            .append("createrId", getCreaterId())
            .append("modifierId", getModifierId())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("deleted", getDeleted())
            .toString();
    }
}
