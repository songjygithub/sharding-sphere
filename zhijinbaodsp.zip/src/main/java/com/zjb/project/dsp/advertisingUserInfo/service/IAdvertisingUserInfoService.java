package com.zjb.project.dsp.advertisingUserInfo.service;

import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingUserInfo.domain.*;
import com.zjb.project.dsp.rpcrequest.domain.RpcRequest;
import com.zjb.project.dsp.vipidList.domain.UserVipOpenInfo;
import com.zjb.project.dsp.vipidList.domain.VipidList;
import com.zjb.project.dsp.zjbprresponse.domain.ZjbPrResponse;

import java.util.List;

/**
 * @author songjy
 * @date 2019/08/08
 */
public interface IAdvertisingUserInfoService extends IMgBaseService<AdvertisingUserInfo> {
    /**
     * 主键之属性字段名
     */
    String PRIMARY_KEY_OPEN_ID = "openId";

    /**
     * 手机号码
     */
    String PRIMARY_KEY_PHONE = "phone";
    /**
     * 用户UserId
     */
    String PRIMARY_KEY_USER_ID = "userId";

    /**
     * 根据用户微信|支付宝唯一标识查询记录
     *
     * @param openId
     */
    AdvertisingUserInfo findByOpenId(String openId);

    /**
     * 根据手机号码查询记录
     *
     * @param phone 手机号码
     */
    AdvertisingUserInfo findByPhone(String phone);

    /**
     * 根据用户userId查询记录
     *
     * @param userId
     */
    List<AdvertisingUserInfo> findByUserId(Integer userId);

    /**
     * 用户总取纸次数递增，$ZJBPR命令上报且出纸顺利完成时调用
     *
     * @param advertisingUserInfo
     */
    void totalPaperNumIncrement(AdvertisingUserInfo advertisingUserInfo);

    /**
     * 更新当天广告投放至用户记录,$ZJBPL命令下发时调用
     *
     * @param advertisingUserInfo
     */
    void updateAdvertisingDayRecord(AdvertisingUserInfo advertisingUserInfo);

    /**
     * 清空用户当天查看广告记录，次日凌晨调用
     */
    void clearAdvertisingDayRecord();

    /**
     * 清空用户当天取纸次数，次日凌晨调用
     */
    void clearTodayPaperNum();

    /**
     * 根据用户openId查出用户信息
     */
    AdvertisingUserInfo getUserInfo(String openId);

    /**
     * 获取环保等级和成就信息
     *
     * @param advertisingUserInfo
     * @return
     */
    AdvertisingUserInfo getUserLevelsInfo(AdvertisingUserInfo advertisingUserInfo);

    /**
     * 根据用户openId查出用户成就信息
     *
     * @param openId 用户微信ID|用户支付宝ID
     * @return
     */
    List<PersonalAchievement> getPersonalAchievement(String openId);

    /**
     * 完善头像信息和用户昵称
     *
     * @param openId
     * @param advertisingUserInfo
     */
    void setHeadImgAndUserNick(String openId, AdvertisingUserInfo advertisingUserInfo);

    byte[] generatorBindQrCode(String openId);

    /**
     * 微信绑定支付宝
     *
     * @param weChatAndAlipayOpenId
     * @return
     */
    Boolean weChatBindAlipay(WeChatAndAlipayOpenId weChatAndAlipayOpenId);

    /**
     * 根据取纸次数获取对应的问题列表
     *
     * @param totalPaperNum
     * @return
     */
    List<UseQuestion> getQuestions(Integer totalPaperNum);

    /**
     * 根据用户openId查出用户首页弹窗记录
     */
    PopupRecord getUserPopupRecord(String openId);

    /**
     * 更新用户弹窗记录
     *
     * @param popupRecord
     * @return
     */
    void setUserPopupRecord(PopupRecord popupRecord);

    VipidList getVipId();

    /**
     * 添加小树叶数量
     *
     * @param userInfo
     */
    AdvertisingUserInfo addAmountObtainedLeaf(AdvertisingUserInfo userInfo);

    /**
     * 获取用户当前需要弹窗的信息
     * 1.从弹窗记录中获取用户的以往弹窗记录
     * 2.按优先级与用户的当前各信息比较，若需要弹窗显示set进实例化对象中并返回
     * 3.若没有需要弹窗的信息则不做任何操作
     *
     * @param userInfo
     */
    void getPopupInfo(AdvertisingUserInfo userInfo);

    /**
     * 完善用户信息
     * 1置个人资料完善进度
     * 2完善头像信息和用户昵称
     * 3新手使用时获取首页展示问题
     * 4获取弹框内容
     *
     * @param userInfo 用户基础信息
     */
    void completeUserInfo(AdvertisingUserInfo userInfo);

    /**
     * 判断是否关注给定的公众号
     *
     * @param userVipOpenInfo
     * @return
     */
    boolean followSubscriptionCheck(UserVipOpenInfo userVipOpenInfo);

    /**
     * 极速取值扣减小树叶，即增加已消费的小树叶数量
     *
     * @param adUserInfo
     */
    void speedPicking(AdvertisingUserInfo adUserInfo);

    /**
     * 取纸失败，恢复扣减的小树叶数量
     *
     * @param userInfo
     */
    void speedPickingRecover(AdvertisingUserInfo userInfo);

    /**
     * $ZJBPR上报处理
     *
     * @param pr
     */
    void handleZJBPR(ZjbPrResponse pr);


    /**
     * 从OTS中通过唯一事件流水号查询记录
     *
     * @param eventSerialNum 事件流水号，如：yyyy-MM-dd + '_'+ $ZJBPL + '_' + deviceName + '_' + 出纸流水号
     * @return
     */
    RpcRequest findByEventSerialNumFromOTS(String eventSerialNum);

    /**
     * 微信个人号添加记录更新
     *
     * @param userInfo
     * @param plan
     */
    void updateWeChatPersonalGroup(AdvertisingUserInfo userInfo, AdvertisingPlan plan);

    /**
     * QQ个人号添加记录更新
     *
     * @param userInfo
     * @param plan
     */
    void updateQqPersonalGroup(AdvertisingUserInfo userInfo, AdvertisingPlan plan);

    /**
     * @param id 主键
     * @return 扫码用户信息
     */
    AdvertisingUserInfo findById(String id);

    /**
     * 删除扫码用户信息
     *
     * @param ids
     * @return 条数
     */
    int deleteAdvertisingUserInfoByIds(String ids);

    /**
     * 查询扫码用户信息列表
     *
     * @param advertisingUserInfo
     * @return 扫码用户信息列表
     */
    List<AdvertisingUserInfo> selectAdvertisingUserInfoList(AdvertisingUserInfo advertisingUserInfo);
}
