package com.zjb.project.dsp.advertisingCombinationUnitFans.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingCombinationUnitFans.service.IAdvertisingCombinationUnitFansService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 广告方案/广告池 中间 信息操作处理
 * 
 * @author shenlong
 * @date 2019-11-26
 */
@Controller
@RequestMapping("/dsp/advertisingCombinationUnitFans")
public class AdvertisingCombinationUnitFansController extends BaseController
{
    private String prefix = "dsp/advertisingCombinationUnitFans";
	
	@Autowired
	private IAdvertisingCombinationUnitFansService advertisingCombinationUnitFansService;
	
	@RequiresPermissions("dsp:advertisingCombinationUnitFans:view")
	@GetMapping()
	public String advertisingCombinationUnitFans()
	{
	    return prefix + "/advertisingCombinationUnitFans";
	}
	
	/**
	 * 查询广告方案/广告池 中间列表
	 */
	@RequiresPermissions("dsp:advertisingCombinationUnitFans:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{
		startPage();
        List<AdvertisingCombinationUnitFans> list = advertisingCombinationUnitFansService.selectAdvertisingCombinationUnitFansList(advertisingCombinationUnitFans);
		return getDataTable(list);
	}
	
	/**
	 * 新增广告方案/广告池 中间
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存广告方案/广告池 中间
	 */
	@RequiresPermissions("dsp:advertisingCombinationUnitFans:add")
	@Log(title = "广告方案/广告池 中间", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{		
		return toAjax(advertisingCombinationUnitFansService.insertAdvertisingCombinationUnitFans(advertisingCombinationUnitFans));
	}

	/**
	 * 修改广告方案/广告池 中间
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AdvertisingCombinationUnitFans advertisingCombinationUnitFans = advertisingCombinationUnitFansService.selectAdvertisingCombinationUnitFansById(id);
		mmap.put("advertisingCombinationUnitFans", advertisingCombinationUnitFans);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存广告方案/广告池 中间
	 */
	@RequiresPermissions("dsp:advertisingCombinationUnitFans:edit")
	@Log(title = "广告方案/广告池 中间", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AdvertisingCombinationUnitFans advertisingCombinationUnitFans)
	{		
		return toAjax(advertisingCombinationUnitFansService.updateAdvertisingCombinationUnitFans(advertisingCombinationUnitFans));
	}
	
	/**
	 * 删除广告方案/广告池 中间
	 */
	@RequiresPermissions("dsp:advertisingCombinationUnitFans:remove")
	@Log(title = "广告方案/广告池 中间", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertisingCombinationUnitFansService.deleteAdvertisingCombinationUnitFansByIds(ids));
	}
	
}
