package com.zjb.project.dsp.gzhGroup.service;


import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;

import java.util.List;

/**
 * 公众号组 服务层
 * 
 * @author zjb
 * @date 2019-07-12
 */
public interface IGzhGroupService 
{
	/**
     * 查询公众号组信息
     * 
     * @param id 公众号组ID
     * @return 公众号组信息
     */
	public GzhGroup selectGzhGroupById(Integer id);

	/**
	 * 查询公众号组信息
	 *
	 * @param groupId 公众号组编号
	 * @return 公众号组信息
	 */
	public GzhGroup selectGzhGroupByGroupId(String groupId);
	/**
     * 查询公众号组列表
     * 
     * @param gzhGroup 公众号组信息
     * @return 公众号组集合
     */
	public List<GzhGroup> selectGzhGroupList(GzhGroup gzhGroup);

	/**
	 * 查询公众号组列表
	 *
	 * @param id 公众号组id
	 * @return 公众号组集合
	 */
	public List<GzhxcxInfo> selectGzhByGroupId(Integer id);

	/**
     * 新增公众号组
     * 
     * @param gzhGroup 公众号组信息
     * @return 结果
     */
	public int insertGzhGroup(GzhGroup gzhGroup);
	
	/**
     * 修改公众号组
     * 
     * @param gzhGroup 公众号组信息
     * @return 结果
     */
	public int updateGzhGroup(GzhGroup gzhGroup);
		
	/**
     * 删除公众号组信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhGroupByIds(String ids);
	
}
