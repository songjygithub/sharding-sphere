package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;

/**
 * @author ：guoj
 * @date ：Created in 2019/10/24 17:12
 * @description： 微信用户信息
 */

public class UserInfo implements Serializable {

    /**
     * 自增主键
     */
    private Integer id;

    /**
     * 纸巾包用户openId
     */
    private String zjbOpenId;
    /**
     * 公众号名称
     */
    @Excel(name = "公众号名称")
    private String gzhName;
    /**
     * 关注渠道 场景标识
     * */
    @Excel(name = "来源渠道")
    private String sceneStr;
    /**
     * 用户openid
     */
    @Excel(name = "openId")
    private String openid;
    /**
     * 用户昵称
     */
    @Excel(name = "用户昵称")
    private String nickName;
    /**
     * 性别 0:未知,1:男,2:女
     */
    @Excel(name = "性别")
    private Integer sex;
    /**
     * 头像地址
     */
    @Excel(name = "头像地址")
    private String headImgUrl;
    /**
     * 国家
     */
    @Excel(name = "国家")
    private String country;
    /**
     * 省份
     */
    @Excel(name = "省份")
    private String province;
    /**
     * 城市
     */
    @Excel(name = "城市")
    private String city;
    /**
     * 关注时间
     */
    @Excel(name = "关注时间")
    private String gmtDate;

    public String getGmtDate() {
        return gmtDate;
    }

    public void setGmtDate(String gmtDate) {
        this.gmtDate = gmtDate;
    }

    public String getGzhName() {
        return gzhName;
    }

    public void setGzhName(String gzhName) {
        this.gzhName = gzhName;
    }

    public String getSceneStr() {
        return sceneStr;
    }

    public void setSceneStr(String sceneStr) {
        this.sceneStr = sceneStr;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getZjbOpenId() {
        return zjbOpenId;
    }

    public void setZjbOpenId(String zjbOpenId) {
        this.zjbOpenId = zjbOpenId;
    }

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
}
