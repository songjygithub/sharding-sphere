package com.zjb.project.dsp.deviceSpecial.service;

import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_DAY;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.deviceSpecial.domain.DeviceSpecial;

/**
 * 查询该设备是否屏蔽付费取纸
 * @author zhanghuan
 */
@Service
public class DeviceSpecialServiceImpl implements IDeviceSpecialService{
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    /**
     * 查询该设备微信端是否屏蔽付费取纸
     *
     * @param deviceSn
     */
    @Override
    public int countByWx(String deviceSn) {
        if (StringUtils.isNotEmpty(deviceSn)) {
            String sql = "SELECT COUNT(id) FROM zjb_device_special WHERE device_sn = ? and special_type = 1 and deleted = 0";
            return jdbcTemplate.queryForObject(sql, new Object[]{deviceSn}, Integer.class);
        }
        return 0;
    }

    /**
     * 查询该设备支付宝端是否屏蔽付费取纸
     *
     * @param deviceSn
     */
    @Override
    public int countByZfb(String deviceSn) {
        if (StringUtils.isNotEmpty(deviceSn)) {
            String sql = "SELECT COUNT(id) FROM zjb_device_special WHERE device_sn = ? and special_type = 2 and deleted = 0";
            return jdbcTemplate.queryForObject(sql, new Object[]{deviceSn}, Integer.class);
        }
        return 0;
    }

    /**
     * 查询设备屏蔽付费取纸信息
     * @param deviceSn
     * @param specialType
     * @return
     */
    @Override
    public DeviceSpecial selectDeviceSpecialInfoBySn(String deviceSn, Integer specialType,Integer outPaperType) {
        if(StringUtils.isEmpty(deviceSn) || null == specialType || null == outPaperType){
            return null;
        }
        String key = ZjbConstantsRedis.REDIS_DEVICE_SPECIAL_INFO + '_' + deviceSn+ '_'+specialType+'_'+outPaperType;
        DeviceSpecial deviceSpecial = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceSpecial.class);

        if (null != deviceSpecial) {
            return deviceSpecial;
        }


        String sql = "SELECT * FROM `zjb_device_special` WHERE `device_sn` = ? AND special_type = ? AND special_out_paper_type = ? AND deleted = 0 LIMIT 1";
        int[] argTypes = {Types.VARCHAR, Types.INTEGER,Types.INTEGER};
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{deviceSn, specialType,outPaperType}, argTypes, new RowMapper<DeviceSpecial>() {
                @Override
                public DeviceSpecial mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DeviceSpecial deviceSpecial = new DeviceSpecial();
                    deviceSpecial.setId(rs.getInt("id"));
                    deviceSpecial.setDeviceId(null != rs.getObject("device_id") ? rs.getInt("device_id") : null);
                    deviceSpecial.setDeviceSn(rs.getString("device_sn"));
                    deviceSpecial.setAgencyId(null != rs.getObject("agency_id") ? rs.getInt("agency_id") : null);
                    deviceSpecial.setAgencyName(rs.getString("agency_name"));
                    deviceSpecial.setSpecialType(null != rs.getObject("special_type") ? rs.getInt("special_type") : null);
                    deviceSpecial.setEffectiveTime(null != rs.getObject("effective_time") ? rs.getTimestamp("effective_time") : null);
                    deviceSpecial.setLoseEfficacyTime(null != rs.getObject("lose_efficacy_time") ? rs.getTimestamp("lose_efficacy_time") : null);
                    deviceSpecial.setDeviceSpecialStatus(null != rs.getObject("device_special_status") ? rs.getInt("device_special_status") : null);
                    deviceSpecial.setRemark(rs.getString("remark"));
                    if(deviceSpecial != null){
                        JedisPoolCacheUtils.setVExpire(key, deviceSpecial, EXRP_DAY, ZjbConstantsRedis.ZJB_DB_4);
                    }
                    return deviceSpecial;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * 查询单条记录
     *
     * @param sql
     * @return
     */
    private DeviceSpecial selectSingleDeviceSpecial(String sql,String deviceSn,Integer specialType) {
        Object[] args = {deviceSn, specialType};
        int[] argTypes = {Types.VARCHAR, Types.INTEGER};
        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<DeviceSpecial>() {
                @Override
                public DeviceSpecial mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DeviceSpecial deviceSpecial = new DeviceSpecial();
                    deviceSpecial.setId(rs.getInt("id"));
                    deviceSpecial.setDeviceId(null != rs.getObject("device_id") ? rs.getInt("device_id") : null);
                    deviceSpecial.setDeviceSn(rs.getString("device_sn"));
                    deviceSpecial.setAgencyId(null != rs.getObject("agency_id") ? rs.getInt("agency_id") : null);
                    deviceSpecial.setAgencyName(rs.getString("agency_name"));
                    deviceSpecial.setSpecialType(null != rs.getObject("special_type") ? rs.getInt("special_type") : null);
                    deviceSpecial.setEffectiveTime(null != rs.getObject("effective_time") ? rs.getDate("effective_time") : null);
                    deviceSpecial.setLoseEfficacyTime(null != rs.getObject("lose_efficacy_time") ? rs.getDate("lose_efficacy_time") : null);
                    deviceSpecial.setDeviceSpecialStatus(null != rs.getObject("device_special_status") ? rs.getInt("device_special_status") : null);
                    deviceSpecial.setRemark(rs.getString("remark"));
                    return deviceSpecial;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}
