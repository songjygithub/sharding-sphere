package com.zjb.project.dsp.advertisingCombinationWx.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.PerformanceSensitive;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.service.DictService;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.service.IAdvertisingCombinationService;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationUnitWx;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationWx;
import com.zjb.project.dsp.advertisingCombinationWx.service.IAdvertisingCombinationWxService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.service.IAdvertisingUnitWxService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;

/**
 * 广告方案-微信 信息操作处理
 *
 * @author ZH
 * @date 2019-08-13
 */
@Controller
@RequestMapping("/dsp/advertisingCombinationWx")
public class AdvertisingCombinationWxController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "zjb/advertisingCombinationWx";

    @Autowired
    private IAdvertisingCombinationWxService advertisingCombinationWxService;
    @Autowired
    private DictService dataService;
    @Autowired
    private IAdvertisingUnitWxService advertisingUnitWxService;
    @Autowired
    private IAdvertisingPlanWxService advertisingPlanWxService;

    @RequiresPermissions("dsp:advertisingCombinationWx:view")
    @GetMapping()
    public String advertisingCombinationWx() {
        return prefix + "/advertisingCombinationWx";
    }

    /**
     * 查询广告方案列表
     */
    @RequiresPermissions("dsp:advertisingCombinationWx:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingCombinationWx advertisingCombinationWx) {
        startPage();
        List<AdvertisingCombinationWx> list = advertisingCombinationWxService.selectAdvertisingCombinationWxList(advertisingCombinationWx);
        return getDataTable(list);
    }

    /**
     * 新增广告方案
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationWx:add")
    @Log(title = "广告方案", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingCombinationWx advertisingCombinationWx) {
        advertisingCombinationWx.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        return toAjax(advertisingCombinationWxService.insertAdvertisingCombinationWx(advertisingCombinationWx));
    }

    /**
     * 修改广告方案
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingCombinationWx advertisingCombinationWx = advertisingCombinationWxService.selectAdvertisingCombinationWxById(id);
        mmap.put("advertisingCombinationWx", advertisingCombinationWx);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationWx:edit")
    @Log(title = "广告方案", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingCombinationWx advertisingCombinationWx) {
        advertisingCombinationWx.setUpdateBaseParams(getUserId().intValue());
        return toAjax(advertisingCombinationWxService.updateAdvertisingCombinationWx(advertisingCombinationWx));
    }

    /**
     * 删除广告方案
     */
    @RequiresPermissions("dsp:advertisingCombinationWx:remove")
    @Log(title = "广告方案", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        int result = advertisingCombinationWxService.deleteAdvertisingCombinationWxByIds(ids);
        result += advertisingCombinationWxService.deleteAdvertisingCombinationUnitWxByCombinationId(ids);
        return toAjax(result);
    }


    /**
     * 详情页面
     */
    @PerformanceSensitive("dsp:advertisingCombinationWx:getDetails")
    @GetMapping("/getDetails")
    public String getDetails() {
        return prefix + "/getDetailsNew";
    }

    /**
     * 广告方案详情
     */
    @PerformanceSensitive("dsp:advertisingCombinationWx:combinationDetails")
    @PostMapping("/combinationDetails/{combinationId}")
    @ResponseBody
    public AjaxResult getCombinationDetails(@PathVariable("combinationId") Integer combinationId) {
        Map<String, Object> map = new HashMap<>();
        AdvertisingCombinationWx advertisingCombinationWx = advertisingCombinationWxService.selectAdvertisingCombinationWxById(combinationId);
        if (null != advertisingCombinationWx) {
            if (null != advertisingCombinationWx.getProgramType()) {
                String combinationTypeName = dataService.getLabel(ZjbDictionaryTypeEnum.PROGRAM_TYPE.getType(), advertisingCombinationWx.getProgramType().toString());//广告方案名称
                advertisingCombinationWx.setProgramTypeName(combinationTypeName);//广告方案类型
            }
            map.put("adDombinationWx", advertisingCombinationWx);//广告方案
            AdvertisingCombinationUnitWx advertisingCombinationUnitWx = new AdvertisingCombinationUnitWx();
            advertisingCombinationUnitWx.setCombinationId(combinationId);//广告方案id
            List<AdvertisingCombinationUnitWx> advertisingCombinationUnitWxs = advertisingCombinationWxService.selectAdvertisingCombinationUnitWxList(advertisingCombinationUnitWx);
            Map<String, List<AdvertisingCombinationUnitWx>> adSpeaceMap = new HashMap<>();


            for (AdvertisingCombinationUnitWx advertisingCombinationUnitWx_db : advertisingCombinationUnitWxs) {
                List<AdvertisingCombinationUnitWx> advertisingCombinationUnitWxList = new ArrayList<>();
                if ("0501".equals(advertisingCombinationUnitWx_db.getAdSpaceIdentifier())) {
                    if (null != adSpeaceMap.get("0501")) {
                        advertisingCombinationUnitWxList = adSpeaceMap.get("0501");
                    }
                    advertisingCombinationUnitWxList.add(advertisingCombinationUnitWx_db);
                    adSpeaceMap.put("0501", advertisingCombinationUnitWxList);
                    map.put("lunbo", adSpeaceMap.get("0501"));
                } else if ("0502".equals(advertisingCombinationUnitWx_db.getAdSpaceIdentifier())) {
                    if (null != adSpeaceMap.get("0502")) {
                        advertisingCombinationUnitWxList = adSpeaceMap.get("0502");
                    }
                    advertisingCombinationUnitWxList.add(advertisingCombinationUnitWx_db);
                    adSpeaceMap.put("0502", advertisingCombinationUnitWxList);
                    map.put("shouye", adSpeaceMap.get("0502"));
                } else if ("0503".equals(advertisingCombinationUnitWx_db.getAdSpaceIdentifier())) {
                    map.put("saoma", advertisingCombinationUnitWx_db);
                }
            }
            if (null == map.get("lunbo")) {
                map.put("lunbo", "");
            }
            if (null == map.get("shouye")) {
                map.put("shouye", "");
            }
            if (null == map.get("saoma")) {
                map.put("saoma", "");
            }
        }
        return success(map);
    }

    /**
     * 添加广告方案详情,拉取广告
     * */
	/*@GetMapping("/addDection/{combinationId}")
	public String addDection(@PathVariable("combinationId") Integer combinationId,ModelMap modelMap){
		modelMap.put("combinationId",combinationId);
		return prefix + "/addDection";
	}*/

    /**
     * 广告列表
     */
    @PostMapping("/getAdList")
    @ResponseBody
    public AjaxResult getAdList(AdvertisingUnitWx advertisingUnitWx) {
        advertisingUnitWx.setAdUseStatus(ZjbDictionaryEnum.AD_USE_YES.getValue());//启用状态
        //advertisingUnit.setAdUseType(1);//使用标识
        List<AdvertisingUnitWx> advertisingUnitWxs = advertisingUnitWxService.selectAdvertisingUnitWxList(advertisingUnitWx);
        return success(advertisingUnitWxs);
    }

    /**
     * 添加广告方案详情
     */
    @PerformanceSensitive("dsp:advertisingCombinationWx:addDection")
    @PostMapping("/addDection")
    @ResponseBody
    public AjaxResult addDection(AdvertisingCombinationUnitWx advertisingCombinationUnitWx) {
        advertisingCombinationUnitWx.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        return toAjax(advertisingCombinationWxService.insertAdvertisingCombinationUnitWx(advertisingCombinationUnitWx));
    }

    /**
     * 删除广告方案详情
     */
    @RequiresPermissions("dsp:advertisingCombinationWx:delDection")
    @Log(title = "广告方案详情", businessType = BusinessType.DELETE)
    @PostMapping("/delDection")
    @ResponseBody
    public AjaxResult delDection(String ids) {
        return toAjax(advertisingCombinationWxService.deleteAdvertisingCombinationUnitWxByIds(ids));
    }

    /**
     * 更换广告方案详情
     */
    @PostMapping("/modifyDection")
    @ResponseBody
    public AjaxResult modifyDetailsWx(AdvertisingCombinationUnitWx advertisingCombinationUnitWx) {

        int r = advertisingCombinationWxService.modifyDetailsWx(advertisingCombinationUnitWx);

        restartAdvertisingPlan(advertisingCombinationUnitWx);

        advertisingPlanWxService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param advertisingCombinationUnit
     */
    private void restartAdvertisingPlan(AdvertisingCombinationUnitWx advertisingCombinationUnit) {
        List<AdvertisingCombinationUnitWx> list = advertisingCombinationWxService.selectByUnitId(advertisingCombinationUnit.getAdUnitId());

        if (null == list || list.isEmpty()) {
            return;
        }

        for (AdvertisingCombinationUnitWx combinationUnit : list) {

            AdvertisingPlanWx advertisingPlan = new AdvertisingPlanWx();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());

            List<AdvertisingPlanWx> advertisingPlans = advertisingPlanWxService.selectAdvertisingPlanWxList(advertisingPlan);

            if (null == advertisingPlans || advertisingPlans.isEmpty()) {
                continue;
            }

            for (AdvertisingPlanWx plan : advertisingPlans) {

                String adAppIdOld = plan.getAdAppId();

                List<ComponentAuthorizationInfo> componentAuthorizationInfos = advertisingCombinationWxService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
                if (null != componentAuthorizationInfos && !componentAuthorizationInfos.isEmpty()) {
                    plan.setWeChatOfficialAccounts(String.join(",", componentAuthorizationInfos.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
                    if (null == plan.getRadioWeChatOfficialAccount()
                            || ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(plan.getRadioWeChatOfficialAccount())) {
                        plan.setRadioWeChatOfficialAccount(ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue());
                    }
                } else {
                    plan.setRadioWeChatOfficialAccount(ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue());
                    plan.setWeChatOfficialAccounts(null);
                }

                plan.setOperationType(IAdvertisingCombinationService.OPERATION_TYPE_UPDATE);
                advertisingPlanWxService.updateAdvertisingPlanWx(plan);

                if (!StringUtils.equals(adAppIdOld, plan.getAdAppId()) && plan.getAdvertisingStatus().equals(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(plan.getPlanId());
                    advertisingPlanService.reloadPattern(plan.getPlanId());
                }

            }

        }
    }

    /**
     * 根据主键ID查询广告方案信息
     */
    @GetMapping("/find/{id}")
    @ResponseBody
    public AjaxResult findById(@PathVariable("id") Integer id) {
        AdvertisingCombination advertisingCombination = advertisingCombinationWxService.selectAdvertisingCombinationWxById(id);
        List<ComponentAuthorizationInfo> list = advertisingCombinationWxService.isWeChatOfficialAccountOnSpacePaperOutput(id);

        AjaxResult ajaxResult = success(advertisingCombination);
        ajaxResult.put("componentAuthorizationInfos", list);

        return ajaxResult;
    }
}
