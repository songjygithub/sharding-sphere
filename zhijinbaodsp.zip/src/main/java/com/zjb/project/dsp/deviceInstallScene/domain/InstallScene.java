package com.zjb.project.dsp.deviceInstallScene.domain;

import com.zjb.framework.web.controller.BaseController;

import java.util.List;

/**
 * 设备安装场景
 * @author jiangbingjie
 * @date 2020/2/27 12:53 AM
 */
public class InstallScene extends BaseController{
    private static final long serialVersionUID = 1L;
    /** 场景ID */
    private Integer value;
    /** 场景名称 */
    private String name;
    /**场景子节点*/
    private List<InstallScene> children;

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<InstallScene> getChildren() {
        return children;
    }

    public void setChildren(List<InstallScene> children) {
        this.children = children;
    }
}
