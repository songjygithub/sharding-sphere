package com.zjb.project.dsp.advertisingCombinationFans.service;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_FANS_PAPER_OUTPUT;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_REDIRECT_QQ_PERSONAL;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_REDIRECT_WE_CHAT_ACCOUNT;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_REDIRECT_WE_CHAT_PERSONAL;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationFans.mapper.AdvertisingCombinationFansMapper;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.mapper.AdvertisingUnitFansMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.qqPersonal.mapper.QqPersonalMapper;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.mapper.WeChatPersonalMapper;

/**
 * 粉丝通广告方案 服务层实现
 * 
 * @author shenlong
 * @date 2019-11-22
 */
@Service
public class AdvertisingCombinationFansServiceImpl implements IAdvertisingCombinationFansService 
{
	@Autowired
	private AdvertisingCombinationFansMapper advertisingCombinationFansMapper;
	@Autowired
	private AdvertisingUnitFansMapper advertisingUnitFansMapper;
	@Autowired
	private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
	@Autowired
	private WeChatPersonalMapper weChatPersonalMapper;
	@Autowired
	private QqPersonalMapper qqPersonalMapper;

	/**
     * 查询粉丝通广告方案信息
     * 
     * @param id 粉丝通广告方案ID
     * @return 粉丝通广告方案信息
     */
    @Override
	public AdvertisingCombinationFans selectAdvertisingCombinationFansById(Integer id)
	{
	    return advertisingCombinationFansMapper.selectAdvertisingCombinationFansById(id);
	}
	
	/**
     * 查询粉丝通广告方案列表
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 粉丝通广告方案集合
     */
	@Override
	public List<AdvertisingCombinationFans> selectAdvertisingCombinationFansList(AdvertisingCombinationFans advertisingCombinationFans)
	{
	    return advertisingCombinationFansMapper.selectAdvertisingCombinationFansList(advertisingCombinationFans);
	}

	@Override
	public List<AdvertisingCombinationUnitFans> selectAdvertisingCombinationUnitFansList(AdvertisingCombinationUnitFans advertisingCombinationUnitFans) {
		return advertisingCombinationFansMapper.selectAdvertisingCombinationUnitFansList(advertisingCombinationUnitFans);
	}

	/**
     * 新增粉丝通广告方案
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
	@Override
	public int insertAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans)
	{
		int r = advertisingCombinationFansMapper.insertAdvertisingCombinationFans(advertisingCombinationFans);

		if (r > 0) {
			advertisingCombinationFans.setComId(ZjbDictionaryEnum.AD_UNIT_TYPE_FANS.getValue().toString() + advertisingCombinationFans.getId());
			r += advertisingCombinationFansMapper.updateAdvertisingCombinationFans(advertisingCombinationFans);
		}

		return r;
	}
	
	/**
     * 修改粉丝通广告方案
     * 
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
	@Override
	public int updateAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans)
	{
	    return advertisingCombinationFansMapper.updateAdvertisingCombinationFans(advertisingCombinationFans);
	}

	/**
     * 删除粉丝通广告方案对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisingCombinationFansByIds(String ids)
	{
		return advertisingCombinationFansMapper.deleteAdvertisingCombinationFansByIds(Convert.toStrArray(ids));
	}

	@Override
	public int deleteAdvertisingCombinationUnitFansByUnitId(String ids) {
		return advertisingCombinationFansMapper.deleteAdvertisingCombinationUnitFansByUnitId(Convert.toStrArray(ids));
	}

	@Override
	public int modifyDetails(AdvertisingCombinationUnitFans advertisingCombinationUnitFans) {
		return advertisingCombinationFansMapper.modifyDetails(advertisingCombinationUnitFans);
	}


	@Override
	public List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer id) {
		AdvertisingCombinationUnitFans combinationUnitFans = new AdvertisingCombinationUnitFans();
		combinationUnitFans.setCombinationId(id);
		List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansMapper.selectAdvertisingCombinationUnitFansList(combinationUnitFans);
		if (null == list || list.isEmpty()) {
			return Collections.emptyList();
		}

		List<ComponentAuthorizationInfo> all = new ArrayList<>(4);

		for (AdvertisingCombinationUnitFans advertisingCombinationUnit : list) {
			AdvertisingUnit advertisingUnit = advertisingUnitFansMapper.selectAdvertisingUnitFansById(advertisingCombinationUnit.getAdUnitId());
			if (null != advertisingUnit  && AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
					&& AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())) {

				ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(advertisingUnit.getAppId());
				if (null != componentAuthorizationInfo) {
					all.add(componentAuthorizationInfo);
				}
			}
		}

		return all;
	}

	@Override
	public List<WeChatPersonal> isWeChatPersonalAccountOnSpacePaperOutput(Integer id) {

		AdvertisingCombinationUnitFans combinationUnitFans = new AdvertisingCombinationUnitFans();
		combinationUnitFans.setCombinationId(id);
		List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansMapper.selectAdvertisingCombinationUnitFansList(combinationUnitFans);
		if (null == list || list.isEmpty()) {
			return Collections.emptyList();
		}

		List<WeChatPersonal> all = new ArrayList<>(4);

		for (AdvertisingCombinationUnitFans advertisingCombinationUnit : list) {
			AdvertisingUnit advertisingUnit = advertisingUnitFansMapper.selectAdvertisingUnitFansById(advertisingCombinationUnit.getAdUnitId());
			if (null != advertisingUnit  && AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
					&& AD_REDIRECT_WE_CHAT_PERSONAL.getValue().equals(advertisingUnit.getRedirectUrlType())) {

				WeChatPersonal weChatPersonal = weChatPersonalMapper.selectByPersonalId(advertisingUnit.getWeChatPersonalId());
				if (null != weChatPersonal) {
					all.add(weChatPersonal);
				}
			}
		}

		return all;
	}

	@Override
	public List<QqPersonal> isQQPersonalAccountOnSpacePaperOutput(Integer id) {

		AdvertisingCombinationUnitFans combinationUnitFans = new AdvertisingCombinationUnitFans();
		combinationUnitFans.setCombinationId(id);
		List<AdvertisingCombinationUnitFans> list = advertisingCombinationFansMapper.selectAdvertisingCombinationUnitFansList(combinationUnitFans);
		if (null == list || list.isEmpty()) {
			return Collections.emptyList();
		}

		List<QqPersonal> all = new ArrayList<>(4);

		for (AdvertisingCombinationUnitFans advertisingCombinationUnit : list) {
			AdvertisingUnit advertisingUnit = advertisingUnitFansMapper.selectAdvertisingUnitFansById(advertisingCombinationUnit.getAdUnitId());
			if (null != advertisingUnit  && AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
					&& AD_REDIRECT_QQ_PERSONAL.getValue().equals(advertisingUnit.getRedirectUrlType())) {

				QqPersonal qqPersonal = qqPersonalMapper.selectByPersonalId(advertisingUnit.getQqPersonalId());
				if (null != qqPersonal) {
					all.add(qqPersonal);
				}
			}
		}

		return all;
	}

	@Override
	public List<AdvertisingCombinationUnitFans> selectByUnitId(Integer unitId) {
		return advertisingUnitFansMapper.selectByUnitId(unitId);
	}
}
