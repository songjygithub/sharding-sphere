package com.zjb.project.dsp.deviceSpecial.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;
import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

public class DeviceSpecial extends BaseEntity {

    private static final long serialVersionUID = 1L;
    /** id */
    private Integer id;
    /** 设备id */
    private Integer deviceId;
    /** 设备sn */
    private String deviceSn;
    /** 代理商id */
    @Excel(name = "agencyId")
    private Integer agencyId;
    /** 代理商名称 */
    @Excel(name = "agencyName")
    private String agencyName;
    /** 类型 0:支付宝端指定设备拦截；1：微信端屏蔽付费取纸；2：支付宝端屏蔽付费取纸*/
    private Integer specialType;
    /** 生效时间 */
    private Date effectiveTime;
    /** 失效时间 */
    private Date loseEfficacyTime;
    /** 屏蔽付费设备状态 */
    private Integer deviceSpecialStatus;

    private String specialTypes;
    /** 安装场合类型 */
    private String installCodeType;
    /** 安装场合 */
    private String installCode;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public Integer getSpecialType() {
        return specialType;
    }

    public void setSpecialType(Integer specialType) {
        this.specialType = specialType;
    }

    public Date getEffectiveTime() {
        return effectiveTime;
    }

    public void setEffectiveTime(Date effectiveTime) {
        this.effectiveTime = effectiveTime;
    }

    public Date getLoseEfficacyTime() {
        return loseEfficacyTime;
    }

    public void setLoseEfficacyTime(Date loseEfficacyTime) {
        this.loseEfficacyTime = loseEfficacyTime;
    }

    public Integer getDeviceSpecialStatus() {
        return deviceSpecialStatus;
    }

    public void setDeviceSpecialStatus(Integer deviceSpecialStatus) {
        this.deviceSpecialStatus = deviceSpecialStatus;
    }

    public String getSpecialTypes() {
        return specialTypes;
    }

    public void setSpecialTypes(String specialTypes) {
        this.specialTypes = specialTypes;
    }

    public String getInstallCodeType() {
        return installCodeType;
    }

    public void setInstallCodeType(String installCodeType) {
        this.installCodeType = installCodeType;
    }

    public String getInstallCode() {
        return installCode;
    }

    public void setInstallCode(String installCode) {
        this.installCode = installCode;
    }
}
