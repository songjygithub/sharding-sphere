package com.zjb.project.dsp.advertisingCombinationWx.domain;

import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;

/**
 * 广告方案表-微信 zjb_advertising_combination_wx
 *
 * @author ZH
 * @date 2019-08-13
 */
public class AdvertisingCombinationWx extends AdvertisingCombination {
	private static final long serialVersionUID = 7639699086635678292L;
}