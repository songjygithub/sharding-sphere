package com.zjb.project.dsp.advertisingCombinationWx.service;

import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationUnitWx;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationWx;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;

import java.util.List;

/**
 * 广告方案-微信 服务层
 *
 * @author ZH
 * @date 2019-08-13
 */
public interface IAdvertisingCombinationWxService {
    /**
     * 查询广告方案信息
     *
     * @param id 广告方案ID
     * @return 广告方案信息
     */
    AdvertisingCombinationWx selectAdvertisingCombinationWxById(Integer id);

    /**
     * 查询广告方案列表
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 广告方案集合
     */
    List<AdvertisingCombinationWx> selectAdvertisingCombinationWxList(AdvertisingCombinationWx advertisingCombinationWx);

    /**
     * 新增广告方案
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 结果
     */
    int insertAdvertisingCombinationWx(AdvertisingCombinationWx advertisingCombinationWx);

    /**
     * 修改广告方案
     *
     * @param advertisingCombinationWx 广告方案信息
     * @return 结果
     */
    int updateAdvertisingCombinationWx(AdvertisingCombinationWx advertisingCombinationWx);

    /**
     * 删除广告方案信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingCombinationWxByIds(String ids);

    /**
     * 查询广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情信息
     * @return 广告方案详情集合
     */
    List<AdvertisingCombinationUnitWx> selectAdvertisingCombinationUnitWxList(AdvertisingCombinationUnitWx advertisingCombinationUnitWx);

    /**
     * 新增广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情信息
     * @return 结果
     */
    int insertAdvertisingCombinationUnitWx(AdvertisingCombinationUnitWx advertisingCombinationUnitWx);

    /**
     * 修改广告方案详情
     *
     * @param advertisingCombinationUnitWx 广告方案详情
     * @return 结果
     */
    int modifyDetailsWx(AdvertisingCombinationUnitWx advertisingCombinationUnitWx);


    /**
     * 删除广告方案详情
     *
     * @param ids 需删除的数据id
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitWxByIds(String ids);

    /**
     * 删除广告方案详情
     *
     * @param combinationId 广告方案id集
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitWxByCombinationId(String combinationId);

    /**
     * 删除广告方案详情
     *
     * @param adUnitId 广告池id集
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitWxByUnitId(String adUnitId);

    /**
     * 扫码取纸按钮是否配置公众号
     *
     * @param combinationId
     * @return
     */
    List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer combinationId);

    /**
     * 通过广告单元ID查询所有记录
     * @param unitId
     * @return
     */
    List<AdvertisingCombinationUnitWx> selectByUnitId(Integer unitId);
}
