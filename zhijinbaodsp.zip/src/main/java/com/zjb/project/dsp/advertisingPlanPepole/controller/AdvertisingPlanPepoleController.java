package com.zjb.project.dsp.advertisingPlanPepole.controller;

import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * 广告投放人群定向 信息操作处理
 *
 * @author songjy
 * @date 2019-07-12
 */
@Controller
@RequestMapping("/zjb/advertisingPlanPepole")
public class AdvertisingPlanPepoleController extends BaseController {
    private String prefix = "zjb/advertisingPlanPepole";

    @Autowired
    private IAdvertisingPlanPepoleService advertisingPlanPepoleService;

    @RequiresPermissions("zjb:advertisingPlanPepole:view")
    @GetMapping()
    public String advertisingPlanPepole() {
        return prefix + "/advertisingPlanPepole";
    }

    /**
     * 查询广告投放人群定向列表
     */
    @RequiresPermissions("zjb:advertisingPlanPepole:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingPlanPepole advertisingPlanPepole) {
        startPage();
        List<AdvertisingPlanPepole> list = advertisingPlanPepoleService.selectAdvertisingPlanPepoleList(advertisingPlanPepole);
        return getDataTable(list);
    }

    /**
     * 新增广告投放人群定向
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告投放人群定向
     */
    @RequiresPermissions("zjb:advertisingPlanPepole:add")
    @Log(title = "广告投放人群定向", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingPlanPepole advertisingPlanPepole) {
        return toAjax(advertisingPlanPepoleService.insertAdvertisingPlanPepole(advertisingPlanPepole));
    }

    /**
     * 修改广告投放人群定向
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlanPepole advertisingPlanPepole = advertisingPlanPepoleService.selectAdvertisingPlanPepoleById(id);
        mmap.put("advertisingPlanPepole", advertisingPlanPepole);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告投放人群定向
     */
    @RequiresPermissions("zjb:advertisingPlanPepole:edit")
    @Log(title = "广告投放人群定向", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingPlanPepole advertisingPlanPepole) {
        return toAjax(advertisingPlanPepoleService.updateAdvertisingPlanPepole(advertisingPlanPepole));
    }

    /**
     * 删除广告投放人群定向
     */
    @RequiresPermissions("zjb:advertisingPlanPepole:remove")
    @Log(title = "广告投放人群定向", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingPlanPepoleService.deleteAdvertisingPlanPepoleByIds(ids));
    }

    /**
     * 人群定向正则对应的预编译类(Pattern)
     *
     * @return
     */
    @GetMapping("/peopleRegexMapPattern")
    @ResponseBody
    public Map<String, Pattern> peopleRegexMapPattern() {
        return advertisingPlanPepoleService.peopleRegexMapPattern();
    }

    /**
     * 重新载入正则及对应的广告计划
     */
    @GetMapping("/reloadPatternPlan")
    @ResponseBody
    public AjaxResult reloadPatternPlan() {
        advertisingPlanPepoleService.reloadPatternPlan();
        return success();
    }

}
