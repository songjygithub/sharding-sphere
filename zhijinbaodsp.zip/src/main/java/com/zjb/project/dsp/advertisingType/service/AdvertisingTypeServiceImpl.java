package com.zjb.project.dsp.advertisingType.service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.support.Convert;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.dsp.advertisingType.domain.AdvertisingType;
import com.zjb.project.dsp.advertisingType.mapper.AdvertisingTypeMapper;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.mapper.AdvertisingUnitMapper;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.mapper.AdvertisingUnitFansMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.zjb.common.constant.AdvertisingConstants.KEY_ADVERTISING_TYPE_ADD_EVENT;
import static com.zjb.common.constant.AdvertisingConstants.KEY_ADVERTISING_TYPE_REMOVE_EVENT;

/**
 * 广告类型 服务层实现
 *
 * @author songjy
 * @date 2020-03-24
 */
@Service
public class AdvertisingTypeServiceImpl implements IAdvertisingTypeService {
    @Autowired
    private AdvertisingTypeMapper advertisingTypeMapper;
    @Autowired
    private AdvertisingUnitFansMapper advertisingUnitFansMapper;
    @Autowired
    private AdvertisingUnitMapper advertisingUnitMapper;

    /**
     * 查询广告类型信息
     *
     * @param id 广告类型ID
     * @return 广告类型信息
     */
    @Override
    public AdvertisingType selectAdvertisingTypeById(Integer id) {
        return advertisingTypeMapper.selectAdvertisingTypeById(id);
    }

    /**
     * 查询广告类型列表
     *
     * @param advertisingType 广告类型信息
     * @return 广告类型集合
     */
    @Override
    public List<AdvertisingType> selectAdvertisingTypeList(AdvertisingType advertisingType) {
        return advertisingTypeMapper.selectAdvertisingTypeList(advertisingType);
    }

    /**
     * 新增广告类型
     *
     * @param advertisingType 广告类型信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingType(AdvertisingType advertisingType) {

        advertisingType.setGmtCreated(new Date());
        advertisingType.setGmtModified(advertisingType.getGmtCreated());

        int r = advertisingTypeMapper.insertAdvertisingType(advertisingType);

        Map<String, AdvertisingType> map = new HashMap<>(6);
        map.put(KEY_ADVERTISING_TYPE_ADD_EVENT, advertisingType);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_CORE_ADMIN_COMMON_EVENT, JSON.toJSONString(map));

        return r;
    }

    /**
     * 修改广告类型
     *
     * @param advertisingType 广告类型信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingType(AdvertisingType advertisingType) {

        AdvertisingType old = advertisingTypeMapper.selectAdvertisingTypeById(advertisingType.getId());

        AdvertisingUnitFans query = new AdvertisingUnitFans();
        query.setAdTypeId(advertisingType.getId());

        List<AdvertisingUnit> listZst = advertisingUnitMapper.selectAdvertisingUnitList(query);
        List<AdvertisingUnitFans> list = advertisingUnitFansMapper.selectAdvertisingUnitFansList(query);
        advertisingType.setCountAdConfig(list.size() + listZst.size());

        int r = advertisingTypeMapper.updateAdvertisingType(advertisingType);
        AdvertisingType newAdvertisingType = advertisingTypeMapper.selectAdvertisingTypeById(advertisingType.getId());

        Map<String, AdvertisingType> map = new HashMap<>(6);
        map.put(KEY_ADVERTISING_TYPE_ADD_EVENT, newAdvertisingType);
        map.put(KEY_ADVERTISING_TYPE_REMOVE_EVENT, old);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_CORE_ADMIN_COMMON_EVENT, JSON.toJSONString(map));

        return r;
    }

    /**
     * 删除广告类型对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingTypeByIds(String ids) {
        return advertisingTypeMapper.deleteAdvertisingTypeByIds(Convert.toStrArray(ids));
    }

}
