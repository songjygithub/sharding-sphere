package com.zjb.project.dsp.forbidPutOfficialAccountConfig.service;

import static com.zjb.common.constant.AdvertisingConstants.KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD;
import static com.zjb.common.constant.AdvertisingConstants.KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE;
import static com.zjb.common.enums.ZjbDictionaryEnum.FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_HAND_STOP;
import static com.zjb.framework.config.RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.mapper.ForbidPutOfficialAccountConfigMapper;

import cn.hutool.core.collection.ConcurrentHashSet;

/**
 * 指定次数禁投公众号广告配置 服务层实现
 *
 * @author jiangbingjie
 * @date 2020-02-20
 */
@Service
public class ForbidPutOfficialAccountConfigServiceImpl implements IForbidPutOfficialAccountConfigService, InitializingBean {
    private static final Logger logger = LoggerFactory.getLogger(ForbidPutOfficialAccountConfigServiceImpl.class);

    @Autowired
    private ForbidPutOfficialAccountConfigMapper forbidPutOfficialAccountConfigMapper;

    /**
     * 次数屏蔽对应的设备SN：key=取纸次数  value=设备SN集合
     */
    private static final Map<Integer, Set<String>> TIMES_MAP_DEVICE_SN = new ConcurrentHashMap<>();

    /**
     * 不限次数屏蔽的设备
     */
    private static final Set<String> FORBID_ALL_DEVICE_SN = new ConcurrentHashSet<>();

    @Override
    public void afterPropertiesSet() throws Exception {

        /*初始化屏蔽公众号正则数据*/
        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {
                List<ForbidPutOfficialAccountConfig> list = forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigList(new ForbidPutOfficialAccountConfig());
                if (null == list || list.isEmpty()) {
                    return;
                }

                for (ForbidPutOfficialAccountConfig config : list) {
                    config.setTakePaperTimes(StringUtils.defaultString(config.getTakePaperTimes()));
                    addPattern(config);
                }
            }
        });

    }

    @Override
    public boolean matcher(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo) {

        if (FORBID_ALL_DEVICE_SN.contains(deviceInfo.getDeviceSn())) {
            return true;
        }

        Set<String> set = TIMES_MAP_DEVICE_SN.get(peopleInfo.getTodayPaperNum());

        if (null != set && set.contains(deviceInfo.getDeviceSn())) {
            return true;
        }

        return false;
    }

    @Override
    public boolean effective(ForbidPutOfficialAccountConfig config) {

        if (null == config || null == config.getConfigId()) {
            logger.error("公众号屏蔽记录主键缺失");
            return false;
        }

        if (StringUtils.isAnyBlank(config.getDeviceSn())) {
            logger.error("公众号屏蔽记录{}缺失设备SN", config.getConfigId());
            return false;
        }

        if (null == config.getLoseEfficacyTime() || null == config.getEffectiveTime()) {
            logger.error("公众号屏蔽记录主键{}缺失生效时间||失效时间", config.getConfigId());
            return false;
        }

        if (config.getLoseEfficacyTime().before(new Date())) {
            logger.debug("公众号屏蔽记录主键{}已过失效时间", config.getConfigId());
            return false;
        }

        if (config.getEffectiveTime().after(new Date())) {
            logger.info("公众号屏蔽记录主键{}生效时间未到", config.getConfigId());
            return false;
        }

        if (null != config.getConfigStatus()
                && config.getConfigStatus().equals(FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_HAND_STOP.getValue())) {
            logger.info("公众号屏蔽记录主键{}手动停止", config.getConfigId());
            return false;
        }

        return true;
    }

    @Override
    public void addPattern(ForbidPutOfficialAccountConfig config) {

        if (!effective(config)) {
            return;
        }

        if (StringUtils.isBlank(config.getTakePaperTimes())) {
            FORBID_ALL_DEVICE_SN.add(config.getDeviceSn());
        } else {
            String[] array = StringUtils.split(config.getTakePaperTimes(), ',');

            for (String times : array) {
                Integer key = Integer.parseInt(times);
                Set<String> set = TIMES_MAP_DEVICE_SN.computeIfAbsent(key, k -> new HashSet<>());
                set.add(config.getDeviceSn());
            }
        }


    }

    @Override
    public void removePattern(ForbidPutOfficialAccountConfig config) {
        if (null == config.getConfigId()) {
            logger.error("缺失主键");
            return;
        }

        if (StringUtils.isBlank(config.getTakePaperTimes())) {
            FORBID_ALL_DEVICE_SN.remove(config.getDeviceSn());
        } else {
            String[] array = StringUtils.split(config.getTakePaperTimes(), ',');

            for (String times : array) {
                Integer key = Integer.parseInt(times);
                Set<String> set = TIMES_MAP_DEVICE_SN.get(key);

                if (null == set || set.isEmpty()) {
                    continue;
                }

                set.remove(config.getDeviceSn());

            }
        }

    }

    /**
     * 查询指定次数禁投公众号广告配置信息
     *
     * @param configId 指定次数禁投公众号广告配置ID
     * @return 指定次数禁投公众号广告配置信息
     */
    @Override
    public ForbidPutOfficialAccountConfig selectForbidPutOfficialAccountConfigById(Integer configId) {
        return forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigById(configId);
    }

    /**
     * 查询指定次数禁投公众号广告配置列表
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 指定次数禁投公众号广告配置集合
     */
    @Override
    public List<ForbidPutOfficialAccountConfig> selectForbidPutOfficialAccountConfigList(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        return forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigList(forbidPutOfficialAccountConfig);
    }

    @Override
    public List<ForbidPutOfficialAccountConfig> selectAutomaticInvalid() {
        return forbidPutOfficialAccountConfigMapper.selectAutomaticInvalid();
    }

    /**
     * 新增指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    @Override
    public int insertForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {

        int r = forbidPutOfficialAccountConfigMapper.insertForbidPutOfficialAccountConfig(forbidPutOfficialAccountConfig);

        if (r > 0) {
            Map<String, ForbidPutOfficialAccountConfig> map = new HashMap<>(6);
            map.put(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD, forbidPutOfficialAccountConfig);
            JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
        }

        return r;
    }

    /**
     * 修改指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    @Override
    public int updateForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {

        ForbidPutOfficialAccountConfig old = forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigById(forbidPutOfficialAccountConfig.getConfigId());

        if (null == old) {
            return 0;
        }

        int r = forbidPutOfficialAccountConfigMapper.updateForbidPutOfficialAccountConfig(forbidPutOfficialAccountConfig);

        if (r > 0) {
            ForbidPutOfficialAccountConfig newConfig = forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigById(forbidPutOfficialAccountConfig.getConfigId());
            Map<String, ForbidPutOfficialAccountConfig> map = new HashMap<>(6);
            map.put(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE, old);
            map.put(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD, newConfig);
            JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
        }

        return r;
    }

    /**
     * 删除指定次数禁投公众号广告配置对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteForbidPutOfficialAccountConfigByIds(String ids) {

        String[] arr = StringUtils.split(ids, ',');

        for (String id : arr) {
            ForbidPutOfficialAccountConfig config = forbidPutOfficialAccountConfigMapper.selectForbidPutOfficialAccountConfigById(Integer.parseInt(id));
            if (null == config) {
                continue;
            }
            Map<String, ForbidPutOfficialAccountConfig> map = new HashMap<>(6);
            map.put(KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE, config);
            JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
        }

        return forbidPutOfficialAccountConfigMapper.deleteForbidPutOfficialAccountConfigByIds(Convert.toStrArray(ids));
    }

    /**
     * 获取用户通过某台设备在某次取纸是是否屏蔽公众号
     *
     * @return 返回值大于0屏蔽，否则不屏蔽
     */
    @Override
    public int getForbidPutOfficialAccountCount(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        if (null == forbidPutOfficialAccountConfig.getDeviceId() || null == forbidPutOfficialAccountConfig.getTakePaperTime()) {
            return 0;
        }
        String nowTime = DateUtils.getTime();
        forbidPutOfficialAccountConfig.setNowTime(nowTime);
        forbidPutOfficialAccountConfig.setTakePaperTimesDesc(forbidPutOfficialAccountConfig.getTakePaperTime() + ",");
        return forbidPutOfficialAccountConfigMapper.getForbidPutOfficialAccountCount(forbidPutOfficialAccountConfig);
    }

    /**
     * 获取配置状态为空的配置信息
     *
     * @return
     */
    @Override
    public List<ForbidPutOfficialAccountConfig> getForbidPutOfficialAccountListWithoutStatus() {
        return forbidPutOfficialAccountConfigMapper.getForbidPutOfficialAccountListWithoutStatus();
    }

}
