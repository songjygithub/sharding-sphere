package com.zjb.project.dsp.advertisingUnitWx.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.mapper.AdvertisingPlanWxMapper;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.mapper.AdvertisingUnitWxMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.scanTask.mapper.ScanTaskMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT_WX;
import static com.zjb.common.enums.ZjbDictionaryEnum.NO;

/**
 * 广告池-微信 服务层实现
 *
 * @author ZH
 * @date 2019-08-13
 */
@Service
public class AdvertisingUnitWxServiceImpl implements IAdvertisingUnitWxService {
    @Autowired
    private AdvertisingUnitWxMapper advertisingUnitWxMapper;
    @Autowired
    private AdvertisingPlanWxMapper advertisingPlanWxMapper;
    @Autowired
    private GzhGroupMapper gzhGroupMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private ScanTaskMapper scanTaskMapper;

    /**
     * 查询广告池信息
     *
     * @param id 广告池ID
     * @return 广告池信息
     */
    @Override
    public AdvertisingUnitWx selectAdvertisingUnitWxById(Integer id) {
        return advertisingUnitWxMapper.selectAdvertisingUnitWxById(id);
    }

    /**
     * 查询广告池列表
     *
     * @param advertisingUnitWx 广告池信息
     * @return 广告池集合
     */
    @Override
    public List<AdvertisingUnitWx> selectAdvertisingUnitWxList(AdvertisingUnitWx advertisingUnitWx) {
        return advertisingUnitWxMapper.selectAdvertisingUnitWxList(advertisingUnitWx);
    }

    /**
     * 新增广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx) {
        int r = advertisingUnitWxMapper.insertAdvertisingUnitWx(advertisingUnitWx);
        if (r > 0) {
            advertisingUnitWx.setAdId(ZjbDictionaryEnum.AD_COMBINATION_UNIT_PREFIX_WX.getValue().toString() + advertisingUnitWx.getId());
            r += advertisingUnitWxMapper.updateAdvertisingUnitWx(advertisingUnitWx);
        }
        return r;
    }

    /**
     * 修改广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx) {
        return advertisingUnitWxMapper.updateAdvertisingUnitWx(advertisingUnitWx);
    }

    /**
     * 删除广告池对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingUnitWxByIds(String ids) {
        return advertisingUnitWxMapper.deleteAdvertisingUnitWxByIds(Convert.toStrArray(ids));
    }

    @Override
    public List<AdvertisingUnitWx> selectAdvertisingUnitListByCombinationId(Integer combinationId) {
        return advertisingUnitWxMapper.selectAdvertisingUnitListByCombinationId(combinationId);
    }

    @Override
    public List<AdvertisingUnitWx> selectAdvertisingUnitByTaskId(Integer taskId) {

        if (null == taskId) {
            return Collections.emptyList();
        }

        return advertisingUnitWxMapper.selectAdvertisingUnitByTaskId(taskId.toString());
    }

    @Override
    public List<AdvertisingUnitWx> selectAdvertisingUnitWxListByPlanId(Integer planId) {

        if (null == planId) {
            return Collections.emptyList();
        }

        AdvertisingPlanWx advertisingPlanWx = advertisingPlanWxMapper.selectAdvertisingPlanWxById(planId);

        if (null == advertisingPlanWx) {
            return Collections.emptyList();
        }

        return advertisingUnitWxMapper.selectAdvertisingUnitListByCombinationId(advertisingPlanWx.getCombinationId());
    }

    @Override
    public List<AdvertisingUnitWx> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(weChatOfficialAccount);

        if (null == componentAuthorizationInfo) {
            return Collections.emptyList();
        }

        AdvertisingUnitWx advertisingUnitWx = new AdvertisingUnitWx();
        advertisingUnitWx.setDeleted(NO.getValue());
        advertisingUnitWx.setAdSpaceIdentifier(AD_SPACE_PAPER_OUTPUT_WX.getValue());
        advertisingUnitWx.setWeChatAccount(componentAuthorizationInfo.getComponentId());

        return advertisingUnitWxMapper.selectAdvertisingUnitWxList(advertisingUnitWx);
    }

}
