package com.zjb.project.dsp.gzhTjData.service;

import com.zjb.project.dsp.gzhTjData.domain.GzhTjData;

import java.util.List;

/**
 * 公众号关注数据 服务层
 *
 * @author shenlong
 * @date 2020-01-04
 */
public interface IGzhTjDataService {
    /**
     * 查询公众号关注数据信息
     *
     * @param id 公众号关注数据ID
     * @return 公众号关注数据信息
     */
    public GzhTjData selectGzhTjDataById(Integer id);

    /**
     * 查询公众号关注数据列表
     *
     * @param gzhTjData 公众号关注数据信息
     * @return 公众号关注数据集合
     */
    public List<GzhTjData> selectGzhTjDataList(GzhTjData gzhTjData);

    /**
     * 查询公众号关注数据列表
     *
     * @param gzhTjData 公众号关注数据信息
     * @return 公众号关注数据集合
     */
    public List<GzhTjData> selectGzhTjDataListByAppIds(GzhTjData gzhTjData);

    /**
     * 新增公众号关注数据
     *
     * @param gzhTjData 公众号关注数据信息
     * @return 结果
     */
    public int insertGzhTjData(GzhTjData gzhTjData);

    /**
     * 修改公众号关注数据
     *
     * @param gzhTjData 公众号关注数据信息
     * @return 结果
     */
    public int updateGzhTjData(GzhTjData gzhTjData);

    /**
     * 删除公众号关注数据信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteGzhTjDataByIds(String ids);

}
