package com.zjb.project.dsp.advertisingUserInfo.domain;

import com.zjb.project.system.dict.domain.DictData;
/**
 * @author guoj
 * @date 2019/08/17
 */
public class PersonalAchievement extends DictData {

    private static final long serialVersionUID = 2118740219744872089L;

    /** 成就是否达到（0否 1是） */
    private String satisfy;

    /** 未达成图片地址 */
    private String noAchieveUrl;

    /** 达成图片地址 */
    private String achieveUrl;

    public String getSatisfy() {
        return satisfy;
    }

    public void setSatisfy(String satisfy) {
        this.satisfy = satisfy;
    }

    public String getNoAchieveUrl() {
        return noAchieveUrl;
    }

    public void setNoAchieveUrl(String noAchieveUrl) {
        this.noAchieveUrl = noAchieveUrl;
    }

    public String getAchieveUrl() {
        return achieveUrl;
    }

    public void setAchieveUrl(String achieveUrl) {
        this.achieveUrl = achieveUrl;
    }
}
