package com.zjb.project.dsp.blackThirdPlatformGzh.service;

import java.util.*;

import cn.hutool.extra.mail.MailUtil;
import com.alibaba.fastjson.JSON;
import com.vdurmont.emoji.EmojiParser;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.web.service.DictService;
import com.zjb.project.dsp.advertisingADExchange.domain.ThirdPlatformGzh;
import com.zjb.project.dsp.blackPersonalAccount.domain.BlackPersonalAccount;
import com.zjb.project.dsp.blackPersonalAccount.service.BlackPersonalAccountServiceImpl;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.domain.BlackThirdPlatformGzhTemporary;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.service.IBlackThirdPlatformGzhTemporaryService;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService;
import com.zjb.project.dsp.thirdPlatformGzhWinRecord.domain.ThirdPlatformGzhWinRecord;
import com.zjb.project.dsp.thirdPlatformGzhWinRecord.service.IThirdPlatformGzhWinRecordService;
import com.zjb.project.system.config.service.IConfigService;
import org.apache.poi.ss.formula.functions.T;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.blackThirdPlatformGzh.mapper.BlackThirdPlatformGzhMapper;
import com.zjb.project.dsp.blackThirdPlatformGzh.domain.BlackThirdPlatformGzh;
import com.zjb.project.dsp.blackThirdPlatformGzh.service.IBlackThirdPlatformGzhService;
import com.zjb.common.support.Convert;

/**
 * 第三方平台公众号黑名单 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-04-17
 */
@Service
public class BlackThirdPlatformGzhServiceImpl implements IBlackThirdPlatformGzhService 
{
	private static final Logger logger = LoggerFactory.getLogger(BlackThirdPlatformGzhServiceImpl.class);
	@Autowired
	private BlackThirdPlatformGzhMapper blackThirdPlatformGzhMapper;
	@Autowired
	private IThirdPlatformGzhWinRecordService thirdPlatformGzhWinRecordService;
	@Autowired
	private IMediumSellRullService mediumSellRullService;
	@Autowired
	private DictService dataService;
	@Autowired
	private IConfigService configService;
	@Autowired
	private IBlackThirdPlatformGzhTemporaryService blackThirdPlatformGzhTemporaryService;

	/**
     * 查询第三方平台公众号黑名单信息
     * 
     * @param id 第三方平台公众号黑名单ID
     * @return 第三方平台公众号黑名单信息
     */
    @Override
	public BlackThirdPlatformGzh selectBlackThirdPlatformGzhById(Integer id)
	{
	    return blackThirdPlatformGzhMapper.selectBlackThirdPlatformGzhById(id);
	}
	
	/**
     * 查询第三方平台公众号黑名单列表
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 第三方平台公众号黑名单集合
     */
	@Override
	public List<BlackThirdPlatformGzh> selectBlackThirdPlatformGzhList(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{
	    return blackThirdPlatformGzhMapper.selectBlackThirdPlatformGzhList(blackThirdPlatformGzh);
	}
	
    /**
     * 新增第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	@Override
	public int insertBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{
		//公众号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackThirdPlatformGzh.getThirdPlatformAppName())){
			String thirdPlatformAppName = EmojiParser.parseToAliases(blackThirdPlatformGzh.getThirdPlatformAppName());
			blackThirdPlatformGzh.setThirdPlatformAppName(thirdPlatformAppName);
		}
	    return blackThirdPlatformGzhMapper.insertBlackThirdPlatformGzh(blackThirdPlatformGzh);
	}
	
	/**
     * 修改第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	@Override
	public int updateBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{
		//公众号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackThirdPlatformGzh.getThirdPlatformAppName())){
			String thirdPlatformAppName = EmojiParser.parseToAliases(blackThirdPlatformGzh.getThirdPlatformAppName());
			blackThirdPlatformGzh.setThirdPlatformAppName(thirdPlatformAppName);
		}
	    return blackThirdPlatformGzhMapper.updateBlackThirdPlatformGzh(blackThirdPlatformGzh);
	}

	/**
     * 删除第三方平台公众号黑名单对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteBlackThirdPlatformGzhByIds(String ids)
	{
		return blackThirdPlatformGzhMapper.logicDeleteBlackThirdPlatformGzhByIds(Convert.toStrArray(ids));
	}

	/**
	 * 广告方案第三方公众号胜出后将appid和openid记入缓存（第三方公众号黑名单）
	 * @param thirdPlatformGzh
	 */
	@Override
	public void cacheThirdPlatformGzhInfo(ThirdPlatformGzh thirdPlatformGzh) {
		logger.info("广告方案第三方公众号胜出事件{}【{}】",thirdPlatformGzh);
		if(StringUtils.isEmpty(thirdPlatformGzh.getAppId()) || StringUtils.isEmpty(thirdPlatformGzh.getThirdPlatformChannel()) || StringUtils.isEmpty(thirdPlatformGzh.getRandomNum()) || StringUtils.isEmpty(thirdPlatformGzh.getOpenId())){
			logger.warn("广告方案第三方公众号胜出事件参数缺失【{}】",thirdPlatformGzh);
			return;
		}
		//获取媒体售卖规则7的相关信息
		MediumSellRull mediumSellRull = mediumSellRullService.selectMediumSellRullById(7);
		boolean checkBlackThirdPlatformGzh = false;
		if(mediumSellRull != null && 0 == mediumSellRull.getDeleted() && (int) ZjbDictionaryEnum.RULL_STATUS_EFFECTIV.getValue() == mediumSellRull.getRullStatus()){
			checkBlackThirdPlatformGzh = true;
			if(null == mediumSellRull.getSuccessTimes() && null == mediumSellRull.getSuccessPerson()){
				checkBlackThirdPlatformGzh = false;
			}
		}
		if(!checkBlackThirdPlatformGzh){
			return;
		}


		String blackThirdPlatformAppId = configService.selectConfigByKey("zjb_black_third_platform_gzh");
		if(StringUtils.isNotEmpty(blackThirdPlatformAppId) && !("0".equals(blackThirdPlatformAppId))){
			if(!(blackThirdPlatformAppId.equals(thirdPlatformGzh.getAppId()))){
				return;
			}
		}

		String time = DateUtils.getTime();
		//获取该第三方公众号第一次胜出时间
		String thirdPlatformGzhFirstSuccessTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.THIRD_PLATFORM_GZH_FIRST_SUCCESS_TIME+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), ZjbConstantsRedis.ZJB_DB_58);
		Date date = DateUtils.dateTime("yyyy-MM-dd HH:mm:ss",time);
		ThirdPlatformGzhWinRecord thirdPlatformGzhWinRecord = new ThirdPlatformGzhWinRecord();
		thirdPlatformGzhWinRecord.setThirdPlatformChannel(thirdPlatformGzh.getThirdPlatformChannel());
		thirdPlatformGzhWinRecord.setThirdPlatformAppId(thirdPlatformGzh.getAppId());
		thirdPlatformGzhWinRecord.setOpenId(thirdPlatformGzh.getOpenId());
		thirdPlatformGzhWinRecord.setRandomNum(thirdPlatformGzh.getRandomNum());
		thirdPlatformGzhWinRecord.setWinDate(date);
		thirdPlatformGzhWinRecord.setIssuePlStatus(0);
		thirdPlatformGzhWinRecord.setInsertBaseParamsBySys();
		thirdPlatformGzhWinRecordService.insertThirdPlatformGzhWinRecord(thirdPlatformGzhWinRecord);

		int gzhSuccessTimes = 0;
		//判断该第三方公众号已经在黑名单
		boolean blackGzh = false;
		BlackThirdPlatformGzh blackThirdPlatformGzh = new BlackThirdPlatformGzh();
		blackThirdPlatformGzh.setDeleted(0);
		blackThirdPlatformGzh.setThirdPlatformAppId(thirdPlatformGzh.getAppId());
		blackThirdPlatformGzh.setThirdPlatformChannel(thirdPlatformGzh.getThirdPlatformChannel());
		List<BlackThirdPlatformGzh> blackThirdPlatformGzhList = blackThirdPlatformGzhMapper.selectBlackThirdPlatformGzhList(blackThirdPlatformGzh);
		if(blackThirdPlatformGzhList != null && !(blackThirdPlatformGzhList.isEmpty())){
			blackGzh = true;
		}
		if(blackGzh){
			return;
		}else{
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_LAST_SUCCESS_TIME +"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), DateUtils.parseDateToStr("yyyy-MM-dd HH:mm:ss",date), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}
		if(StringUtils.isEmpty(thirdPlatformGzhFirstSuccessTime)){
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_FIRST_SUCCESS_TIME +"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), time, JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}


		JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_LAST_SUCCESS_TIME +"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), time, JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		//获取该第三方公众号胜出次数
		String thirdPlatformGzhSuccessTimes = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_TIMES+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(),ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isNotEmpty(thirdPlatformGzhSuccessTimes)){
			gzhSuccessTimes = Integer.parseInt(thirdPlatformGzhSuccessTimes);
		}
		gzhSuccessTimes++;
		JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_TIMES +"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), String.valueOf(gzhSuccessTimes), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		JedisPoolCacheUtils.sadd(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_PERSON+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), ZjbConstantsRedis.ZJB_DB_58, JedisPoolCacheUtils.EXRP_DAY, thirdPlatformGzh.getOpenId());

		//获取该用户该第三方公众号胜出次数
		String thirdPlatformGzhSuccessPersonTimes = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_PERSON_TIMES+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId()+"_"+thirdPlatformGzh.getOpenId(),ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isEmpty(thirdPlatformGzhSuccessPersonTimes)){
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_PERSON_TIMES+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId()+"_"+thirdPlatformGzh.getOpenId(),"1", JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}else{
			int thirdPlatformGzhSuccessPersonTime = Integer.parseInt(thirdPlatformGzhSuccessPersonTimes);
			thirdPlatformGzhSuccessPersonTime++;
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_PERSON_TIMES+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId()+"_"+thirdPlatformGzh.getOpenId(),String.valueOf(thirdPlatformGzhSuccessPersonTime), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}
		JedisPoolCacheUtils.sadd(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_RANDOM_NUM+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(), ZjbConstantsRedis.ZJB_DB_58, JedisPoolCacheUtils.EXRP_DAY, thirdPlatformGzh.getRandomNum());



		//获取该第三方公众号最后一次胜出时间
		String thirdPlatformGzhLastSuccessTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.THIRD_PLATFORM_GZH_LAST_SUCCESS_TIME+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(),ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isEmpty(thirdPlatformGzhLastSuccessTime)){
			thirdPlatformGzhLastSuccessTime = time;
		}
		//获取该第三方公众号胜出人数
		Set<String> thirdPlatformGzhSuccessPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_PERSON+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(),ZjbConstantsRedis.ZJB_DB_58);
		int thirdPlatformGzhSuccessPersonCount = 0;
		if(thirdPlatformGzhSuccessPerson != null && !(thirdPlatformGzhSuccessPerson.isEmpty())){
			thirdPlatformGzhSuccessPersonCount = thirdPlatformGzhSuccessPerson.size();
		}


		//获取该渠道公众号胜出流水号
		Set<String> thirdPlatformGzhSuccessRandomNum = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.THIRD_PLATFORM_GZH_SUCCESS_RANDOM_NUM+"_" +thirdPlatformGzh.getThirdPlatformChannel()+"_" +thirdPlatformGzh.getAppId(),ZjbConstantsRedis.ZJB_DB_58);


		if(gzhSuccessTimes >= mediumSellRull.getSuccessTimes() || thirdPlatformGzhSuccessPersonCount >= mediumSellRull.getSuccessPerson()){
			//将该公众号信息记录到公众号黑名单临时表中
			BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary = new BlackThirdPlatformGzhTemporary();
			blackThirdPlatformGzhTemporary.setThirdPlatformChannel(thirdPlatformGzh.getThirdPlatformChannel());
			blackThirdPlatformGzhTemporary.setThirdPlatformAppId(thirdPlatformGzh.getAppId());
			blackThirdPlatformGzhTemporary.setThirdPlatformAppName(thirdPlatformGzh.getAppName());
			blackThirdPlatformGzhTemporary.setRandomNums(String.join(",", thirdPlatformGzhSuccessRandomNum));
			blackThirdPlatformGzhTemporary.setCreateTime(date);
			blackThirdPlatformGzhTemporary.setInsertBaseParamsBySys();
			if(gzhSuccessTimes >= mediumSellRull.getSuccessTimes()){
				blackThirdPlatformGzhTemporary.setJoinBlackType(2);
			}else{
				blackThirdPlatformGzhTemporary.setJoinBlackType(1);
			}
			blackThirdPlatformGzhTemporaryService.insertBlackThirdPlatformGzhTemporary(blackThirdPlatformGzhTemporary);


		}

	}

	/**
	 * 获取第三方平台公众号黑名单数量
	 * @param blackThirdPlatformGzh
	 * @return
	 */
	@Override
	public int getBlackThirdPlatformGzhCount(BlackThirdPlatformGzh blackThirdPlatformGzh) {
		blackThirdPlatformGzh.setDeleted(0);
		if(StringUtils.isNotEmpty(blackThirdPlatformGzh.getThirdPlatformAppId()) && StringUtils.isNotEmpty(blackThirdPlatformGzh.getThirdPlatformChannel())){
			List<BlackThirdPlatformGzh> blackThirdPlatformGzhList = blackThirdPlatformGzhMapper.selectBlackThirdPlatformGzhList(blackThirdPlatformGzh);
			if(blackThirdPlatformGzhList != null && !(blackThirdPlatformGzhList.isEmpty())){
				return blackThirdPlatformGzhList.size();
			}
		}
		return 0;
	}

}
