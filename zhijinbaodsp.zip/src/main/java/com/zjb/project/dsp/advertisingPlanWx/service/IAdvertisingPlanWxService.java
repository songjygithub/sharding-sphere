package com.zjb.project.dsp.advertisingPlanWx.service;

import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;

import java.io.Serializable;
import java.util.List;

/**
 * 广告投放计划 服务层
 *
 * @author songjy
 * @date 2019-08-19
 */
public interface IAdvertisingPlanWxService extends IAdPlanService {
    /**
     * 查询广告投放计划信息
     *
     * @param id 广告投放计划ID
     * @return 广告投放计划信息
     */
    AdvertisingPlanWx selectAdvertisingPlanWxById(Serializable id);

    /**
     * 查询广告投放计划列表
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 广告投放计划集合
     */
    List<AdvertisingPlanWx> selectAdvertisingPlanWxList(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 新增广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    int insertAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 修改广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    int updateAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 删除广告投放计划信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanWxByIds(String ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param ids
     * @return
     */
    int logicDeleteAdvertisingPlanWxByIds(String ids);

    /**
     * 根据公众号查询广告投放计划
     *
     * @param adAppId
     * @return
     */
    List<AdvertisingPlanWx> selectByAdAppId(String adAppId);

    /**
     * 根据广告池单元ID查询关联的广告投放计划
     * @param unitId
     * @return
     */
    List<AdvertisingPlanWx> selectByUnitId(Integer unitId);
}
