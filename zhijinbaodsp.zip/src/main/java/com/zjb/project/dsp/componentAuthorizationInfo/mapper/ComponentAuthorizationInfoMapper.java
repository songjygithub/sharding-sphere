package com.zjb.project.dsp.componentAuthorizationInfo.mapper;


import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;

import java.util.List;

import static com.zjb.common.constant.ConstantsEhCache.CACHE_WE_CHAT_OFFICIAL_ACCOUNT;

/**
 * 公众号或小程序的授权
 * 数据层
 *
 * @author zjb
 * @date 2019-07-09
 */
@CacheConfig(cacheNames = {CACHE_WE_CHAT_OFFICIAL_ACCOUNT})
public interface ComponentAuthorizationInfoMapper {
    /**
     * 查询公众号或小程序的授权信息
     *
     * @param id 公众号或小程序的授权ID
     * @return 公众号或小程序的授权信息
     */
    ComponentAuthorizationInfo selectComponentAuthorizationInfoById(Integer id);

    /**
     * 查询公众号或小程序的授权信息
     *
     * @param componentId 公众号或小程序的授权ID
     * @return 公众号或小程序的授权信息
     */
    ComponentAuthorizationInfo selectComponentAuthorizationInfoByComponentId(String componentId);

    /**
     * 查询公众号或小程序的授权信息
     *
     * @param appId 公众号或小程序的授权ID
     * @return 公众号或小程序的授权信息
     */
    @Cacheable(key = "#p0")
    ComponentAuthorizationInfo selectComponentAuthorizationInfoByAppId(String appId);

    /**
     * 查询公众号或小程序的授权列表
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权信息
     * @return 公众号或小程序的授权集合
     */
    List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoList(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 新增公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权信息
     * @return 结果
     */
    int insertComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 修改公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权信息
     * @return 结果
     */
    @Caching(evict = {@CacheEvict(key = "#p0.id")})
    @CacheEvict(key = "#p0.appId")
    int updateComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo);

    /**
     * 修改公众号取纸二维码
     *
     * @param componentAuthorizationInfo
     * @return
     */
    int updateComponentAuthorizationInfoPickPaperUrl(ComponentAuthorizationInfo componentAuthorizationInfo);

    int updateComponentAuthorizationInfoLabel(ComponentAuthorizationInfo componentAuthorizationInfo);

    int deleteComponentAuthorizationInfoPickPaperUrl(Integer id);

    /**
     * 删除公众号或小程序的授权
     *
     * @param id 公众号或小程序的授权ID
     * @return 结果
     */
    int deleteComponentAuthorizationInfoById(Integer id);

    /**
     * 批量删除公众号或小程序的授权
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteComponentAuthorizationInfoByIds(String[] ids);

    /**
     * 通过主键ID集合查询公众号信息
     *
     * @param ids
     * @return
     */
    List<ComponentAuthorizationInfo> findByIds(Integer[] ids);

    /**
     * 模糊匹配公众号
     *
     * @param nickName 公众号名称
     * @return
     */
    List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoByName(String nickName);

    /**
     * 日关注量清零且状态更新为生效中
     *
     * @return
     */
    @CacheEvict(allEntries = true)
    int cleanDayFollowAmount();
}