package com.zjb.project.dsp.agencyWeChatAccountStatistics.mapper;

import com.zjb.project.dsp.agencyWeChatAccountStatistics.domain.AgencyWeChatAccountStatistics;

import java.util.List;

/**
 * 代理商维度公众号统计 数据层
 *
 * @author songjy
 * @date 2020-01-02
 */
public interface AgencyWeChatAccountStatisticsMapper {
    /**
     * 查询代理商维度公众号统计信息
     *
     * @param id 代理商维度公众号统计ID
     * @return 代理商维度公众号统计信息
     */
    AgencyWeChatAccountStatistics selectAgencyWeChatAccountStatisticsById(Long id);

    /**
     * 查询代理商维度公众号统计列表
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 代理商维度公众号统计集合
     */
    List<AgencyWeChatAccountStatistics> selectAgencyWeChatAccountStatisticsList(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 新增代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    int insertAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 修改代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    int updateAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 删除代理商维度公众号统计
     *
     * @param id 代理商维度公众号统计ID
     * @return 结果
     */
    int deleteAgencyWeChatAccountStatisticsById(Long id);

    /**
     * 批量删除代理商维度公众号统计
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAgencyWeChatAccountStatisticsByIds(String[] ids);
}