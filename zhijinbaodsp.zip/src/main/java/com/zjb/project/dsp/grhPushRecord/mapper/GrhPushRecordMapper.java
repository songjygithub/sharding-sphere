package com.zjb.project.dsp.grhPushRecord.mapper;

import com.zjb.project.dsp.grhPushRecord.domain.GrhPushRecord;
import java.util.List;	

/**
 * 个人号推送记录 数据层
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
public interface GrhPushRecordMapper 
{
	/**
     * 查询个人号推送记录信息
     * 
     * @param id 个人号推送记录ID
     * @return 个人号推送记录信息
     */
	public GrhPushRecord selectGrhPushRecordById(Integer id);
	
	/**
     * 查询个人号推送记录列表
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 个人号推送记录集合
     */
	public List<GrhPushRecord> selectGrhPushRecordList(GrhPushRecord grhPushRecord);
	
	/**
     * 新增个人号推送记录
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 结果
     */
	public int insertGrhPushRecord(GrhPushRecord grhPushRecord);
	
	/**
     * 修改个人号推送记录
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 结果
     */
	public int updateGrhPushRecord(GrhPushRecord grhPushRecord);
	
	/**
     * 删除个人号推送记录
     * 
     * @param id 个人号推送记录ID
     * @return 结果
     */
	public int deleteGrhPushRecordById(Integer id);
	
	/**
     * 批量删除个人号推送记录
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGrhPushRecordByIds(String[] ids);

	/**
	 * 清除个人号展示记录
	 * @return
	 */
	public int removeGrhShowRecord(String grhPushTimes);
	
}