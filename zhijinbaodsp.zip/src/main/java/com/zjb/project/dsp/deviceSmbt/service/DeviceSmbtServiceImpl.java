package com.zjb.project.dsp.deviceSmbt.service;

import com.zjb.common.constant.Constants;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceSmbt.domain.DeviceSmbt;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;

/**
 * @author songjy
 * @Date 2020/01/03
 **/
@Service
public class DeviceSmbtServiceImpl implements IDeviceSmbtService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private IDeviceService deviceService;

    @Override
    public List<DeviceSmbt> findByEventSerialNum(Date smbtDate, String deviceName, String zjbPrSn) {

        if (null == smbtDate || StringUtils.isAnyBlank(deviceName, zjbPrSn)) {
            logger.warn("缺失日期||设备名称||设备出纸流水号");
            return null;
        }

        DeviceDTO device = deviceService.selectByDeviceName(deviceName);

        if (null == device) {
            logger.error("根据设备名称【{}】获取设备信息失败", deviceName);
            return null;
        }

        int day = Integer.parseInt(DateUtils.DAY_FORMAT.format(smbtDate));

        Object[] args = {device.getSn(), day, Integer.parseInt(zjbPrSn)};
        int[] argTypes = {Types.VARCHAR, Types.INTEGER, Types.INTEGER};
        String sql = "SELECT * FROM `zjb_device_smbt` WHERE `device_sn` = ? AND `smbt_date` = ? AND `zjbpr_sn` = ?";

        return jdbcTemplate.query(sql, args, argTypes, new RowMapper<DeviceSmbt>() {
            @Override
            public DeviceSmbt mapRow(ResultSet rs, int rowNum) throws SQLException {
                DeviceSmbt record = new DeviceSmbt();
                record.setId(rs.getInt("id"));
                record.setDeviceId(rs.getInt("device_id"));
                record.setDeviceSn(rs.getString("device_sn"));
                record.setAgencyId(rs.getInt("agency_id"));
                record.setAgencyName(rs.getString("agency_name"));
                record.setSmbtAccount(rs.getBigDecimal("smbt_account"));
                record.setZjbprSn(rs.getString("zjbpr_sn"));
                record.setSmbtDate(rs.getInt("smbt_date"));

                return record;
            }
        });
    }
}
