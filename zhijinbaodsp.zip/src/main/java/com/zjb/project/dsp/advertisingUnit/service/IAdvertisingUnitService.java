package com.zjb.project.dsp.advertisingUnit.service;

import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;

import java.util.List;

/**
 * 广告池-支付宝 服务层
 *
 * @author zjb
 * @date 2019-07-12
 */
public interface IAdvertisingUnitService {
    /**
     * 查询广告池信息
     *
     * @param id 广告池ID
     * @return 广告池信息
     */
    AdvertisingUnit selectAdvertisingUnitById(Integer id);

    /**
     * 查询广告池信息
     *
     * @param ids 广告池ids
     * @return 广告池集
     */
    List<AdvertisingUnit> selectAdvertisingUnitByIds(String ids);

    /**
     * 获取所有未删除的广告
     *
     * @return
     */
    List<AdvertisingUnit> selectAdvertisingUnit();

    /**
     * 查询广告池列表
     *
     * @param advertisingUnit 广告池信息
     * @return 广告池集合
     */
    List<AdvertisingUnit> selectAdvertisingUnitList(AdvertisingUnit advertisingUnit);

    /**
     * 新增广告池
     *
     * @param advertisingUnit 广告池信息
     * @return 结果
     */
    int insertAdvertisingUnit(AdvertisingUnit advertisingUnit);

    /**
     * 修改广告池
     *
     * @param advertisingUnit 广告池信息
     * @return 结果
     */
    int updateAdvertisingUnit(AdvertisingUnit advertisingUnit);

    /**
     * 删除广告池信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingUnitByIds(String ids);

    /**
     * 通过广告方案ID查询广告单元
     *
     * @param combinationId
     * @return
     */
    List<AdvertisingUnit> selectAdvertisingUnitListByCombinationId(Integer combinationId);

    /**
     * 通过广告投放计划ID查询广告单元
     *
     * @param planId
     * @return
     */
    List<AdvertisingUnit> selectAdvertisingUnitListByPlanId(Integer planId);

    /**
     * @param taskId 表【zjb_scan_task】主键ID
     * @return
     */
    List<AdvertisingUnit> selectAdvertisingUnitByTaskId(Integer taskId);

    /**
     * @param weChatOfficialAccount 微信公众号
     * @return
     */
    List<AdvertisingUnit> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount);

}
