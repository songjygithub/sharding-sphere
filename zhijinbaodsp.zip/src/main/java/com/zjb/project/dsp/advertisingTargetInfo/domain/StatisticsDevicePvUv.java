package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;

/**
 * @author songjy
 * @date 2020-01-13
 */
public class StatisticsDevicePvUv implements Serializable {
    private static final long serialVersionUID = -214843232278117958L;

    /**
     * 设备SN
     */
    @Excel(name = "设备SN")
    private String deviceSn;

    /**
     * 代理商ID
     */
    @Excel(name = "代理商ID")
    private Integer agencyId;

    /**
     * 代理商名称
     */
    @Excel(name = "代理商名称")
    private String agencyName;

    /**
     * 设备安装场景
     */
    @Excel(name = "设备安装场景")
    private String sceneName;

    /**
     * 省 参考 省市区表
     */
    @Excel(name = "省")
    private String provinceName;
    /**
     * 市 参考 省市区表
     */
    @Excel(name = "市")
    private String cityName;
    /**
     * 区 参考 省市区表
     */
    @Excel(name = "区")
    private String areaName;

    /**
     * 设备安装地址
     */
    @Excel(name = "设备安装地址")
    private String installAddress;

    /**
     * 按次数
     */
    @Excel(name = "PV")
    private Integer pv;

    /**
     * 按人数
     */
    @Excel(name = "UV")
    private Integer uv;

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    public String getInstallAddress() {
        return installAddress;
    }

    public void setInstallAddress(String installAddress) {
        this.installAddress = installAddress;
    }

    public Integer getPv() {
        return pv;
    }

    public void setPv(Integer pv) {
        this.pv = pv;
    }

    public Integer getUv() {
        return uv;
    }

    public void setUv(Integer uv) {
        this.uv = uv;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }
}
