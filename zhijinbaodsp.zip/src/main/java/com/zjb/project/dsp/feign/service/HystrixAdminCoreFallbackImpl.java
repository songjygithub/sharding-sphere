package com.zjb.project.dsp.feign.service;

import com.alibaba.fastjson.JSON;
import com.zjb.project.common.componentAuthorizationInfo.domain.OpenApiAccountDTO;
import com.zjb.project.common.miniConfig.domain.WeChatSms;
import com.zjb.project.dsp.advertisingADExchange.domain.WechatParameter;
import com.zjb.qrcodego.domain.WeChatAccountTaskInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author songjy
 * @date 2020-05-20
 */
@Component
public class HystrixAdminCoreFallbackImpl implements IFeignAdminCoreService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public String taskInfo(String openId, String taskId, String qrCode, Long randomNum, String appId) {

        logger.error("尴尬，用户{}流水号{}设备二维码{}调用任务{}公众号{}服务{}超时3秒了", openId, randomNum, qrCode,
                taskId, (null == appId ? "" : appId), ADMIN_CORE_URL_TASK_INFO);
        return null;
    }

    @Override
    public WeChatAccountTaskInfo weChatInfo(WechatParameter wechatParameter) {

        logger.error("根据参数{}获取公众号信息超时5秒了", JSON.toJSONString(wechatParameter));

        return null;
    }

    @Override
    public String isSubscribe(String json) {
        logger.error("根据参数{}获取判断openid是否关注4个公众号失败", json);
        return "{}";
    }

    @Override
    public OpenApiAccountDTO getOpenApiAccountInfoByAppId(String appId) {
        logger.error("根据{}查询开放平台对接渠道账号申请信息失败", appId);
        return null;
    }

    @Override
    public String getAccessToken(String appId) {
        logger.error("根据微信公众号【{}】获取获取token失败", appId);
        return null;
    }

    @Override
    public String weChatSmsSend(WeChatSms weChatSms) {
        logger.error("公众号消息{}推送失败", JSON.toJSONString(weChatSms));
        return null;
    }
}
