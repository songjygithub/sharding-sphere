package com.zjb.project.dsp.deviceInstallInfo.service;

import com.zjb.common.constant.Constants;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.deviceInstallInfo.domain.DeviceInstallInfo;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Collections;
import java.util.List;

import static com.zjb.common.constant.ConstantsEhCache.CACHE_DEVICE_INSTALL_INFO;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MINUTE;

/**
 * 设备安装 服务层实现
 *
 * @author songjy
 * @date 2019-11-30
 */
@Service
public class DeviceInstallInfoServiceImpl implements IDeviceInstallInfoService, InitializingBean {

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private CacheManager cacheManager;
    private Cache cacheDeviceInstallInfo;

    @Override
    public void afterPropertiesSet() throws Exception {
        cacheDeviceInstallInfo = cacheManager.getCache(CACHE_DEVICE_INSTALL_INFO);
    }

    /**
     * 查询设备安装信息
     *
     * @param id 设备安装ID
     * @return 设备安装信息
     */
    @Override
    public DeviceInstallInfo selectDeviceInstallInfoById(Integer id) {
        //TODO
        return null;
    }

    /**
     * 查询设备安装列表
     *
     * @param deviceInstallInfo 设备安装信息
     * @return 设备安装集合
     */
    @Override
    public List<DeviceInstallInfo> selectDeviceInstallInfoList(DeviceInstallInfo deviceInstallInfo) {
        //TODO
        return Collections.emptyList();
    }

    @Override
    public DeviceInstallInfo findByDeviceId(Integer deviceId) {

        if (null == deviceId) {
            return null;
        }

        String key = "device_install_info_device_id_" + deviceId + '_' + Constants.SYSTEM_ID;
        DeviceInstallInfo deviceInstallInfo = JedisPoolCacheUtils.getV(key, ZJB_DB_50, DeviceInstallInfo.class);

        if (null != deviceInstallInfo) {
            return deviceInstallInfo;
        }

        String sql = "SELECT `id`, `device_id`, `province_name`, `city_name`, `area_name`, `sex`, `install_location_code_type`, " +
                "`install_location_code`, `detail_address` FROM `zjb_device_install_info` " +
                "WHERE `device_id` = ? AND `deleted` = 0 LIMIT 1";

        Object[] args = {deviceId};
        int[] argTypes = {Types.INTEGER};

        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<DeviceInstallInfo>() {
                @Override
                public DeviceInstallInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

                    DeviceInstallInfo record = new DeviceInstallInfo();
                    record.setId(rs.getInt("id"));
                    record.setDeviceId(null == rs.getObject("device_id") ? null : rs.getInt("device_id"));
                    record.setProvinceName(rs.getString("province_name"));
                    record.setCityName(rs.getString("city_name"));
                    record.setAreaName(rs.getString("area_name"));
                    record.setSex(rs.getString("sex"));
                    record.setInstallLocationCodeType(rs.getString("install_location_code_type"));
                    record.setInstallLocationCode(rs.getString("install_location_code"));
                    record.setDetailAddress(rs.getString("detail_address"));

                    JedisPoolCacheUtils.setVExpire(key, record, 15 * EXRP_MINUTE, ZJB_DB_50);

                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public DeviceInstallInfo findByDeviceName(String deviceName) {

        DeviceInstallInfo installInfo = cacheDeviceInstallInfo.get(deviceName, DeviceInstallInfo.class);

        if (null != installInfo) {
            return installInfo;
        }

        String sql = "SELECT * FROM `zjb_device_install_info` WHERE `device_id` = (SELECT id FROM `zjb_device` WHERE `name` = ? ORDER BY `deleted` LIMIT 1) ORDER BY `deleted` LIMIT 1";

        Object[] args = {deviceName};
        int[] argTypes = {Types.VARCHAR};

        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<DeviceInstallInfo>() {
                @Override
                public DeviceInstallInfo mapRow(ResultSet rs, int rowNum) throws SQLException {

                    DeviceInstallInfo record = new DeviceInstallInfo();
                    record.setId(rs.getInt("id"));
                    record.setDeviceId(null == rs.getObject("device_id") ? null : rs.getInt("device_id"));
                    record.setProvinceName(rs.getString("province_name"));
                    record.setProvinceId(null == rs.getObject("province_id") ? null : rs.getInt("province_id"));
                    record.setCityName(rs.getString("city_name"));
                    record.setCityId(null == rs.getObject("city_id") ? null : rs.getInt("city_id"));
                    record.setAreaName(rs.getString("area_name"));
                    record.setCityId(null == rs.getObject("area_id") ? null : rs.getInt("area_id"));
                    record.setSex(rs.getString("sex"));
                    record.setAgencyId(null == rs.getObject("agency_id") ? null : rs.getInt("agency_id"));
                    record.setAgencyName(rs.getString("agency_name"));
                    record.setInstallLocationCodeType(rs.getString("install_location_code_type"));
                    record.setInstallLocationCode(rs.getString("install_location_code"));
                    record.setDetailAddress(rs.getString("detail_address"));

                    cacheDeviceInstallInfo.put(deviceName, record);

                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            cacheDeviceInstallInfo.put(deviceName, new DeviceInstallInfo());
            return null;
        }
    }
}
