package com.zjb.project.dsp.blackThirdPlatformGzh.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
											import java.util.Date;

/**
 * 第三方平台公众号黑名单表 zjb_black_third_platform_gzh
 * 
 * @author jiangbingjie
 * @date 2020-04-17
 */
public class BlackThirdPlatformGzh extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 自增主键 */
	private Integer id;
	/** 第三方平台标识(参考字典) */
	private String thirdPlatformChannel;
	/** 第三方平台公众号唯一标识 */
	private String thirdPlatformAppId;
	/** 第三方平台公众号名称 */
	private String thirdPlatformAppName;
	/** 本次进入黑名单时间 */
	private Date joinBlackTime;
	/** 累计进入黑名单次数 */
	private Integer joinBlackCount;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setThirdPlatformChannel(String thirdPlatformChannel) 
	{
		this.thirdPlatformChannel = thirdPlatformChannel;
	}

	public String getThirdPlatformChannel() 
	{
		return thirdPlatformChannel;
	}
	public void setThirdPlatformAppId(String thirdPlatformAppId) 
	{
		this.thirdPlatformAppId = thirdPlatformAppId;
	}

	public String getThirdPlatformAppId() 
	{
		return thirdPlatformAppId;
	}
	public void setThirdPlatformAppName(String thirdPlatformAppName) 
	{
		this.thirdPlatformAppName = thirdPlatformAppName;
	}

	public String getThirdPlatformAppName() 
	{
		return thirdPlatformAppName;
	}
	public void setJoinBlackTime(Date joinBlackTime) 
	{
		this.joinBlackTime = joinBlackTime;
	}

	public Date getJoinBlackTime() 
	{
		return joinBlackTime;
	}
	public void setJoinBlackCount(Integer joinBlackCount) 
	{
		this.joinBlackCount = joinBlackCount;
	}

	public Integer getJoinBlackCount() 
	{
		return joinBlackCount;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("thirdPlatformChannel", getThirdPlatformChannel())
            .append("thirdPlatformAppId", getThirdPlatformAppId())
            .append("thirdPlatformAppName", getThirdPlatformAppName())
            .append("joinBlackTime", getJoinBlackTime())
            .append("joinBlackCount", getJoinBlackCount())
            .append("gmtCreated", getGmtCreated())
            .append("createrId", getCreaterId())
            .append("gmtModified", getGmtModified())
            .append("modifierId", getModifierId())
            .append("deleted", getDeleted())
            .toString();
    }
}
