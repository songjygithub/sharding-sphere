package com.zjb.project.dsp.advertisingPlanPepole.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.util.List;

/**
 * 广告投放人群定向表 zjb_advertising_plan_pepole
 *
 * @author songjy
 * @date 2019-07-12
 */
public class AdvertisingPlanPepole extends BaseEntity {

    private static final long serialVersionUID = 6312006877526360598L;

    /**
     * 主键
     */
    private Integer id;
    /**
     * 广告投放计划主键，即表[zjb_advertising_plan]的业务主键【plan_id】
     */
    private String adPlanId;
    /**
     * 广告投放总取纸上限次数
     */
    private Integer paperUpperNum;
    /**
     * 广告投放总取纸下限次数
     */
    private Integer paperLowerNum;
    /**
     * 广告投放当日取纸次数，多个之间用,分隔
     */
    private String paperTodayNum;
    /**
     * 广告投放当日取纸下限次数
     */
    private Integer paperTodayLowerNum;

    /**
     * 广告投放当日取纸上限次数
     */
    private Integer paperTodayUpperNum;

    /**
     * 面向人群(zjb_face_sex) 0：男 1：女 2：综合
     */
    private Integer sex;
    /**
     * 指定投放年龄
     */
    private Integer age;
    /**
     * 广告投放年龄上限
     */
    private Integer ageUpperLimit;
    /**
     * 广告投放年龄下限
     */
    private Integer ageLowerLimit;
    /**
     * 广告投放平台类型(zjb_platform_type)，如：1:Android 2:IOS, 9:其它
     */
    private Integer platformType;
    /**
     * 广告投放扫码环境(zjb_ scan_tool)，1:微信 2:支付宝 9：其它
     */
    private Integer scanTool;
    /**
     * 广告投放网络类型(zjb_ network_type)，1：WIFI 2：4G 3：3G 4：2G 9：其它
     */
    private Integer networkType;
    /**
     * 广告投放运营商(zjb_operator_type)，1：移动 2：联通 3：电信 9：其它
     */
    private Integer operatorType;
    /**
     * 广告投放黑名单用户(zjb_black_user_enable)，0：不限 1：不投 2：只投
     */
    private Integer blackUserEnable;
    /**
     * 广告投放兴趣爱好
     */
    private String hobby;
    /**
     * 广告投放自定义标签
     */
    private String customLabel;
    /**
     * 正则表达式
     */
    private String regex;

    /**
     * 公众号定向，0：不限 1：仅投从未关注过的用户 2：可投已关注且已取关用户
     */
    private Integer radioWeChatOfficialAccount;

    /**
     * 公众号
     */
    private String weChatOfficialAccounts;

    private Integer operationType;

    /**========已下非数据库映射字段=======*/
    /**
     * 是否手动暂停
     */
    private boolean manualPause;
    /**
     * 是否手动恢复
     */
    private boolean manualResume;

    /**
     * 今日花费清零
     */
    private boolean clearTodaySpend;

    /**
     * 用户位置,多个之间用,分隔，省和市之间用_隔开，如：北京市_北京城区,江苏省_无锡市
     */
    private String userZone;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getAdPlanId() {
        return adPlanId;
    }

    public void setAdPlanId(String adPlanId) {
        this.adPlanId = adPlanId;
    }

    public void setPaperUpperNum(Integer paperUpperNum) {
        this.paperUpperNum = paperUpperNum;
    }

    public Integer getPaperUpperNum() {
        return paperUpperNum;
    }

    public void setPaperLowerNum(Integer paperLowerNum) {
        this.paperLowerNum = paperLowerNum;
    }

    public Integer getPaperLowerNum() {
        return paperLowerNum;
    }

    public String getPaperTodayNum() {
        return paperTodayNum;
    }

    public void setPaperTodayNum(String paperTodayNum) {
        this.paperTodayNum = paperTodayNum;
    }

    public Integer getPaperTodayUpperNum() {
        return paperTodayUpperNum;
    }

    public void setPaperTodayUpperNum(Integer paperTodayUpperNum) {
        this.paperTodayUpperNum = paperTodayUpperNum;
    }

    public Integer getPaperTodayLowerNum() {
        return paperTodayLowerNum;
    }

    public void setPaperTodayLowerNum(Integer paperTodayLowerNum) {
        this.paperTodayLowerNum = paperTodayLowerNum;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getAge() {
        return age;
    }

    public void setAgeUpperLimit(Integer ageUpperLimit) {
        this.ageUpperLimit = ageUpperLimit;
    }

    public Integer getAgeUpperLimit() {
        return ageUpperLimit;
    }

    public void setAgeLowerLimit(Integer ageLowerLimit) {
        this.ageLowerLimit = ageLowerLimit;
    }

    public Integer getAgeLowerLimit() {
        return ageLowerLimit;
    }

    public Integer getPlatformType() {
        return platformType;
    }

    public void setPlatformType(Integer platformType) {
        this.platformType = platformType;
    }

    public Integer getScanTool() {
        return scanTool;
    }

    public void setScanTool(Integer scanTool) {
        this.scanTool = scanTool;
    }

    public Integer getNetworkType() {
        return networkType;
    }

    public void setNetworkType(Integer networkType) {
        this.networkType = networkType;
    }

    public Integer getOperatorType() {
        return operatorType;
    }

    public void setOperatorType(Integer operatorType) {
        this.operatorType = operatorType;
    }

    public Integer getBlackUserEnable() {
        return blackUserEnable;
    }

    public void setBlackUserEnable(Integer blackUserEnable) {
        this.blackUserEnable = blackUserEnable;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public String getHobby() {
        return hobby;
    }

    public void setCustomLabel(String customLabel) {
        this.customLabel = customLabel;
    }

    public String getCustomLabel() {
        return customLabel;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public String getRegex() {
        return regex;
    }

    public boolean isManualPause() {
        return manualPause;
    }

    public void setManualPause(boolean manualPause) {
        this.manualPause = manualPause;
    }

    public boolean isManualResume() {
        return manualResume;
    }

    public void setManualResume(boolean manualResume) {
        this.manualResume = manualResume;
    }

    public boolean isClearTodaySpend() {
        return clearTodaySpend;
    }

    public void setClearTodaySpend(boolean clearTodaySpend) {
        this.clearTodaySpend = clearTodaySpend;
    }

    public Integer getRadioWeChatOfficialAccount() {
        return radioWeChatOfficialAccount;
    }

    public void setRadioWeChatOfficialAccount(Integer radioWeChatOfficialAccount) {
        this.radioWeChatOfficialAccount = radioWeChatOfficialAccount;
    }

    public String getWeChatOfficialAccounts() {
        return weChatOfficialAccounts;
    }

    public void setWeChatOfficialAccounts(String weChatOfficialAccounts) {
        this.weChatOfficialAccounts = weChatOfficialAccounts;
    }

    public String getUserZone() {
        return userZone;
    }

    public void setUserZone(String userZone) {
        this.userZone = userZone;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }
}
