package com.zjb.project.dsp.advertisementWithoutBiddingPrice.mapper;

import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.AdvertisementWithoutBiddingPrice;
import com.zjb.project.dsp.advertisingADExchange.domain.WithoutBiddingAd;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;

import java.util.List;

/**
 * 非竞价广告投放 数据层
 * 
 * @author jiangbingjie
 * @date 2020-03-30
 */
public interface AdvertisementWithoutBiddingPriceMapper 
{
	/**
     * 查询非竞价广告投放信息
     * 
     * @param id 非竞价广告投放ID
     * @return 非竞价广告投放信息
     */
	public AdvertisementWithoutBiddingPrice selectAdvertisementWithoutBiddingPriceById(Integer id);
	
	/**
     * 查询非竞价广告投放列表
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 非竞价广告投放集合
     */
	public List<AdvertisementWithoutBiddingPrice> selectAdvertisementWithoutBiddingPriceList(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
	
	/**
     * 新增非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	public int insertAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
	
	/**
     * 修改非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	public int updateAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
	
	/**
     * 删除非竞价广告投放
     * 
     * @param id 非竞价广告投放ID
     * @return 结果
     */
	public int deleteAdvertisementWithoutBiddingPriceById(Integer id);
	
	/**
     * 批量删除非竞价广告投放
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisementWithoutBiddingPriceByIds(String[] ids);

	/**
	 * 逻辑删除非竞价广告投放
	 *
	 * @param ids 需要删除的数据ID
	 * @return 结果
	 */
	public int logicDeleteAdvertisementWithoutBiddingPriceByIds(String[] ids);

	/**
	 * 获取胜出的非竞价广告信息
	 * @param withoutBiddingAd
	 * @return
	 */
	public List<AdvertisingUnit> getAdvertisingUnitFansInfo(WithoutBiddingAd withoutBiddingAd);
	
}