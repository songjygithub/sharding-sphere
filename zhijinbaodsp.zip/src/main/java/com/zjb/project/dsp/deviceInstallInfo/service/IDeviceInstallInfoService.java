package com.zjb.project.dsp.deviceInstallInfo.service;

import com.zjb.project.dsp.deviceInstallInfo.domain.DeviceInstallInfo;

import java.util.List;

/**
 * 设备安装 服务层
 *
 * @author songjy
 * @date 2019-11-30
 */
public interface IDeviceInstallInfoService {
    /**
     * 查询设备安装信息
     *
     * @param id 设备安装ID
     * @return 设备安装信息
     */
    DeviceInstallInfo selectDeviceInstallInfoById(Integer id);

    /**
     * 查询设备安装列表
     *
     * @param deviceInstallInfo 设备安装信息
     * @return 设备安装集合
     */
    List<DeviceInstallInfo> selectDeviceInstallInfoList(DeviceInstallInfo deviceInstallInfo);

    /**
     * 根據設備ID查詢設備安裝信息
     *
     * @param deviceId
     * @return
     */
    DeviceInstallInfo findByDeviceId(Integer deviceId);

    /**
     * 根据设备通讯号查询其安装信息
     *
     * @param deviceName 设备通讯号
     * @return 设备安装信息
     */
    DeviceInstallInfo findByDeviceName(String deviceName);


}
