package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import com.zjb.framework.web.controller.BaseController;

import java.util.List;

/**
 * 授权公司第三方平台信息
 * @author jiangbingjie
 * @date 2020/3/5 11:36 AM
 */
public class CompanyThirdPlatformData extends BaseController {
    private static final long serialVersionUID = 1L;
    /** 授权公司主体ID */
    private Integer value;
    /** 授权公司主体名称 */
    private String name;
    /**授权公司主体第三方平台*/
    private List<CompanyThirdPlatformData> children;

    public Integer getValue() {
        return value;
    }

    public void setValue(Integer value) {
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<CompanyThirdPlatformData> getChildren() {
        return children;
    }

    public void setChildren(List<CompanyThirdPlatformData> children) {
        this.children = children;
    }
}
