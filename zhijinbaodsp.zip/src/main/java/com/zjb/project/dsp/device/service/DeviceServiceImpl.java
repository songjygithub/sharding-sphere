package com.zjb.project.dsp.device.service;

import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.common.device.domain.DeviceDTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;

/**
 * @author songjy
 * @date 2019/07/27
 */
@Service
public class DeviceServiceImpl implements IDeviceService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Override
    public DeviceDTO selectDeviceById(Integer id) {

        String key = ZjbConstantsRedis.REDIS_DEVICE_INFO_ID + '_' + id;
        DeviceDTO device = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);

        if (null != device) {
            return device;
        }

        String sql = "SELECT * FROM `zjb_device` WHERE id = ? AND deleted = 0 LIMIT 1";

        return selectSingleDevice(sql, id);
    }

    @Override
    public DeviceDTO selectDeviceBySn(String sn) {
        String key = ZjbConstantsRedis.REDIS_DEVICE_INFO_SN + "_" + sn;
        DeviceDTO device = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);

        if (null != device) {
            return device;
        }

        String sql = "SELECT * FROM `zjb_device` WHERE sn = ? AND deleted = 0 LIMIT 1";

        return selectSingleDevice(sql, sn);
    }

    @Override
    public DeviceDTO selectByDeviceName(String deviceName) {

        if (StringUtils.isBlank(deviceName)) {
            logger.error("设备名称为空");
            return null;
        }

        String key = ZjbConstantsRedis.REDIS_DEVICE_INFO_NAME + '_' + deviceName;
        DeviceDTO device = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);
        if (null != device) {
            return device;
        }

        String sql = "SELECT * FROM `zjb_device` WHERE `name` = ? AND deleted = 0 LIMIT 1";

        return selectSingleDevice(sql, deviceName);
    }

    @Override
    public DeviceDTO selectByQrCode(String qrCode) {

    	DeviceDTO device = selectDeviceByQrcode(qrCode);

        if (null != device) {
            return device;
        }

        return selectDeviceByQrcodeb(qrCode);
    }

    @Override
    public DeviceDTO selectDeviceByQrcode(String qrcode) {
        String key = ZjbConstantsRedis.REDIS_DEVICE_INFO_QRCODE + "_" + qrcode;
        DeviceDTO device = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);

        if (null != device) {
            return device;
        }

        device = JedisPoolCacheUtils.getV(ZjbConstantsRedis.REDIS_DEVICE_INFO_QRCODEB + "_" + qrcode, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);

        if (null != device) {
            return device;
        }

        String sql = "SELECT * FROM `zjb_device` WHERE qrcode LIKE ? AND deleted = 0 LIMIT 1";

        return selectSingleDevice(sql, '%' + qrcode + '%');
    }

    @Override
    public DeviceDTO selectDeviceByQrcodeb(String qrcodeb) {

        String key = ZjbConstantsRedis.REDIS_DEVICE_INFO_QRCODEB + "_" + qrcodeb;

        DeviceDTO device = JedisPoolCacheUtils.getV(key, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);

        if (null != device) {
            return device;
        }

        device = JedisPoolCacheUtils.getV(ZjbConstantsRedis.REDIS_DEVICE_INFO_QRCODE + "_" + qrcodeb, ZjbConstantsRedis.ZJB_DB_4, DeviceDTO.class);
        if (null != device) {
            return device;
        }

        String sql = "SELECT * FROM `zjb_device` WHERE qrcodeb LIKE ? AND deleted = 0 LIMIT 1";

        return selectSingleDevice(sql, '%' + qrcodeb + '%');
    }

    @Override
    public DeviceDTO selectDeviceByMixId(String mixId) {

        if (mixId.length() == 16 || mixId.length() == 12) {
            /*整机sn*/
            return selectDeviceBySn(mixId);
        } else if (mixId.contains("/device/sa/")) {
            /*qrcode*/
            return selectDeviceByQrcode(mixId);
        } else if (mixId.contains("/device/sb/")) {
            /*qrcodeb*/
            return selectDeviceByQrcodeb(mixId);
        } else if (StringUtils.isNumeric(mixId) && mixId.length() <= 11) {
            /*设备id*/
            return selectDeviceById(Integer.parseInt(mixId));
        }

        return null;
    }

    /**
     * 根据代理商id获取设备信息
     * @param agencyId
     * @return
     */
    @Override
    public List<String> selectDeviceSnByAgencyId(Integer agencyId) {
        String sql = "SELECT sn FROM `zjb_device` WHERE agency_id = "+agencyId+" AND deleted = 0 ";
        return jdbcTemplate.query(sql, new RowMapper<String>() {
            @Nullable
            @Override
            public String mapRow(ResultSet rs, int rowNum) throws SQLException {
                return rs.getString("sn");
            }
        });
    }

    /**
     * 查询单条记录
     *
     * @param sql
     * @param mixId
     * @return
     */
    private DeviceDTO selectSingleDevice(String sql, Serializable mixId) {

        Object[] args = {mixId};
        String key = "device_mix_id_" + mixId + '_' + Constants.SYSTEM_ID;

        DeviceDTO record = JedisPoolCacheUtils.getV(key, ZJB_DB_50, DeviceDTO.class);

        if (null != record) {
            return record;
        }

        try {
            return jdbcTemplate.queryForObject(sql, args, new RowMapper<DeviceDTO>() {
                @Override
                public DeviceDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                	DeviceDTO device = new DeviceDTO();
                    device.setId(rs.getInt("id"));
                    device.setSn(rs.getString("sn"));
                    device.setQrcode(rs.getString("qrcode"));
                    device.setQrcodeb(rs.getString("qrcodeb"));
                    device.setAgencyId(null != rs.getObject("agency_id") ? rs.getInt("agency_id") : null);
                    device.setAgencyName(rs.getString("agency_name"));
                    device.setName(rs.getString("name"));
                    JedisPoolCacheUtils.setVExpire(key, device, EXRP_5_MINUTE * 3, ZJB_DB_50);
                    return device;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }
}
