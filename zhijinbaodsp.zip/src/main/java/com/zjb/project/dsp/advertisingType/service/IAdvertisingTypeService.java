package com.zjb.project.dsp.advertisingType.service;

import com.zjb.project.dsp.advertisingType.domain.AdvertisingType;

import java.util.List;

/**
 * 广告类型 服务层
 *
 * @author songjy
 * @date 2020-03-24
 */
public interface IAdvertisingTypeService {
    /**
     * 查询广告类型信息
     *
     * @param id 广告类型ID
     * @return 广告类型信息
     */
    AdvertisingType selectAdvertisingTypeById(Integer id);

    /**
     * 查询广告类型列表
     *
     * @param advertisingType 广告类型信息
     * @return 广告类型集合
     */
    List<AdvertisingType> selectAdvertisingTypeList(AdvertisingType advertisingType);

    /**
     * 新增广告类型
     *
     * @param advertisingType 广告类型信息
     * @return 结果
     */
    int insertAdvertisingType(AdvertisingType advertisingType);

    /**
     * 修改广告类型
     *
     * @param advertisingType 广告类型信息
     * @return 结果
     */
    int updateAdvertisingType(AdvertisingType advertisingType);

    /**
     * 删除广告类型信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingTypeByIds(String ids);

}
