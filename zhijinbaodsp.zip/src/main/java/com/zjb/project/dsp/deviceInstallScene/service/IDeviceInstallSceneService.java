package com.zjb.project.dsp.deviceInstallScene.service;

import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.domain.InstallScene;
import io.swagger.models.auth.In;

import java.util.List;

/**
 * @author jiangbingjie
 * @date 2020/2/27 12:52 AM
 */
public interface IDeviceInstallSceneService {

    List<InstallScene> selectInstallSceneTypeList();

    List<InstallScene> selectInstallSceneListByType(Integer sceneId);

    DeviceInstallScene getDeviceInstallSceneById(String sceneId);

    String getSceneIdsByCode(String codes);
}
