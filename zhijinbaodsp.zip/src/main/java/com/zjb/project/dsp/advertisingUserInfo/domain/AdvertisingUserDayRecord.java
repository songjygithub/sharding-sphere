package com.zjb.project.dsp.advertisingUserInfo.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;

/**
 * 用户当天查看广告记录
 *
 * @author songjy
 * @date 2019/08/13
 */
public class AdvertisingUserDayRecord implements Serializable {
    private static final long serialVersionUID = 1682888840051048689L;

    /**
     * 用户最后一次查看广告时间
     */
    private Date gmtLastAdvertising;

    /**
     * 最后查看的广告计划ID
     */
    private String lastPlanId;

    /**
     * 用户查看广告记录
     *  HashMap<广告计划ID, 投放次数>
     */
    private HashMap<String, Integer> advertisingRecord;

    public Date getGmtLastAdvertising() {
        return gmtLastAdvertising;
    }

    public void setGmtLastAdvertising(Date gmtLastAdvertising) {
        this.gmtLastAdvertising = gmtLastAdvertising;
    }

    public String getLastPlanId() {
        return lastPlanId;
    }

    public void setLastPlanId(String lastPlanId) {
        this.lastPlanId = lastPlanId;
    }

    public HashMap<String, Integer> getAdvertisingRecord() {
        return advertisingRecord;
    }

    public void setAdvertisingRecord(HashMap<String, Integer> advertisingRecord) {
        this.advertisingRecord = advertisingRecord;
    }
}
