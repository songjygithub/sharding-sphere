package com.zjb.project.dsp.appidOpenidIndex.service;

import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;

import java.util.Date;
import java.util.List;

/**
 * openid和appid关系 服务层
 *
 * @author songjy
 * @date 2019-11-01
 */
public interface IAppidOpenidIndexService {

    /**
     * 根据自增主键查询记录
     *
     * @param id
     * @return
     */
    AppIdOpenIdIndex selectById(Integer id);

    /**
     * 根据主键删除记录
     *
     * @param id
     * @return
     */
    int deleteById(Integer id);

    /**
     * 根据纸巾包平台用户opendId获取记录
     *
     * @param zjbOpenId
     * @return
     */
    List<AppIdOpenIdIndex> list(String zjbOpenId);

    /**
     * 根据openId和公众号查询记录
     *
     * @param openId 用户关注公众号后的唯一标识
     * @param appId  公众号
     * @return
     */
    AppIdOpenIdIndex selectByOpenIdAndAppId(String openId, String appId);

    /**
     * 根据zjbOpenId和公众号查询记录
     *
     * @param zjbOpenId
     * @param appId
     * @return
     */
    AppIdOpenIdIndex selectByZjbOpenIdAndAppId(String zjbOpenId, String appId);

    /**
     * 更新关注事件
     *
     * @param appIdOpenIdIndex
     * @return
     */
    int updateAppIdOpenIdIndexEvent(AppIdOpenIdIndex appIdOpenIdIndex);

    /**
     * 根据公众号和创建日期查询记录
     *
     * @param appId      公众号
     * @param createDate 创建日期, yyyy-MM-dd
     * @return
     */
    @Deprecated
    List<UserInfo> selectByAppIdAndCreateDate(String appId, Date createDate);

    /**
     * 按天统计公众号关注数
     *
     * @param appId
     * @return
     */
    @Deprecated
    List<ComponentGzhEvent> selectByAppIdGroupByDate(String appId);
}
