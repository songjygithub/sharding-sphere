package com.zjb.project.dsp.deviceInstallScene.service;

import com.zjb.common.constant.Constants;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.domain.InstallScene;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author jiangbingjie
 * @date 2020/2/27 12:55 AM
 */
@Service
public class DeviceInstallSceneServiceImpl implements IDeviceInstallSceneService{
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;


    @Override
    public List<InstallScene> selectInstallSceneTypeList() {
        String sql = "select scene_id, scene_name from zjb_device_install_scene WHERE deleted=0 AND parent_id = 0";

        return jdbcTemplate.query(sql, new RowMapper<InstallScene>() {
            @Nullable
            @Override
            public InstallScene mapRow(ResultSet rs, int rowNum) throws SQLException {
                InstallScene agency = new InstallScene();
                agency.setValue(rs.getInt("scene_id"));
                agency.setName(rs.getString("scene_name"));

                return agency;
            }
        });
    }

    @Override
    public List<InstallScene> selectInstallSceneListByType(Integer sceneId) {
        String sql = "select scene_id, scene_name from zjb_device_install_scene WHERE deleted=0 AND parent_id = "+sceneId;

        return jdbcTemplate.query(sql, new RowMapper<InstallScene>() {
            @Nullable
            @Override
            public InstallScene mapRow(ResultSet rs, int rowNum) throws SQLException {
                InstallScene agency = new InstallScene();
                agency.setValue(rs.getInt("scene_id"));
                agency.setName(rs.getString("scene_name"));

                return agency;
            }
        });
    }

    @Override
    public DeviceInstallScene getDeviceInstallSceneById(String sceneId) {
        String sql = "SELECT * FROM `zjb_device_install_scene` WHERE scene_id = ? AND deleted = 0 LIMIT 1";

        return selectSingleDeviceScene(sql, sceneId);
    }

    @Override
    public String getSceneIdsByCode(String codes) {
        if(StringUtils.isEmpty(codes)){
            return null;
        }
        Set<String> set = new HashSet<>();
        String[] codeList = codes.split(",");
        if(codeList == null || codeList.length<=0){
            return null;
        }
        for(String code : codeList){
            if(StringUtils.isNotEmpty(code)){
                DeviceInstallScene deviceInstallScene = getDeviceInstallSceneByCode(code);
                if(deviceInstallScene != null){
                    set.add(deviceInstallScene.getSceneId().toString());
                }
            }
        }
        if(set.size() == 0){
            return null;
        }
        String result = String.join(",", set);
        return result;
    }

    private DeviceInstallScene selectSingleDeviceScene(String sql, Serializable sceneValue) {

        Object[] args = {sceneValue};

        try {
            return jdbcTemplate.queryForObject(sql, args, new RowMapper<DeviceInstallScene>() {
                @Override
                public DeviceInstallScene mapRow(ResultSet rs, int rowNum) throws SQLException {
                    DeviceInstallScene deviceInstallScene = new DeviceInstallScene();
                    deviceInstallScene.setSceneId(rs.getInt("scene_id"));
                    deviceInstallScene.setSceneCode(rs.getString("scene_code"));
                    deviceInstallScene.setSceneName(rs.getString("scene_name"));
                    return deviceInstallScene;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }


    private DeviceInstallScene getDeviceInstallSceneByCode(String sceneCode) {
        String sql = "SELECT * FROM `zjb_device_install_scene` WHERE scene_code = ? AND deleted = 0 LIMIT 1";

        return selectSingleDeviceScene(sql, sceneCode);
    }
}
