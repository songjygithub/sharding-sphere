package com.zjb.project.dsp.advertisingCombination.domain;

import com.zjb.framework.web.domain.BaseEntity;


/**
 * 广告方案表 zjb_advertising_combination
 *
 * @author zjb
 * @date 2019-07-13
 */
public class AdvertisingCombination extends BaseEntity {
    private static final long serialVersionUID = 8505773240431361409L;

    /**
     * id
     */
    private Integer id;
    /**
     * 方案编号
     * */
    private String comId;
    /**
     * 方案名称
     */
    private String name;
    /**
     * 方案描述
     */
    private String description;
    /**
     * 方案类型  zjb_program_type
     */
    private Integer programType;
    /**
     * 方案类型名称
     */
    private String programTypeName;
    /**
     * 所属广告产品 zjb_ad_unit_type
     */
    private String adUnitType;

    /**
     * 广告模板 zjb_ad_template
     * */
    private String template;
    /**
     * 已配置广告计划数量
     * */
    private Integer advertisingPlanNum;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getComId() {
        return comId;
    }

    public void setComId(String comId) {
        this.comId = comId;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setProgramType(Integer programType) {
        this.programType = programType;
    }

    public Integer getProgramType() {
        return programType;
    }

    public String getProgramTypeName() {
        return programTypeName;
    }

    public void setProgramTypeName(String programTypeName) {
        this.programTypeName = programTypeName;
    }

    public void setAdUnitType(String adUnitType) {
        this.adUnitType = adUnitType;
    }

    public String getAdUnitType() {
        return adUnitType;
    }

    public String getTemplate() {
        return template;
    }

    public void setTemplate(String template) {
        this.template = template;
    }

    public Integer getAdvertisingPlanNum() {
        return advertisingPlanNum;
    }

    public void setAdvertisingPlanNum(Integer advertisingPlanNum) {
        this.advertisingPlanNum = advertisingPlanNum;
    }
}
