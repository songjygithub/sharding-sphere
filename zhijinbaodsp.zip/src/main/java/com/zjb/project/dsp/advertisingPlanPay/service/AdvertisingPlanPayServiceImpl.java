package com.zjb.project.dsp.advertisingPlanPay.service;

import java.io.Serializable;
import java.util.*;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.advertisingPlan.service.AdPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlan.service.AdvertisingPlanServiceImpl;
import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisingPlanPay.mapper.AdvertisingPlanPayMapper;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;
import com.zjb.common.support.Convert;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_OK;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_UNIT_TYPE_PAY;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_SECOND;

/**
 * 广告投放计划(支付) 服务层实现
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
@Service
public class AdvertisingPlanPayServiceImpl extends AdPlanServiceImpl implements IAdvertisingPlanPayService
{
	@Autowired
	private AdvertisingPlanPayMapper advertisingPlanPayMapper;
	@Autowired
	private IDeviceInstallSceneService deviceInstallSceneService;

	/**
     * 查询广告投放计划(支付)信息
     * 
     * @param id 广告投放计划(支付)ID
     * @return 广告投放计划(支付)信息
     */
    @Override
	public AdvertisingPlanPay selectAdvertisingPlanPayById(Serializable id)
	{
		if (null == id) {
			return null;
		}

		if (id.getClass() == Integer.class || id.getClass() == int.class) {
			return advertisingPlanPayMapper.selectAdvertisingPlanPayById((Integer) id);
		}

		if (id.getClass() == String.class && id.toString().startsWith(AD_UNIT_TYPE_PAY.getValue())) {
			return advertisingPlanPayMapper.selectAdvertisingPlanPayByPlanId((String) id);
		}

		return null;
	}
	
	/**
     * 查询广告投放计划(支付)列表
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 广告投放计划(支付)集合
     */
	@Override
	public List<AdvertisingPlanPay> selectAdvertisingPlanPayList(AdvertisingPlanPay advertisingPlanPay)
	{
	    return advertisingPlanPayMapper.selectAdvertisingPlanPayList(advertisingPlanPay);
	}
	
    /**
     * 新增广告投放计划(支付)
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
	@Override
	public int insertAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay)
	{
		advertisingPlanPay.setGmtCreated(new Date());
		advertisingPlanPay.setGmtModified(advertisingPlanPay.getGmtCreated());
		advertisingPlanPay.setModifierId(advertisingPlanPay.getCreaterId());
		if(StringUtils.isNotEmpty(advertisingPlanPay.getInstallSceneIds())){
			handleDeviceInstallScene(advertisingPlanPay);
		}

		int r = advertisingPlanPayMapper.insertAdvertisingPlanPay(advertisingPlanPay);

		if (r <= 0) {
			return r;
		}

		/*业务标识自增主键，且必须是06开头，即06 + id*/
		advertisingPlanPay.setPlanId(AD_UNIT_TYPE_PAY.getValue().toString() + advertisingPlanPay.getId());
		advertisingPlanPayMapper.updateAdvertisingPlanPay(advertisingPlanPay);

		/*保存广告投放定向信息*/
		r += insertTargetingInfo(advertisingPlanPay);

		AdvertisingPlanServiceImpl.synchronizeRedis(advertisingPlanPayMapper.selectAdvertisingPlanPayById(advertisingPlanPay.getId()));

		return r;
	}
	
	/**
     * 修改广告投放计划(支付)
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
	@Override
	public int updateAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay)
	{
		AdvertisingPlanPay advertisingPlanOld = advertisingPlanPayMapper.selectAdvertisingPlanPayById(advertisingPlanPay.getId());

		if (null == advertisingPlanOld) {
			return 0;
		}
		if(StringUtils.isNotEmpty(advertisingPlanPay.getInstallSceneIds())){
			handleDeviceInstallScene(advertisingPlanPay);
		}

		advertisingPlanPay.setGmtModified(new Date());

		setAdvertisingStatus(advertisingPlanPay, advertisingPlanOld);

		int r = advertisingPlanPayMapper.updateAdvertisingPlanPay(advertisingPlanPay);

		if (r <= 0) {
			return r;
		}

		synchronizeAdvertisingStatus(advertisingPlanPay);

		if (null != advertisingPlanPay && null != advertisingPlanPay.getAdvertisingStatus()
				&& !advertisingPlanPay.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
			/*该广告投放暂停*/
			clearLocalCacheRegex(advertisingPlanOld.getPlanId());
		}

		if (null != advertisingPlanPay && null != advertisingPlanPay.getAdvertisingStatus()
				&& advertisingPlanPay.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
				&& !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
				&& !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_PAUSE_MANUAL.getValue())) {
			/*该广告投放恢复*/
			reloadPattern(advertisingPlanOld.getPlanId());
		}

		/*修改广告投放定向信息*/
		r += updateTargetingInfo(advertisingPlanPay);

		AdvertisingPlanPay advertisingPlanNew = advertisingPlanPayMapper.selectAdvertisingPlanPayById(advertisingPlanPay.getId());
		AdvertisingPlanServiceImpl.synchronizeRedis(advertisingPlanNew);
		/*Redis中数据保存到数据库中*/
		advertisingPlanPayMapper.updateAdvertisingPlanPay(advertisingPlanNew);

		return r;
	}

	/**
     * 删除广告投放计划(支付)对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisingPlanPayByIds(String ids)
	{
		return advertisingPlanPayMapper.deleteAdvertisingPlanPayByIds(Convert.toStrArray(ids));
	}

	@Override
	public int logicDeleteAdvertisingPlanPayByIds(String ids) {
		String[] array = Convert.toStrArray(ids);
		int r = advertisingPlanPayMapper.logicDeleteAdvertisingPlanPayByIds(Convert.toStrArray(ids));

		/*清空缓存对应数据*/
		for (String id : array) {
			id = id.startsWith(AD_UNIT_TYPE_PAY.getValue()) ? id : (AD_UNIT_TYPE_PAY.getValue() + id);
			String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + id;
			clearLocalCacheRegex(id);
			JedisPoolCacheUtils.setVExpire(key, "", EXRP_SECOND, ZJB_DB_50);
		}

		return r;
	}

	@Override
	public List<AdvertisingPlanPay> selectByAdAppId(String adAppId) {
		return advertisingPlanPayMapper.selectByAdAppId(adAppId);
	}

	private void handleDeviceInstallScene(AdvertisingPlanPay advertisingPlanPay){
		if(StringUtils.isEmpty(advertisingPlanPay.getInstallSceneIds())){
			return;
		}
		Set<String> set = new HashSet<>();
		String[] sceneIds = advertisingPlanPay.getInstallSceneIds().split(",");
		if(sceneIds == null || sceneIds.length<=0){
			return;
		}
		for(String sceneId : sceneIds){
			DeviceInstallScene deviceInstallScene = deviceInstallSceneService.getDeviceInstallSceneById(sceneId);
			if(deviceInstallScene != null && StringUtils.isNotEmpty(deviceInstallScene.getSceneCode())){
				set.add(deviceInstallScene.getSceneCode());
			}
		}
		if(set.size() == 0){
			return;
		}
		advertisingPlanPay.setDeviceScene(String.join(",", set));

	}
	
}
