package com.zjb.project.dsp.blackPersonalAccountTemporary.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.blackPersonalAccountTemporary.domain.BlackPersonalAccountTemporary;
import com.zjb.project.dsp.blackPersonalAccountTemporary.service.IBlackPersonalAccountTemporaryService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 个人号黑名单临时 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-05-08
 */
@Controller
@RequestMapping("/dsp/blackPersonalAccountTemporary")
public class BlackPersonalAccountTemporaryController extends BaseController
{
    private String prefix = "dsp/blackPersonalAccountTemporary";
	
	@Autowired
	private IBlackPersonalAccountTemporaryService blackPersonalAccountTemporaryService;
	
	@RequiresPermissions("dsp:blackPersonalAccountTemporary:view")
	@GetMapping()
	public String blackPersonalAccountTemporary()
	{
	    return prefix + "/blackPersonalAccountTemporary";
	}
	
	/**
	 * 查询个人号黑名单临时列表
	 */
	@RequiresPermissions("dsp:blackPersonalAccountTemporary:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{
		startPage();
        List<BlackPersonalAccountTemporary> list = blackPersonalAccountTemporaryService.selectBlackPersonalAccountTemporaryList(blackPersonalAccountTemporary);
		return getDataTable(list);
	}
	
	/**
	 * 新增个人号黑名单临时
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存个人号黑名单临时
	 */
	@RequiresPermissions("dsp:blackPersonalAccountTemporary:add")
	@Log(title = "个人号黑名单临时", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{		
		return toAjax(blackPersonalAccountTemporaryService.insertBlackPersonalAccountTemporary(blackPersonalAccountTemporary));
	}

	/**
	 * 修改个人号黑名单临时
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		BlackPersonalAccountTemporary blackPersonalAccountTemporary = blackPersonalAccountTemporaryService.selectBlackPersonalAccountTemporaryById(id);
		mmap.put("blackPersonalAccountTemporary", blackPersonalAccountTemporary);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存个人号黑名单临时
	 */
	@RequiresPermissions("dsp:blackPersonalAccountTemporary:edit")
	@Log(title = "个人号黑名单临时", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{		
		return toAjax(blackPersonalAccountTemporaryService.updateBlackPersonalAccountTemporary(blackPersonalAccountTemporary));
	}
	
	/**
	 * 删除个人号黑名单临时
	 */
	@RequiresPermissions("dsp:blackPersonalAccountTemporary:remove")
	@Log(title = "个人号黑名单临时", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(blackPersonalAccountTemporaryService.deleteBlackPersonalAccountTemporaryByIds(ids));
	}
	
}
