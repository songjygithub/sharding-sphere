package com.zjb.project.dsp.agency.service;

import com.zjb.project.dsp.agency.domain.Agency;

import java.util.List;

/**
 * 代理商 服务层
 *
 * @author songjy
 * @date 2019-07-18
 */
public interface IAgencyService {

    /**
     * 通过主键查询代理商信息
     *
     * @param id
     * @return
     */
    Agency findById(Integer id);

    /**
     * 查询代理商列表
     *
     * @param agency 代理商信息
     * @return 代理商集合
     */
    List<Agency> selectAgencyList(Agency agency);

    /**
     * 获取代理商名下设备免费取纸次数
     *
     * @param id 代理商id
     * @return 结果
     */
    Agency getMaxCount(Integer id);

}
