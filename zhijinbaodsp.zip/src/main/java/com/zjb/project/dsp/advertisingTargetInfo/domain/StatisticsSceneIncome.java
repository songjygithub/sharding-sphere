package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author songjy
 * @date 2020-02-06
 */
public class StatisticsSceneIncome implements Serializable {
    private static final long serialVersionUID = -202564840036276795L;

    /**
     * 设备安装场景名稱
     */
    @Excel(name = "设备安装场景")
    private String deviceSceneName;

    /**
     * 广告收益（元）
     */
    @Excel(name = "广告收益（元）")
    private BigDecimal income;

    /**
     * 代理商分成（元）
     */
    @Excel(name = "代理商分成（元）")
    private BigDecimal benefit;

    /**
     * 利润（元）
     */
    @Excel(name = "利润（元）")
    private BigDecimal profit;

    public String getDeviceSceneName() {
        return deviceSceneName;
    }

    public void setDeviceSceneName(String deviceSceneName) {
        this.deviceSceneName = deviceSceneName;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getBenefit() {
        return benefit;
    }

    public void setBenefit(BigDecimal benefit) {
        this.benefit = benefit;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }
}
