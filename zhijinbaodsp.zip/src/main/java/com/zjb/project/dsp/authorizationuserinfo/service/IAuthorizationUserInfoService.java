package com.zjb.project.dsp.authorizationuserinfo.service;

import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;

/**
 * @author songjy
 * @Date 2019/11/18
 **/
public interface IAuthorizationUserInfoService {

    /**
     * 根据openId从OTS中查询授权用户信息
     *
     * @param openId
     * @return
     */
    AuthorizationUserInfoDTO selectAuthorizationUserInfoByOpenId(String openId);

    /**
     * 修改授权用户
     *
     * @param authorizationUserInfo 授权用户信息
     * @return 结果
     */
    int updateAuthorizationUserInfo(AuthorizationUserInfoDTO authorizationUserInfo);
}
