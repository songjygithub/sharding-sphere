package com.zjb.project.dsp.gzhGroup.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * 公众号组 服务层实现
 *
 * @author zjb
 * @date 2019-07-12
 */
@Service
public class GzhGroupServiceImpl implements IGzhGroupService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private GzhGroupMapper gzhGroupMapper;



    /**
     * 查询公众号组信息
     *
     * @param id 公众号组ID
     * @return 公众号组信息
     */
    @Override
    public GzhGroup selectGzhGroupById(Integer id) {
        return gzhGroupMapper.selectGzhGroupById(id);
    }

    @Override
    public GzhGroup selectGzhGroupByGroupId(String groupId) {
        return gzhGroupMapper.selectGzhGroupByGroupId(groupId);
    }

    /**
     * 查询公众号组列表
     *
     * @param gzhGroup 公众号组信息
     * @return 公众号组集合
     */
    @Override
    public List<GzhGroup> selectGzhGroupList(GzhGroup gzhGroup) {
        return gzhGroupMapper.selectGzhGroupList(gzhGroup);
    }

    @Override
    public List<GzhxcxInfo> selectGzhByGroupId(Integer id) {
        return gzhGroupMapper.selectGzhByGroupId(id);
    }

    /**
     * 新增公众号组
     *
     * @param gzhGroup 公众号组信息
     * @return 结果
     */
    @Override
    public int insertGzhGroup(GzhGroup gzhGroup) {
        gzhGroup.setGmtCreated(new Date());
        gzhGroup.setGmtModified(gzhGroup.getGmtCreated());
        int r = gzhGroupMapper.insertGzhGroup(gzhGroup);

        if (r > 0) {
            gzhGroup.setGroupId(ZjbDictionaryEnum.AD_FAN_GROUP_COMBINATION_UNIT_PREFIX.getValue().toString() + gzhGroup.getId());
            r += gzhGroupMapper.updateGzhGroup(gzhGroup);
        }
        return r;
    }

    /**
     * 修改公众号组
     *
     * @param gzhGroup 公众号组信息
     * @return 结果
     */
    @Override
    public int updateGzhGroup(GzhGroup gzhGroup) {
        gzhGroup.setGmtModified(new Date());
        return gzhGroupMapper.updateGzhGroup(gzhGroup);
    }

    /**
     * 删除公众号组对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteGzhGroupByIds(String ids) {
        return gzhGroupMapper.deleteGzhGroupByIds(Convert.toStrArray(ids));
    }

}
