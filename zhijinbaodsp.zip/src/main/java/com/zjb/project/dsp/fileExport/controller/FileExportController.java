package com.zjb.project.dsp.fileExport.controller;

import com.aliyun.oss.model.OSSObject;
import com.zjb.common.utils.OssUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.fileExport.domain.FileExport;
import com.zjb.project.dsp.fileExport.service.IFileExportService;
import com.zjb.project.system.user.domain.User;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.InputStream;
import java.net.URLEncoder;
import java.util.List;

/**
 * 导出文件记录 信息操作处理
 *
 * @author songjy
 * @date 2020-06-20
 */
@Controller
@RequestMapping("/dsp/fileExport")
public class FileExportController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "dsp/fileExport";

    @Autowired
    private IFileExportService fileExportService;

    @RequiresPermissions("dsp:fileExport:view")
    @GetMapping()
    public String fileExport() {
        return prefix + "/fileExport";
    }

    /**
     * 查询导出文件记录列表
     */
    @RequiresPermissions("dsp:fileExport:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(FileExport fileExport) {
        startPage();
        List<FileExport> list = fileExportService.selectFileExportList(fileExport);
        for (FileExport e : list) {
            User user = getUser(e.getCreaterId());
            e.setCreateBy(null == user ? null : user.getUserName());

            user = getUser(e.getModifierId());
            e.setUpdateBy(null == user ? null : user.getUserName());
        }
        return getDataTable(list);
    }

    /**
     * 新增导出文件记录
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存导出文件记录
     */
    @RequiresPermissions("dsp:fileExport:add")
    @Log(title = "导出文件记录", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(FileExport fileExport) {
        return toAjax(fileExportService.insertFileExport(fileExport));
    }

    /**
     * 修改导出文件记录
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        FileExport fileExport = fileExportService.selectFileExportById(id);
        mmap.put("fileExport", fileExport);
        return prefix + "/edit";
    }

    /**
     * 修改保存导出文件记录
     */
    @RequiresPermissions("dsp:fileExport:edit")
    @Log(title = "导出文件记录", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(FileExport fileExport) {
        return toAjax(fileExportService.updateFileExport(fileExport));
    }

    /**
     * 删除导出文件记录
     */
    @RequiresPermissions("dsp:fileExport:remove")
    @Log(title = "导出文件记录", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(fileExportService.deleteFileExportByIds(ids));
    }

    @RequiresPermissions("dsp:fileExport:list")
    @Log(title = "导出文件下载", businessType = BusinessType.EXPORT)
    @RequestMapping("/download")
    public void fileDownload(FileExport fileExport, HttpServletResponse response) {
        fileExport = fileExportService.selectFileExportById(fileExport.getId());
        response.setCharacterEncoding("utf-8");
        response.setContentType("multipart/form-data;charset=UTF-8");
        try (BufferedOutputStream outputStream = new BufferedOutputStream(response.getOutputStream());
             OSSObject ossObject = OssUtil.downloadFile(fileExport.getFileKey());
             InputStream inputStream = ossObject.getObjectContent()) {
            response.setHeader("Content-Disposition", "attachment;fileName=" + URLEncoder.encode(fileExport.getFileName(), "utf-8"));
            byte[] car = new byte[1024];
            int len;
            while ((len = inputStream.read(car)) != -1) {
                outputStream.write(car, 0, len);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
    }

}
