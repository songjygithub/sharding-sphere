package com.zjb.project.dsp.backupFileRecord.mapper;

import com.zjb.project.dsp.backupFileRecord.domain.BackupFileRecord;

import java.util.List;

/**
 * 文件备份记录 数据层
 *
 * @author songjy
 * @date 2019-08-27
 */
public interface BackupFileRecordMapper {
    /**
     * 查询文件备份记录信息
     *
     * @param id 文件备份记录ID
     * @return 文件备份记录信息
     */
    BackupFileRecord selectBackupFileRecordById(Integer id);

    /**
     * 根据文件MD5值查询记录
     *
     * @param md5 文件MD5值
     * @return 文件备份记录信息
     */
    BackupFileRecord selectByMD5(String md5);

    /**
     * 查询文件备份记录列表
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 文件备份记录集合
     */
    List<BackupFileRecord> selectBackupFileRecordList(BackupFileRecord backupFileRecord);

    /**
     * 新增文件备份记录
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 结果
     */
    int insertBackupFileRecord(BackupFileRecord backupFileRecord);

    /**
     * 修改文件备份记录
     *
     * @param backupFileRecord 文件备份记录信息
     * @return 结果
     */
    int updateBackupFileRecord(BackupFileRecord backupFileRecord);

    /**
     * 删除文件备份记录
     *
     * @param id 文件备份记录ID
     * @return 结果
     */
    int deleteBackupFileRecordById(Integer id);

    /**
     * 批量删除文件备份记录
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteBackupFileRecordByIds(String[] ids);

}