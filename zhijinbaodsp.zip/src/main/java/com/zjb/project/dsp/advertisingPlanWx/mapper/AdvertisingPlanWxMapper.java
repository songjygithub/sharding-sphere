package com.zjb.project.dsp.advertisingPlanWx.mapper;

import java.util.List;

import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;

/**
 * 广告投放计划 数据层
 *
 * @author songjy
 * @date 2019-08-19
 */
public interface AdvertisingPlanWxMapper {
    /**
     * 查询广告投放计划信息
     *
     * @param id 广告投放计划ID
     * @return 广告投放计划信息
     */
    AdvertisingPlanWx selectAdvertisingPlanWxById(Integer id);

    /**
     * 查询广告投放计划列表
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 广告投放计划集合
     */
    List<AdvertisingPlanWx> selectAdvertisingPlanWxList(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 新增广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    int insertAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 修改广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    int updateAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx);

    /**
     * 删除广告投放计划
     *
     * @param id 广告投放计划ID
     * @return 结果
     */
    int deleteAdvertisingPlanWxById(Integer id);

    /**
     * 批量删除广告投放计划
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanWxByIds(String[] ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param arr
     * @return
     */
    int logicDeleteAdvertisingPlanWxByIds(String[] arr);

    /**
     * 广告投放计划业务主键ID
     *
     * @param planId
     * @return
     */
    AdvertisingPlanWx selectAdvertisingPlanWxByPlanId(String planId);

    /**
     * 根据公众号查询广告投放计划
     *
     * @param adAppId
     * @return
     */
    List<AdvertisingPlanWx> selectByAdAppId(String adAppId);
}