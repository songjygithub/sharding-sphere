package com.zjb.project.dsp.fileExport.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 导出文件记录表 sys_file_export
 *
 * @author songjy
 * @date 2020-06-20
 */
public class FileExport extends BaseEntity {
    private static final long serialVersionUID = -3435177376859453504L;

    /**
     * 主键Id
     */
    private Integer id;
    /**
     * 文件名
     */
    private String fileName;
    /**
     * 文件类型
     */
    private Integer fileType;
    /**
     * OSS的fileKey
     */
    private String fileKey;
    /**
     * 文件格式
     */
    private String fileForm;
    /**
     * 文件状态：0、正在导出，1、导出成功，2、导出失败，3、文件已过期
     */
    private Integer status;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileType(Integer fileType) {
        this.fileType = fileType;
    }

    public Integer getFileType() {
        return fileType;
    }

    public void setFileKey(String fileKey) {
        this.fileKey = fileKey;
    }

    public String getFileKey() {
        return fileKey;
    }

    public void setFileForm(String fileForm) {
        this.fileForm = fileForm;
    }

    public String getFileForm() {
        return fileForm;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getStatus() {
        return status;
    }
}
