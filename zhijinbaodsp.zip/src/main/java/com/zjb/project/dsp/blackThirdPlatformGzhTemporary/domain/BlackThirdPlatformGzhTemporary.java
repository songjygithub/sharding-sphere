package com.zjb.project.dsp.blackThirdPlatformGzhTemporary.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
											import java.util.Date;

/**
 * 公众号黑名单临时表 zjb_black_third_platform_gzh_temporary
 * 
 * @author jiangbingjie
 * @date 2020-05-07
 */
public class BlackThirdPlatformGzhTemporary extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 自增主键 */
	private Integer id;
	/** 第三方平台标识(参考字典) */
	private String thirdPlatformChannel;
	/** 第三方平台公众号唯一标识 */
	private String thirdPlatformAppId;
	/** 第三方平台公众号名称 */
	private String thirdPlatformAppName;
	/** 用户扫码流水号，多个之间用英文逗号分隔 */
	private String randomNums;
	/**
	 * 加入黑名单类型（1:人数，2:次数）
	 */
	protected Integer joinBlackType;
	/**结束时间 非数据库映射字段*/
	private String createTimeEnd;



	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setThirdPlatformChannel(String thirdPlatformChannel) 
	{
		this.thirdPlatformChannel = thirdPlatformChannel;
	}

	public String getThirdPlatformChannel() 
	{
		return thirdPlatformChannel;
	}
	public void setThirdPlatformAppId(String thirdPlatformAppId) 
	{
		this.thirdPlatformAppId = thirdPlatformAppId;
	}

	public String getThirdPlatformAppId() 
	{
		return thirdPlatformAppId;
	}
	public void setThirdPlatformAppName(String thirdPlatformAppName) 
	{
		this.thirdPlatformAppName = thirdPlatformAppName;
	}

	public String getThirdPlatformAppName() 
	{
		return thirdPlatformAppName;
	}
	public void setRandomNums(String randomNums) 
	{
		this.randomNums = randomNums;
	}

	public String getRandomNums() 
	{
		return randomNums;
	}

	public Integer getJoinBlackType() {
		return joinBlackType;
	}

	public void setJoinBlackType(Integer joinBlackType) {
		this.joinBlackType = joinBlackType;
	}

	public String getCreateTimeEnd() {
		return createTimeEnd;
	}

	public void setCreateTimeEnd(String createTimeEnd) {
		this.createTimeEnd = createTimeEnd;
	}

	public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("thirdPlatformChannel", getThirdPlatformChannel())
            .append("thirdPlatformAppId", getThirdPlatformAppId())
            .append("thirdPlatformAppName", getThirdPlatformAppName())
            .append("randomNums", getRandomNums())
            .append("createTime", getCreateTime())
            .append("createrId", getCreaterId())
            .append("modifierId", getModifierId())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("deleted", getDeleted())
            .toString();
    }
}
