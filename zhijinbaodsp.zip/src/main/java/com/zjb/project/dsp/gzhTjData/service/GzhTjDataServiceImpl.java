package com.zjb.project.dsp.gzhTjData.service;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.*;

import cn.hutool.core.date.DateUtil;
import cn.hutool.core.util.ArrayUtil;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.gzhTjData.mapper.GzhTjDataMapper;
import com.zjb.project.dsp.gzhTjData.domain.GzhTjData;
import com.zjb.project.dsp.gzhTjData.service.IGzhTjDataService;
import com.zjb.common.support.Convert;

import static com.zjb.common.constant.ZjbConstantsRedis.*;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_57;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.common.enums.ZjbDictionaryEnum.VERIFIED;

/**
 * 公众号关注数据 服务层实现
 * 
 * @author shenlong
 * @date 2020-01-04
 */
@Service
public class GzhTjDataServiceImpl implements IGzhTjDataService 
{
	private Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
	@Autowired
	@Qualifier(value = Constants.DB_ZJB_ID)
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private GzhTjDataMapper gzhTjDataMapper;

	/**
     * 查询公众号关注数据信息
     * 
     * @param id 公众号关注数据ID
     * @return 公众号关注数据信息
     */
    @Override
	public GzhTjData selectGzhTjDataById(Integer id)
	{
	    return gzhTjDataMapper.selectGzhTjDataById(id);
	}
	
	/**
     * 查询公众号关注数据列表
     * 
     * @param gzhTjData 公众号关注数据信息
     * @return 公众号关注数据集合
     */
	@Override
	public List<GzhTjData> selectGzhTjDataList(GzhTjData gzhTjData)
	{
	    return gzhTjDataMapper.selectGzhTjDataList(gzhTjData);
	}
	
    /**
     * 新增公众号关注数据
     * 
     * @param gzhTjData 公众号关注数据信息
     * @return 结果
     */
	@Override
	public int insertGzhTjData(GzhTjData gzhTjData)
	{
	    return gzhTjDataMapper.insertGzhTjData(gzhTjData);
	}
	
	/**
     * 修改公众号关注数据
     * 
     * @param gzhTjData 公众号关注数据信息
     * @return 结果
     */
	@Override
	public int updateGzhTjData(GzhTjData gzhTjData)
	{
	    return gzhTjDataMapper.updateGzhTjData(gzhTjData);
	}

	/**
     * 删除公众号关注数据对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGzhTjDataByIds(String ids)
	{
		return gzhTjDataMapper.deleteGzhTjDataByIds(Convert.toStrArray(ids));
	}
	/**
	 * 查询公众号关注数据列表
	 *
	 * @param gzhTjData 公众号关注数据信息
	 * @return 公众号关注数据集合
	 */
	@Override
	public List<GzhTjData> selectGzhTjDataListByAppIds(GzhTjData gzhTjData){
		if(ArrayUtil.isNotEmpty(gzhTjData.getAppIds())){
			for(String s :gzhTjData.getAppIds()){
				handleTodayData(s);
			}
		}

		return gzhTjDataMapper.selectGzhTjDataListByAppIds(gzhTjData);
	}

	private void handleTodayData(String appId){

		long start = System.currentTimeMillis();

		ComponentAuthorizationInfo authorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(appId);


		if (null == authorizationInfo) {
			logger.error("微信公众号【{}】不存在", appId);
			return;
		}
		String dateSql ;
		if (VERIFIED.getValue().equals(authorizationInfo.getVerifyTypeInfo()) ) {
			dateSql = "SELECT DISTINCT `gmt_date` FROM `zjb_component_gzh_event` WHERE `appid` = ?";
		}else {
			dateSql = "SELECT DISTINCT `create_date` FROM `zjb_appid_openid_index` WHERE `appid` = ?";
		}

		List<Date> listDate = jdbcTemplate.queryForList(dateSql, new Object[]{appId}, new int[]{Types.VARCHAR}, Date.class);

		if (null == listDate || listDate.isEmpty()) {
			logger.warn("微信公众号【{}】未投放", appId);
			return;
		}
		if(! DateUtil.isSameDay(listDate.get(listDate.size()-1),DateUtils.getNowDate())){
			logger.warn("微信公众号【{}】没有{}数据", appId,DateUtils.getNowDate());
			return;
		}
		String openIdSql;
		if (authorizationInfo.getComponentAuthorizationType().equals(MANUAL_ADD.getValue()) || authorizationInfo.getComponentAuthorizationType().equals(MANUAL_GROUND.getValue())) {
			openIdSql = "SELECT DISTINCT `zjb_openid` FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `gmt_date` = ? AND `event` = ?";
		} else {
			openIdSql = "SELECT DISTINCT `openid` FROM `zjb_component_gzh_event` WHERE `appid` = ? AND `gmt_date` = ? AND `event` = ?";
		}
		Date date = DateUtils.dateTime("yyyy-MM-dd",DateUtils.getDate());

		int[] argTypes = {Types.VARCHAR, Types.VARCHAR, Types.VARCHAR};
		ComponentGzhEvent gzhEvent = new ComponentGzhEvent();
		gzhEvent.setAppid(appId);
		String gmtDate = DateUtils.toLocalDateTime(date).toLocalDate().toString();
		gzhEvent.setDate(gmtDate);
		gzhEvent.setGmtDate(date);
		Object[] args = {appId, gmtDate, AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue()};
		List<String> openIdSubscribe = jdbcTemplate.queryForList(openIdSql, args, argTypes, String.class);
		gzhEvent.setSubscribeCount(null == openIdSubscribe ? 0 : openIdSubscribe.size());
		args[2] = AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue();
		List<String> openIdUnSubscribe = jdbcTemplate.queryForList(openIdSql, args, argTypes, String.class);
		gzhEvent.setUnSubscribeCount(null == openIdUnSubscribe ? 0 : openIdUnSubscribe.size());

		if (null != openIdSubscribe && null != openIdUnSubscribe) {
			openIdSubscribe.retainAll(openIdUnSubscribe);
			gzhEvent.setSamedayUnSubscribeCount(openIdSubscribe.size());
		}

		GzhTjData gzhTjData = new GzhTjData();
		gzhTjData.setAppid(appId);
		gzhTjData.setGzhFromType(ZjbDictionaryEnum.AUTHORIZE_ADD.getValue());
		gzhTjData.setNickName(authorizationInfo.getNickName());
		if(VERIFIED.getValue().equals(authorizationInfo.getVerifyTypeInfo()) || OTHER_VERIFIED.getValue().equals(authorizationInfo.getVerifyTypeInfo()) ){
			gzhTjData.setSubscribeCount(gzhEvent.getSubscribeCount());
			gzhTjData.setSameDayUnsubscribeCount(gzhEvent.getSamedayUnSubscribeCount());
			gzhTjData.setUnsubscribeCount(gzhEvent.getUnSubscribeCount());
			if(gzhEvent.getUnSubscribeCount() > 0 && gzhEvent.getSubscribeCount() > 0 ){
				BigDecimal divide = new BigDecimal(gzhEvent.getUnSubscribeCount()).divide(new BigDecimal(gzhEvent.getSubscribeCount()), 4, BigDecimal.ROUND_HALF_UP);
				gzhTjData.setUnsubscribeRate(divide);
			}else{
				gzhTjData.setUnsubscribeRate(new BigDecimal(0));
			}
			if(gzhEvent.getSamedayUnSubscribeCount() > 0 && gzhEvent.getSubscribeCount() > 0){
				BigDecimal divide = new BigDecimal(gzhEvent.getSamedayUnSubscribeCount()).divide(new BigDecimal(gzhEvent.getSubscribeCount()), 4, BigDecimal.ROUND_HALF_UP);
				gzhTjData.setSameDayUnsubscribeRate(divide);
			}
		}else{
			if(authorizationInfo.getComponentAuthorizationType().equals(MANUAL_ADD.getValue()) || authorizationInfo.getComponentAuthorizationType().equals(MANUAL_GROUND.getValue())){
				gzhTjData.setSubscribeCount(gzhEvent.getSubscribeCount());
			}else{
				// 未认证
				String tjKey = ZjbConstantsRedis.UNVERIFIED_GZH_DATA + "_" + gmtDate + "_" + appId;
				String tjData = JedisPoolCacheUtils.getVStr(tjKey, ZjbConstantsRedis.ZJB_DB_6);
				if(StringUtils.isBlank(tjData)){
					gzhTjData.setSubscribeCount(0);
				}else{
					gzhTjData.setSubscribeCount(Integer.valueOf(tjData));
				}
			}

		}

		gzhTjData.setTjDate(date);
		gzhTjData.setGmtCreated(new Date());

		// 获取二维码的pv和uv
		String pvKey = ZJB_GZH_QRCODE_PV + "_" + appId + "_" + gmtDate ;
		String pvValue = JedisPoolCacheUtils.getVStr(pvKey, ZJB_DB_57);
		if(StringUtils.isBlank(pvValue)){
			gzhTjData.setQrcodePv(0);
		}else{
			gzhTjData.setQrcodePv(Integer.parseInt(pvValue));
		}
		// UV
		String uvNewKey = ZJB_GZH_QRCODE_NEW_UV + "_" + appId + "_" + gmtDate ;
		String uvOldKey = ZJB_GZH_QRCODE_OLD_UV + "_" + appId + "_" + gmtDate ;
		Long scardNew = JedisPoolCacheUtils.scard(uvNewKey, ZJB_DB_57);
		if (scardNew == null) {
			gzhTjData.setQrcodeNewUv(0);
		} else {
			gzhTjData.setQrcodeNewUv(scardNew.intValue());
		}
		Long scardOld = JedisPoolCacheUtils.scard(uvOldKey, ZJB_DB_57);
		if (scardOld == null) {
			gzhTjData.setQrcodeOldUv(0);
		} else {
			gzhTjData.setQrcodeOldUv(scardOld.intValue());
		}

		GzhTjData gzhTjData1 = new GzhTjData();
		gzhTjData1.setAppid(appId);
		gzhTjData1.setTjDate(date);
		List<GzhTjData> gzhTjData2 = gzhTjDataMapper.selectGzhTjDataList(gzhTjData1);
		if(CollectionUtils.isNotEmpty(gzhTjData2)){
			GzhTjData gzhTjData3 = gzhTjData2.get(0);
			gzhTjData.setId(gzhTjData3.getId());
			updateGzhTjData(gzhTjData);
		}else{
			insertGzhTjData(gzhTjData);
		}

		logger.info("公众号【{}】的关注和取关数据统计耗时（秒）：{}", authorizationInfo.getNickName(), (System.currentTimeMillis() - start) / 1000);
	}
}
