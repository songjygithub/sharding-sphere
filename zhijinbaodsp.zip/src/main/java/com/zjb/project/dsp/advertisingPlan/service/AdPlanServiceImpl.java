package com.zjb.project.dsp.advertisingPlan.service;

import com.alibaba.fastjson.JSON;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.zjb.common.constant.AdvertisingConstants;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.mapper.AdvertisingPlanMapper;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.mapper.AdvertisingPlanDeviceMapper;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.mapper.AdvertisingPlanFansMapper;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;
import com.zjb.project.dsp.advertisingPlanPay.mapper.AdvertisingPlanPayMapper;
import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;
import com.zjb.project.dsp.advertisingPlanPepole.mapper.AdvertisingPlanPepoleMapper;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.mapper.AdvertisingPlanWxMapper;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.mapper.AdvertisingUnitMapper;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.mapper.AdvertisingUnitWxMapper;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.mapper.MediumSellRullMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MONTH;

/**
 * @author songjy
 * @date 2019/08/19
 */
public abstract class AdPlanServiceImpl implements IAdPlanService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 竞价胜出广告计划信息缓存：key=广告计划ID  value=胜出广告信息
     */
    private static final Cache<String, AdvertisingPlan> LOCAL_CACHE_WIN_PLAN = CacheBuilder.newBuilder()
            .expireAfterWrite(30, TimeUnit.MINUTES)
            .build();

    @Autowired
    protected AdvertisingPlanDeviceMapper advertisingPlanDeviceMapper;
    @Autowired
    protected AdvertisingPlanPepoleMapper advertisingPlanPepoleMapper;
    @Autowired
    protected IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    protected IAdvertisingPlanPepoleService advertisingPlanPepoleService;
    @Autowired
    protected AdvertisingPlanMapper advertisingPlanMapper;
    @Autowired
    protected AdvertisingPlanWxMapper advertisingPlanWxMapper;
    @Autowired
    protected AdvertisingPlanFansMapper advertisingPlanFansMapper;
    @Autowired
    protected AdvertisingUnitMapper advertisingUnitMapper;
    @Autowired
    protected AdvertisingUnitWxMapper advertisingUnitWxMapper;
    @Autowired
    protected AdvertisingPlanPayMapper advertisingPlanPayMapper;
    @Autowired
    private MediumSellRullMapper mediumSellRullMapper;

    @Override
    public void clearLocalCacheRegex(String planId) {

        String key = AD_PLAN_ID_PREFIX + '_' + planId;
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
        setAdvertisingStatus(planFromRedis);

        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(planId);
        advertisingPlanDeviceService.removePattern(advertisingPlanDevice);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_REMOVE_DEVICE, advertisingPlanDevice);
        AdvertisingPlanPepole advertisingPlanPepole = advertisingPlanPepoleMapper.selectAdvertisingPlanPepoleByPlanId(planId);
        advertisingPlanPepoleService.removePattern(advertisingPlanPepole);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_REMOVE_PEOPLE, advertisingPlanPepole);


    }

    /**
     * 投放状态同步
     *
     * @param planFromRedis
     */
    private void setAdvertisingStatus(AdvertisingPlan planFromRedis) {

        if (null == planFromRedis || StringUtils.isBlank(planFromRedis.getPlanId())) {
            return;
        }

        String planId = planFromRedis.getPlanId();
        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())) {
            AdvertisingPlan aliPay = new AdvertisingPlan();
            aliPay.setId(planFromRedis.getId());
            aliPay.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());
            advertisingPlanMapper.updateAdvertisingPlan(aliPay);
        } else if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())) {
            AdvertisingPlanWx planWx = new AdvertisingPlanWx();
            planWx.setId(planFromRedis.getId());
            planWx.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());
            advertisingPlanWxMapper.updateAdvertisingPlanWx(planWx);
        } else if (planId.startsWith(AD_UNIT_TYPE_FANS.getValue())) {
            AdvertisingPlanFans planFans = new AdvertisingPlanFans();
            planFans.setId(planFromRedis.getId());
            planFans.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());
            advertisingPlanFansMapper.updateAdvertisingPlanFans(planFans);
        } else if (planId.startsWith(AD_UNIT_TYPE_PAY.getValue())) {
            AdvertisingPlanPay planPay = new AdvertisingPlanPay();
            planPay.setId(planFromRedis.getId());
            planPay.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());
            advertisingPlanPayMapper.updateAdvertisingPlanPay(planPay);
        }

    }

    @Override
    public void reloadPattern(String planId) {

        if (!valid(planId)) {
            return;
        }

        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(planId);
        advertisingPlanDeviceService.addPattern(advertisingPlanDevice);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_ADD_DEVICE, advertisingPlanDevice);
        AdvertisingPlanPepole advertisingPlanPepole = advertisingPlanPepoleMapper.selectAdvertisingPlanPepoleByPlanId(planId);
        advertisingPlanPepoleService.addPattern(advertisingPlanPepole);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_ADD_PEOPLE, advertisingPlanPepole);
    }

    /**
     * 广告投放计划之取纸位广告是否有效
     *
     * @param planId
     * @return
     */
    protected boolean valid(String planId) {

        if (StringUtils.isBlank(planId)) {
            logger.error("广告投放计划ID为空");
            return false;
        }

        if (!planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_PAY.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_FANS.getValue())) {
            logger.error("广告投放计划ID【{}】格式错误", planId);
            return false;
        }

        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())) {

            AdvertisingPlan planAliPay = advertisingPlanMapper.selectAdvertisingPlanByPlanId(planId);

            if (null == planAliPay) {
                logger.error("广告投放计划ID【{}】不存在或已删除", planId);
                return false;
            }

            List<AdvertisingUnit> listUnit = advertisingUnitMapper.selectAdvertisingUnitListByCombinationId(planAliPay.getCombinationId());

            if (null == listUnit || listUnit.isEmpty()) {
                logger.error("广告投放计划ID【{}】未设置广告单元", planId);
                return false;
            }

            List<AdvertisingUnit> unitList = listUnit.stream().filter(e -> e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT.getValue())).collect(Collectors.toList());
            if (null == unitList || unitList.isEmpty()) {
                logger.error("广告投放计划ID【{}】未设置取纸广告单元", planId);
                return false;
            }

            for (AdvertisingUnit unit : unitList) {
                if (!unit.getAdUseStatus().equals(AD_USE_YES.getValue())) {
                    logger.error("广告投放计划ID【{}】取纸广告单元【{}】未启用", planId, unit.getId());
                    return false;
                }
            }

            return true;
        }

        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())) {
            AdvertisingPlanWx planWx = advertisingPlanWxMapper.selectAdvertisingPlanWxByPlanId(planId);
            if (null == planWx) {
                logger.error("广告投放计划ID【{}】不存在或已删除", planId);
                return false;
            }

            List<AdvertisingUnitWx> listUnit = advertisingUnitWxMapper.selectAdvertisingUnitListByCombinationId(planWx.getCombinationId());

            if (null == listUnit || listUnit.isEmpty()) {
                logger.error("广告投放计划ID【{}】未设置广告单元", planId);
                return false;
            }

            List<AdvertisingUnitWx> unitList = listUnit.stream().filter(e -> e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT_WX.getValue())).collect(Collectors.toList());
            if (unitList.isEmpty()) {
                logger.error("广告投放计划ID【{}】未设置取纸广告单元", planId);
                return false;
            }

            for (AdvertisingUnitWx unit : unitList) {
                if (!unit.getAdUseStatus().equals(AD_USE_YES.getValue())) {
                    logger.error("广告投放计划ID【{}】取纸广告单元【{}】未启用", planId, unit.getId());
                    return false;
                }
            }
        }

        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_PAY.getValue())) {

            AdvertisingPlan planPay = advertisingPlanPayMapper.selectAdvertisingPlanPayByPlanId(planId);

            if (null == planPay) {
                logger.error("广告投放计划ID【{}】不存在或已删除", planId);
                return false;
            }

            return true;
        }

        return true;
    }

    @Override
    public int insertTargetingInfo(AdvertisingPlan advertisingPlan) {
        /*设备定向信息存储*/
        AdvertisingPlanDevice advertisingPlanDevice = new AdvertisingPlanDevice();
        BeanUtils.copyProperties(advertisingPlan, advertisingPlanDevice);
        advertisingPlanDevice.setSex(advertisingPlan.getDeviceFaceSex());
        advertisingPlanDevice.setAdPlanId(advertisingPlan.getPlanId());
        advertisingPlanDevice.setId(null);
        int r = advertisingPlanDeviceService.insertAdvertisingPlanDevice(advertisingPlanDevice);

        /*人群定向信息存储*/
        AdvertisingPlanPepole advertisingPlanPepole = new AdvertisingPlanPepole();
        BeanUtils.copyProperties(advertisingPlan, advertisingPlanPepole);
        advertisingPlanPepole.setSex(advertisingPlan.getPepoleSex());
        advertisingPlanPepole.setAdPlanId(advertisingPlan.getPlanId());
        advertisingPlanPepole.setId(null);
        r += advertisingPlanPepoleService.insertAdvertisingPlanPepole(advertisingPlanPepole);

        return r;
    }

    @Override
    public int updateTargetingInfo(AdvertisingPlan advertisingPlan) {

        int r = 0;

        /*设备定向信息修改*/
        if (null != advertisingPlan.getPlanDeviceId()) {
            AdvertisingPlanDevice advertisingPlanDevice = new AdvertisingPlanDevice();
            BeanUtils.copyProperties(advertisingPlan, advertisingPlanDevice);
            advertisingPlanDevice.setSex(advertisingPlan.getDeviceFaceSex());
            advertisingPlanDevice.setAdPlanId(advertisingPlan.getPlanId());
            advertisingPlanDevice.setId(advertisingPlan.getPlanDeviceId());
            r += advertisingPlanDeviceService.updateAdvertisingPlanDevice(advertisingPlanDevice);
        }

        /*人群定向信息修改*/
        if (null != advertisingPlan.getPepolePlanId()) {
            AdvertisingPlanPepole advertisingPlanPepole = new AdvertisingPlanPepole();
            BeanUtils.copyProperties(advertisingPlan, advertisingPlanPepole);
            advertisingPlanPepole.setSex(advertisingPlan.getPepoleSex());
            advertisingPlanPepole.setAdPlanId(advertisingPlan.getPlanId());
            advertisingPlanPepole.setId(advertisingPlan.getPepolePlanId());
            r += advertisingPlanPepoleService.updateAdvertisingPlanPepole(advertisingPlanPepole);
        }

        return r;
    }

    /**
     * 同步广告投放状态
     *
     * @param advertisingPlan
     */
    public static void synchronizeAdvertisingStatus(AdvertisingPlan advertisingPlan) {
        String key = AD_PLAN_ID_PREFIX + '_' + advertisingPlan.getPlanId();
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null != planFromRedis && null != advertisingPlan.getAdvertisingStatus()
                && !advertisingPlan.getAdvertisingStatus().equals(planFromRedis.getAdvertisingStatus())) {
            planFromRedis.setAdvertisingStatus(advertisingPlan.getAdvertisingStatus());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);
        }
    }

    /**
     * 处理投放状态
     *
     * @param advertisingPlanNew
     * @param advertisingPlanOld
     */
    protected void setAdvertisingStatus(AdvertisingPlan advertisingPlanNew, AdvertisingPlan advertisingPlanOld) {

        String key = AD_PLAN_ID_PREFIX + '_' + advertisingPlanOld.getPlanId();
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

        /*增加日预算*/
        if (null != advertisingPlanNew.getDayBudget() && null != advertisingPlanOld.getDayBudget()
                && advertisingPlanNew.getDayBudget().compareTo(advertisingPlanOld.getDayBudget()) > 0
                && AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_DAY.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：增加日预算", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*减少日预算*/
        if (null != advertisingPlanNew.getDayBudget() && null != planFromRedis && null != planFromRedis.getTodaySpend()
                && planFromRedis.getTodaySpend().compareTo(advertisingPlanNew.getDayBudget()) >= 0
                && AD_PLAN_STATUS_OK.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】暂停：减少日预算", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_DAY.getValue());
            return;
        }

        /*日预算：不限*/
        if (null == advertisingPlanNew.getDayBudget()
                && AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_DAY.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：日预算不限", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*增加总预算*/
        if (null != advertisingPlanNew.getTotalBudget() && null != advertisingPlanOld.getTotalBudget()
                && advertisingPlanNew.getTotalBudget().compareTo(advertisingPlanOld.getTotalBudget()) > 0
                && AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_TOTAL.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：增加总预算", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*减少总预算*/
        if (null != advertisingPlanNew.getTotalBudget() && null != planFromRedis && null != planFromRedis.getTotalSpend()
                && planFromRedis.getTotalSpend().compareTo(advertisingPlanNew.getTotalBudget()) >= 0) {
            logger.info("广告计划【{}】暂停：减少总预算", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_TOTAL.getValue());
            return;
        }

        /*总预算：不限*/
        if (null == advertisingPlanNew.getTotalBudget()
                && AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_TOTAL.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：总预算不限", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*投放结束*/
        if (null != advertisingPlanNew.getGmtShowEnd()
                && advertisingPlanNew.getGmtShowEnd().before(new Date())) {
            logger.info("广告计划【{}】暂停：投放结束", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
            return;
        }

        /*投放开始*/
        if (null != advertisingPlanNew.getGmtShowEnd()
                && advertisingPlanNew.getGmtShowEnd().after(new Date())
                && AD_PLAN_STATUS_PAUSE_TIME_END.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：投放开始", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*投放未开始*/
        if (null != advertisingPlanNew.getGmtShowStart()
                && advertisingPlanNew.getGmtShowStart().after(new Date())) {
            logger.info("广告计划【{}】暂停：投放未开始", advertisingPlanNew.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
            return;
        }

        /*投放开始*/
        if (null != advertisingPlanNew.getGmtShowStart()
                && advertisingPlanNew.getGmtShowStart().before(new Date())
                && AD_PLAN_STATUS_PAUSE_TIME_END.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：投放开始", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }

        /*投放长期有效*/
        if (YES.getValue().toString().equals(advertisingPlanNew.getLongTermEffective())
                && AD_PLAN_STATUS_PAUSE_TIME_END.getValue().equals(advertisingPlanOld.getAdvertisingStatus())) {
            logger.info("广告计划【{}】恢复：投放长期有效", planFromRedis.getPlanId());
            advertisingPlanNew.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
        }
    }

    @Override
    public void mediumSellRuleThreeNotice() {
        Map<String, Object> map = new HashMap<>();
        MediumSellRull mediumSellRuleNew = mediumSellRullMapper.selectMediumSellRullById(3);
        map.put(AdvertisingConstants.MEDIUM_SELL_RULE_UPDATE_EVENT, mediumSellRuleNew);
        map.put(AdvertisingConstants.KEY_SYSTEM_ID, Constants.SYSTEM_ID);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
    }

    @Override
    public AdvertisingPlan findByPlanId(String planId) {

        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_ZFB.getValue())) {
            return advertisingPlanMapper.selectAdvertisingPlanByPlanId(planId);
        }

        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_WX.getValue())) {
            return advertisingPlanWxMapper.selectAdvertisingPlanWxByPlanId(planId);
        }

        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_FANS.getValue())) {
            return advertisingPlanFansMapper.selectAdvertisingPlanFansByPlanId(planId);
        }

        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_PAY.getValue())) {
            return advertisingPlanPayMapper.selectAdvertisingPlanPayByPlanId(planId);
        }

        logger.error("计划ID{}格式错误或未处理", planId);

        return null;
    }

    @Override
    public List<AdvertisingPlan> findByWeChatPersonalId(String weChatPersonalId) {

        List<AdvertisingPlan> all = new ArrayList<>(4);

        List<AdvertisingPlanFans> list = advertisingPlanFansMapper.findByWeChatPersonalId(weChatPersonalId);

        if (null != list && !list.isEmpty()) {
            all.addAll(list);
        }

        return all;
    }

    @Override
    public List<AdvertisingPlan> findByQQPersonalId(String qqPersonalId) {
        List<AdvertisingPlan> all = new ArrayList<>(4);

        List<AdvertisingPlanFans> list = advertisingPlanFansMapper.findByQQPersonalId(qqPersonalId);

        if (null != list && !list.isEmpty()) {
            all.addAll(list);
        }

        return all;
    }

    @Override
    public void restartAdvertisingPlanByWeChatPersonalId(String weChatPersonalId) {
        List<AdvertisingPlanFans> list = advertisingPlanFansMapper.findByWeChatPersonalId(weChatPersonalId);
        for (AdvertisingPlanFans planFans : list) {
            if (!AD_PLAN_STATUS_PAUSE_WE_CHAT_PERSONAL_DAY_LIMIT.getValue().equals(planFans.getAdvertisingStatus())) {
                continue;
            }

            String key = AD_PLAN_ID_PREFIX + '_' + planFans.getPlanId();
            AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            if (null == planFromRedis) {
                logger.error("广告计划{}不存在Redis中，无法自动恢复投放", planFans.getPlanId());
                continue;
            }

            /*设置MySQL中广告计划状态*/
            planFans.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
            advertisingPlanFansMapper.updateAdvertisingPlanFans(planFans);

            /*设置Redis中广告计划状态*/
            planFromRedis.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);

            /*广告计划恢复投放*/
            reloadPattern(planFans.getPlanId());
            logger.info("广告计划【{}】因微信个人号【{}】日投放量不足恢复投放", planFans.getPlanId(), weChatPersonalId);
        }
    }

    @Override
    public void restartAdvertisingPlanByQQPersonalId(String qqPersonalId) {
        List<AdvertisingPlanFans> list = advertisingPlanFansMapper.findByQQPersonalId(qqPersonalId);
        for (AdvertisingPlanFans planFans : list) {
            if (!AD_PLAN_STATUS_PAUSE_WE_CHAT_PERSONAL_DAY_LIMIT.getValue().equals(planFans.getAdvertisingStatus())) {
                continue;
            }

            String key = AD_PLAN_ID_PREFIX + '_' + planFans.getPlanId();
            AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            if (null == planFromRedis) {
                logger.error("广告计划{}不存在Redis中，无法自动恢复投放", planFans.getPlanId());
                continue;
            }

            /*设置MySQL中广告计划状态*/
            planFans.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
            advertisingPlanFansMapper.updateAdvertisingPlanFans(planFans);

            /*设置Redis中广告计划状态*/
            planFromRedis.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);

            /*广告计划恢复投放*/
            reloadPattern(planFans.getPlanId());
        }
    }

    @Override
    public void localCacheWinPlan(AdvertisingPlan win) {
        if (null == win || StringUtils.isBlank(win.getPlanId())) {
            return;
        }

        AdvertisingPlan plan = LOCAL_CACHE_WIN_PLAN.getIfPresent(win.getPlanId());
        if (null != plan && null != plan.getRecentWinTimestamp()
                && null != plan.getWinFrequency() && plan.getWinFrequency() > 0
                && (System.currentTimeMillis() - plan.getRecentWinTimestamp()) >= (plan.getWinFrequency() * 1000L)) {
            LOCAL_CACHE_WIN_PLAN.invalidate(win.getPlanId());
        }

        if (null != win.getRecentWinTimestamp()
                && null != win.getWinFrequency() && win.getWinFrequency() > 0
                && (System.currentTimeMillis() - win.getRecentWinTimestamp()) <= (win.getWinFrequency() * 1000L)) {
            LOCAL_CACHE_WIN_PLAN.put(win.getPlanId(), win);
        }
    }

    @Override
    public AdvertisingPlan fromLocalCacheWinPlan(String planId) {
        return LOCAL_CACHE_WIN_PLAN.getIfPresent(planId);
    }
}