package com.zjb.project.dsp.advertisingTargetInfo.controller;

import cn.hutool.extra.mail.MailUtil;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Excel;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.framework.web.page.PageDomain;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.page.TableSupport;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.*;
import com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService;
import com.zjb.project.dsp.fileExport.domain.FileExport;
import com.zjb.project.dsp.fileExport.service.IFileExportService;
import com.zjb.project.dsp.rpcrequest.domain.StatisticsZjbPlRoi;
import com.zjb.project.dsp.rpcrequest.service.IRpcRequestService;
import com.zjb.project.dsp.takePaperHealthRecord.domain.TakePaperHealthRecord;
import com.zjb.project.dsp.takePaperHealthRecord.service.ITakePaperHealthRecordService;
import com.zjb.project.dsp.zjbprresponse.domain.StatisticsDeviceRoi;
import com.zjb.project.dsp.zjbprresponse.domain.StatisticsUserRoi;
import com.zjb.project.dsp.zjbprresponse.service.IZjbPrResponseService;
import com.zjb.project.system.user.domain.User;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.io.*;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_HOUR;
import static org.apache.commons.lang3.time.DateUtils.MILLIS_PER_SECOND;

/**
 * 广告交易数据 信息操作处理
 *
 * @author songjy
 * @date 2019-09-10
 */
@Controller
@RequestMapping("/dsp/advertisingTargetInfo")
public class AdvertisingTargetInfoController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "dsp/advertisingTargetInfo";

    @Autowired
    private IAdvertisingTargetInfoService advertisingTargetInfoService;
    @Autowired
    private ITakePaperHealthRecordService takePaperHealthRecordService;
    @Autowired
    private IAdvertisingPlanService advertisingPlanService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IZjbPrResponseService zjbPrResponseService;
    @Autowired
    private IRpcRequestService rpcRequestService;
    @Autowired
    private IFileExportService fileExportService;

    @RequiresPermissions("dsp:advertisingTargetInfo:view")
    @GetMapping()
    public String advertisingTargetInfo(ModelMap mmap) {

        /*广告统计信息发布消费数量*/
        String value = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.CHANNEL_STATISTICS_AD_INFO_COUNT_PUBLISH, ZJB_DB_50);
        value = (StringUtils.isNumeric(value) ? value : "0");
        mmap.put("statisticsAdInfoCountPublish", value);
        mmap.put("statisticsAdInfoCountConsume", RedisSubscribe.CHANNEL_STATISTICS_AD_INFO_COUNT_CONSUME.get());
        mmap.put("statisticsAdInfoCountDiff", Math.abs(Integer.parseInt(value) - RedisSubscribe.CHANNEL_STATISTICS_AD_INFO_COUNT_CONSUME.get()));
        mmap.put("gmtAdRequestTimeStart", LocalDate.now().toString());
        mmap.put("gmtAdRequestTimeEnd", LocalDate.now().toString());

        return prefix + "/advertisingTargetInfo";
    }

    /**
     * 查询广告交易数据列表
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingTargetInfo advertisingTargetInfo) {

        advertisingTargetInfo.setGmtAdRequestTimeStart(null == advertisingTargetInfo.getGmtAdRequestTimeStart() ? DateUtils.toDate(LocalDate.now()) : advertisingTargetInfo.getGmtAdRequestTimeStart());

        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();

        Pageable pageable = PageRequest.of(pageNum - 1, pageSize);
        IMgBaseService.PAGEABLE_THREAD_LOCAL.set(pageable);
        List<AdvertisingTargetInfo> list = advertisingTargetInfoService.selectAdvertisingTargetInfoList(advertisingTargetInfo);
        IMgBaseService.PAGEABLE_THREAD_LOCAL.remove();

        TableDataInfo dataInfo = IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.get();

        if (null != dataInfo) {
            IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.remove();
            return dataInfo;
        }

        return getDataTable(list);
    }

    /**
     * 根据主键查询记录
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:view")
    @GetMapping("/find/{id}")
    @ResponseBody
    public AdvertisingTargetInfo findById(@PathVariable("id") Long id) {
        return advertisingTargetInfoService.find(id);
    }

    /**
     * 新增广告交易数据
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告交易数据
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:add")
    @Log(title = "广告交易数据", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingTargetInfo advertisingTargetInfo) {
        return toAjax(1);
    }

    /**
     * 修改广告交易数据
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Long id, ModelMap mmap) {
        AdvertisingTargetInfo advertisingTargetInfo = advertisingTargetInfoService.find(id);
        mmap.put("advertisingTargetInfo", advertisingTargetInfo);
        return prefix + "/edit";
    }

    /**
     * 修改保存广告交易数据
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:edit")
    @Log(title = "广告交易数据", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingTargetInfo advertisingTargetInfo) {
        return toAjax(1);
    }

    /**
     * 删除广告交易数据
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:remove")
    @Log(title = "广告交易数据", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(1);
    }

    /**
     * 广告交易数据统计
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "广告交易数据导出", businessType = BusinessType.EXPORT)
    @GetMapping("/statistics")
    @ResponseBody
    public AjaxResult statistics(String startTime) {

        AjaxResult ajaxResult = success();
        Date start = StringUtils.isBlank(startTime) ? DateUtils.toDate(LocalDate.now().minusDays(1L)) : DateUtils.toDate(LocalDate.parse(startTime));

        /*String mapFunction = "";
        String reduceFunction = "";

        MapReduceIterable<Document> mapReduceIterable = mongoTemplate.getCollection(collectionName).mapReduce(mapFunction, reduceFunction).batchSize(1000);

        try (MongoCursor<Document> mongoCursor = mapReduceIterable.iterator()) {
            for (; mongoCursor.hasNext(); ) {

            }
        }*/

        List<String> extDataList = new ArrayList<>();

        /*统计扫码取纸方式数量*/
        statisticsTakePaperSource(start, extDataList);

        /*统计扫码用户数量*/
        statisticsCountUsers(start, extDataList);

        List<StatisticsCommon> listCommon = advertisingTargetInfoService.statisticsAdWinCount(start, start);

        ajaxResult.put("statisticsCommon", listCommon);

        Map<String, StatisticsCommon> map = listCommon.stream().collect(Collectors.toMap(StatisticsCommon::getAdWinPlanId, Function.identity()));

        /*广告请求出纸次数：PL*/
        List<StatisticsCommon> countOutPaperPl = advertisingTargetInfoService.statisticsCountOutPaper(start, start);
        for (StatisticsCommon e : countOutPaperPl) {
            logger.info("广告{}请求出纸次数：{}", e.getAdWinPlanId(), e.getCountOutPaper());
            StatisticsCommon c = map.get(e.getAdWinPlanId());
            if (null == c) {
                continue;
            }
            c.setSmbtAccount(e.getSmbtAccount());
            c.setProfit(e.getProfit());
            c.setCountOutPaper(e.getCountOutPaper());
        }

        /*出纸成功次数*/
        List<StatisticsCommon> successOutPaper = advertisingTargetInfoService.statisticsSuccessOutPaper(start, start);
        for (StatisticsCommon e : successOutPaper) {
            StatisticsCommon c = map.get(e.getAdWinPlanId());
            if (null == c) {
                continue;
            }
            c.setIncome(e.getIncome());
            c.setSmbtAccount(null == c.getSmbtAccount() ? e.getSmbtAccount() : c.getSmbtAccount());
            c.setCountSuccessOutPaper(e.getCountSuccessOutPaper());
        }

        /*广告计划UV数量统计条数*/
        planUniqueVisitor(start, map);

        ExcelUtil<StatisticsCommon> util = new ExcelUtil<>(StatisticsCommon.class);
        /*sheetName*/
        String sheetName = "adCountData";
        String splitCharacter = "-";

        /*倒序*/
        Collections.sort(listCommon, new Comparator<StatisticsCommon>() {
            @Override
            public int compare(StatisticsCommon o1, StatisticsCommon o2) {
                return o2.getCountAdWinPlanId().compareTo(o1.getCountAdWinPlanId());
            }
        });

        statisticsAdIncome(listCommon);

        AjaxResult excelWithExtList = util.exportExcelWithExtList(listCommon, sheetName, extDataList, splitCharacter);
        String fileName = excelWithExtList.get("msg").toString();
        String ext = FilenameUtils.getExtension(fileName);
        String md5 = DigestUtils.md5Hex(startTime);
        String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + md5 + '.' + ext;
        File file = new File(FileUtils.getTempDirectory(), fileName);
        try {
            OssUtil.uploadFile(fileKey, new FileInputStream(file));
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage(), e);
        }
        String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
        logger.info("文件OSS路径：{}", fileUrl);

        excelWithExtList.put("fileUrl", fileUrl);
        excelWithExtList.put("fileName", fileName);

        return excelWithExtList;
    }

    /**
     * 广告计划UV数量统计条数
     *
     * @param start
     * @param map
     */
    private void planUniqueVisitor(Date start, Map<String, StatisticsCommon> map) {
        List<StatisticsCommon> planUniqueVisitor = advertisingTargetInfoService.statisticsPlanUniqueVisitor(start, start);

        for (StatisticsCommon e : planUniqueVisitor) {
            StatisticsCommon c = map.get(e.getAdWinPlanId());
            if (null == c) {
                continue;
            }
            if (null == e.getScanTool()) {
                continue;
            }

            switch (e.getScanTool()) {
                case 1:
                    c.setCountOpenIdWeChat(e.getCountOpenIdWeChat());
                    break;
                case 2:
                    c.setCountOpenIdAliPay(e.getCountOpenIdAliPay());
                    break;
                case 9:
                    c.setCountOpenIdOther(e.getCountOpenIdOther());
                    break;
                default:
                    break;
            }
        }
    }

    /**
     * 广告维度收益数据处理
     *
     * @param all
     */
    private void statisticsAdIncome(List<StatisticsCommon> all) {
        long start = System.currentTimeMillis();

        Cache<String, AdvertisingPlan> planCache = CacheBuilder.newBuilder()
                .maximumSize(400)
                .expireAfterAccess(1, TimeUnit.MINUTES)
                .build();

        for (StatisticsCommon common : all) {
            if (null == common.getSmbtAccount()) {
                continue;
            }
            common.setIncome(BigDecimal.ZERO);
            AdvertisingPlan plan = planCache.getIfPresent(common.getAdWinPlanId());
            if (null == plan && StringUtils.isNotBlank(common.getAdWinPlanId())) {
                plan = advertisingPlanService.findByPlanId(common.getAdWinPlanId());
                if (null == plan) {
                    logger.warn("根据计划ID{}查询记录失败", common.getAdWinPlanId());
                    continue;
                }

                planCache.put(plan.getPlanId(), plan);
            }

            if (null == plan.getPlanBid()) {
                logger.warn("计划ID{}出价未指定", common.getAdWinPlanId());
                continue;
            }

            if (null == common.getCountOutPaper()) {
                logger.warn("计划ID{}出纸次数为空", common.getAdWinPlanId());
                continue;
            }

            common.setIncome(common.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(common.getCountOutPaper()))));

            if (null == common.getCountSuccessOutPaper()) {
                logger.warn("计划ID{}成功出纸次数为空", common.getAdWinPlanId());
                continue;
            }

            common.setProfit(common.getIncome().subtract(common.getSmbtAccount()));
        }

        planCache.invalidateAll();

        logger.info("广告维度收益数据处理耗时：{}", DateUtils.timeConsuming(System.currentTimeMillis() - start));
    }

    /**
     * 统计扫码用户数量
     *
     * @param start
     * @param extDataList
     */
    private void statisticsCountUsers(Date start, List<String> extDataList) {
        StatisticsCommon countUsers = advertisingTargetInfoService.countUsers(start, start);

        if (null == countUsers) {
            return;
        }

        if (null != countUsers.getCountOpenId()) {
            extDataList.add("扫码用户总数量-" + countUsers.getCountOpenId());
        }

        if (null != countUsers.getCountOpenIdOther()) {
            extDataList.add("扫码其他用户数量-" + countUsers.getCountOpenIdOther());
        }

        if (null != countUsers.getCountOpenIdWeChat()) {
            extDataList.add("扫码微信用户数量-" + countUsers.getCountOpenIdWeChat());
        }

        if (null != countUsers.getCountOpenIdAliPay()) {
            extDataList.add("扫码支付宝用户数量-" + countUsers.getCountOpenIdAliPay());
        }

    }

    /**
     * 统计取纸方式数量
     *
     * @param start
     * @param extDataList
     */
    private void statisticsTakePaperSource(Date start, List<String> extDataList) {
        List<StatisticsCommon> listTakePaperSource = zjbPrResponseService.countTakePaperSource(start, start);

        if (null == listTakePaperSource || listTakePaperSource.isEmpty()) {
            return;
        }

        for (StatisticsCommon common : listTakePaperSource) {
            if (TAKE_PAPER_FREE.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("普通取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_FREE_WE_CHAT.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("微信免费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_FREE_ALI_PAY.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("支付宝免费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_LEAF_WE_CHAT.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("微信小树叶取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_LEAF.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("小树叶次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_LEAF_APP.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("APP小树叶取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_PAY_WE_CHAT.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("微信付费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_PAY_ALI_PAY.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("支付宝付费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_MONEY_WE_CHAT.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("微信纯付费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_MONEY.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("纯付费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_MONEY_ALI_PAY.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("支付宝纯付费取纸次数-" + common.getCountPaperSource());
                continue;
            }

            if (TAKE_PAPER_PAY_APP.getValue().equals(common.getTakePaperSource())) {
                extDataList.add("APP付费取纸取纸次数-" + common.getCountPaperSource());
            }
        }
    }

    /**
     * 胜出计划及设备导出
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "胜出计划及设备导出", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/plan/device")
    @ResponseBody
    public AjaxResult statisticsAdPlanIdAndDevice(@RequestParam(value = "startDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                                  @RequestParam(value = "endDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {

        long start = System.currentTimeMillis();
        LocalDate onLine = LocalDate.of(2019, 12, 20);
        User user = getUser();
        int maxDiffDays = 15;
        Date startAdRequestDate = (null == startDate ? new Date() : startDate);
        Date endAdRequestDate = (null == endDate ? new Date() : endDate);
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startAdRequestDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endAdRequestDate).toLocalDate();
        String downFileName = StringUtils.remove(startLocalDate.toString() + '_' + endLocalDate.toString(), '-');

        long diffDays = Math.abs(endLocalDate.toEpochDay() - startLocalDate.toEpochDay());

        if (diffDays > maxDiffDays) {
            return error("查询范围不能超过" + maxDiffDays + "天");
        }

        if (startLocalDate.isBefore(onLine)) {
            return error("查询时间超过了功能上线时间：" + onLine);
        }

        String lockKey = user.getLoginName() + user.getPassword() + "plan_device";
        String requestId = String.valueOf(System.currentTimeMillis());
        Long millisecond = EXRP_HOUR * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, millisecond.intValue())) {
            return error("系统繁忙，请稍后再试");
        }

        AjaxResult ajaxResult = success();

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {

                ExcelUtil<StatisticsDeviceAdPlan> util = new ExcelUtil<>(StatisticsDeviceAdPlan.class);
                ExcelUtil<StatisticsDeviceIncome> deviceIncomeExcelUtil = new ExcelUtil<>(StatisticsDeviceIncome.class);
                ExcelUtil<StatisticsAgencyIncome> agencyIncomeExcelUtil = new ExcelUtil<>(StatisticsAgencyIncome.class);
                ExcelUtil<StatisticsSceneIncome> sceneIncomeExcelUtil = new ExcelUtil<>(StatisticsSceneIncome.class);

                List<StatisticsDeviceAdPlan> all = null;

                try {
                    all = zjbPrResponseService.findGroupByDeviceSnAndPlanId(DateUtils.toDate(startLocalDate), DateUtils.toDate(endLocalDate));
                } catch (Exception e) {
                    logger.error(e.getMessage(), e);
                } finally {
                    JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
                    logger.info("锁【{}】已释放", lockKey);
                    logger.info("查询胜出计划时间段{}至{}所关联的设备信息共{}条，耗时(秒):{}", startLocalDate, endLocalDate, null == all ? 0 : all.size(), (System.currentTimeMillis() - start) / MILLIS_PER_SECOND);
                }

                if (null == all || all.isEmpty()) {
                    return;
                }

                logger.info("{}至{}设备与广告维度收益倒序处理开始", startLocalDate, endLocalDate);
                Collections.sort(all, new Comparator<StatisticsDeviceAdPlan>() {
                    @Override
                    public int compare(StatisticsDeviceAdPlan o1, StatisticsDeviceAdPlan o2) {
                        /*倒序*/
                        return o2.getCountAdWinPlanId().compareTo(o1.getCountAdWinPlanId());
                    }
                });
                logger.info("{}至{}设备与广告维度收益倒序处理完毕", startLocalDate, endLocalDate);

                /*设备与广告维度收益处理*/
                logger.info("{}至{}设备与广告维度收益处理开始", startLocalDate, endLocalDate);
                for (StatisticsDeviceAdPlan deviceAdPlan : all) {
                    deviceAdPlan.setIncome(BigDecimal.ZERO);
                    deviceAdPlan.setBenefit(BigDecimal.ZERO);
                    AdvertisingPlan plan = StringUtils.isBlank(deviceAdPlan.getAdWinPlanId()) ? null : advertisingPlanService.findByPlanId(deviceAdPlan.getAdWinPlanId());
                    deviceAdPlan.setIncome(deviceAdPlan.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(deviceAdPlan.getCountAdWinPlanId()))));
                    deviceAdPlan.setBenefit(deviceAdPlan.getBenefit().add(BigDecimal.valueOf(0.13).multiply(BigDecimal.valueOf(deviceAdPlan.getCountAdWinPlanId()))));
                    deviceAdPlan.setProfit(deviceAdPlan.getIncome().subtract(deviceAdPlan.getBenefit()));
                }

                logger.info("{}至{}设备与广告维度收益处理完毕", startLocalDate, endLocalDate);

                List<StatisticsDeviceIncome> deviceIncomeList = statisticsDeviceIncome(all);
                List<StatisticsAgencyIncome> statisticsAgencyIncomes = statisticsAgencyIncome(all);
                List<StatisticsSceneIncome> statisticsSceneIncomes = statisticsSceneIncome(all);
                AjaxResult ajaxResult = util.exportExcel(all, "AdPlanIdAndDevice");
                AjaxResult ajaxResultIncome = deviceIncomeExcelUtil.exportExcel(deviceIncomeList, "StatisticsDeviceIncome");
                AjaxResult ajaxResultAgencyIncome = agencyIncomeExcelUtil.exportExcel(statisticsAgencyIncomes, "StatisticsDeviceIncome");
                AjaxResult ajaxResultSceneIncome = sceneIncomeExcelUtil.exportExcel(statisticsSceneIncomes, "StatisticsSceneIncome");

                String fileName = ajaxResult.get("msg").toString();
                String fileNameIncome = ajaxResultIncome.get("msg").toString();
                String fileNameAgencyIncome = ajaxResultAgencyIncome.get("msg").toString();
                String fileNameSceneIncome = ajaxResultSceneIncome.get("msg").toString();

                String ext = FilenameUtils.getExtension(fileName);

                String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + '.' + ext;
                String fileKeyIncome = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + "_income." + ext;
                String fileKeyAgencyIncome = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + "_agency_income." + ext;
                String fileKeySceneIncome = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + "_scene_income." + ext;

                File file = new File(FileUtils.getTempDirectory(), fileName);
                File fileIncome = new File(FileUtils.getTempDirectory(), fileNameIncome);
                File fileAgencyIncome = new File(FileUtils.getTempDirectory(), fileNameAgencyIncome);
                File fileSceneIncome = new File(FileUtils.getTempDirectory(), fileNameSceneIncome);

                try (InputStream inputStream = new FileInputStream(file)) {
                    OssUtil.uploadFile(fileKey, inputStream);
                    logger.info("文件{}上传至OSS完毕", file.getAbsolutePath());
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }

                try (InputStream inputStream = new FileInputStream(fileIncome)) {
                    OssUtil.uploadFile(fileKeyIncome, inputStream);
                    logger.info("文件{}上传至OSS完毕", fileIncome.getAbsolutePath());
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }

                try (InputStream inputStream = new FileInputStream(fileAgencyIncome)) {
                    OssUtil.uploadFile(fileKeyAgencyIncome, inputStream);
                    logger.info("文件{}上传至OSS完毕", fileAgencyIncome.getAbsolutePath());
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }

                try (InputStream inputStream = new FileInputStream(fileSceneIncome)) {
                    OssUtil.uploadFile(fileKeySceneIncome, inputStream);
                    logger.info("文件{}上传至OSS完毕", fileSceneIncome.getAbsolutePath());
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                }

                String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
                String fileUrlIncome = ZjbConstants.File_Domain + '/' + fileKeyIncome;
                String fileUrlAgencyIncome = ZjbConstants.File_Domain + '/' + fileKeyAgencyIncome;
                String fileUrlSceneIncome = ZjbConstants.File_Domain + '/' + fileKeySceneIncome;

                logger.info("文件OSS路径：{}", fileUrl);
                logger.info("文件OSS路径：{}", fileUrlIncome);
                logger.info("文件OSS路径：{}", fileUrlAgencyIncome);
                logger.info("文件OSS路径：{}", fileUrlSceneIncome);

                ajaxResult.put("fileUrl", fileUrl);
                ajaxResult.put("fileName", fileName);

                Collection<String> tos = Collections.singletonList(user.getEmail());
                Collection<String> ccs = Collections.singletonList("renqiyao@sczj-inc.com");
                Collection<String> bcc = Collections.singletonList("lichuang@sczj-inc.com");

                String subject = startLocalDate + "至" + endLocalDate + "广告与设备数据Excel下载";
                StringBuilder content = new StringBuilder();
                content.append("<a href=\"").append(fileUrl).append("\">").append(subject);
                content.append("</a>&nbsp;&nbsp;&nbsp;&nbsp;</br>");
                content.append("<a href=\"").append(fileUrlIncome).append("\">");
                content.append(startLocalDate + "至" + endLocalDate + "设备利润数据Excel下载");
                content.append("</a>&nbsp;&nbsp;&nbsp;&nbsp;</br>");
                content.append("<a href=\"").append(fileUrlAgencyIncome).append("\">");
                content.append(startLocalDate + "至" + endLocalDate + "代理商维度利润数据Excel下载");
                content.append("</a>&nbsp;&nbsp;&nbsp;&nbsp;</br>");
                content.append("<a href=\"").append(fileUrlSceneIncome).append("\">");
                content.append(startLocalDate + "至" + endLocalDate + "场景维度利润数据Excel下载");
                content.append("</a>&nbsp;&nbsp;&nbsp;&nbsp;</br>");
                content.append("数据生成耗时（秒）：").append((System.currentTimeMillis() - start) / MILLIS_PER_SECOND);

                MailUtil.send(tos, ccs, bcc, subject, content.toString(), true);
            }
        });

        return ajaxResult;
    }

    /**
     * 场景维度收益
     *
     * @param all
     */
    private List<StatisticsSceneIncome> statisticsSceneIncome(List<StatisticsDeviceAdPlan> all) {
        long start = System.currentTimeMillis();
        Map<String, StatisticsDeviceAdPlan> mapScene = all.stream()
                .collect(Collectors.toMap(StatisticsDeviceAdPlan::getDeviceSceneName, Function.identity(), (exists, replace) -> exists));

        List<StatisticsSceneIncome> statisticsSceneIncomeIncomes = new ArrayList<>(mapScene.size());

        logger.info("场景数量：{}", mapScene.size());

        for (Map.Entry<String, StatisticsDeviceAdPlan> entry : mapScene.entrySet()) {
            StatisticsSceneIncome sceneIncome = new StatisticsSceneIncome();
            String sceneName = entry.getKey();

            sceneIncome.setDeviceSceneName(sceneName);
            sceneIncome.setBenefit(BigDecimal.ZERO);
            sceneIncome.setIncome(BigDecimal.ZERO);

            List<StatisticsDeviceAdPlan> adPlans = all.stream().filter(e -> sceneName.equals(e.getDeviceSceneName())).collect(Collectors.toList());
            for (StatisticsDeviceAdPlan adPlan : adPlans) {
                AdvertisingPlan plan = advertisingPlanService.findByPlanId(adPlan.getAdWinPlanId());
                sceneIncome.setIncome(sceneIncome.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
                sceneIncome.setBenefit(sceneIncome.getBenefit().add(BigDecimal.valueOf(0.13).multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
            }
            sceneIncome.setProfit(sceneIncome.getIncome().subtract(sceneIncome.getBenefit()));
            statisticsSceneIncomeIncomes.add(sceneIncome);
        }

        Collections.sort(statisticsSceneIncomeIncomes, new Comparator<StatisticsSceneIncome>() {
            @Override
            public int compare(StatisticsSceneIncome o1, StatisticsSceneIncome o2) {
                return o1.getProfit().compareTo(o2.getProfit());
            }
        });

        logger.info("场景维度收益数据处理耗时：{}", DateUtils.timeConsuming(System.currentTimeMillis() - start));
        return statisticsSceneIncomeIncomes;
    }

    /**
     * 代理商维度收益
     *
     * @param all
     */
    private List<StatisticsAgencyIncome> statisticsAgencyIncome(List<StatisticsDeviceAdPlan> all) {
        long start = System.currentTimeMillis();
        Map<String, StatisticsDeviceAdPlan> mapAgency = all.stream()
                .collect(Collectors.toMap(StatisticsDeviceAdPlan::getAgencyName, Function.identity(), (exists, replace) -> exists));

        List<StatisticsAgencyIncome> statisticsAgencyIncomes = new ArrayList<>(mapAgency.size());

        logger.info("代理商数量：{}", mapAgency.size());

        for (Map.Entry<String, StatisticsDeviceAdPlan> entry : mapAgency.entrySet()) {
            StatisticsAgencyIncome agencyIncome = new StatisticsAgencyIncome();
            String agencyName = entry.getKey();
            StatisticsDeviceAdPlan deviceAdPlan = entry.getValue();

            agencyIncome.setAgencyName(deviceAdPlan.getAgencyName());
            agencyIncome.setBenefit(BigDecimal.ZERO);
            agencyIncome.setIncome(BigDecimal.ZERO);

            List<StatisticsDeviceAdPlan> adPlans = all.stream().filter(e -> agencyName.equals(e.getAgencyName())).collect(Collectors.toList());
            for (StatisticsDeviceAdPlan adPlan : adPlans) {
                AdvertisingPlan plan = advertisingPlanService.findByPlanId(adPlan.getAdWinPlanId());
                agencyIncome.setIncome(agencyIncome.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
                agencyIncome.setBenefit(agencyIncome.getBenefit().add(BigDecimal.valueOf(0.13).multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
            }
            agencyIncome.setProfit(agencyIncome.getIncome().subtract(agencyIncome.getBenefit()));
            statisticsAgencyIncomes.add(agencyIncome);
        }

        Collections.sort(statisticsAgencyIncomes, new Comparator<StatisticsAgencyIncome>() {
            @Override
            public int compare(StatisticsAgencyIncome o1, StatisticsAgencyIncome o2) {
                return o1.getProfit().compareTo(o2.getProfit());
            }
        });

        logger.info("代理商维度收益数据处理耗时：{}", DateUtils.timeConsuming(System.currentTimeMillis() - start));

        return statisticsAgencyIncomes;

    }

    /**
     * 设备收益
     *
     * @param all
     */
    private List<StatisticsDeviceIncome> statisticsDeviceIncome(List<StatisticsDeviceAdPlan> all) {
        long start = System.currentTimeMillis();
        Map<String, StatisticsDeviceAdPlan> mapDeviceSn = all.stream()
                .collect(Collectors.toMap(StatisticsDeviceAdPlan::getDeviceSn, Function.identity(), (exists, replace) -> exists));

        List<StatisticsDeviceIncome> statisticsDeviceIncomes = new ArrayList<>(mapDeviceSn.size());

        logger.info("设备数量：{}", mapDeviceSn.size());

        for (Map.Entry<String, StatisticsDeviceAdPlan> entry : mapDeviceSn.entrySet()) {
            StatisticsDeviceIncome deviceIncome = new StatisticsDeviceIncome();
            String deviceSn = entry.getKey();
            StatisticsDeviceAdPlan deviceAdPlan = entry.getValue();

            deviceIncome.setDeviceSn(deviceSn);
            deviceIncome.setAgencyName(deviceAdPlan.getAgencyName());
            deviceIncome.setDeviceSceneName(deviceAdPlan.getDeviceSceneName());
            deviceIncome.setBenefit(BigDecimal.ZERO);
            deviceIncome.setIncome(BigDecimal.ZERO);

            List<StatisticsDeviceAdPlan> adPlans = all.stream().filter(e -> deviceSn.equals(e.getDeviceSn())).collect(Collectors.toList());
            for (StatisticsDeviceAdPlan adPlan : adPlans) {
                AdvertisingPlan plan = advertisingPlanService.findByPlanId(adPlan.getAdWinPlanId());
                deviceIncome.setIncome(deviceIncome.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
                deviceIncome.setBenefit(deviceIncome.getBenefit().add(BigDecimal.valueOf(0.13).multiply(BigDecimal.valueOf(adPlan.getCountAdWinPlanId()))));
            }
            deviceIncome.setProfit(deviceIncome.getIncome().subtract(deviceIncome.getBenefit()));
            statisticsDeviceIncomes.add(deviceIncome);
        }

        Collections.sort(statisticsDeviceIncomes, new Comparator<StatisticsDeviceIncome>() {
            @Override
            public int compare(StatisticsDeviceIncome o1, StatisticsDeviceIncome o2) {
                return o1.getProfit().compareTo(o2.getProfit());
            }
        });

        logger.info("设备收益数据处理耗时：{}", DateUtils.timeConsuming(System.currentTimeMillis() - start));

        return statisticsDeviceIncomes;

    }

    /**
     * 城市量级分布导出
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "城市量级分布导出", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/area/info")
    @ResponseBody
    public AjaxResult statisticsAreaInfo(@RequestParam(value = "startDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                         @RequestParam(value = "endDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {

        long start = System.currentTimeMillis();
        User user = getUser();

        int maxDiffDays = 31;
        Date startAdRequestDate = (null == startDate ? new Date() : startDate);
        Date endAdRequestDate = (null == endDate ? new Date() : endDate);
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startAdRequestDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endAdRequestDate).toLocalDate();
        String downFileName = StringUtils.remove(startLocalDate.toString() + '_' + endLocalDate.toString(), '-');

        long diffDays = Math.abs(endLocalDate.toEpochDay() - startLocalDate.toEpochDay());

        if (diffDays > maxDiffDays) {
            return error("查询范围不能超过" + maxDiffDays + "天");
        }

        String lockKey = user.getLoginName() + user.getPassword();
        String requestId = String.valueOf(System.currentTimeMillis());
        Long millisecond = EXRP_5_MINUTE * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, millisecond.intValue())) {
            return error("系统繁忙，请稍后再试");
        }

        ExcelUtil<StatisticsAreaInfo> util = new ExcelUtil<>(StatisticsAreaInfo.class);

        List<StatisticsAreaInfo> all = null;

        try {
            all = advertisingTargetInfoService.statisticsAreaInfo(DateUtils.toDate(startLocalDate), DateUtils.toDate(endLocalDate));
        } finally {
            JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
            logger.info("锁【{}】已释放", lockKey);
            logger.info("查询时间段{}至{}区域信息共{}条，耗时(秒):{}", startLocalDate, endLocalDate, null == all ? 0 : all.size(), (System.currentTimeMillis() - start) / MILLIS_PER_SECOND);
        }

        if (null == all || all.isEmpty()) {
            return error("未查询到数据");
        }

        long exportStart = System.currentTimeMillis();
        AjaxResult ajaxResult = util.exportExcel(all, "statisticsAreaInfo");
        logger.info("Excel生成耗时(秒):{}", (System.currentTimeMillis() - exportStart) / MILLIS_PER_SECOND);
        String fileName = ajaxResult.get("msg").toString();
        String ext = FilenameUtils.getExtension(fileName);
        String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + '.' + ext;
        File file = new File(FileUtils.getTempDirectory(), fileName);
        try {
            OssUtil.uploadFile(fileKey, new FileInputStream(file));
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage(), e);
        }
        String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
        logger.info("文件OSS路径：{}", fileUrl);
        logger.info("文件本地路径：{}", file.getAbsolutePath());

        ajaxResult.put("fileUrl", fileUrl);
        ajaxResult.put("fileName", fileName);

        return ajaxResult;
    }

    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "用户ROI数据导出", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/user/roi")
    @ResponseBody
    public AjaxResult statisticsUserRoi(@RequestParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                        @RequestParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {

        long start = System.currentTimeMillis();
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endDate).toLocalDate();
        int maxDiffDays = 31;
        long diffDays = Math.abs(endLocalDate.toEpochDay() - startLocalDate.toEpochDay());
        if (diffDays > maxDiffDays) {
            return error("查询范围不能超过" + maxDiffDays + "天");
        }

        User user = getUser();
        String lockKey = "statistics_user_ROI";
        String requestId = String.valueOf(System.currentTimeMillis());
        Long millisecond = EXRP_HOUR * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, millisecond.intValue())) {
            return error("用户ROI数据导出中，请等待");
        }

        AjaxResult ajaxResult = success();

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {
                List<StatisticsUserRoi> list = zjbPrResponseService.statisticsUserRoi(startDate, endDate);

                if (list.isEmpty()) {
                    return;
                }

                List<TakePaperHealthRecord> healthRecords = takePaperHealthRecordService.userWeChat(startLocalDate, endLocalDate);
                Map<String, TakePaperHealthRecord> mapHealthRecord = healthRecords.stream().collect(Collectors.toMap(TakePaperHealthRecord::getOpenId, Function.identity()));

                long startWriteExcel = System.currentTimeMillis();
                String filename = startLocalDate + "_" + endLocalDate + "statisticsUserRoi.xlsx";
                File xlsx = new File(FileUtils.getTempDirectory(), filename);

                try (OutputStream out = new FileOutputStream(xlsx)) {

                    /*产生工作薄对象*/
                    SXSSFWorkbook workbook = new SXSSFWorkbook();

                    /*产生工作表对象*/
                    String sheetName = startLocalDate + "日至" + endLocalDate + "日用户ROI数据";
                    Sheet sheet = workbook.createSheet();
                    workbook.setSheetName(0, sheetName);

                    /*设置Excel标题*/
                    setTitle(sheet);

                    int rowNum = 1;
                    for (StatisticsUserRoi roi : list) {
                        TakePaperHealthRecord healthRecord = mapHealthRecord.get(roi.getOpenId());
                        Row row = sheet.createRow(rowNum++);
                        row.createCell(0).setCellValue(roi.getOpenId());
                        row.createCell(1).setCellValue(null == roi.getSmbtAccount() ? "" : roi.getSmbtAccount().toString());
                        row.createCell(2).setCellValue(null == roi.getIncome() ? "" : roi.getIncome().toString());
                        row.createCell(3).setCellValue(null == roi.getProfit() ? "" : roi.getProfit().toString());
                        row.createCell(4).setCellValue(null == roi.getCountOutPaperPl() ? 0 : roi.getCountOutPaperPl());
                        row.createCell(5).setCellValue(null == roi.getCountOutPaperSuccess() ? 0 : roi.getCountOutPaperSuccess());
                        row.createCell(6).setCellValue(roi.getDeviceNames());
                        row.createCell(7).setCellValue(roi.getAgencyNames());
                        row.createCell(8).setCellValue(roi.getPlanIds());
                        row.createCell(9).setCellValue(null == healthRecord || null == healthRecord.getSex() ? 0 : healthRecord.getSex());
                        row.createCell(10).setCellValue(null == healthRecord || null == healthRecord.getCountSubscribe() ? 0 : healthRecord.getCountSubscribe());
                        row.createCell(11).setCellValue(null == healthRecord || null == healthRecord.getCountUnsubscribe() ? 0 : healthRecord.getCountUnsubscribe());
                        row.createCell(12).setCellValue(null == healthRecord || null == healthRecord.getCountUnsubscribeAll() ? 0 : healthRecord.getCountUnsubscribeAll());
                        if (rowNum % 1000 == 0) {
                            logger.info("已写入{}条用户ROI记录到Excel中", rowNum);
                        }
                    }

                    workbook.write(out);

                    logger.info("共写入{}条用户ROI记录到Excel中，耗时（秒）：{}", rowNum - 1, (System.currentTimeMillis() - startWriteExcel) / 1000);
                } catch (Exception e) {
                    logger.error("用户ROI记录导出失败！" + e.getMessage(), e);
                    return;
                } finally {
                    JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
                    logger.info("锁【{}】已释放", lockKey);
                }

                String ext = FilenameUtils.getExtension(filename);
                String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + startLocalDate + '_' + endLocalDate + "statisticsUserROI." + ext;

                try (InputStream input = new FileInputStream(xlsx)) {
                    OssUtil.uploadFile(fileKey, input);
                } catch (IOException e) {
                    logger.error("文件上传至OSS失败！" + e.getMessage(), e);
                    return;
                }

                String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
                logger.info("{}文件OSS路径：{}", user.getLoginName(), fileUrl);
                logger.info("{}文件本地路径：{}", user.getLoginName(), xlsx.getAbsolutePath());

                ajaxResult.put("fileUrl", fileUrl);
                ajaxResult.put("fileName", filename);

                Collection<String> tos = Collections.singletonList(user.getEmail());
                Collection<String> ccs = Collections.singletonList("renqiyao@sczj-inc.com");
                Collection<String> bcc = Collections.singletonList("lichuang@sczj-inc.com");

                String subject = startLocalDate + "至" + endLocalDate + "用户ROI数据Excel下载";
                String content = "<a href=\"" + fileUrl + "\">" + subject + "</a></br>数据生成耗时（秒）：" + ((System.currentTimeMillis() - start) / MILLIS_PER_SECOND);

                MailUtil.send(tos, ccs, bcc, subject, content, true);
            }

            /**
             * 设置标题
             * @param sheet
             */
            private void setTitle(Sheet sheet) {
                Row row = sheet.createRow(0);
                String[] titles = {"openId", "取纸产生成本(分)", "取纸产生收益（元）", "利润（元）", "下发PL次数", "取纸成功次数", "设备", "代理商", "广告计划", "性别(1：男2：女)", "公众号关注次数", "公众号关注且取关次数", "取关次数"};
                int len = titles.length;
                for (int i = 0; i < len; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(titles[i]);
                }
            }
        });

        return ajaxResult;
    }

    /**
     * 设备ROI数据导出
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "设备ROI数据导出", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/device/roi")
    @ResponseBody
    public AjaxResult statisticsDeviceRoi(@RequestParam(value = "startDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                          @RequestParam(value = "endDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate) {
        long start = System.currentTimeMillis();
        LocalDate onLine = LocalDate.of(2019, 12, 20);
        User user = getUser();
        int maxDiffDays = 15;
        Date startAdRequestDate = (null == startDate ? new Date() : startDate);
        Date endAdRequestDate = (null == endDate ? new Date() : endDate);
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startAdRequestDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endAdRequestDate).toLocalDate();
        String downFileName = StringUtils.remove(startLocalDate.toString() + '_' + endLocalDate.toString(), '-');

        FileExport fileExport = new FileExport();
        fileExport.setFileName(startLocalDate + "至" + endLocalDate + "设备ROI数据.xlsx");
        fileExport.setFileForm("xlsx");
        fileExport.setFileType(SYS_FILE_DEVICE_ROI.getValue());
        fileExport.setStatus(EXPORT_SYS_FILE_PROCESSING.getValue());
        fileExport.setCreaterId(user.getUserId().intValue());
        fileExport.setModifierId(fileExport.getCreaterId());
        fileExport.setGmtCreated(new Date());
        fileExport.setGmtModified(fileExport.getGmtCreated());
        fileExportService.insertFileExport(fileExport);

        long diffDays = Math.abs(endLocalDate.toEpochDay() - startLocalDate.toEpochDay());

        if (diffDays > maxDiffDays) {
            return error("查询范围不能超过" + maxDiffDays + "天");
        }

        if (startLocalDate.isBefore(onLine)) {
            return error("查询时间超过了功能上线时间：" + onLine);
        }

        String lockKey = "statistics_device_ROI";
        String requestId = String.valueOf(System.currentTimeMillis());
        long millisecond = EXRP_HOUR * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, (int) millisecond)) {
            return error("系统繁忙，请稍后再试");
        }

        AjaxResult ajaxResult = success();

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {

                List<StatisticsDeviceRoi> all = null;
                List<StatisticsZjbPlRoi> zjbPlRois = null;

                logger.info("{}设备时间段{}至{}ROI信息记录查询中......", user.getLoginName(), startLocalDate, endLocalDate);

                try {
                    all = zjbPrResponseService.statisticsDeviceRoi(DateUtils.toDate(startLocalDate), DateUtils.toDate(endLocalDate));
                    zjbPlRois = rpcRequestService.statisticsZjbPlRoi(DateUtils.toDate(startLocalDate), DateUtils.toDate(endLocalDate));

                } catch (Exception e) {
                    logger.error("设备ROI导出异常：{}" , e.getMessage(), e);
                    fileExport.setStatus(EXPORT_SYS_FILE_FAIL.getValue());
                    fileExport.setGmtModified(new Date());
                    fileExportService.updateFileExport(fileExport);
                } finally {
                    JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
                    logger.info("锁【{}】已释放", lockKey);
                    logger.info("{}$ZJBPL之ROI时间段【{}】-【{}】数据条数：{}", lockKey, startLocalDate, endLocalDate, null == zjbPlRois ? 0 : zjbPlRois.size());
                    logger.info("{}设备时间段{}至{}ROI信息共{}条，耗时(秒)：{}", lockKey, startLocalDate, endLocalDate, null == all ? 0 : all.size(), (System.currentTimeMillis() - start) / MILLIS_PER_SECOND);
                }

                if (null == all || all.isEmpty()) {
                    logger.error("$ZJBPR之ROI时间段【{}】-【{}】数据查询为空", startLocalDate, endLocalDate);
                    fileExport.setStatus(EXPORT_SYS_FILE_FAIL.getValue());
                    fileExport.setGmtModified(new Date());
                    fileExportService.updateFileExport(fileExport);
                    return;
                }

                if (null == zjbPlRois || zjbPlRois.isEmpty()) {
                    logger.error("{}$ZJBPL之ROI时间段【{}】-【{}】数据查询为空", lockKey, startLocalDate, endLocalDate);
                    fileExport.setStatus(EXPORT_SYS_FILE_FAIL.getValue());
                    fileExport.setGmtModified(new Date());
                    fileExportService.updateFileExport(fileExport);
                    return;
                }

                all.sort(new Comparator<StatisticsDeviceRoi>() {
                    @Override
                    public int compare(StatisticsDeviceRoi o1, StatisticsDeviceRoi o2) {
                        /*倒序*/
                        return o2.getCountOutPaperSuccess().compareTo(o1.getCountOutPaperSuccess());
                    }
                });

                logger.info("{}导出数据中......", lockKey);
                AjaxResult ajaxResult = exportExcel(all, zjbPlRois, "ROI");
                logger.info("{}写入数据到Excel完毕", lockKey);
                String fileName = ajaxResult.get("msg").toString();
                String ext = FilenameUtils.getExtension(fileName);
                String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + "ROI." + ext;
                fileExport.setFileForm(ext);
                fileExport.setFileKey(fileKey);
                File file = new File(FileUtils.getTempDirectory(), fileName);
                try {
                    OssUtil.uploadFile(fileKey, new FileInputStream(file));
                    fileExport.setStatus(EXPORT_SYS_FILE_SUCCESS.getValue());
                    fileExport.setGmtModified(new Date());
                    fileExportService.updateFileExport(fileExport);
                } catch (FileNotFoundException e) {
                    logger.error(e.getMessage(), e);
                    fileExport.setStatus(EXPORT_SYS_FILE_FAIL.getValue());
                    fileExport.setGmtModified(new Date());
                    fileExportService.updateFileExport(fileExport);
                }
                String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
                logger.info("{}文件OSS路径：{}", user.getLoginName(), fileUrl);
                logger.info("{}文件本地路径：{}", user.getLoginName(), file.getAbsolutePath());

                ajaxResult.put("fileUrl", fileUrl);
                ajaxResult.put("fileName", fileName);

                Collection<String> tos = Collections.singletonList(user.getEmail());
                Collection<String> ccs = Collections.singletonList("renqiyao@sczj-inc.com");
                Collection<String> bcc = Collections.singletonList("lichuang@sczj-inc.com");

                String subject = startLocalDate + "至" + endLocalDate + "设备ROI数据Excel下载";
                String content = "<a href=\"" + fileUrl + "\">" + subject + "</a></br>数据生成耗时（秒）：" + ((System.currentTimeMillis() - start) / MILLIS_PER_SECOND);

                try {
                    MailUtil.send(tos, ccs, bcc, subject, content, true);
                } catch (Exception e) {
                    logger.error("邮件发送失败:{}", e.getMessage(), e);
                }

            }
        });

        return ajaxResult;
    }

    /**
     * 导出广告交易数据
     *
     * @param startDate
     * @param endDate
     * @return
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "导出广告交易数据", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/advertising/list")
    @ResponseBody
    public AjaxResult statisticsAdvertisingList(@RequestParam(value = "startDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                                @RequestParam(value = "endDate") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate, AdvertisingTargetInfo advertisingTargetInfo) {

        long start = System.currentTimeMillis();
        startDate = null == startDate ? DateUtils.toDate(LocalDate.now()) : startDate;
        endDate = null == endDate ? DateUtils.toDate(LocalDate.now()) : endDate;
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endDate).toLocalDate();
        int maxDiffDays = 3;
        long diffDays = Math.abs(endLocalDate.toEpochDay() - startLocalDate.toEpochDay());
        if (diffDays > maxDiffDays) {
            return error("导出日期不能超过" + maxDiffDays + "天");
        }

        User user = getUser();
        String lockKey = "statistics_advertising_list";
        String requestId = String.valueOf(System.currentTimeMillis());
        long millisecond = EXRP_HOUR * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, (int) millisecond)) {
            return error("广告交易数据导出中，请等待");
        }

        AjaxResult ajaxResult = success();

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {
                List<AdvertisingTargetInfo> list = new ArrayList<>();

                Date beginDate = DateUtils.toDate(startLocalDate);
                String beginDateStr = DateUtils.parseDateToStr(DateUtils.YYYY_MM_DD, beginDate);
                Date endDate = DateUtils.toDate(endLocalDate);
                String endDateStr = DateUtils.parseDateToStr(DateUtils.YYYY_MM_DD, endDate);
                List<String> days = DateUtils.getDays(beginDateStr, endDateStr);
                for (String oneDay : days) {
                    Date dateTime = DateUtils.dateTime(DateUtils.YYYY_MM_DD_HH_MM_SS, oneDay + " 00:00:00");
                    advertisingTargetInfo.setGmtAdRequestTimeStart(dateTime);
                    advertisingTargetInfo.setGmtAdRequestTimeEnd(dateTime);
                    List<AdvertisingTargetInfo> advertisingTargetInfos = advertisingTargetInfoService.selectAdvertisingTargetInfoList(advertisingTargetInfo);
                    if (CollectionUtils.isNotEmpty(advertisingTargetInfos)) {
                        list.addAll(advertisingTargetInfos);
                    }
                }
                if (list.isEmpty()) {
                    return;
                }

                long startWriteExcel = System.currentTimeMillis();
                String filename = startLocalDate + "_" + endLocalDate + "statisticsAdvertisingList.xlsx";
                File xlsx = new File(FileUtils.getTempDirectory(), filename);

                try (OutputStream out = new FileOutputStream(xlsx)) {

                    /*产生工作薄对象*/
                    SXSSFWorkbook workbook = new SXSSFWorkbook();

                    /*产生工作表对象*/
                    String sheetName = startLocalDate + "日至" + endLocalDate + "日广告交易数据";
                    Sheet sheet = workbook.createSheet();
                    workbook.setSheetName(0, sheetName);

                    /*设置Excel标题*/
                    setTitle(sheet);

                    int rowNum = 1;
                    for (AdvertisingTargetInfo ad : list) {
                        Row row = sheet.createRow(rowNum++);
                        AdvertisingPeopleInfo peopleInfo = ad.getPeopleInfo();
                        String randomNum = null;
                        if (null != peopleInfo) {
                            randomNum = peopleInfo.getRandomNum();
                        }
                        AdvertisingDeviceInfo deviceInfo = ad.getDeviceInfo();
                        String deviceSn = null;
                        if (null != peopleInfo) {
                            deviceSn = deviceInfo.getDeviceSn();
                        }
                        row.createCell(0).setCellValue(randomNum);
                        row.createCell(1).setCellValue(ad.getOpenId());
                        row.createCell(2).setCellValue(deviceSn);
                        row.createCell(3).setCellValue(DateUtils.parseDateToStr(DateUtils.YYYY_MM_DD_HH_MM_SS, ad.getGmtAdRequestTime()));
                        if (rowNum % 1000 == 0) {
                            logger.info("已写入{}条广告交易数据到Excel中", rowNum);
                        }
                    }

                    workbook.write(out);

                    logger.info("共写入{}条广告交易数据到Excel中，耗时（秒）：{}", rowNum - 1, (System.currentTimeMillis() - startWriteExcel) / 1000);
                } catch (Exception e) {
                    logger.error("广告交易数据导出失败！" + e.getMessage(), e);
                    return;
                } finally {
                    JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
                    logger.info("锁【{}】已释放", lockKey);
                }

                String ext = FilenameUtils.getExtension(filename);
                String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + startLocalDate + '_' + endLocalDate + "statisticsAdvertisingList." + ext;

                try (InputStream input = new FileInputStream(xlsx)) {
                    OssUtil.uploadFile(fileKey, input);
                } catch (IOException e) {
                    logger.error("文件上传至OSS失败！" + e.getMessage(), e);
                    return;
                }

                String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
                logger.info("{}文件OSS路径：{}", user.getLoginName(), fileUrl);
                logger.info("{}文件本地路径：{}", user.getLoginName(), xlsx.getAbsolutePath());

                ajaxResult.put("fileUrl", fileUrl);
                ajaxResult.put("fileName", filename);

                Collection<String> tos = Collections.singletonList(user.getEmail());
                Collection<String> ccs = Collections.singletonList("renqiyao@sczj-inc.com");
                Collection<String> bcc = Collections.singletonList("lichuang@sczj-inc.com");

                String subject = startLocalDate + "至" + endLocalDate + "广告交易数据Excel下载";
                String content = "<a href=\"" + fileUrl + "\">" + subject + "</a></br>数据生成耗时（秒）：" + ((System.currentTimeMillis() - start) / MILLIS_PER_SECOND);

                MailUtil.send(tos, ccs, bcc, subject, content, true);
            }

            /**
             * 设置标题
             * @param sheet
             */
            private void setTitle(Sheet sheet) {
                Row row = sheet.createRow(0);
                String[] titles = {"序号", "用户ID", "设备SN", "交易时间"};
                int len = titles.length;
                for (int i = 0; i < len; i++) {
                    Cell cell = row.createCell(i);
                    cell.setCellValue(titles[i]);
                }
            }
        });

        return ajaxResult;
    }

    /**
     * 按照domain中的excel注解导出
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param sheetName 工作表的名称
     */
    public AjaxResult exportExcel(List<StatisticsDeviceRoi> list, List<StatisticsZjbPlRoi> zjbPlRois, String sheetName) {
        try {
            int size = list.size();
            int wCount = 0;
            /*所有胜出广告计划ID*/
            List<String> planIdList = zjbPlRois.stream()
                    .map(StatisticsZjbPlRoi::getPlanId)
                    .distinct()
                    .sorted()
                    .collect(Collectors.toList());

            /*key=deviceName*/
            Map<String, List<StatisticsZjbPlRoi>> deviceNameMapPl = zjbPlRois.stream()
                    .collect(Collectors.groupingBy(StatisticsZjbPlRoi::getDeviceName));

            Map<String, AdvertisingPlan> mapPlan = new HashMap<>(planIdList.size());

            for (String planId : planIdList) {
                mapPlan.put(planId, advertisingPlanService.findByPlanId(planId));
            }

            logger.info("StatisticsDeviceRoi所有胜出广告计划：{}", planIdList);

            // 得到所有定义字段
            Field[] allFields = StatisticsDeviceRoi.class.getDeclaredFields();
            List<Field> fields = new ArrayList<Field>(32);
            // 得到所有field并存放到一个list中.
            for (Field field : allFields) {
                if (field.isAnnotationPresent(Excel.class)) {
                    fields.add(field);
                }
            }

            // 产生工作薄对象
            SXSSFWorkbook workbook = new SXSSFWorkbook();

            // 产生工作表对象
            Sheet sheet = workbook.createSheet();
            workbook.setSheetName(0, sheetName);

            // 产生一行
            Row row = sheet.createRow(0);
            Cell cell;

            List<Object> allTitle = new ArrayList<>(fields.size() + planIdList.size());

            allTitle.addAll(fields);
            allTitle.addAll(planIdList);

            setTitle(allTitle, row, mapPlan);

            // 写入各条记录,每条记录对应excel表中的一行
            for (int i = 1; i <= size; i++) {
                wCount++;
                row = sheet.createRow(i);
                // 得到导出对象.
                StatisticsDeviceRoi vo = list.get(i - 1);
                String deviceName = vo.getDeviceName();
                List<StatisticsZjbPlRoi> zjbPlRoiList = deviceNameMapPl.get(deviceName);

                boolean empty = (null == zjbPlRoiList || zjbPlRoiList.isEmpty());
                if (empty) {
                    logger.info("设备名称{}对应的PL记录不存在", deviceName);
                }

                Map<String, StatisticsZjbPlRoi> map = empty ? Collections.emptyMap() : zjbPlRoiList.stream()
                        .filter(e -> StringUtils.isNotBlank(e.getPlanId()))
                        .collect(Collectors.toMap(StatisticsZjbPlRoi::getPlanId, Function.identity(), (e, r) -> e));

                for (int j = 0; j < allTitle.size(); j++) {
                    Object title = allTitle.get(j);
                    // 获得field.
                    boolean isStr = title.getClass() == String.class;
                    Field field = isStr ? null : ((Field) title);
                    String value = isStr ? null : BeanUtils.getProperty(vo, field.getName());
                    StatisticsZjbPlRoi plRoi = isStr ? map.get(title.toString()) : null;

                    // 创建cell
                    cell = row.createCell(j);
                    cell.setCellValue(isStr ? (null != plRoi ? plRoi.getAdvertisingBillingTimes().toString() : "") : StringUtils.defaultString(value));
                }

                if (wCount % 100 == 0) {
                    logger.info("已写入{}条记录到Excel中", wCount);
                }
            }

            logger.info("共写入{}条记录到Excel中", wCount);

            String filename = UUID.randomUUID().toString() + "ROI.xlsx";
            OutputStream out = new FileOutputStream(new File(FileUtils.getTempDirectory(), filename));
            workbook.write(out);
            out.close();
            logger.info("{}条数据写入Excel", list.size());
            return AjaxResult.success(filename);
        } catch (Exception e) {
            logger.error("关闭flush失败" + e.getMessage(), e);
            return AjaxResult.error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 收益处理
     *
     * @param mapPlan
     * @param vo
     * @param map
     */
    @Deprecated
    private void handleIncome(Map<String, AdvertisingPlan> mapPlan, StatisticsDeviceRoi vo, Map<String, StatisticsZjbPlRoi> map) {

        if (null == map || map.isEmpty()) {
            return;
        }

        vo.setIncome(BigDecimal.ZERO);
        for (Map.Entry<String, StatisticsZjbPlRoi> entry : map.entrySet()) {
            StatisticsZjbPlRoi zjbPlRoi = entry.getValue();
            AdvertisingPlan plan = mapPlan.get(zjbPlRoi.getPlanId());
            if (null == plan || null == plan.getUnitPrice() || null == zjbPlRoi.getAdvertisingBillingTimes()) {
                continue;
            }
            vo.setIncome(vo.getIncome().add(plan.getUnitPrice().multiply(BigDecimal.valueOf(zjbPlRoi.getAdvertisingBillingTimes()))));
        }
        if (null != vo.getSmbtAccount()) {
            vo.setProfit(vo.getIncome().subtract(BigDecimal.valueOf(vo.getSmbtAccount() / 100F)));
        }
    }

    /**
     * 写入各个字段的列头名称
     *
     * @param allTitle
     * @param row
     * @param mapPlan
     */
    private void setTitle(List<Object> allTitle, Row row, Map<String, AdvertisingPlan> mapPlan) {

        Cell cell;
        int count = allTitle.size();
        int j = 0;
        for (int i = 0; i < allTitle.size(); i++) {
            j++;
            Object title = allTitle.get(i);
            Excel attr = (title instanceof Field) ? ((Field) title).getAnnotation(Excel.class) : null;
            // 创建列
            cell = row.createCell(i);

            AdvertisingPlan plan = (null == attr) ? mapPlan.get(title.toString()) : null;

            // 写入列名
            cell.setCellValue(null == attr ? (null == plan ? title.toString() : title + plan.getPlanName()) : attr.name());
            logger.debug("Excel标题：{}", cell.getStringCellValue());
        }
        logger.info("共{}个标题，已成功创建{}个", count, j);
    }

    /**
     * 数据需求：拉取最近一周目前支付宝端仍有用户进入访问的设备，及对应的代理商、场景、省、市、区、访问UV、PV（仅拉取数据即可，无需做成功能）
     *
     * @param startDate
     * @param endDate
     * @param scanTool
     * @return
     */
    @RequiresPermissions("dsp:advertisingTargetInfo:list")
    @Log(title = "设备PV-UV导出", businessType = BusinessType.EXPORT)
    @PostMapping("/statistics/device/pv/uv")
    @ResponseBody
    public AjaxResult statisticsDevicePvUv(@RequestParam(value = "startDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date startDate,
                                           @RequestParam(value = "endDate", required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date endDate,
                                           @RequestParam(value = "scanTool", defaultValue = "2") Integer scanTool) {


        String scanToolName;
        if (AD_SCAN_TOOL_WX.getValue().equals(scanTool)) {
            scanToolName = AD_SCAN_TOOL_WX.getName();
        } else if (AD_SCAN_TOOL_ALI_PAY.getValue().equals(scanTool)) {
            scanToolName = AD_SCAN_TOOL_ALI_PAY.getName();
        } else {
            scanToolName = "其它";
        }

        long start = System.currentTimeMillis();
        Date startAdRequestDate = (null == startDate ? new Date() : startDate);
        Date endAdRequestDate = (null == endDate ? new Date() : endDate);
        LocalDate startLocalDate = DateUtils.toLocalDateTime(startAdRequestDate).toLocalDate();
        LocalDate endLocalDate = DateUtils.toLocalDateTime(endAdRequestDate).toLocalDate();
        String downFileName = StringUtils.remove(startLocalDate.toString() + "DevicePvUv" + endLocalDate.toString(), '-');
        User user = getUser();

        String lockKey = user.getLoginName() + user.getPassword() + "StatisticsDevicePvUv";
        String requestId = String.valueOf(System.currentTimeMillis());
        Long millisecond = EXRP_5_MINUTE * MILLIS_PER_SECOND;

        if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, millisecond.intValue())) {
            return error("系统繁忙，请稍后再试");
        }

        try {
            List<StatisticsDevicePvUv> list = advertisingTargetInfoService.statisticsDevicePvUv(startAdRequestDate, endAdRequestDate, scanTool);
            ExcelUtil<StatisticsDevicePvUv> util = new ExcelUtil<>(StatisticsDevicePvUv.class);
            AjaxResult ajaxResult = util.exportExcel(list, "StatisticsDevicePv" + scanToolName + "Uv");
            String fileName = ajaxResult.get("msg").toString();
            String ext = FilenameUtils.getExtension(fileName);
            String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + downFileName + '.' + ext;
            File file = new File(FileUtils.getTempDirectory(), fileName);
            OssUtil.uploadFile(fileKey, new FileInputStream(file));
            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            logger.info("{}文件OSS路径：{}", user.getLoginName(), fileUrl);
            logger.info("{}文件本地路径：{}", user.getLoginName(), file.getAbsolutePath());

            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);

            Collection<String> tos = Collections.singletonList(user.getEmail());
            Collection<String> ccs = Collections.singletonList("renqiyao@sczj-inc.com");
            Collection<String> bcc = Collections.singletonList("lichuang@sczj-inc.com");

            String subject = startLocalDate + "至" + endLocalDate + "设备PV" + scanToolName + "UV数据Excel下载";
            String content = "<a href=\"" + fileUrl + "\">" + subject + "</a></br>数据生成耗时（秒）：" + ((System.currentTimeMillis() - start) / MILLIS_PER_SECOND);

            MailUtil.send(tos, ccs, bcc, subject, content, true);

            return ajaxResult;
        } catch (FileNotFoundException e) {
            logger.error(e.getMessage(), e);
            return error(e.getMessage());
        } finally {
            JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
            logger.info("锁【{}】已释放", lockKey);
        }
    }

}
