package com.zjb.project.dsp.advertisingCombinationUnitFans.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
									import java.util.Date;

/**
 * 广告方案/广告池 中间表 zjb_advertising_combination_unit_fans
 * 
 * @author shenlong
 * @date 2019-11-26
 */
public class AdvertisingCombinationUnitFans extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** id */
	private Integer id;
	/** 广告方案id,表【zjb_advertising_combination_fans】主键ID */
	private Integer combinationId;
	/** 广告id，表【zjb_advertising_unit_fans】主键ID */
	private Integer adUnitId;
	/** 位置：用于区分同一广告位的不同位置 */
	private Integer position;
	/**
	 * 业务主键id 格式 “01+id”
	 */
	private String adId;
	/**
	 * 广告名称
	 */
	private String adName;
	/**
	 * 广告图片链接
	 */
	private String adPhotoUrl;
	/**
	 * 使用状态 zjb_ad_use_status
	 */
	private Integer adUseStatus;
	/**
	 * 广告位标识  zjb_ad_space_identifier
	 */
	private String adSpaceIdentifier;
	/**
	 * 广告产品单元类型，参阅字典：zjb_ad_unit_type
	 */
	private String adUnitType;
	/**
	 * 跳转链接
	 */
	private String redirectUrl;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setCombinationId(Integer combinationId) 
	{
		this.combinationId = combinationId;
	}

	public Integer getCombinationId() 
	{
		return combinationId;
	}
	public void setAdUnitId(Integer adUnitId) 
	{
		this.adUnitId = adUnitId;
	}

	public Integer getPosition() {
		return position;
	}

	public void setPosition(Integer position) {
		this.position = position;
	}

	public Integer getAdUnitId()
	{
		return adUnitId;
	}

	public String getAdId() {
		return adId;
	}

	public void setAdId(String adId) {
		this.adId = adId;
	}

	public String getAdName() {
		return adName;
	}

	public void setAdName(String adName) {
		this.adName = adName;
	}

	public String getAdPhotoUrl() {
		return adPhotoUrl;
	}

	public void setAdPhotoUrl(String adPhotoUrl) {
		this.adPhotoUrl = adPhotoUrl;
	}

	public Integer getAdUseStatus() {
		return adUseStatus;
	}

	public void setAdUseStatus(Integer adUseStatus) {
		this.adUseStatus = adUseStatus;
	}

	public String getAdSpaceIdentifier() {
		return adSpaceIdentifier;
	}

	public void setAdSpaceIdentifier(String adSpaceIdentifier) {
		this.adSpaceIdentifier = adSpaceIdentifier;
	}

	public String getAdUnitType() {
		return adUnitType;
	}

	public void setAdUnitType(String adUnitType) {
		this.adUnitType = adUnitType;
	}

	public String getRedirectUrl() {
		return redirectUrl;
	}

	public void setRedirectUrl(String redirectUrl) {
		this.redirectUrl = redirectUrl;
	}


}
