package com.zjb.project.dsp.advertisingCombinationUnitFans.mapper;

import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import java.util.List;	

/**
 * 广告方案/广告池 中间 数据层
 * 
 * @author shenlong
 * @date 2019-11-26
 */
public interface AdvertisingCombinationUnitFansMapper 
{
	/**
     * 查询广告方案/广告池 中间信息
     * 
     * @param id 广告方案/广告池 中间ID
     * @return 广告方案/广告池 中间信息
     */
	public AdvertisingCombinationUnitFans selectAdvertisingCombinationUnitFansById(Integer id);
	
	/**
     * 查询广告方案/广告池 中间列表
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 广告方案/广告池 中间集合
     */
	public List<AdvertisingCombinationUnitFans> selectAdvertisingCombinationUnitFansList(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);
	
	/**
     * 新增广告方案/广告池 中间
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 结果
     */
	public int insertAdvertisingCombinationUnitFans(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);
	
	/**
     * 修改广告方案/广告池 中间
     * 
     * @param advertisingCombinationUnitFans 广告方案/广告池 中间信息
     * @return 结果
     */
	public int updateAdvertisingCombinationUnitFans(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);
	
	/**
     * 删除广告方案/广告池 中间
     * 
     * @param id 广告方案/广告池 中间ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationUnitFansById(Integer id);
	
	/**
     * 批量删除广告方案/广告池 中间
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisingCombinationUnitFansByIds(String[] ids);
	
}