package com.zjb.project.dsp.agency.domain;

import java.math.BigDecimal;
import java.util.Date;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 代理商表 zjb_agency
 *
 * @author songjy
 * @date 2019-07-18
 */
public class Agency extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     * 序号
     */
    private Integer id;
    /**
     * 用户id
     */
    private Integer userId;
    /**
     * 用户名称
     */
    private String userNick;
    /**
     * 上级代理商id
     */
    private Integer parentAgencyId;
    /**
     * 代理商类型 参考字典代理商类型
     */
    private Integer atype;
    /**
     *
     */
    private Integer applyStatus;
    /**
     * 公司名称
     */
    private String name;
    /**
     * 级别 参考字典AGENT_RANK
     */
    private String rankCode;
    /**
     * 省id 参考字典的 提现/打款类别 PAYMENT_TYPE
     */
    private Integer proviceId;
    /**
     * 城市id 参考字典的 提现/打款类别 PAYMENT_TYPE
     */
    private Integer cityId;
    /**
     * 区id
     */
    private Integer areaId;
    /**
     * 区域
     */
    private String zone;
    /**
     * 代理期限之开始日期
     */
    private Date agencyStartDay;
    /**
     * 代理期限之结束日期
     */
    private Date agencyEndDay;
    /**
     * 详细地址
     */
    private String address;
    /**
     * 代理区域-省
     */
    private Integer regionProvice;
    /**
     * 代理区域—市
     */
    private Integer regionCity;
    /**
     * 代理区域—区
     */
    private Integer regionArea;
    /**
     * 联系方式
     */
    private String contact;
    /**
     * 负责人
     */
    private String responsiblePerson;
    /**
     * 邮箱
     */
    private String email;
    /**
     * 传真
     */
    private String fax;
    /**
     * qq
     */
    private String qq;
    /**
     * 状态参考 字典 代理商状态 AGENCY_STATUS
     */
    private String status;
    /**
     * 营业执照 图片地址
     */
    private String businessLicence;
    /**
     * 法人身份证 图片地址
     */
    private String legalPersonIdentityCard;
    /**
     * 发票信息
     */
    private String invoiceInfo;
    /**
     * 协议编号
     */
    private String contractNo;
    /**
     * 收货地址
     */
    private String receiveAddress;
    /**
     * 收入总金额
     */
    private BigDecimal revenueTotal;
    /**
     * 可提现金额
     */
    private BigDecimal revenueCanWithdraw;
    /**
     * 提现中金额
     */
    private BigDecimal revenueWithdrawing;
    /**
     * 已提现金额
     */
    private BigDecimal revenueWithdrawed;
    /**
     * 默认提现类别参考字典的 提现/打款类别 PAYMENT_TYPE
     */
    private Integer defaultWithdrawType;
    /**
     * 支付宝账号
     */
    private String zhifubaoAccount;
    /**
     * 微信账号
     */
    private String weixinAccount;
    /**
     * 银行账户
     */
    private String bankAccount;
    /**
     * 告警接收人
     */
    private String alarmSendee;
    /**
     * 告警联系方式
     */
    private String alarmContact;
    /**
     * 关联合伙人
     */
    private Integer partnerAgencyId;
    /**
     * 服务商来源，1：平台招募 2：合伙人招募,参阅字典[zjb_service_provider_source]
     */
    private String agencySource;
    /**
     * 代理商来源，1：平台招募 2：合伙人招募,参阅字典[zjb_service_provider_source],延时生效用
     */
    private String agencySourceDelay;
    /**
     * 代理商分成说明
     */
    private String benefitRemark;

    /** 代理商名下设备微信端免费扫码次数 */
    private Integer wxCount;
    /** 代理商名下设备支付宝端免费扫码次数 */
    private Integer zfbCount;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserNick(String userNick) {
        this.userNick = userNick;
    }

    public String getUserNick() {
        return userNick;
    }

    public void setParentAgencyId(Integer parentAgencyId) {
        this.parentAgencyId = parentAgencyId;
    }

    public Integer getParentAgencyId() {
        return parentAgencyId;
    }

    public void setAtype(Integer atype) {
        this.atype = atype;
    }

    public Integer getAtype() {
        return atype;
    }

    public void setApplyStatus(Integer applyStatus) {
        this.applyStatus = applyStatus;
    }

    public Integer getApplyStatus() {
        return applyStatus;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setRankCode(String rankCode) {
        this.rankCode = rankCode;
    }

    public String getRankCode() {
        return rankCode;
    }

    public void setProviceId(Integer proviceId) {
        this.proviceId = proviceId;
    }

    public Integer getProviceId() {
        return proviceId;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setZone(String zone) {
        this.zone = zone;
    }

    public String getZone() {
        return zone;
    }

    public void setAgencyStartDay(Date agencyStartDay) {
        this.agencyStartDay = agencyStartDay;
    }

    public Date getAgencyStartDay() {
        return agencyStartDay;
    }

    public void setAgencyEndDay(Date agencyEndDay) {
        this.agencyEndDay = agencyEndDay;
    }

    public Date getAgencyEndDay() {
        return agencyEndDay;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }

    public void setRegionProvice(Integer regionProvice) {
        this.regionProvice = regionProvice;
    }

    public Integer getRegionProvice() {
        return regionProvice;
    }

    public void setRegionCity(Integer regionCity) {
        this.regionCity = regionCity;
    }

    public Integer getRegionCity() {
        return regionCity;
    }

    public void setRegionArea(Integer regionArea) {
        this.regionArea = regionArea;
    }

    public Integer getRegionArea() {
        return regionArea;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getContact() {
        return contact;
    }

    public void setResponsiblePerson(String responsiblePerson) {
        this.responsiblePerson = responsiblePerson;
    }

    public String getResponsiblePerson() {
        return responsiblePerson;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getEmail() {
        return email;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getFax() {
        return fax;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public String getQq() {
        return qq;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setBusinessLicence(String businessLicence) {
        this.businessLicence = businessLicence;
    }

    public String getBusinessLicence() {
        return businessLicence;
    }

    public void setLegalPersonIdentityCard(String legalPersonIdentityCard) {
        this.legalPersonIdentityCard = legalPersonIdentityCard;
    }

    public String getLegalPersonIdentityCard() {
        return legalPersonIdentityCard;
    }

    public void setInvoiceInfo(String invoiceInfo) {
        this.invoiceInfo = invoiceInfo;
    }

    public String getInvoiceInfo() {
        return invoiceInfo;
    }

    public void setContractNo(String contractNo) {
        this.contractNo = contractNo;
    }

    public String getContractNo() {
        return contractNo;
    }

    public void setReceiveAddress(String receiveAddress) {
        this.receiveAddress = receiveAddress;
    }

    public String getReceiveAddress() {
        return receiveAddress;
    }

    public void setRevenueTotal(BigDecimal revenueTotal) {
        this.revenueTotal = revenueTotal;
    }

    public BigDecimal getRevenueTotal() {
        return revenueTotal;
    }

    public void setRevenueCanWithdraw(BigDecimal revenueCanWithdraw) {
        this.revenueCanWithdraw = revenueCanWithdraw;
    }

    public BigDecimal getRevenueCanWithdraw() {
        return revenueCanWithdraw;
    }

    public void setRevenueWithdrawing(BigDecimal revenueWithdrawing) {
        this.revenueWithdrawing = revenueWithdrawing;
    }

    public BigDecimal getRevenueWithdrawing() {
        return revenueWithdrawing;
    }

    public void setRevenueWithdrawed(BigDecimal revenueWithdrawed) {
        this.revenueWithdrawed = revenueWithdrawed;
    }

    public BigDecimal getRevenueWithdrawed() {
        return revenueWithdrawed;
    }

    public void setDefaultWithdrawType(Integer defaultWithdrawType) {
        this.defaultWithdrawType = defaultWithdrawType;
    }

    public Integer getDefaultWithdrawType() {
        return defaultWithdrawType;
    }

    public void setZhifubaoAccount(String zhifubaoAccount) {
        this.zhifubaoAccount = zhifubaoAccount;
    }

    public String getZhifubaoAccount() {
        return zhifubaoAccount;
    }

    public void setWeixinAccount(String weixinAccount) {
        this.weixinAccount = weixinAccount;
    }

    public String getWeixinAccount() {
        return weixinAccount;
    }

    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    public String getBankAccount() {
        return bankAccount;
    }

    public void setAlarmSendee(String alarmSendee) {
        this.alarmSendee = alarmSendee;
    }

    public String getAlarmSendee() {
        return alarmSendee;
    }

    public void setAlarmContact(String alarmContact) {
        this.alarmContact = alarmContact;
    }

    public String getAlarmContact() {
        return alarmContact;
    }

    public void setPartnerAgencyId(Integer partnerAgencyId) {
        this.partnerAgencyId = partnerAgencyId;
    }

    public Integer getPartnerAgencyId() {
        return partnerAgencyId;
    }

    public void setAgencySource(String agencySource) {
        this.agencySource = agencySource;
    }

    public String getAgencySource() {
        return agencySource;
    }

    public void setAgencySourceDelay(String agencySourceDelay) {
        this.agencySourceDelay = agencySourceDelay;
    }

    public String getAgencySourceDelay() {
        return agencySourceDelay;
    }

    public void setBenefitRemark(String benefitRemark) {
        this.benefitRemark = benefitRemark;
    }

    public String getBenefitRemark() {
        return benefitRemark;
    }

    public Integer getWxCount() {
        return wxCount;
    }

    public void setWxCount(Integer wxCount) {
        this.wxCount = wxCount;
    }

    public Integer getZfbCount() {
        return zfbCount;
    }

    public void setZfbCount(Integer zfbCount) {
        this.zfbCount = zfbCount;
    }
}
