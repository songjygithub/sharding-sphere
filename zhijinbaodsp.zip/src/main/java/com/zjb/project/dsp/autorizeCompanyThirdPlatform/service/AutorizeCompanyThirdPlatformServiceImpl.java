package com.zjb.project.dsp.autorizeCompanyThirdPlatform.service;

import java.util.List;

import com.zjb.project.dsp.componentAuthorizationInfo.domain.CompanyThirdPlatformData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.mapper.AutorizeCompanyThirdPlatformMapper;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.domain.AutorizeCompanyThirdPlatform;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.service.IAutorizeCompanyThirdPlatformService;
import com.zjb.common.support.Convert;

/**
 * 授权公司第三方平台 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-03-05
 */
@Service
public class AutorizeCompanyThirdPlatformServiceImpl implements IAutorizeCompanyThirdPlatformService 
{
	@Autowired
	private AutorizeCompanyThirdPlatformMapper autorizeCompanyThirdPlatformMapper;

	/**
     * 查询授权公司第三方平台信息
     * 
     * @param id 授权公司第三方平台ID
     * @return 授权公司第三方平台信息
     */
    @Override
	public AutorizeCompanyThirdPlatform selectAutorizeCompanyThirdPlatformById(Integer id)
	{
	    return autorizeCompanyThirdPlatformMapper.selectAutorizeCompanyThirdPlatformById(id);
	}
	
	/**
     * 查询授权公司第三方平台列表
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 授权公司第三方平台集合
     */
	@Override
	public List<AutorizeCompanyThirdPlatform> selectAutorizeCompanyThirdPlatformList(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{
	    return autorizeCompanyThirdPlatformMapper.selectAutorizeCompanyThirdPlatformList(autorizeCompanyThirdPlatform);
	}
	
    /**
     * 新增授权公司第三方平台
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 结果
     */
	@Override
	public int insertAutorizeCompanyThirdPlatform(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{
	    return autorizeCompanyThirdPlatformMapper.insertAutorizeCompanyThirdPlatform(autorizeCompanyThirdPlatform);
	}
	
	/**
     * 修改授权公司第三方平台
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 结果
     */
	@Override
	public int updateAutorizeCompanyThirdPlatform(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform)
	{
	    return autorizeCompanyThirdPlatformMapper.updateAutorizeCompanyThirdPlatform(autorizeCompanyThirdPlatform);
	}

	/**
     * 删除授权公司第三方平台对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAutorizeCompanyThirdPlatformByIds(String ids)
	{
		return autorizeCompanyThirdPlatformMapper.deleteAutorizeCompanyThirdPlatformByIds(Convert.toStrArray(ids));
	}

	/**
	 * 获取公司主体下有效的第三方平台信息
	 * @param companyId
	 * @return
	 */
	@Override
	public List<CompanyThirdPlatformData> getAutorizeCompanyThirdPlatformList(Integer companyId) {
		return autorizeCompanyThirdPlatformMapper.getAutorizeCompanyThirdPlatformList(companyId);
	}

	/**
	 * 获取公司主体第三方平台信息
	 * @param appId
	 * @return
	 */
	@Override
	public AutorizeCompanyThirdPlatform selectAutorizeCompanyThirdPlatformByAppId(String appId) {
		return autorizeCompanyThirdPlatformMapper.selectAutorizeCompanyThirdPlatformByAppId(appId);
	}

}
