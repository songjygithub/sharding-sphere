package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 获取第三方公众号二维码URL参数
 *
 * @author jiangbingjie
 */
public class ThirdPlatformParameter extends BaseEntity {
    private static final long serialVersionUID = -1358929458634765166L;

    /**
     * 微信公众号
     */
    private String weChatAccount;
    /**
     * 设备二维码
     */
    private String qrCode;
    /**
     * 用户标识ID(用户微信ID｜用户支付宝ID)
     */
    private String openId;
    /**
     * 用户扫码流水号
     */
    private Long randomNum;

    public String getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccount(String weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Long getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(Long randomNum) {
        this.randomNum = randomNum;
    }
}
