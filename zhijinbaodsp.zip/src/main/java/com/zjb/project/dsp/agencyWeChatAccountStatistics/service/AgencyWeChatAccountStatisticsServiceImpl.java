package com.zjb.project.dsp.agencyWeChatAccountStatistics.service;

import com.zjb.common.constant.Constants;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.agencyWeChatAccountStatistics.domain.AgencyWeChatAccountStatistics;
import com.zjb.project.dsp.agencyWeChatAccountStatistics.mapper.AgencyWeChatAccountStatisticsMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 代理商维度公众号统计 服务层实现
 *
 * @author songjy
 * @date 2020-01-02
 */
@Service
public class AgencyWeChatAccountStatisticsServiceImpl implements IAgencyWeChatAccountStatisticsService, InitializingBean {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private AgencyWeChatAccountStatisticsMapper agencyWeChatAccountStatisticsMapper;
    @Autowired
    private IAgencyService agencyService;

    @Override
    public void afterPropertiesSet() throws Exception {
        //statisticsDayToDb(DateUtils.toDate(LocalDate.now().minusDays(1L)));
    }

    @Override
    public void statisticsDayToDb(Date statisticsDay) {

        if (null == statisticsDay) {
            logger.error("未指定统计日期");
            return;
        }

        LocalDate localDate = DateUtils.toLocalDateTime(statisticsDay).toLocalDate();

        if (!localDate.isBefore(LocalDate.now())) {
            logger.debug("指定的统计日期{}必须是早于当前日期", DateUtils.DATE_FORMAT.format(statisticsDay));
            return;
        }

        List<AgencyWeChatAccountStatistics> list = selectByStatisticsDay(statisticsDay);

        if (null == list || list.isEmpty()) {
            logger.warn("{}日未有公众号关注事件", DateUtils.DATE_FORMAT.format(statisticsDay));
            return;
        }

        Map<String, IntSummaryStatistics> summaryStatisticsMap = list.stream()
                .collect(Collectors.groupingBy(e -> {
                            return e.getEvent() + '_' + e.getAgencyId();
                        },
                        Collectors.summarizingInt(AgencyWeChatAccountStatistics::getCount)));

        Set<String> keys = new HashSet<>(summaryStatisticsMap.keySet());
        for (String key : keys) {
            String[] arr = StringUtils.split(key, '_');
            if (null == arr || 2 != arr.length || !StringUtils.isNumeric(arr[1])) {
                continue;
            }

            AgencyWeChatAccountStatistics record = new AgencyWeChatAccountStatistics();
            String event = arr[0];
            Integer agencyId = Integer.parseInt(arr[1]);
            IntSummaryStatistics summaryStatistics = summaryStatisticsMap.remove(key);
            if (null == summaryStatistics) {
                continue;
            }

            Agency agency = agencyService.findById(agencyId);
            Long count = summaryStatistics.getCount();
            record.setStatisticsDay(statisticsDay);
            record.setEvent(event);
            record.setAgencyId(agencyId);
            record.setAgencyName(null == agency ? "未知" : agency.getUserNick());
            record.setSubscribe(AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(record.getEvent()) ? YES.getValue() : NO.getValue());
            if (YES.getValue().equals(record.getSubscribe())) {
                record.setSubscribeCount(count.intValue());
                IntSummaryStatistics unsubscribeStatistics = summaryStatisticsMap.remove(AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue() + "_" + agencyId);
                record.setUnsubscribeCount(null == unsubscribeStatistics ? 0 : (int) (unsubscribeStatistics.getCount()));
            } else {
                record.setUnsubscribeCount(count.intValue());
                IntSummaryStatistics subscribeStatistics = summaryStatisticsMap.remove(AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue() + "_" + agencyId);
                record.setSubscribeCount(null == subscribeStatistics ? 0 : (int) (subscribeStatistics.getCount()));
            }

            List<String> openIdSubscribe = list.stream()
                    .filter(e -> AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(e.getEvent()) && e.getAgencyId().equals(agencyId))
                    .map(AgencyWeChatAccountStatistics::getOpenId)
                    .collect(Collectors.toList());
            List<String> openIdUnsubscribe = list.stream()
                    .filter(e -> AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue().equals(e.getEvent()) && e.getAgencyId().equals(agencyId))
                    .map(AgencyWeChatAccountStatistics::getOpenId)
                    .collect(Collectors.toList());

            openIdSubscribe.retainAll(openIdUnsubscribe);
            record.setSameDayUnsubscribeCount(openIdSubscribe.size());

            agencyWeChatAccountStatisticsMapper.insertAgencyWeChatAccountStatistics(record);
        }
    }

    /**
     * 查询代理商维度公众号统计信息
     *
     * @param id 代理商维度公众号统计ID
     * @return 代理商维度公众号统计信息
     */
    @Override
    public AgencyWeChatAccountStatistics selectAgencyWeChatAccountStatisticsById(Long id) {
        return agencyWeChatAccountStatisticsMapper.selectAgencyWeChatAccountStatisticsById(id);
    }

    /**
     * 查询代理商维度公众号统计列表
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 代理商维度公众号统计集合
     */
    @Override
    public List<AgencyWeChatAccountStatistics> selectAgencyWeChatAccountStatisticsList(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {
        return agencyWeChatAccountStatisticsMapper.selectAgencyWeChatAccountStatisticsList(agencyWeChatAccountStatistics);
    }

    @Override
    public List<AgencyWeChatAccountStatistics> selectByStatisticsDay(Date statisticsDay) {

        if (null == statisticsDay) {
            logger.error("未指定统计日期");
            return Collections.emptyList();
        }

        LocalDate localDate = DateUtils.toLocalDateTime(statisticsDay).toLocalDate();

        String sql = "SELECT `agency_id`,`event`,IFNULL(`openid`, `zjb_openid`) AS `open_id`, COUNT(*) AS `count` FROM `zjb_component_gzh_event` " +
                "WHERE `gmt_date` = ? AND `agency_id` <> -1 GROUP BY `agency_id`,`event`,IFNULL(`openid`, `zjb_openid`)";
        Object[] args = {java.sql.Date.valueOf(localDate)};
        int[] argTypes = {Types.DATE};

        return jdbcTemplate.query(sql, args, argTypes, new RowMapper<AgencyWeChatAccountStatistics>() {
            @Override
            public AgencyWeChatAccountStatistics mapRow(ResultSet rs, int rowNum) throws SQLException {
                AgencyWeChatAccountStatistics record = new AgencyWeChatAccountStatistics();
                record.setStatisticsDay(statisticsDay);
                record.setSubscribeCount(0);
                record.setUnsubscribeCount(0);
                record.setSameDayUnsubscribeCount(0);
                record.setAgencyId(rs.getInt("agency_id"));
                //record.setAgencyName();
                record.setEvent(rs.getString("event"));
                record.setSubscribe(AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(record.getEvent()) ? YES.getValue() : NO.getValue());
                record.setCount(rs.getInt("count"));
                record.setOpenId(rs.getString("open_id"));
                return record;
            }
        });
    }

    /**
     * 新增代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    @Override
    public int insertAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {
        return agencyWeChatAccountStatisticsMapper.insertAgencyWeChatAccountStatistics(agencyWeChatAccountStatistics);
    }

    /**
     * 修改代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    @Override
    public int updateAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics) {
        return agencyWeChatAccountStatisticsMapper.updateAgencyWeChatAccountStatistics(agencyWeChatAccountStatistics);
    }

    /**
     * 删除代理商维度公众号统计对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAgencyWeChatAccountStatisticsByIds(String ids) {
        return agencyWeChatAccountStatisticsMapper.deleteAgencyWeChatAccountStatisticsByIds(Convert.toStrArray(ids));
    }

}
