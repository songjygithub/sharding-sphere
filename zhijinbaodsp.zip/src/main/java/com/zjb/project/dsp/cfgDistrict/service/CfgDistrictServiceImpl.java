package com.zjb.project.dsp.cfgDistrict.service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import com.zjb.common.constant.Constants;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.cfgDistrict.domain.CfgDistrict;
import com.zjb.project.dsp.cfgDistrict.mapper.CfgDistrictMapper;
import com.zjb.project.system.dict.domain.DictData;
import com.zjb.project.system.dict.domain.DictType;
import com.zjb.project.system.dict.mapper.DictDataMapper;
import com.zjb.project.system.dict.mapper.DictTypeMapper;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;
import com.zjb.common.support.Convert;

/**
 * 省市区 服务层实现
 *
 * @author zjb
 * @date 2018-08-15
 */
@Service
public class CfgDistrictServiceImpl implements ICfgDistrictService, InitializingBean {
    @Autowired
    private CfgDistrictMapper cfgDistrictMapper;
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private DictTypeMapper dictTypeMapper;
    @Autowired
    private DictDataMapper dictDataMapper;

    /**
     * 查询省市区信息
     *
     * @param id 省市区ID
     * @return 省市区信息
     */
    @Override
    public CfgDistrict selectCfgDistrictById(Integer id) {
        return cfgDistrictMapper.selectCfgDistrictById(id);
    }

    /**
     * 查询省市区列表
     *
     * @param cfgDistrict 省市区信息
     * @return 省市区集合
     */
    @Override
    public List<CfgDistrict> selectCfgDistrictList(CfgDistrict cfgDistrict) {
        return cfgDistrictMapper.selectCfgDistrictList(cfgDistrict);
    }

    /**
     * 新增省市区
     *
     * @param cfgDistrict 省市区信息
     * @return 结果
     */
    @Override
    public int insertCfgDistrict(CfgDistrict cfgDistrict) {
        return cfgDistrictMapper.insertCfgDistrict(cfgDistrict);
    }

    /**
     * 修改省市区
     *
     * @param cfgDistrict 省市区信息
     * @return 结果
     */
    @Override
    public int updateCfgDistrict(CfgDistrict cfgDistrict) {
        return cfgDistrictMapper.updateCfgDistrict(cfgDistrict);
    }

    /**
     * 删除省市区对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteCfgDistrictByIds(String ids) {
        return cfgDistrictMapper.deleteCfgDistrictByIds(Convert.toStrArray(ids));
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        ZjbDictionaryTypeEnum[] dictionaryTypeEnums = {ZjbDictionaryTypeEnum.DEVICE_SCENE};
        String sqlDictType = "SELECT * FROM `sys_dict_type` WHERE dict_type = ?";
        String sqlDictData = "SELECT * FROM `sys_dict_data` WHERE `dict_type` = ?";


        for (ZjbDictionaryTypeEnum type : dictionaryTypeEnums) {
            Object[] args = {type.getType()};
            try {
                DictType dictType = jdbcTemplate.queryForObject(sqlDictType , args , new RowMapper<DictType>() {
                    @Override
                    public DictType mapRow(ResultSet rs , int rowNum) throws SQLException {
                        DictType dictType = new DictType();
                        dictType.setDictName(rs.getString("dict_name"));
                        dictType.setDictType(rs.getString("dict_type"));
                        dictType.setStatus(rs.getString("status"));
                        dictType.setCreateTime(new Date());
                        dictType.setUpdateTime(dictType.getCreateTime());
                        dictType.setCreateBy("自动导入");
                        dictType.setUpdateBy("自动导入");
                        dictType.setRemark(StringUtils.defaultIfBlank(rs.getString("remark") , "自动导入"));

                        return dictType;
                    }
                });

                dictTypeMapper.insertDictType(dictType);

            } catch (EmptyResultDataAccessException e) {
                continue;
            }

            List<DictData> list = jdbcTemplate.query(sqlDictData , args , new RowMapper<DictData>() {
                @Override
                public DictData mapRow(ResultSet rs , int rowNum) throws SQLException {

                    DictData dictData = new DictData();
                    dictData.setDictSort(rs.getLong("dict_sort"));
                    dictData.setDictLabel(rs.getString("dict_label"));
                    dictData.setDictValue(rs.getString("dict_value"));
                    dictData.setDictType(rs.getString("dict_type"));
                    dictData.setCssClass(rs.getString("css_class"));
                    dictData.setListClass(rs.getString("list_class"));
                    dictData.setIsDefault(rs.getString("is_default"));
                    dictData.setStatus(rs.getString("status"));
                    dictData.setCreateBy("自动导入");
                    dictData.setCreateTime(new Date());
                    dictData.setUpdateBy("自动导入");
                    dictData.setUpdateTime(dictData.getCreateTime());
                    dictData.setRemark(StringUtils.defaultIfBlank(rs.getString("remark") , "自动导入"));

                    return dictData;
                }
            });

            if (null == list || list.isEmpty()) {
                continue;
            }

            for (DictData dictData : list) {
                dictDataMapper.insertDictData(dictData);
            }
        }

    }
}
