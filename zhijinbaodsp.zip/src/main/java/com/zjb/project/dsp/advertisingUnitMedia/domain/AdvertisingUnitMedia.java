package com.zjb.project.dsp.advertisingUnitMedia.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
																	import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * 媒体矩阵广告池表 zjb_advertising_unit_media
 * 
 * @author 17854
 * @date 2020-03-19
 */
public class AdvertisingUnitMedia extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** 广告id 格式 “15”+id */
	private String advertisingId;
	/** 参考：zjb_msg_type；群发的消息类型，图文消息为mpnews，文本消息为text，语音为voice，音乐为music，图片为image，视频为video，卡券为wxcard */
	private String msgtype;
	/** 广告名称 */
	private String name;
	/** 消息的标题 */
	private String title;
	/** 作者 */
	private String author;
	/** 广告描述 */
	private String description;
	/** 图片地址 */
	private String imgUrl;
	/** 文章摘要 */
	private String digest;
	/** 正文 */
	private String content;
	/** 阅读原文地址 */
	private String contentSourceUrl;
	/** 推送数量 */
	private String count;
	/** 推送状态 */
	private Integer sendStatus;
	/** 推送时间 */
	private Date sendTime;
	/** appid列表 */
	private String appid;
	/** 推送成功 */
	private Integer sendSuccess;
	/** 推送失败 */
	private Integer sendErr;
	/** 图文地址 */
	private String contentImg;
	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}

	public String getAdvertisingId() {
		return advertisingId;
	}

	public void setAdvertisingId(String advertisingId) {
		this.advertisingId = advertisingId;
	}

	public void setMsgtype(String msgtype)
	{
		this.msgtype = msgtype;
	}

	public String getMsgtype()
	{
		return msgtype;
	}
	public void setName(String name) 
	{
		this.name = name;
	}

	public String getName() 
	{
		return name;
	}
	public void setTitle(String title) 
	{
		this.title = title;
	}

	public String getTitle() 
	{
		return title;
	}
	public void setAuthor(String author) 
	{
		this.author = author;
	}

	public String getAuthor() 
	{
		return author;
	}
	public void setDescription(String description) 
	{
		this.description = description;
	}

	public String getDescription() 
	{
		return description;
	}
	public void setImgUrl(String imgUrl) 
	{
		this.imgUrl = imgUrl;
	}

	public String getImgUrl() 
	{
		return imgUrl;
	}
	public void setDigest(String digest) 
	{
		this.digest = digest;
	}

	public String getDigest() 
	{
		return digest;
	}
	public void setContent(String content) 
	{
		this.content = content;
	}

	public String getContent() 
	{
		return content;
	}
	public void setContentSourceUrl(String contentSourceUrl) 
	{
		this.contentSourceUrl = contentSourceUrl;
	}

	public String getContentSourceUrl() 
	{
		return contentSourceUrl;
	}
	public void setCount(String count)
	{
		this.count = count;
	}

	public String getCount()
	{
		return count;
	}

	public Integer getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(Integer sendStatus) {
		this.sendStatus = sendStatus;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public Integer getSendSuccess() {
		return sendSuccess;
	}

	public void setSendSuccess(Integer sendSuccess) {
		this.sendSuccess = sendSuccess;
	}

	public Integer getSendErr() {
		return sendErr;
	}

	public void setSendErr(Integer sendErr) {
		this.sendErr = sendErr;
	}

	public String getContentImg() {
		return contentImg;
	}

	public void setContentImg(String contentImg) {
		this.contentImg = contentImg;
	}

	public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("msgtype", getMsgtype())
            .append("name", getName())
            .append("title", getTitle())
            .append("author", getAuthor())
            .append("description", getDescription())
            .append("imgUrl", getImgUrl())
            .append("digest", getDigest())
            .append("content", getContent())
            .append("contentSourceUrl", getContentSourceUrl())
            .append("count", getCount())
            .append("remark", getRemark())
            .append("createrId", getCreaterId())
            .append("modifierId", getModifierId())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("deleted", getDeleted())
            .toString();
    }
}
