package com.zjb.project.dsp.advertisingPlanDevice.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 广告投放设备定向表 zjb_advertising_plan_device
 *
 * @author songjy
 * @date 2019-07-12
 */
public class AdvertisingPlanDevice extends BaseEntity {
    private static final long serialVersionUID = -5188688958521377851L;
    /**
     * 主键
     */
    private Integer id;
    /**
     * 广告投放计划主键，即表[zjb_advertising_plan]的业务主键【plan_id】
     */
    private String adPlanId;

    /**
     * 设备SN定向，0：不限 1：指定设备 2：不投设备
     */
    private Integer radioDeviceSn;

    /**
     * 投放指定设备SN，多个之间用;分隔
     */
    private String deviceSn;
    /**
     * 面向人群(zjb_face_sex) 0：男 1：女 2：综合
     */
    private Integer sex;
    /**
     * 指定投放设备安装地址编码,多个之间用,分隔，如：330000,330482,...
     */
    private String deviceInstallCode;
    /**
     * 指定投放设备安装地址,多个之间用,分隔，如：北京市北京城区东城区,江苏省无锡市惠山区
     */
    private String deviceInstallZone;

    /**
     * 设备场景定向，0:不限 1:指定安装场景 2:不投安装场景
     */
    Integer radioDeviceScene;

    /**
     * 指定投放设备安装场合code 参考 字典 安装场合 SCENE，多个之间用,分隔
     */
    private String deviceScene;
    /**
     * 代理商定向，0:不限 1:指定代理商 2:不投代理商
     */
    Integer radioAgencyId;
    /**
     * 指定投放代理商ID集合，多个之间用,分隔
     */
    private String agencyIdArray;
    /**
     * 正则表达式
     */
    private String regex;

    /**
     * 广告投放指定设备文件名
     */
    private String adPlanDeviceExcel;

    /**
     * 广告投放指定设备文件路径
     */
    private String adPlanDeviceUrl;

    /**
     * 是否金融行业，0：否 1：是
     */
    private Integer categoryFinance;

    /**
     * 是否公众号，0：否 1：是
     */
    private Integer weChatAccount;

    /**
     * 是否个人号，0：否 1：是
     */
    private Integer personalAccount;

    private Integer operationType;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public String getAdPlanId() {
        return adPlanId;
    }

    public void setAdPlanId(String adPlanId) {
        this.adPlanId = adPlanId;
    }

    public Integer getRadioDeviceSn() {
        return radioDeviceSn;
    }

    public void setRadioDeviceSn(Integer radioDeviceSn) {
        this.radioDeviceSn = radioDeviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getSex() {
        return sex;
    }

    public void setDeviceInstallCode(String deviceInstallCode) {
        this.deviceInstallCode = deviceInstallCode;
    }

    public String getDeviceInstallCode() {
        return deviceInstallCode;
    }

    public void setDeviceInstallZone(String deviceInstallZone) {
        this.deviceInstallZone = deviceInstallZone;
    }

    public String getDeviceInstallZone() {
        return deviceInstallZone;
    }

    public Integer getRadioDeviceScene() {
        return radioDeviceScene;
    }

    public void setRadioDeviceScene(Integer radioDeviceScene) {
        this.radioDeviceScene = radioDeviceScene;
    }

    public void setDeviceScene(String deviceScene) {
        this.deviceScene = deviceScene;
    }

    public String getDeviceScene() {
        return deviceScene;
    }

    public Integer getRadioAgencyId() {
        return radioAgencyId;
    }

    public void setRadioAgencyId(Integer radioAgencyId) {
        this.radioAgencyId = radioAgencyId;
    }

    public void setAgencyIdArray(String agencyIdArray) {
        this.agencyIdArray = agencyIdArray;
    }

    public String getAgencyIdArray() {
        return agencyIdArray;
    }

    public void setRegex(String regex) {
        this.regex = regex;
    }

    public String getRegex() {
        return regex;
    }

    public Integer getCategoryFinance() {
        return categoryFinance;
    }

    public void setCategoryFinance(Integer categoryFinance) {
        this.categoryFinance = categoryFinance;
    }

    public Integer getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccount(Integer weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public String getAdPlanDeviceExcel() {
        return adPlanDeviceExcel;
    }

    public void setAdPlanDeviceExcel(String adPlanDeviceExcel) {
        this.adPlanDeviceExcel = adPlanDeviceExcel;
    }

    public String getAdPlanDeviceUrl() {
        return adPlanDeviceUrl;
    }

    public void setAdPlanDeviceUrl(String adPlanDeviceUrl) {
        this.adPlanDeviceUrl = adPlanDeviceUrl;
    }

    public Integer getPersonalAccount() {
        return personalAccount;
    }

    public void setPersonalAccount(Integer personalAccount) {
        this.personalAccount = personalAccount;
    }

    public Integer getOperationType() {
        return operationType;
    }

    public void setOperationType(Integer operationType) {
        this.operationType = operationType;
    }
}
