package com.zjb.project.dsp.appidOpenidIndex.controller;

import java.util.Collections;
import java.util.List;

import com.zjb.common.utils.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.appidOpenidIndex.service.IAppidOpenidIndexService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * openid和appid关系 信息操作处理
 *
 * @author songjy
 * @date 2019-11-01
 */
@Controller
@RequestMapping("/dsp/appidOpenidIndex")
@Deprecated /*已过时，可登录核心系统》》系统监控》》用户关注公众号记录 查看*/
public class AppidOpenidIndexController extends BaseController {
    private String prefix = "dsp/appidOpenidIndex";

    @Autowired
    private IAppidOpenidIndexService appidOpenidIndexService;

    @RequiresPermissions("dsp:appidOpenidIndex:view")
    @GetMapping()
    public String appidOpenidIndex() {
        return prefix + "/appidOpenidIndex";
    }

    /**
     * 查询openid和appid关系列表
     */
    @RequiresPermissions("dsp:appidOpenidIndex:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AppIdOpenIdIndex appidOpenidIndex) {
        startPage();
        List<AppIdOpenIdIndex> list = appidOpenidIndexService.list(appidOpenidIndex.getSearchValue());
        return getDataTable(list);
    }

    /**
     * 新增openid和appid关系
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存openid和appid关系
     */
    @RequiresPermissions("dsp:appidOpenidIndex:add")
    @Log(title = "openid和appid关系", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AppIdOpenIdIndex appidOpenidIndex) {
        return success();
    }

    /**
     * 修改openid和appid关系
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AppIdOpenIdIndex appidOpenidIndex = new AppIdOpenIdIndex();
        mmap.put("appidOpenidIndex", appidOpenidIndex);
        return prefix + "/edit";
    }

    /**
     * 修改保存openid和appid关系
     */
    @RequiresPermissions("dsp:appidOpenidIndex:edit")
    @Log(title = "openid和appid关系", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AppIdOpenIdIndex appidOpenidIndex) {
        return success();
    }

    /**
     * 删除openid和appid关系
     */
    @RequiresPermissions("dsp:appidOpenidIndex:remove")
    @Log(title = "openid和appid关系", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {

        int r = 0;
        for (String id : StringUtils.split(ids, ',')) {
            r += appidOpenidIndexService.deleteById(Integer.parseInt(id));
        }

        return success(r);
    }

}
