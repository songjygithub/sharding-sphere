package com.zjb.project.dsp.advertisingPlanFans.service;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationFans.mapper.AdvertisingCombinationFansMapper;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.AdPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.mapper.AdvertisingPlanFansMapper;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.mapper.AdvertisingUnitFansMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MONTH;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_SECOND;

/**
 * 粉丝通广告投放计划 服务层实现
 *
 * @author shenlong
 * @date 2019-11-22
 */
@Service
public class AdvertisingPlanFansServiceImpl extends AdPlanServiceImpl implements IAdvertisingPlanFansService {
    private static final Logger logger = LoggerFactory.getLogger(AdvertisingPlanFansServiceImpl.class);

    @Autowired
    private AdvertisingPlanFansMapper advertisingPlanFansMapper;
    @Autowired
    protected IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    protected IAdvertisingPlanPepoleService advertisingPlanPepoleService;
    @Autowired
    private AdvertisingCombinationFansMapper advertisingCombinationFansMapper;
    @Autowired
    private AdvertisingUnitFansMapper advertisingUnitFansMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;

    /**
     * 查询粉丝通广告投放计划信息
     *
     * @param id 粉丝通广告投放计划ID
     * @return 粉丝通广告投放计划信息
     */
    @Override
    public AdvertisingPlanFans selectAdvertisingPlanFansById(Serializable id) {

        if (null == id) {
            return null;
        }

        if (id instanceof Integer) {
            return advertisingPlanFansMapper.selectAdvertisingPlanFansById((Integer) id);
        }

        if (id.getClass() == String.class) {
            return advertisingPlanFansMapper.selectAdvertisingPlanFansByPlanId((String) id);
        }

        return null;

    }

    /**
     * 查询粉丝通广告投放计划列表
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 粉丝通广告投放计划集合
     */
    @Override
    public List<AdvertisingPlanFans> selectAdvertisingPlanFansList(AdvertisingPlanFans advertisingPlanFans) {
        return advertisingPlanFansMapper.selectAdvertisingPlanFansList(advertisingPlanFans);
    }

    /**
     * 新增粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans) {
        if(StringUtils.isNotEmpty(advertisingPlanFans.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlanFans);
        }
        int r = advertisingPlanFansMapper.insertAdvertisingPlanFans(advertisingPlanFans);

        if (r <= 0) {
            return r;
        }
        //处理人工授权公众号类型
        handleComponentAuthorizationType(advertisingPlanFans);

        advertisingPlanFans.setPlanId(AD_UNIT_TYPE_FANS.getValue().toString() + advertisingPlanFans.getId());
        r += advertisingPlanFansMapper.updateAdvertisingPlanFans(advertisingPlanFans);

        /*保存广告投放定向信息*/
        r += insertTargetingInfo(advertisingPlanFans);

        synchronizeRedis(advertisingPlanFansMapper.selectAdvertisingPlanFansById(advertisingPlanFans.getId()));
        return r;
    }

    /**
     * 修改粉丝通广告投放计划
     *
     * @param advertisingPlanFans 粉丝通广告投放计划信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingPlanFans(AdvertisingPlanFans advertisingPlanFans) {
        AdvertisingPlan advertisingPlanOld = advertisingPlanFansMapper.selectAdvertisingPlanFansById(advertisingPlanFans.getId());

        if (null == advertisingPlanOld) {
            return 0;
        }
        if(StringUtils.isNotEmpty(advertisingPlanFans.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlanFans);
        }

        setAdvertisingStatus(advertisingPlanFans, advertisingPlanOld);
        //处理人工授权公众号类型
        handleComponentAuthorizationType(advertisingPlanFans);

        boolean thirdPlatform = IMediumSellRullService.MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(advertisingPlanFans.getPlanId());
        advertisingPlanFans.setThirdPlatform(thirdPlatform ? YES.getValue() : NO.getValue());

        int r = advertisingPlanFansMapper.updateAdvertisingPlanFans(advertisingPlanFans);

        if (r <= 0) {
            return r;
        }

        synchronizeAdvertisingStatus(advertisingPlanFans);

        if (null != advertisingPlanFans.getAdvertisingStatus()
                && !advertisingPlanFans.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            /*该广告投放暂停*/
            clearLocalCacheRegex(advertisingPlanOld.getPlanId());
        }

        if (null != advertisingPlanFans.getAdvertisingStatus()
                && advertisingPlanFans.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_PAUSE_MANUAL.getValue())) {
            /*该广告投放恢复*/
            reloadPattern(advertisingPlanOld.getPlanId());
        }

        /*修改广告投放定向信息*/
        r += updateTargetingInfo(advertisingPlanFans);

        AdvertisingPlanFans advertisingPlanNew = advertisingPlanFansMapper.selectAdvertisingPlanFansById(advertisingPlanFans.getId());
        synchronizeRedis(advertisingPlanNew);
        /*Redis中数据保存到数据库中*/
        advertisingPlanFansMapper.updateAdvertisingPlanFans(advertisingPlanNew);

        return r;
    }

    /**
     * 删除粉丝通广告投放计划对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingPlanFansByIds(String ids) {
        return advertisingPlanFansMapper.deleteAdvertisingPlanFansByIds(Convert.toStrArray(ids));
    }


    /**
     * 同步Redis数据
     *
     * @param plan
     */
    public static void synchronizeRedis(AdvertisingPlanFans plan) {

        if (null == plan) {
            return;
        }

        String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + plan.getPlanId();
        AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null != planFromRedis) {
            /*今日花费*/
            plan.setTodaySpend(planFromRedis.getTodaySpend());
            /*今日胜出次数*/
            plan.setTodayWinNum(planFromRedis.getTodayWinNum());
            /*总胜出次数*/
            plan.setTotalWinNum(planFromRedis.getTotalWinNum());
            /*总花费*/
            plan.setTotalSpend(planFromRedis.getTotalSpend());
            /*竞价胜出次数*/
            plan.setBidWinNum(planFromRedis.getBidWinNum());
            /*参与竞价次数*/
            plan.setParticipateBidNum(planFromRedis.getParticipateBidNum());
            /*广告投放状态*/
            if (!ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue().equals(planFromRedis.getAdvertisingStatus())) {
                logger.info("广告计划【{}】暂停", plan.getPlanId());
            }
            plan.setAdvertisingStatus(planFromRedis.getAdvertisingStatus());

        }

        if (ZjbDictionaryEnum.YES.getValue().equals(plan.getDeleted())) {
            JedisPoolCacheUtils.setVExpire(key, "", EXRP_SECOND, ZJB_DB_50);
            return;
        }

        JedisPoolCacheUtils.setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
    }

    @Override
    public int logicDeleteAdvertisingPlanPayByIds(String ids) {
        String[] array = Convert.toStrArray(ids);
        int r = advertisingPlanFansMapper.logicDeleteAdvertisingPlanPayByIds(Convert.toStrArray(ids));

        /*清空缓存对应数据*/
        for (String id : array) {
            id = id.startsWith(AD_UNIT_TYPE_FANS.getValue()) ? id : (AD_UNIT_TYPE_FANS.getValue() + id);
            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + id;
            clearLocalCacheRegex(id);
            JedisPoolCacheUtils.setVExpire(key, "", EXRP_SECOND, ZJB_DB_50);
        }

        return r;
    }

    @Override
    public List<AdvertisingPlanFans> selectByAdAppId(String adAppId) {
        return advertisingPlanFansMapper.selectByAdAppId(adAppId);
    }

    @Override
    public List<AdvertisingPlanFans> selectByUnitId(Integer unitId) {
        if (null == unitId) {
            return Collections.emptyList();
        }

        List<AdvertisingCombinationUnitFans> combinationUnitFans = advertisingCombinationFansMapper.selectByUnitId(unitId);

        if (null == combinationUnitFans || combinationUnitFans.isEmpty()) {
            return Collections.emptyList();
        }

        List<AdvertisingPlanFans> list = new ArrayList<>();

        for (AdvertisingCombinationUnitFans combinationUnit : combinationUnitFans) {
            AdvertisingPlanFans advertisingPlan = new AdvertisingPlanFans();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());
            List<AdvertisingPlanFans> planFans = advertisingPlanFansMapper.selectAdvertisingPlanFansList(advertisingPlan);
            if (null != planFans && !planFans.isEmpty()) {
                list.addAll(planFans);
            }
        }

        return list;
    }

    private void handleComponentAuthorizationType(AdvertisingPlanFans advertisingPlanFans) {
        if (advertisingPlanFans == null || null == advertisingPlanFans.getCombinationId()) {
            return;
        }
        AdvertisingCombinationFans advertisingCombinationFans = advertisingCombinationFansMapper.selectAdvertisingCombinationFansById(advertisingPlanFans.getCombinationId());
        if (advertisingCombinationFans == null || null == advertisingCombinationFans.getId()) {
            return;
        }
        AdvertisingCombinationUnitFans unit = new AdvertisingCombinationUnitFans();
        unit.setCombinationId(advertisingCombinationFans.getId());

        List<AdvertisingCombinationUnitFans> advertisingCombinationUnitFansList = advertisingCombinationFansMapper.selectAdvertisingCombinationUnitFansList(unit);
        if (advertisingCombinationUnitFansList == null || advertisingCombinationUnitFansList.isEmpty()) {
            return;
        }
        advertisingCombinationUnitFansList = advertisingCombinationUnitFansList.stream().filter(e -> e.getAdSpaceIdentifier().equals(AD_FANS_PAPER_OUTPUT.getValue())).collect(Collectors.toList());

        if (advertisingCombinationUnitFansList.size() != 1) {
            /*扫码取纸位只能有一条记录*/
            return;
        }
        AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansMapper.selectAdvertisingUnitFansById(advertisingCombinationUnitFansList.get(0).getAdUnitId());
        if (advertisingUnitFans == null || null == advertisingUnitFans.getAdUseStatus() || !AD_USE_YES.getValue().equals(advertisingUnitFans.getAdUseStatus()) || StringUtils.isEmpty(advertisingUnitFans.getWeChatAccount())) {
            return;
        }
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(advertisingUnitFans.getWeChatAccount());
        if (componentAuthorizationInfo == null) {
            return;
        }
        advertisingPlanFans.setComponentAuthorizationType(componentAuthorizationInfo.getComponentAuthorizationType());
    }

    private void handleDeviceInstallScene(AdvertisingPlanFans advertisingPlanFans){
        if(StringUtils.isEmpty(advertisingPlanFans.getInstallSceneIds())){
            return;
        }
        Set<String> set = new HashSet<>();
        String[] sceneIds = advertisingPlanFans.getInstallSceneIds().split(",");
        if(sceneIds == null || sceneIds.length<=0){
            return;
        }
        for(String sceneId : sceneIds){
            DeviceInstallScene deviceInstallScene = deviceInstallSceneService.getDeviceInstallSceneById(sceneId);
            if(deviceInstallScene != null && StringUtils.isNotEmpty(deviceInstallScene.getSceneCode())){
                set.add(deviceInstallScene.getSceneCode());
            }
        }
        if(set.size() == 0){
            return;
        }
        advertisingPlanFans.setDeviceScene(String.join(",", set));

    }
}
