package com.zjb.project.dsp.advertisingPlanFans.controller;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.PageDomain;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.page.TableSupport;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationFans.service.IAdvertisingCombinationFansService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.service.IWeChatPersonalService;
import com.zjb.project.system.user.domain.User;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.AdUnit;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 粉丝通广告投放计划 信息操作处理
 *
 * @author shenlong
 * @date 2019-11-22
 */
@Controller
@RequestMapping("/dsp/advertisingPlanFans")
public class AdvertisingPlanFansController extends BaseController {
    private static final Logger log = LoggerFactory.getLogger(AdvertisingPlanFansController.class);
    private String prefix = "dsp/advertisingPlanFans";

    @Autowired
    private IAdvertisingPlanFansService advertisingPlanFansService;
    @Autowired
    private IAdvertisingCombinationFansService advertisingCombinationFansService;
    @Autowired
    private IAgencyService agencyService;
    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;
    @Autowired
    private IWeChatPersonalService weChatPersonalService;
    @Autowired
    private IAdvertisingPlanPepoleService advertisingPlanPeopleService;

    @RequiresPermissions("dsp:advertisingPlanFans:view")
    @GetMapping()
    public String advertisingPlanFans(ModelMap mmap) {
        AdvertisingCombinationFans advertisingCombination = new AdvertisingCombinationFans();
        List<AdvertisingCombinationFans> advertisingCombinations = advertisingCombinationFansService.selectAdvertisingCombinationFansList(advertisingCombination);
        mmap.put("advertisingCombinations", advertisingCombinations);
        return prefix + "/advertisingPlanFans";
    }

    /**
     * 查询粉丝通广告投放计划列表
     */
    @RequiresPermissions("dsp:advertisingPlanFans:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingPlanFans advertisingPlanFans) {
        startPageForDiy();
        List<AdvertisingPlanFans> list = advertisingPlanFansService.selectAdvertisingPlanFansList(advertisingPlanFans);

        DecimalFormat decimalFormat = new DecimalFormat("0%");
        for (AdvertisingPlan e : list) {

            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + e.getPlanId();
            AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            if (null != planFromRedis) {
                /*今日花费*/
                e.setTodaySpend(planFromRedis.getTodaySpend());
                /*今日胜出次数*/
                e.setTodayWinNum(planFromRedis.getTodayWinNum());
                /*总胜出次数*/
                e.setTotalWinNum(planFromRedis.getTotalWinNum());
                /*总花费*/
                e.setTotalSpend(planFromRedis.getTotalSpend());
                /*竞价胜出次数*/
                e.setBidWinNum(planFromRedis.getBidWinNum());
                /*参与竞价次数*/
                e.setParticipateBidNum(planFromRedis.getParticipateBidNum());
            }

            boolean zero = (null == e.getBidWinNum() || 0 == e.getBidWinNum() || null == e.getParticipateBidNum()
                    || 0 == e.getParticipateBidNum());
            e.setWinRate(zero ? "--" : decimalFormat.format(1F * e.getBidWinNum() / e.getParticipateBidNum()));

            User user = getUser(e.getCreaterId());
            e.setCreateBy(null == user ? null : user.getUserName());

            user = getUser(e.getModifierId());
            e.setUpdateBy(null == user ? null : user.getUserName());

            AdvertisingCombinationFans advertisingCombination = advertisingCombinationFansService.selectAdvertisingCombinationFansById(e.getCombinationId());
            e.setCombinationName(null == advertisingCombination ? null : advertisingCombination.getName());
        }
        PageDomain pageDomain = TableSupport.buildPageRequest();
        String orderBy = pageDomain.getOrderBy();
        if (StringUtils.isEmpty(orderBy)) {
            CollectionUtils.sortTheList(list, "todayWinNum", CollectionUtils.SORT_ORDER.DESC);
        }

        return getDataTable(list);
    }

    /**
     * 新增粉丝通广告投放计划
     */
    @GetMapping("/add")
    public String add(ModelMap mmap) {

        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /** 过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());
        mmap.put("agencyList", agencyList);
        mmap.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});

        AdvertisingCombinationFans advertisingCombinationFans = new AdvertisingCombinationFans();

        List<AdvertisingCombinationFans> advertisingCombinations = advertisingCombinationFansService.selectAdvertisingCombinationFansList(advertisingCombinationFans);
        mmap.put("advertisingCombinationsFans", advertisingCombinations);
        return prefix + "/add";
    }

    /**
     * 新增保存粉丝通广告投放计划
     */
    @RequiresPermissions("dsp:advertisingPlanFans:add")
    @Log(title = "粉丝通广告投放计划", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanFans advertisingPlanFans) {
        AjaxResult ajaxResult = check(advertisingPlanFans);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        handleFile(file, advertisingPlanFans, deviceService);

        User user = getUser();
        advertisingPlanFans.setCreaterId(user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationFansService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlanFans.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlanFans.getRadioWeChatOfficialAccount() || ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlanFans.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }
            advertisingPlanFans.setAdAppId(list.get(0).getAppId());
        }

        List<WeChatPersonal> weChatPersonals = advertisingCombinationFansService.isWeChatPersonalAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != weChatPersonals && !weChatPersonals.isEmpty()) {
            advertisingPlanFans.setWeChatPersonalId(weChatPersonals.get(0).getPersonalId());
        }

        List<QqPersonal> qqPersonals = advertisingCombinationFansService.isQQPersonalAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != qqPersonals && !qqPersonals.isEmpty()) {
            advertisingPlanFans.setQqPersonalId(qqPersonals.get(0).getPersonalId());
        }

        advertisingPlanFans.setInsertBaseParams(user.getUserId().intValue(), user.getUserId().intValue());
        int r = advertisingPlanFansService.insertAdvertisingPlanFans(advertisingPlanFans);

        advertisingPlanFansService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 修改粉丝通广告投放计划
     */
    @GetMapping("/regex/{id}")
    public String regex(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlanFans advertisingPlan = advertisingPlanFansService.selectAdvertisingPlanFansById(id);
        mmap.put("advertisingPlan", advertisingPlan);
        Pattern devicePattern = advertisingPlanDeviceService.pattern(advertisingPlan.getPlanId());
        Pattern peoplePattern = advertisingPlanPeopleService.pattern(advertisingPlan.getPlanId());
        mmap.put("devicePattern", null == devicePattern ? "" : devicePattern.pattern());
        mmap.put("peoplePattern", null == peoplePattern ? "" : peoplePattern.pattern());

        return prefix + "/regex";
    }

    /**
     * 修改粉丝通广告投放计划
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /** 过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());

        AdvertisingPlanFans advertisingPlan = advertisingPlanFansService.selectAdvertisingPlanFansById(id);
        AdvertisingCombinationFans advertisingCombination = new AdvertisingCombinationFans();
        List<AdvertisingCombinationFans> advertisingCombinations = advertisingCombinationFansService.selectAdvertisingCombinationFansList(advertisingCombination);

        if (StringUtils.isNotEmpty(advertisingPlan.getDeviceScene())) {
            String deviceSceneIds = deviceInstallSceneService.getSceneIdsByCode(advertisingPlan.getDeviceScene());
            mmap.put("deviceSceneIds", deviceSceneIds);
        }

        mmap.put("deviceSceneSelected", StringUtils.split(advertisingPlan.getDeviceScene(), ','));
        mmap.put("agencyIdSelected", null == advertisingPlan.getAgencyIdArray() ? null : Convert.toIntArray(advertisingPlan.getAgencyIdArray()));
        mmap.put("agencyList", agencyList);
        mmap.put("advertisingCombinations", advertisingCombinations);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
        mmap.put("paperTodayNumSelected", StringUtils.isBlank(advertisingPlan.getPaperTodayNum()) ? null : Convert.toIntArray(advertisingPlan.getPaperTodayNum()));

        return prefix + "/edit";
    }

    /**
     * 修改保存粉丝通广告投放计划
     */
    @RequiresPermissions("dsp:advertisingPlanFans:edit")
    @Log(title = "粉丝通广告投放计划", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanFans advertisingPlanFans) {
        AdvertisingPlanFans advertisingPlanOld = advertisingPlanFansService.selectAdvertisingPlanFansById(advertisingPlanFans.getId());

        if (null == advertisingPlanOld) {
            return error("记录不存在");
        }

        AjaxResult ajaxResult = check(advertisingPlanFans);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        handleFile(file, advertisingPlanFans, deviceService);

        User user = getUser();
        advertisingPlanFans.setModifierId(null == user ? null : user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationFansService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlanFans.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlanFans.getRadioWeChatOfficialAccount() || ZjbDictionaryEnum.AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlanFans.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }
            advertisingPlanFans.setAdAppId(list.get(0).getAppId());
        } else {
            advertisingPlanFans.setAdAppId(null);
        }

        List<WeChatPersonal> weChatPersonals = advertisingCombinationFansService.isWeChatPersonalAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != weChatPersonals && !weChatPersonals.isEmpty()) {
            advertisingPlanFans.setWeChatPersonalId(weChatPersonals.get(0).getPersonalId());
        }

        List<QqPersonal> qqPersonals = advertisingCombinationFansService.isQQPersonalAccountOnSpacePaperOutput(advertisingPlanFans.getCombinationId());
        if (null != qqPersonals && !qqPersonals.isEmpty()) {
            advertisingPlanFans.setQqPersonalId(qqPersonals.get(0).getPersonalId());
        }

        if (null != advertisingPlanFans.getOperationType()
                && advertisingPlanFans.getOperationType().equals(IAdPlanService.OPERATION_TYPE_UPDATE)) {
            advertisingPlanFans.setCategoryFinance(null == advertisingPlanFans.getCategoryFinance() ? NO.getValue() : advertisingPlanFans.getCategoryFinance());
            advertisingPlanFans.setWeChatAccount(null == advertisingPlanFans.getWeChatAccount() ? NO.getValue() : advertisingPlanFans.getWeChatAccount());
            advertisingPlanFans.setPersonalAccount(null == advertisingPlanFans.getPersonalAccount() ? NO.getValue() : advertisingPlanFans.getPersonalAccount());

        }

        advertisingPlanFans.setWinFrequency(null == advertisingPlanFans.getWinFrequency() ? 0L : advertisingPlanFans.getWinFrequency());
        advertisingPlanFans.setGmtModified(new Date());
        int r = advertisingPlanFansService.updateAdvertisingPlanFans(advertisingPlanFans);
        advertisingPlanFansService.mediumSellRuleThreeNotice();
        return toAjax(r);
    }

    /**
     * 参数校验
     *
     * @param advertisingPlan
     * @return
     */
    public static AjaxResult check(AdvertisingPlanFans advertisingPlan) {

        if (YES.getValue().toString().equals(advertisingPlan.getLongTermEffective())
                && (null != advertisingPlan.getGmtShowEnd() || null != advertisingPlan.getGmtShowStart())) {
            return AjaxResult.error("开始|结束时间无需指定");
        }

        if (NO.getValue().toString().equals(advertisingPlan.getLongTermEffective())
                && (null == advertisingPlan.getGmtShowEnd() || null == advertisingPlan.getGmtShowStart())) {
            return AjaxResult.error("开始|结束时间未指定");
        }

        if (null == advertisingPlan.getGmtShowEnd() && null != advertisingPlan.getGmtShowStart()) {
            return AjaxResult.error("结束时间未指定");
        }

        if (null != advertisingPlan.getGmtShowEnd() && null == advertisingPlan.getGmtShowStart()) {
            return AjaxResult.error("开始时间未指定");
        }

        if (null != advertisingPlan.getGmtShowEnd() && null != advertisingPlan.getGmtShowStart()
                && advertisingPlan.getGmtShowStart().after(advertisingPlan.getGmtShowEnd())) {
            return AjaxResult.error("开始时间不能大于结束时间");
        }

        Integer paperTodayLowerNum = advertisingPlan.getPaperTodayLowerNum();
        Integer paperTodayUpperNum = advertisingPlan.getPaperTodayUpperNum();

        if (null == paperTodayLowerNum && null != paperTodayUpperNum) {
            return AjaxResult.error("请指定当日取纸下限");
        }

        if (null != paperTodayLowerNum && null == paperTodayUpperNum) {
            return AjaxResult.error("请指定当日取纸上限");
        }

        if (null != paperTodayLowerNum && null != paperTodayUpperNum && paperTodayLowerNum > paperTodayUpperNum) {
            return AjaxResult.error("当日取纸下限不能大于上限");
        }

        Integer paperLowerNum = advertisingPlan.getPaperLowerNum();
        Integer paperUpperNum = advertisingPlan.getPaperUpperNum();

        if (null == paperLowerNum && null != paperUpperNum) {
            return AjaxResult.error("请指定总取纸下限");
        }

        if (null != paperLowerNum && null == paperUpperNum) {
            return AjaxResult.error("请指定总取纸上限");
        }

        if (null != paperLowerNum && null != paperUpperNum && paperLowerNum > paperUpperNum) {
            return AjaxResult.error("总取纸下限不能大于上限");
        }

        return null;
    }


    /**
     * 处理上传文件,即提取SN
     *
     * @param file
     * @param advertisingPlan
     * @param deviceService
     */
    public static void handleFile(MultipartFile file, AdvertisingPlanFans advertisingPlan, IDeviceService deviceService) {

        if (null == file || file.isEmpty() || null == advertisingPlan) {
            return;
        }

        try (InputStream is = file.getInputStream()) {
            ExcelUtil<AdvertisingPlan> util = new ExcelUtil<AdvertisingPlan>(AdvertisingPlan.class);
            /*sheetName必须是：addevice*/
            List<AdvertisingPlan> list = util.importExcel("addevice", is);
            if (null == list || list.isEmpty()) {
                log.warn("文件格式错误或空文件");
                return;
            }

            Set<String> set = new HashSet<>();
            for (AdvertisingPlan e : list) {
                if (StringUtils.isNotEmpty(e.getMixId())) {
                    String mixId = StringUtils.trim(e.getMixId().replaceAll("\\xa0", "").replaceAll("\u00A0", ""));
                    DeviceDTO device = deviceService.selectDeviceByMixId(mixId);
                    if (null != device && StringUtils.isNotBlank(device.getSn())) {
                        set.add(device.getSn());
                    } else {
                        log.warn("无效mixId：【{}】", e.getMixId());
                    }
                }
            }

            if (set.size() == 0) {
                return;
            }

            advertisingPlan.setDeviceSn(String.join(",", set));

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 删除粉丝通广告投放计划
     */
    @RequiresPermissions("dsp:advertisingPlanFans:remove")
    @Log(title = "粉丝通广告投放计划删除", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingPlanFansService.logicDeleteAdvertisingPlanPayByIds(ids));
    }


    /**
     * 边界广告投放计划权重
     */
    @GetMapping("/weight/{id}")
    public String weight(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlan advertisingPlan = advertisingPlanFansService.selectAdvertisingPlanFansById(id);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("planWeightArray", new int[]{1, 2, 3, 4, 5});
        return prefix + "/weight";
    }

    /**
     * 边界广告投放计划权重
     */
    @RequiresPermissions("zjb:advertisingPlan:weight")
    @Log(title = "粉丝通广告投放计划权重设置", businessType = BusinessType.UPDATE)
    @PostMapping("/weight")
    @ResponseBody
    public AjaxResult weight(AdvertisingPlanFans advertisingPlan, ModelMap mmap) {

        User user = getUser();
        advertisingPlan.setModifierId(user.getUserId().intValue());

        advertisingPlanFansService.updateAdvertisingPlanFans(advertisingPlan);

        return success();
    }

    /**
     * 广告投放计划手动暂停
     */
    @RequiresPermissions("zjb:advertisingPlan:pause")
    @Log(title = "粉丝通广告投放计划手动暂停", businessType = BusinessType.UPDATE)
    @PostMapping("/pause")
    @ResponseBody
    public AjaxResult pause(String ids) {

        for (String id : StringUtils.split(ids)) {
            AdvertisingPlanFans advertisingPlan = advertisingPlanFansService.selectAdvertisingPlanFansById(Integer.parseInt(id));
            advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlanFansService.updateAdvertisingPlanFans(advertisingPlan);
        }

        return success();
    }

    /**
     * 广告投放计划手动恢复
     */
    @RequiresPermissions("zjb:advertisingPlan:resume")
    @Log(title = "粉丝通广告投放计划手动恢复", businessType = BusinessType.UPDATE)
    @PostMapping("/resume")
    @ResponseBody
    public AjaxResult resume(String ids) {

        User user = getUser();

        for (String id : StringUtils.split(ids)) {

            AdvertisingPlanFans advertisingPlan = advertisingPlanFansService.selectAdvertisingPlanFansById(Integer.parseInt(id));

            AdCombinationInfo combinationInfo = adExchangeService.advertisingCombination(advertisingPlan);

            if (null == combinationInfo || null == combinationInfo.getScan() || combinationInfo.getScan().isEmpty()) {
                return error("该广告计划对应的扫码取纸广告已停用，如需恢复请先至广告池中将对应扫码取纸广告启用。");
            }


            for (AdUnit u : combinationInfo.getScan()) {
                String adId = u.getId().substring(ZjbDictionaryEnum.AD_COMBINATION_UNIT_PREFIX.getValue().toString().length());
                AdvertisingUnitFans advertisingUnit = advertisingUnitFansService.selectAdvertisingUnitFansById(Integer.parseInt(adId));
                if (null == advertisingUnit || null == advertisingUnit.getAdUseStatus() || advertisingUnit.getAdUseStatus().equals(AD_USE_NO.getValue())) {
                    return error("该广告计划对应的扫码取纸广告已停用，如需恢复请先至广告池中将对应扫码取纸广告启用。");
                }
            }

            if (StringUtils.isNotBlank(advertisingPlan.getWeChatPersonalId())) {
                WeChatPersonal weChatPersonal = weChatPersonalService.selectByPersonalId(advertisingPlan.getWeChatPersonalId());
                if (null == weChatPersonal || weChatPersonal.getDeleted().equals(YES.getValue())) {
                    return error("该广告计划关联的微信个人号" + advertisingPlan.getWeChatPersonalId() + "已删除");
                }

                if (!weChatPersonal.getDeliveryStatus().equals(WE_CHAT_PERSONAL_DELIVERY_RUN.getValue())) {
                    return error("该广告计划关联的微信个人号" + advertisingPlan.getWeChatPersonalId() + "未生效");
                }
            }


            advertisingPlan.setAdvertisingStatus(AD_PLAN_STATUS_OK.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlan.setModifierId(user.getUserId().intValue());
            advertisingPlanFansService.updateAdvertisingPlanFans(advertisingPlan);
            advertisingPlanFansService.reloadPattern(advertisingPlan.getPlanId());
        }

        return success();
    }

    /**
     * 文件上传
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return error("文件为空");
        }

        String fileName = FilenameUtils.getName(file.getOriginalFilename());
        String ext = FilenameUtils.getExtension(fileName);
        String md5 = DigestUtils.md5Hex(fileName);
        String fileKey = zjbConfig.getAdPlanDeviceFileUrl() + LocalDate.now() + '/' + md5 + '.' + ext;
        try {
            OssUtil.uploadFile(fileKey, file.getInputStream());
            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            log.debug("文件OSS路径：{}", fileUrl);
            AjaxResult ajaxResult = success();
            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);
            return ajaxResult;
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            return error(e.getMessage());
        }
    }

    @Log(title = "粉丝通广告投放计划", businessType = BusinessType.EXPORT)
    @PostMapping("/export/sn")
    @ResponseBody
    public AjaxResult exportDeviceSn(AdvertisingPlanFans advertisingPlan) {

        List<AdvertisingPlan> list = new ArrayList<>();
        ExcelUtil<AdvertisingPlan> util = new ExcelUtil(AdvertisingPlanFans.class);
        /*sheetName必须是：addevice，否则无法直接上传导入分成配置*/
        String sheetName = "addevice";

        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceService.selectAdvertisingPlanDeviceByPlanId(advertisingPlan.getPlanId());

        if (null == advertisingPlanDevice) {
            return util.exportExcel(list, sheetName);
        }

        String[] array = StringUtils.split(advertisingPlanDevice.getDeviceSn(), ',');

        if (null == array || array.length == 0) {
            return util.exportExcel(list, sheetName);
        }

        for (String sn : array) {
            AdvertisingPlan record = new AdvertisingPlan();
            record.setMixId(sn);
            list.add(record);
        }

        return util.exportExcel(list, sheetName);
    }


}
