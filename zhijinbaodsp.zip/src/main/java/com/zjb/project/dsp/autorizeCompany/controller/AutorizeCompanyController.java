package com.zjb.project.dsp.autorizeCompany.controller;

import java.util.List;

import com.zjb.common.utils.StringUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.autorizeCompany.domain.AutorizeCompany;
import com.zjb.project.dsp.autorizeCompany.service.IAutorizeCompanyService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 授权公司主体 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-02-28
 */
@Controller
@RequestMapping("/dsp/autorizeCompany")
public class AutorizeCompanyController extends BaseController
{
    private String prefix = "dsp/autorizeCompany";
	
	@Autowired
	private IAutorizeCompanyService autorizeCompanyService;
	
	@RequiresPermissions("dsp:autorizeCompany:view")
	@GetMapping()
	public String autorizeCompany()
	{
	    return prefix + "/autorizeCompany";
	}
	
	/**
	 * 查询授权公司主体列表
	 */
	@RequiresPermissions("dsp:autorizeCompany:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AutorizeCompany autorizeCompany)
	{
		startPage();
        List<AutorizeCompany> list = autorizeCompanyService.selectAutorizeCompanyList(autorizeCompany);
		return getDataTable(list);
	}
	
	/**
	 * 新增授权公司主体
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存授权公司主体
	 */
	@RequiresPermissions("dsp:autorizeCompany:add")
	@Log(title = "授权公司主体", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(AutorizeCompany autorizeCompany)
	{		
		return toAjax(autorizeCompanyService.insertAutorizeCompany(autorizeCompany));
	}

	/**
	 * 修改授权公司主体
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AutorizeCompany autorizeCompany = autorizeCompanyService.selectAutorizeCompanyById(id);
		mmap.put("autorizeCompany", autorizeCompany);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存授权公司主体
	 */
	@RequiresPermissions("dsp:autorizeCompany:edit")
	@Log(title = "授权公司主体", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(AutorizeCompany autorizeCompany)
	{		
		return toAjax(autorizeCompanyService.updateAutorizeCompany(autorizeCompany));
	}
	
	/**
	 * 删除授权公司主体
	 */
	@RequiresPermissions("dsp:autorizeCompany:remove")
	@Log(title = "授权公司主体", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(autorizeCompanyService.deleteAutorizeCompanyByIds(ids));
	}

	/**
	 * 根据APPID获取APPSECRET
	 * @param autorizeCompany
	 * @return
	 */
	@PostMapping("/getAppSecretByAppId")
	@ResponseBody
	public String getAppSecretByAppId(@RequestBody AutorizeCompany autorizeCompany){
		if(null == autorizeCompany || StringUtils.isEmpty(autorizeCompany.getAppId())){
			return null;
		}
		AutorizeCompany autorizeCompany1 = autorizeCompanyService.selectAutorizeCompanyByAppId(autorizeCompany.getAppId());
		if(autorizeCompany1 == null || StringUtils.isEmpty(autorizeCompany1.getAppSecret())){
			return null;
		}
		return autorizeCompany1.getAppSecret();
	}


	
}
