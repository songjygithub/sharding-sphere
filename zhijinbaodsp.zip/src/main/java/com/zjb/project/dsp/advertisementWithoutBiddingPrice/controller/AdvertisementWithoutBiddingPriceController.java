package com.zjb.project.dsp.advertisementWithoutBiddingPrice.controller;

import java.io.IOException;
import java.io.InputStream;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import com.zjb.project.dsp.advertisementPlanDevice.service.IAdvertisementPlanDeviceService;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.WithoutBiddingAdStatisticsVo;
import com.zjb.project.dsp.advertisingPlan.controller.AdvertisingPlanController;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.withoutBiddingAdStatistics.domain.WithoutBiddingAdStatistics;
import com.zjb.project.dsp.withoutBiddingAdStatistics.service.IWithoutBiddingAdStatisticsService;
import com.zjb.project.system.dict.domain.DictData;
import com.zjb.project.system.dict.service.IDictDataService;
import com.zjb.project.system.user.domain.User;
import io.swagger.models.auth.In;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.AdvertisementWithoutBiddingPrice;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.service.IAdvertisementWithoutBiddingPriceService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 非竞价广告投放 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-03-30
 */
@Controller
@RequestMapping("/dsp/advertisementWithoutBiddingPrice")
public class AdvertisementWithoutBiddingPriceController extends BaseController
{
	private static final Logger logger = LoggerFactory.getLogger(AdvertisementWithoutBiddingPriceController.class);

    private String prefix = "dsp/advertisementWithoutBiddingPrice";
	
	@Autowired
	private IAdvertisementWithoutBiddingPriceService advertisementWithoutBiddingPriceService;
	@Autowired
	private IAdvertisingUnitFansService advertisingUnitFansService;
	@Autowired
	private IDictDataService dataService;
	@Autowired
	private IWithoutBiddingAdStatisticsService withoutBiddingAdStatisticsService;
	@Autowired
	private ZjbConfig zjbConfig;
	@Autowired
	private IDeviceService deviceService;
	@Autowired
	private IAdvertisementPlanDeviceService iAdvertisementPlanDeviceService;
	
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:view")
	@GetMapping()
	public String advertisementWithoutBiddingPrice(ModelMap modelMap)
	{
	    return prefix + "/advertisementWithoutBiddingPrice";
	}
	
	/**
	 * 查询非竞价广告投放列表
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
		String date = DateUtils.getDate();
		startPage();
        List<AdvertisementWithoutBiddingPrice> list = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceList(advertisementWithoutBiddingPrice);
        if(list != null && !list.isEmpty()){
        	for(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice1 : list){
        		if(null != advertisementWithoutBiddingPrice1.getCreaterId()){
        			User user = userService.selectUserById(Long.valueOf(advertisementWithoutBiddingPrice1.getCreaterId()));
        			if(null != user){
        				advertisementWithoutBiddingPrice1.setCreateBy(user.getUserName());
					}
				}
				if(null != advertisementWithoutBiddingPrice1.getModifierId()){
					User user = userService.selectUserById(Long.valueOf(advertisementWithoutBiddingPrice1.getModifierId()));
					if(null != user){
						advertisementWithoutBiddingPrice1.setUpdateBy(user.getUserName());
					}
				}
        		int showTimes = 0;
        		int showPersons = 0;
        		int clickTimes = 0;
        		int clickPersons = 0;
				//当天数据从缓存中获取
				//获取非竞价广告展示次数
				String showTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_SHOW_TIME+"_"+advertisementWithoutBiddingPrice1.getAdvertisingUnitId()+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
				Set<String> showPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_SHOW_PERSON+"_"+advertisementWithoutBiddingPrice1.getAdvertisingUnitId()+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
				//获取非竞价广告点击转化次数
				String clickTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_CLICK_TIME+"_"+advertisementWithoutBiddingPrice1.getAdvertisingUnitId()+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
				Set<String> clickPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_CLICK_PERSON+"_"+advertisementWithoutBiddingPrice1.getAdvertisingUnitId()+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
				if(StringUtils.isNotEmpty(showTime)){
					showTimes = Integer.parseInt(showTime);
				}
				if(StringUtils.isNotEmpty(clickTime)){
					clickTimes = Integer.parseInt(clickTime);
				}
				if(null != showPerson && !(showPerson.isEmpty())){
					showPersons = showPerson.size();
				}
				if(null != clickPerson && !(clickPerson.isEmpty())){
					clickPersons = clickPerson.size();
				}

        		if(null != advertisementWithoutBiddingPrice1 && null != advertisementWithoutBiddingPrice1.getAdvertisingUnitId()){
					WithoutBiddingAdStatisticsVo withoutBiddingAdStatisticsVo = withoutBiddingAdStatisticsService.statisticsWithoutBiddingAd(advertisementWithoutBiddingPrice1.getAdvertisingUnitId());
					if(withoutBiddingAdStatisticsVo != null){
						if(null != withoutBiddingAdStatisticsVo.getShowCount()){
							showTimes = showTimes+ withoutBiddingAdStatisticsVo.getShowCount();
						}
						if(null != withoutBiddingAdStatisticsVo.getShowPersonCount()){
							showPersons = showPersons+withoutBiddingAdStatisticsVo.getShowPersonCount();
						}
						if(null != withoutBiddingAdStatisticsVo.getClickCount()){
							clickTimes = clickTimes+withoutBiddingAdStatisticsVo.getClickCount();
						}
						if(null != withoutBiddingAdStatisticsVo.getClickPersonCount()){
							clickPersons = clickPersons+withoutBiddingAdStatisticsVo.getClickPersonCount();
						}
					}
				}
        		advertisementWithoutBiddingPrice1.setShowTimes(showTimes);
        		advertisementWithoutBiddingPrice1.setShowPerson(showPersons);
        		advertisementWithoutBiddingPrice1.setClickTimes(clickTimes);
        		advertisementWithoutBiddingPrice1.setClickPerson(clickPersons);
			}
		}
		return getDataTable(list);
	}
	
	/**
	 * 新增非竞价广告投放
	 */
	@GetMapping("/add")
	public String add(ModelMap modelMap)
	{
		List<DictData> dictDataList = new ArrayList<DictData>();
		DictData dictData = new DictData();
		dictData.setDictValue("0204");
		dictData.setDictLabel("首页-浮层弹窗");
		dictDataList.add(dictData);
		modelMap.put("dictDataList",dictDataList);
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存非竞价广告投放
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:add")
	@Log(title = "非竞价广告投放", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
		Integer userId = getUserId().intValue();
		if(null == userId){
			return error("登录超时，请刷新重试");
		}
		if(null == advertisementWithoutBiddingPrice || null == advertisementWithoutBiddingPrice.getAdvertisingUnitId()){
			return error("请输入需要投放的广告");
		}

		//同一个广告id只允许出现一次
		AdvertisementWithoutBiddingPrice ad = new AdvertisementWithoutBiddingPrice();
		ad.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
		ad.setDeleted(ZjbDictionaryEnum.NO.getValue());
		List<AdvertisementWithoutBiddingPrice> advertisementWithoutBiddingPrices = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceList(ad);
		if(CollectionUtils.isNotEmpty(advertisementWithoutBiddingPrices) && advertisementWithoutBiddingPrices.size() > 0){
			return error("您配置的广告已经存在，无需重复创建。如需投放，请找到原已创建的广告进行操作!");
		}

		//获取文件中的设备sn
		handleFile(file, advertisementWithoutBiddingPrice, deviceService);
		if(AD_RADIO_DEVICE_SN_ALL.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
			String regex = ".+";
			advertisementWithoutBiddingPrice.setRegex(regex);
			advertisementWithoutBiddingPrice.setDeviceSn(null);
		}

		advertisementWithoutBiddingPrice.setAdvertisementStatus(ZjbDictionaryEnum.ADVERTISEMENT_STATUS_STOP.getValue());
		advertisementWithoutBiddingPrice.setInsertBaseParams(userId,userId);
		return toAjax(advertisementWithoutBiddingPriceService.insertAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice));
	}

	/**
	 * 修改非竞价广告投放
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceById(id);
		if(null != advertisementWithoutBiddingPrice){
			if(null != advertisementWithoutBiddingPrice.getAdvertisingUnitId()){
				AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansService.selectAdvertisingUnitFansById(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
				if(advertisingUnitFans != null){
					advertisementWithoutBiddingPrice.setAdvertisingUnitName(advertisingUnitFans.getAdName());
				}

			}
		}

		/*设备定向信息存储*/
		AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
		advertisementPlanDevice.setDeleted(NO.getValue());
		advertisementPlanDevice.setAdvertisementPlanId(String.valueOf(advertisementWithoutBiddingPrice.getId()));
		List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
		AdvertisementPlanDevice advertisingPlan = new AdvertisementPlanDevice();
		if(CollectionUtils.isNotEmpty(advertisementPlanDevices) && advertisementPlanDevices.size() > 0){
			advertisingPlan = advertisementPlanDevices.get(0);
		}else {
			//设备SN定向，默认不限
			advertisingPlan.setRadioDeviceSn(0);
		}

		List<DictData> dictDataList = new ArrayList<DictData>();
		DictData dictData = new DictData();
		dictData.setDictValue("0204");
		dictData.setDictLabel("首页-浮层弹窗");
		dictDataList.add(dictData);
		mmap.put("dictDataList",dictDataList);
		mmap.put("advertisementWithoutBiddingPrice", advertisementWithoutBiddingPrice);

		mmap.put("advertisingPlan", advertisingPlan);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存非竞价广告投放
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:edit")
	@Log(title = "非竞价广告投放", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
		Integer userId = getUserId().intValue();
		if(null == userId){
			return error("登录超时，请刷新重试");
		}

		if(null == advertisementWithoutBiddingPrice || null == advertisementWithoutBiddingPrice.getAdvertisingUnitId()){
			return error("请输入需要投放的广告");
		}

		//同一个广告id只允许出现一次
		AdvertisementWithoutBiddingPrice ad = new AdvertisementWithoutBiddingPrice();
		ad.setAdvertisingUnitId(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
		ad.setDeleted(ZjbDictionaryEnum.NO.getValue());
		List<AdvertisementWithoutBiddingPrice> advertisementWithoutBiddingPrices = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceList(ad);
		if(CollectionUtils.isNotEmpty(advertisementWithoutBiddingPrices) && advertisementWithoutBiddingPrices.size() > 0){
			for (AdvertisementWithoutBiddingPrice withoutBiddingPrice : advertisementWithoutBiddingPrices) {
				if(!withoutBiddingPrice.getId().equals(advertisementWithoutBiddingPrice.getId())){
					return error("您配置的广告已经存在，无需重复创建。如需投放，请找到原已创建的广告进行操作!");
				}
			}
		}

		//获取文件中的设备
		handleFile(file, advertisementWithoutBiddingPrice, deviceService);
		if(AD_RADIO_DEVICE_SN_ALL.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
			String regex = ".+";
			advertisementWithoutBiddingPrice.setRegex(regex);
			advertisementWithoutBiddingPrice.setDeviceSn(null);
		}

		advertisementWithoutBiddingPrice.setUpdateBaseParams(userId);
		return toAjax(advertisementWithoutBiddingPriceService.updateAdvertisementWithoutBiddingPrice(advertisementWithoutBiddingPrice));
	}
	
	/**
	 * 删除非竞价广告投放
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:remove")
	@Log(title = "非竞价广告投放", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{
		return toAjax(advertisementWithoutBiddingPriceService.deleteAdvertisementWithoutBiddingPriceByIds(ids));
	}


	/**
	 * 暂停非竞价广告投放
	 * @param ids
	 * @return
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:stop")
	@Log(title = "非竞价广告投放", businessType = BusinessType.UPDATE)
	@PostMapping( "/stopAdvertisementWithoutBiddingPrice")
	@ResponseBody
	public AjaxResult stopAdvertisementWithoutBiddingPrice(String ids)
	{
		Integer userId = getUserId().intValue();
		if(null == userId){
			return error("登录超时，请刷新重试");
		}
		return toAjax(advertisementWithoutBiddingPriceService.stopAdvertisementWithoutBiddingPrice(ids,userId));
	}

	/**
	 * 投放非竞价广告
	 * @param ids
	 * @return
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:start")
	@Log(title = "非竞价广告投放", businessType = BusinessType.UPDATE)
	@PostMapping( "/startAdvertisementWithoutBiddingPrice")
	@ResponseBody
	public AjaxResult startAdvertisementWithoutBiddingPrice(String ids)
	{
		Integer userId = getUserId().intValue();
		if(null == userId){
			return error("登录超时，请刷新重试");
		}
		return toAjax(advertisementWithoutBiddingPriceService.startAdvertisementWithoutBiddingPrice(ids,userId));
	}

	/**
	 * 广告投放数据明细
	 * @param id
	 * @param mmap
	 * @return
	 */
	@GetMapping("/advertisementWithoutBiddingPriceStatistics/{id}")
	public String getHistoryAgencyList(@PathVariable("id") Integer id, ModelMap mmap)
	{
		mmap.put("id",id);
		//获取广告信息
		AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceById(id);
		if(null != advertisementWithoutBiddingPrice && null != advertisementWithoutBiddingPrice.getAdvertisingUnitId()){
			AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansService.selectAdvertisingUnitFansById(advertisementWithoutBiddingPrice.getAdvertisingUnitId());
			if(advertisingUnitFans != null){
				mmap.put("adId",advertisingUnitFans.getAdId());
				mmap.put("adName",advertisingUnitFans.getAdName());
				if(StringUtils.isNotEmpty(advertisingUnitFans.getAdSpaceIdentifier())){
					String adSpaceIdentifier = dataService.selectDictLabel(ZjbDictionaryTypeEnum.AD_SPACE_IDENTIFIER.getType(),advertisingUnitFans.getAdSpaceIdentifier());
					if(StringUtils.isNotEmpty(adSpaceIdentifier)){
						mmap.put("adSpaceIdentifier",adSpaceIdentifier);
					}
				}
			}
		}
		return prefix + "/advertisementWithoutBiddingPriceStatistics";
	}

	/**
	 * 广告投放数据明细
	 * @param advertisementWithoutBiddingPrice
	 * @return
	 */
	@RequiresPermissions("dsp:advertisementWithoutBiddingPrice:statistics")
	@PostMapping("/advertisementWithoutBiddingPriceList")
	@ResponseBody
	public TableDataInfo advertisementWithoutBiddingPriceList(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice)
	{
		List<WithoutBiddingAdStatistics> list = new ArrayList<WithoutBiddingAdStatistics>();
		if(null == advertisementWithoutBiddingPrice || null == advertisementWithoutBiddingPrice.getId()){
			return getDataTable(list);
		}
		AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice1 = advertisementWithoutBiddingPriceService.selectAdvertisementWithoutBiddingPriceById(advertisementWithoutBiddingPrice.getId());
		if(advertisementWithoutBiddingPrice1 == null || null == advertisementWithoutBiddingPrice1.getAdvertisingUnitId()){
			return getDataTable(list);
		}
		String advertisingUnitId = advertisementWithoutBiddingPrice1.getAdvertisingUnitId().toString();

		String date = DateUtils.getDate();
		//当天数据从缓存中获取
		//获取非竞价广告展示次数
		String showTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_SHOW_TIME+"_"+advertisingUnitId+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
		Set<String> showPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_SHOW_PERSON+"_"+advertisingUnitId+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
		//获取非竞价广告点击转化次数
		String clickTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_CLICK_TIME+"_"+advertisingUnitId+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
		Set<String> clickPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.WITHOUT_BIDDING_PRICE_AD_CLICK_PERSON+"_"+advertisingUnitId+"_"+date,ZjbConstantsRedis.ZJB_DB_59);
		WithoutBiddingAdStatistics withoutBiddingAdStatistics = new WithoutBiddingAdStatistics();
		if(StringUtils.isEmpty(showTime)){
			withoutBiddingAdStatistics.setShowCount(0);
		}else{
			withoutBiddingAdStatistics.setShowCount(Integer.parseInt(showTime));
		}
		if(showPerson == null || showPerson.isEmpty()){
			withoutBiddingAdStatistics.setShowPersonCount(0);
		}else{
			withoutBiddingAdStatistics.setShowPersonCount(showPerson.size());
		}
		if(StringUtils.isEmpty(clickTime)){
			withoutBiddingAdStatistics.setClickCount(0);
		}else{
			withoutBiddingAdStatistics.setClickCount(Integer.parseInt(clickTime));
		}
		if(clickPerson == null || clickPerson.isEmpty()){
			withoutBiddingAdStatistics.setClickPersonCount(0);
		}else{
			withoutBiddingAdStatistics.setClickPersonCount(clickPerson.size());
		}
		withoutBiddingAdStatistics.setStatisticsDate(date);
		list.add(withoutBiddingAdStatistics);

		List<WithoutBiddingAdStatistics> withoutBiddingAdStatistics1 = withoutBiddingAdStatisticsService.selectWithoutBiddingAdStatisticsListByAdvertisingUnitId(advertisementWithoutBiddingPrice1.getAdvertisingUnitId());
		if(null != withoutBiddingAdStatistics1 && !(withoutBiddingAdStatistics1.isEmpty())){
			list.addAll(withoutBiddingAdStatistics1);
		}
		return getDataTable(list);
	}


	/**
	 * 文件上传
	 */
	@PostMapping("/uploadFile")
	@ResponseBody
	public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {

		if (file.isEmpty()) {
			return error("文件为空");
		}

		String fileName = FilenameUtils.getName(file.getOriginalFilename());
		String ext = FilenameUtils.getExtension(fileName);
		String md5 = DigestUtils.md5Hex(fileName);
		String fileKey = zjbConfig.getAdWithoutBiddingPriceFileUrl() + LocalDate.now()
				+ '/' + md5 + '.' + ext;

		try {
			OssUtil.uploadFile(fileKey, file.getInputStream());
			String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
			logger.warn("文件OSS路径：{}", fileUrl);
			AjaxResult ajaxResult = success();
			ajaxResult.put("fileUrl", fileUrl);
			ajaxResult.put("fileName", fileName);
			return ajaxResult;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return error(e.getMessage());
		}
	}

	/**
	 * 处理上传文件,即提取SN
	 *
	 * @param file
	 * @param advertisementWithoutBiddingPrice
	 * @param deviceService
	 */
	public static void handleFile(MultipartFile file, AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice, IDeviceService deviceService) {

		if (null == file || file.isEmpty() || null == advertisementWithoutBiddingPrice) {
			return;
		}

		try (InputStream is = file.getInputStream()) {
			ExcelUtil<AdvertisementWithoutBiddingPrice> util = new ExcelUtil<AdvertisementWithoutBiddingPrice>(AdvertisementWithoutBiddingPrice.class);
			/*sheetName必须是：addevice*/
			List<AdvertisementWithoutBiddingPrice> list = util.importExcel("addevice", is);
			if (null == list || list.isEmpty()) {
				logger.warn("文件格式错误或空文件");
				return;
			}

			Set<String> set = new HashSet<>();
			for (AdvertisementWithoutBiddingPrice e : list) {
				if (StringUtils.isNotEmpty(e.getMixId())) {
					String mixId = StringUtils.trim(e.getMixId().replaceAll("\\xa0", "").replaceAll("\u00A0", ""));
					DeviceDTO device = deviceService.selectDeviceByMixId(mixId);
					if (null != device && StringUtils.isNotBlank(device.getSn())) {
						set.add(device.getSn());
					} else {
						logger.warn("无效mixId：【{}】", e.getMixId());
					}
				}
			}

			if (set.size() == 0) {
				return;
			}

			String regex = null;
			if(null == set || set.isEmpty() || AD_RADIO_DEVICE_SN_ALL.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
				regex = ".+";
			}else if(AD_RADIO_DEVICE_SN_INCLUDE.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
				regex = '(' + String.join("|", set) + ')';
			}else if(AD_RADIO_DEVICE_SN_EXCLUDE.getValue().equals(advertisementWithoutBiddingPrice.getRadioDeviceSn())){
				regex = "(?!" + String.join("|", set) + ").+";
			}
			advertisementWithoutBiddingPrice.setRegex(regex);

			advertisementWithoutBiddingPrice.setDeviceSn(String.join(",", set));

		} catch (Exception e) {

			logger.error(e.getMessage(), e);
		}
	}
}
