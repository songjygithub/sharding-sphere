package com.zjb.project.dsp.gzhPushAdInfo.mapper;

import com.zjb.project.dsp.gzhPushAdInfo.domain.GzhPushAdInfo;
import java.util.List;	

/**
 * 关注公众号推送广告 数据层
 * 
 * @author shenlong
 * @date 2019-08-24
 */
public interface GzhPushAdInfoMapper 
{
	/**
     * 查询关注公众号推送广告信息
     * 
     * @param id 关注公众号推送广告ID
     * @return 关注公众号推送广告信息
     */
	public GzhPushAdInfo selectGzhPushAdInfoById(Integer id);

	/**
     * 查询关注公众号推送广告信息
     *
     * @param adId 关注公众号推送广告ID
     * @return 关注公众号推送广告信息
     */
	public GzhPushAdInfo selectGzhPushAdInfoByAdId(String adId);

	/**
     * 查询关注公众号推送广告列表
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 关注公众号推送广告集合
     */
	public List<GzhPushAdInfo> selectGzhPushAdInfoList(GzhPushAdInfo gzhPushAdInfo);

	/**
     * 查询关注公众号推送广告列表
     *
     * @return 关注公众号推送广告集合
     */
	public List<GzhPushAdInfo> selectGzhPushAdInfoListByName(GzhPushAdInfo gzhPushAdInfo);

	/**
     * 新增关注公众号推送广告
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 结果
     */
	public int insertGzhPushAdInfo(GzhPushAdInfo gzhPushAdInfo);
	
	/**
     * 修改关注公众号推送广告
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 结果
     */
	public int updateGzhPushAdInfo(GzhPushAdInfo gzhPushAdInfo);
	
	/**
     * 删除关注公众号推送广告
     * 
     * @param id 关注公众号推送广告ID
     * @return 结果
     */
	public int deleteGzhPushAdInfoById(Integer id);
	
	/**
     * 批量删除关注公众号推送广告
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhPushAdInfoByIds(String[] ids);
	
}