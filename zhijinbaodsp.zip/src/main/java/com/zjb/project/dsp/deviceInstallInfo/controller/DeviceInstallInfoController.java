package com.zjb.project.dsp.deviceInstallInfo.controller;

import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.deviceInstallInfo.domain.DeviceInstallInfo;
import com.zjb.project.dsp.deviceInstallInfo.service.IDeviceInstallInfoService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * 设备安装 信息操作处理
 *
 * @author songjy
 * @date 2019-11-30
 */
@Controller
@RequestMapping("/dsp/deviceInstallInfo")
public class DeviceInstallInfoController extends BaseController {
    private String prefix = "dsp/deviceInstallInfo";

    @Autowired
    private IDeviceInstallInfoService deviceInstallInfoService;

    @RequiresPermissions("dsp:deviceInstallInfo:view")
    @GetMapping()
    public String deviceInstallInfo() {
        return prefix + "/deviceInstallInfo";
    }

    /**
     * 查询设备安装列表
     */
    @RequiresPermissions("dsp:deviceInstallInfo:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(DeviceInstallInfo deviceInstallInfo) {
        startPage();
        List<DeviceInstallInfo> list = deviceInstallInfoService.selectDeviceInstallInfoList(deviceInstallInfo);
        return getDataTable(list);
    }

    /**
     * 新增设备安装
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }


    /**
     * 修改设备安装
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        DeviceInstallInfo deviceInstallInfo = deviceInstallInfoService.selectDeviceInstallInfoById(id);
        mmap.put("deviceInstallInfo", deviceInstallInfo);
        return prefix + "/edit";
    }


}
