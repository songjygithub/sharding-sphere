package com.zjb.project.dsp.advertisingCombinationWx.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 广告方案/广告池-微信 中间表 zjb_advertising_combination_unit_wx
 *
 * @author ZH
 * @date 2019-08-13
 */
public class AdvertisingCombinationUnitWx extends BaseEntity {
    private static final long serialVersionUID = -3925408072061410720L;

    /**
     * id
     */
    private Integer id;
    /**
     * 广告方案id,表【zjb_advertising_combination】主键ID
     */
    private Integer combinationId;
    /**
     * 广告id，表【zjb_advertising_unit】主键ID
     */
    private Integer adUnitId;
    /**
     * 业务主键id 格式 “01+id”
     */
    private String adId;
    /**
     * 广告名称
     */
    private String adName;
    /**
     * 广告图片链接
     */
    private String adPhotoUrl;
    /**
     * 使用状态 zjb_ad_use_status
     */
    private Integer adUseStatus;
    /**
     * 广告位标识  zjb_ad_space_identifier
     */
    private String adSpaceIdentifier;
    /**
     * 广告产品单元类型，参阅字典：zjb_ad_unit_type
     */
    private String adUnitType;
    /**
     * 跳转链接
     */
    private String redirectUrl;

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getCombinationId() {
        return combinationId;
    }

    public void setCombinationId(Integer combinationId) {
        this.combinationId = combinationId;
    }

    public Integer getAdUnitId() {
        return adUnitId;
    }

    public void setAdUnitId(Integer adUnitId) {
        this.adUnitId = adUnitId;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public String getAdName() {
        return adName;
    }

    public void setAdName(String adName) {
        this.adName = adName;
    }

    public String getAdPhotoUrl() {
        return adPhotoUrl;
    }

    public void setAdPhotoUrl(String adPhotoUrl) {
        this.adPhotoUrl = adPhotoUrl;
    }

    public Integer getAdUseStatus() {
        return adUseStatus;
    }

    public void setAdUseStatus(Integer adUseStatus) {
        this.adUseStatus = adUseStatus;
    }

    public String getAdSpaceIdentifier() {
        return adSpaceIdentifier;
    }

    public void setAdSpaceIdentifier(String adSpaceIdentifier) {
        this.adSpaceIdentifier = adSpaceIdentifier;
    }

    public String getAdUnitType() {
        return adUnitType;
    }

    public void setAdUnitType(String adUnitType) {
        this.adUnitType = adUnitType;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }
}
