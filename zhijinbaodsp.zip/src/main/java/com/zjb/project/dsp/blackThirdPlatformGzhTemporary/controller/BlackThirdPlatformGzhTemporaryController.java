package com.zjb.project.dsp.blackThirdPlatformGzhTemporary.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.domain.BlackThirdPlatformGzhTemporary;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.service.IBlackThirdPlatformGzhTemporaryService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 公众号黑名单临时 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-05-07
 */
@Controller
@RequestMapping("/dsp/blackThirdPlatformGzhTemporary")
public class BlackThirdPlatformGzhTemporaryController extends BaseController
{
    private String prefix = "dsp/blackThirdPlatformGzhTemporary";
	
	@Autowired
	private IBlackThirdPlatformGzhTemporaryService blackThirdPlatformGzhTemporaryService;
	
	@RequiresPermissions("dsp:blackThirdPlatformGzhTemporary:view")
	@GetMapping()
	public String blackThirdPlatformGzhTemporary()
	{
	    return prefix + "/blackThirdPlatformGzhTemporary";
	}
	
	/**
	 * 查询公众号黑名单临时列表
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzhTemporary:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{
		startPage();
        List<BlackThirdPlatformGzhTemporary> list = blackThirdPlatformGzhTemporaryService.selectBlackThirdPlatformGzhTemporaryList(blackThirdPlatformGzhTemporary);
		return getDataTable(list);
	}
	
	/**
	 * 新增公众号黑名单临时
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存公众号黑名单临时
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzhTemporary:add")
	@Log(title = "公众号黑名单临时", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{		
		return toAjax(blackThirdPlatformGzhTemporaryService.insertBlackThirdPlatformGzhTemporary(blackThirdPlatformGzhTemporary));
	}

	/**
	 * 修改公众号黑名单临时
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary = blackThirdPlatformGzhTemporaryService.selectBlackThirdPlatformGzhTemporaryById(id);
		mmap.put("blackThirdPlatformGzhTemporary", blackThirdPlatformGzhTemporary);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存公众号黑名单临时
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzhTemporary:edit")
	@Log(title = "公众号黑名单临时", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{		
		return toAjax(blackThirdPlatformGzhTemporaryService.updateBlackThirdPlatformGzhTemporary(blackThirdPlatformGzhTemporary));
	}
	
	/**
	 * 删除公众号黑名单临时
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzhTemporary:remove")
	@Log(title = "公众号黑名单临时", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(blackThirdPlatformGzhTemporaryService.deleteBlackThirdPlatformGzhTemporaryByIds(ids));
	}
	
}
