package com.zjb.project.dsp.grhPushRecord.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
							import java.util.Date;

/**
 * 个人号推送记录表 zjb_grh_push_record
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
public class GrhPushRecord extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** 个人号唯一标识 */
	private String personalAppId;
	/** openid */
	private String openId;
	/** 展示次数 */
	private Integer viewCount;

	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setPersonalAppId(String personalAppId) 
	{
		this.personalAppId = personalAppId;
	}

	public String getPersonalAppId() 
	{
		return personalAppId;
	}
	public void setOpenId(String openId) 
	{
		this.openId = openId;
	}

	public String getOpenId() 
	{
		return openId;
	}
	public void setViewCount(Integer viewCount) 
	{
		this.viewCount = viewCount;
	}

	public Integer getViewCount() 
	{
		return viewCount;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("personalAppId", getPersonalAppId())
            .append("openId", getOpenId())
            .append("viewCount", getViewCount())
            .append("createTime", getCreateTime())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .toString();
    }
}
