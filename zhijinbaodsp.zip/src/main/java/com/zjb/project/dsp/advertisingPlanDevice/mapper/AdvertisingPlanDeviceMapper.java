package com.zjb.project.dsp.advertisingPlanDevice.mapper;

import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;

import java.util.List;

/**
 * 广告投放设备定向 数据层
 *
 * @author songjy
 * @date 2019-07-12
 */
public interface AdvertisingPlanDeviceMapper {
    /**
     * 查询广告投放设备定向信息
     *
     * @param id 广告投放设备定向ID
     * @return 广告投放设备定向信息
     */
    AdvertisingPlanDevice selectAdvertisingPlanDeviceById(Integer id);

    /**
     * 查询广告投放设备定向列表
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 广告投放设备定向集合
     */
    List<AdvertisingPlanDevice> selectAdvertisingPlanDeviceList(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 新增广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    int insertAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 修改广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    int updateAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 删除广告投放设备定向
     *
     * @param id 广告投放设备定向ID
     * @return 结果
     */
    int deleteAdvertisingPlanDeviceById(Integer id);

    /**
     * 批量删除广告投放设备定向
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanDeviceByIds(String[] ids);

    /**
     * 查询广告投放设备定向信息
     *
     * @param planId 广告投放设计划ID
     * @return 广告投放设备定向信息
     */
    AdvertisingPlanDevice selectAdvertisingPlanDeviceByPlanId(String planId);

}