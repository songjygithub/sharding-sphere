package com.zjb.project.dsp.backupRecord.service;

import com.zjb.project.dsp.backupRecord.domain.BackupRecord;

import java.util.Date;
import java.util.List;

/**
 * 数据备份记录 服务层
 *
 * @author songjy
 * @date 2020-04-17
 */
public interface IBackupRecordService {
    /**
     * 查询数据备份记录信息
     *
     * @param id 数据备份记录ID
     * @return 数据备份记录信息
     */
    BackupRecord selectBackupRecordById(Long id);

    /**
     * 查询数据备份记录列表
     *
     * @param backupRecord 数据备份记录信息
     * @return 数据备份记录集合
     */
    List<BackupRecord> selectBackupRecordList(BackupRecord backupRecord);

    /**
     * 新增数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    int insertBackupRecord(BackupRecord backupRecord);

    /**
     * 修改数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    int updateBackupRecord(BackupRecord backupRecord);

    /**
     * 删除数据备份记录信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteBackupRecordByIds(String ids);

    /**
     * 广告交易最小日期
     *
     * @return 广告请求日期：yyyy-MM-dd
     */
    @Deprecated
    Date minAdRequestDate();

    /**
     * 从备份库中导入广告交易数据
     *
     * @param backupRecord
     * @return 成功导入记录条数
     */
    int importAdvertisingTargetInfo(BackupRecord backupRecord);

}
