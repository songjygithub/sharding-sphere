package com.zjb.project.dsp.gzhPushRecord.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.dsp.grhPushRecord.domain.GrhPushRecord;
import com.zjb.project.monitor.job.util.ScheduleUtils;
import com.zjb.project.system.config.service.IConfigService;
import org.apache.commons.logging.LogFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.gzhPushRecord.mapper.GzhPushRecordMapper;
import com.zjb.project.dsp.gzhPushRecord.domain.GzhPushRecord;
import com.zjb.project.dsp.gzhPushRecord.service.IGzhPushRecordService;
import com.zjb.common.support.Convert;

/**
 * 公众号推送记录 服务层实现
 *
 * @author shenlong
 * @date 2020-01-15
 */
@Service
public class GzhPushRecordServiceImpl implements IGzhPushRecordService {
	private static final Logger log = LoggerFactory.getLogger(GzhPushRecordServiceImpl.class);
    @Autowired
    private GzhPushRecordMapper gzhPushRecordMapper;
    @Autowired
    private IConfigService configService;

    /**
     * 查询公众号推送记录信息
     *
     * @param id 公众号推送记录ID
     * @return 公众号推送记录信息
     */
    @Override
    public GzhPushRecord selectGzhPushRecordById(Integer id) {
        return gzhPushRecordMapper.selectGzhPushRecordById(id);
    }

    /**
     * 查询公众号推送记录列表
     *
     * @param gzhPushRecord 公众号推送记录信息
     * @return 公众号推送记录集合
     */
    @Override
    public List<GzhPushRecord> selectGzhPushRecordList(GzhPushRecord gzhPushRecord) {
        return gzhPushRecordMapper.selectGzhPushRecordList(gzhPushRecord);
    }

    /**
     * 新增公众号推送记录
     *
     * @param gzhPushRecord 公众号推送记录信息
     * @return 结果
     */
    @Override
    public int insertGzhPushRecord(GzhPushRecord gzhPushRecord) {

        return gzhPushRecordMapper.insertGzhPushRecord(gzhPushRecord);
    }

    /**
     * 修改公众号推送记录
     *
     * @param gzhPushRecord 公众号推送记录信息
     * @return 结果
     */
    @Override
    public int updateGzhPushRecord(GzhPushRecord gzhPushRecord) {
        return gzhPushRecordMapper.updateGzhPushRecord(gzhPushRecord);
    }

    /**
     * 删除公众号推送记录对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteGzhPushRecordByIds(String ids) {
        return gzhPushRecordMapper.deleteGzhPushRecordByIds(Convert.toStrArray(ids));
    }


    /**
     * 插入或修改记录对象
     * @param gzhPushRecord
     * @return
     */
    @Override
    public int insertOrUpdate(GzhPushRecord gzhPushRecord){
        if(null == gzhPushRecord){
            log.warn("插入数据为null!");
            return 0 ;
        }
        if(StringUtils.isBlank(gzhPushRecord.getAppId()) || StringUtils.isBlank(gzhPushRecord.getOpenId())){
            log.warn("参数不能为空!");
            return 0 ;
        }
        List<GzhPushRecord> gzhPushRecords = selectGzhPushRecordList(gzhPushRecord);

        String gzhPushTimes = configService.selectConfigByKey("zjb_gzh_push_times");
        if(StringUtils.isEmpty(gzhPushTimes)){
            gzhPushTimes = "2";
        }
        int viewCount = 0;
        if(CollectionUtils.isEmpty(gzhPushRecords)){
            viewCount = 1;
        }else{
            GzhPushRecord gzhPushRecord1 = gzhPushRecords.get(0);
            if(null != gzhPushRecord1 && null != gzhPushRecord1.getViewCount()){
                viewCount = gzhPushRecord1.getViewCount()+1;
            }else{
                viewCount = 1;
            }
        }

        if(CollectionUtils.isEmpty(gzhPushRecords)){
            gzhPushRecord.setViewCount(viewCount);
            gzhPushRecord.setCreateTime(DateUtils.dateTime("yyyy-MM-dd",DateUtils.getDate()));
            gzhPushRecord.setGmtCreated(new Date());
            gzhPushRecord.setGmtModified(new Date());
            gzhPushRecordMapper.insertGzhPushRecord(gzhPushRecord);
        }else{
            GzhPushRecord gzhPushRecord1 = gzhPushRecords.get(0);
            gzhPushRecord1.setViewCount(viewCount);
            gzhPushRecord1.setGmtModified(new Date());
            gzhPushRecordMapper.updateGzhPushRecord(gzhPushRecord1);
        }
        int gzhPushTime = Integer.parseInt(gzhPushTimes);
        if(gzhPushTime == viewCount){
            // 将该记录发送到核心系统 index表中
            Map<String, Object> mapQueue = new HashMap<>(4);
            mapQueue.put(RedisSubscribe.KEY_GZH_RECORD_EVENT, gzhPushRecord.getAppId() + "@" + gzhPushRecord.getOpenId());
            JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_ADMIN_GZH,JSON.toJSONString(mapQueue));
        }
        if(gzhPushTime < viewCount){
            // 将该记录发送到核心系统 index表中
            Map<String, Object> mapQueue = new HashMap<>(4);
            mapQueue.put(RedisSubscribe.KEY_GZH_RECORD_EVENT, gzhPushRecord.getAppId() + "@" + gzhPushRecord.getOpenId());
            JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_ADMIN_GZH,JSON.toJSONString(mapQueue));
            log.warn("公众号推送次数记录表数据异常,展示次数大于2且没有过滤!appid:[{}],openid:[{}]",gzhPushRecord.getAppId(),gzhPushRecord.getOpenId());
            return  0 ;
        }


        return 0;

    }

    /**
     * 删除多余的公众号推送记录信息
     *
     * @return 结果
     */
    @Override
    public int deleteGzhPushRecord(String gzhPushTimes){
        return gzhPushRecordMapper.deleteGzhPushRecord(gzhPushTimes);
    }
}
