package com.zjb.project.dsp.advertisingUnit.service;

import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.mapper.AdvertisingUnitFansMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.ArrayList;
import java.util.List;

/**
 * @author songjy
 * @date 2020-03-07
 */
public abstract class BaseAdUnitServiceImpl implements IAdUnitService {

    @Autowired
    protected AdvertisingUnitFansMapper advertisingUnitFansMapper;
    @Autowired
    protected ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;

    @Override
    public List<AdvertisingUnit> findByWeChatPersonalId(String weChatPersonalId) {

        List<AdvertisingUnit> all = new ArrayList<>(4);
        List<AdvertisingUnitFans> list = advertisingUnitFansMapper.findByWeChatPersonalId(weChatPersonalId);

        if (null != list && !list.isEmpty()) {
            all.addAll(list);
        }

        return all;
    }
}
