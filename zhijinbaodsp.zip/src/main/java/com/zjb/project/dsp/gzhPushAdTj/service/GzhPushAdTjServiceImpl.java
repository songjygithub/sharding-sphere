package com.zjb.project.dsp.gzhPushAdTj.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.gzhPushAdTj.mapper.GzhPushAdTjMapper;
import com.zjb.project.dsp.gzhPushAdTj.domain.GzhPushAdTj;
import com.zjb.project.dsp.gzhPushAdTj.service.IGzhPushAdTjService;
import com.zjb.common.support.Convert;

/**
 * 消息广告点击统计 服务层实现
 * 
 * @author shenlong
 * @date 2019-08-26
 */
@Service
public class GzhPushAdTjServiceImpl implements IGzhPushAdTjService 
{
	@Autowired
	private GzhPushAdTjMapper gzhPushAdTjMapper;

	/**
     * 查询消息广告点击统计信息
     * 
     * @param id 消息广告点击统计ID
     * @return 消息广告点击统计信息
     */
    @Override
	public GzhPushAdTj selectGzhPushAdTjById(Integer id)
	{
	    return gzhPushAdTjMapper.selectGzhPushAdTjById(id);
	}
	
	/**
     * 查询消息广告点击统计列表
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 消息广告点击统计集合
     */
	@Override
	public List<GzhPushAdTj> selectGzhPushAdTjList(GzhPushAdTj gzhPushAdTj)
	{
	    return gzhPushAdTjMapper.selectGzhPushAdTjList(gzhPushAdTj);
	}
	
    /**
     * 新增消息广告点击统计
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 结果
     */
	@Override
	public int insertGzhPushAdTj(GzhPushAdTj gzhPushAdTj)
	{
	    return gzhPushAdTjMapper.insertGzhPushAdTj(gzhPushAdTj);
	}
	
	/**
     * 修改消息广告点击统计
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 结果
     */
	@Override
	public int updateGzhPushAdTj(GzhPushAdTj gzhPushAdTj)
	{
	    return gzhPushAdTjMapper.updateGzhPushAdTj(gzhPushAdTj);
	}

	/**
     * 删除消息广告点击统计对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGzhPushAdTjByIds(String ids)
	{
		return gzhPushAdTjMapper.deleteGzhPushAdTjByIds(Convert.toStrArray(ids));
	}
	
}
