package com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain;

import java.io.Serializable;

/**
 * 点击非竞价广告
 * @author jiangbingjie
 * @date 2020/4/7 5:28 下午
 */
public class WithoutBiddingPriceAdParam implements Serializable {

    private static final long serialVersionUID = 1L;

    /**用户openid*/
    private String openid;

    /**广告Id*/
    private String adId;

    /**随机数*/
    private String randomNum;

    public String getOpenid() {
        return openid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getAdId() {
        return adId;
    }

    public void setAdId(String adId) {
        this.adId = adId;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }
}
