package com.zjb.project.dsp.advertisingTargetInfo.domain;

import java.io.Serializable;

/**
 * 广告统计信息
 *
 * @author songjy
 * @date 2019/09/07
 */
public class StatisticsAdInfo implements Serializable {
    private static final long serialVersionUID = -7739482590088748976L;

    /**
     * 来源类型  1.H5网页   2 : 微信公众号  3: 微信小程序  4: 支付宝小程序
     */
    private String sourceType;

    /**
     * 来源名称  1: 微信    2: 支付宝   3:其他
     */
    private String sourceName;

    /**
     * 模块名称  index : 主页   personalcenter : 个人中心
     */
    private String module;

    /**
     * 具体点的名称
     */
    private String name;

    /**
     * 用户微信|支付宝唯一标识ID
     */
    private String openId;

    /**
     * 广告池最小单元主键ID
     */
    private String adUnitId;

    /**
     * 设备二维码
     */
    private String qrcode;

    /**
     * 用户扫码流水号
     */
    private String randomNum;

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public String getModule() {
        return module;
    }

    public void setModule(String module) {
        this.module = module;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAdUnitId() {
        return adUnitId;
    }

    public void setAdUnitId(String adUnitId) {
        this.adUnitId = adUnitId;
    }

    public String getQrcode() {
        return qrcode;
    }

    public void setQrcode(String qrcode) {
        this.qrcode = qrcode;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }
}
