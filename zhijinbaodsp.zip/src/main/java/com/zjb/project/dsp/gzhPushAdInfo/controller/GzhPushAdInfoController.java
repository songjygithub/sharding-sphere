package com.zjb.project.dsp.gzhPushAdInfo.controller;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.enums.ZjbDictionaryTypeEnum;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.gzhPushAdInfo.domain.GzhPushAdInfo;
import com.zjb.project.dsp.gzhPushAdInfo.service.IGzhPushAdInfoService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 关注公众号推送广告 信息操作处理
 * 
 * @author shenlong
 * @date 2019-08-24
 */
@Controller
@RequestMapping("/dsp/gzhPushAdInfo")
public class GzhPushAdInfoController extends BaseController
{
    private String prefix = "dsp/gzhPushAdInfo";
	
	@Autowired
	private IGzhPushAdInfoService gzhPushAdInfoService;
	@Autowired
	private IComponentAuthorizationInfoService componentAuthorizationInfoService;

	@RequiresPermissions("dsp:gzhPushAdInfo:view")
	@GetMapping()
	public String gzhPushAdInfo()
	{
	    return prefix + "/gzhPushAdInfo";
	}
	
	/**
	 * 查询关注公众号推送广告列表
	 */
	@RequiresPermissions("dsp:gzhPushAdInfo:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(GzhPushAdInfo gzhPushAdInfo)
	{
		startPage();
        List<GzhPushAdInfo> list = gzhPushAdInfoService.selectGzhPushAdInfoList(gzhPushAdInfo);
		return getDataTable(list);
	}
	@PostMapping("/listByName")
	@ResponseBody
	public List listByName(GzhPushAdInfo gzhPushAdInfo)
	{
		return gzhPushAdInfoService.selectGzhPushAdInfoListByName(gzhPushAdInfo);
	}
	/**
	 * 新增关注公众号推送广告
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存关注公众号推送广告
	 */
	@RequiresPermissions("dsp:gzhPushAdInfo:add")
	@Log(title = "关注公众号推送广告", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(GzhPushAdInfo gzhPushAdInfo)
	{
		String inUrl = UUID.randomUUID().toString();
		gzhPushAdInfo.setAdInsideUri(inUrl);
		gzhPushAdInfo.setStatus(ZjbDictionaryEnum.GZH_PUSH_AD_STATUS_NORMAL.getValue());
		gzhPushAdInfo.setCreaterId(getUserId().intValue());
		return toAjax(gzhPushAdInfoService.insertGzhPushAdInfo(gzhPushAdInfo));
	}

	/**
	 * 修改关注公众号推送广告
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		GzhPushAdInfo gzhPushAdInfo = gzhPushAdInfoService.selectGzhPushAdInfoById(id);
		mmap.put("gzhPushAdInfo", gzhPushAdInfo);
	    return prefix + "/edit";
	}
	/**
	 * 修改关注公众号推送广告状态
	 */
	@GetMapping("/editStatus/{id}")
	@ResponseBody
	public AjaxResult editStatus(@PathVariable("id") Integer id)
	{
		GzhPushAdInfo gzhPushAdInfo = gzhPushAdInfoService.selectGzhPushAdInfoById(id);
		Integer status = gzhPushAdInfo.getStatus();
		if(status == 1 ){
			gzhPushAdInfo.setStatus(ZjbDictionaryEnum.GZH_PUSH_AD_STATUS_STOP.getValue());
		}else{
			gzhPushAdInfo.setStatus(ZjbDictionaryEnum.GZH_PUSH_AD_STATUS_NORMAL.getValue());
		}
		gzhPushAdInfo.setUpdateBaseParams(getUserId().intValue());
		gzhPushAdInfo.setGmtModified(new Date());
		gzhPushAdInfoService.updateGzhPushAdInfo(gzhPushAdInfo);
		AjaxResult ajaxResult = new AjaxResult();
		ajaxResult.put("code",0);
		ajaxResult.put("msg","更改状态成功");
		return ajaxResult;
	}
	/**
	 * 删除关注公众号推送广告状态
	 */
	@GetMapping("/delete/{id}")
	@ResponseBody
	public AjaxResult delete(@PathVariable("id") Integer id)
	{
		GzhPushAdInfo gzhPushAdInfo = gzhPushAdInfoService.selectGzhPushAdInfoById(id);
		String adId = gzhPushAdInfo.getAdId();
		ComponentAuthorizationInfo componentAuthorizationInfo = new ComponentAuthorizationInfo();
		componentAuthorizationInfo.setMsgId(adId);
		List<ComponentAuthorizationInfo> componentAuthorizationInfos = componentAuthorizationInfoService.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
		int i = 0 ;
		for(ComponentAuthorizationInfo c : componentAuthorizationInfos){
			c.setMsgId(null);
			 i += componentAuthorizationInfoService.updateComponentAuthorizationInfo(c);
		}
		gzhPushAdInfoService.deleteGzhPushAdInfoByIds(id+"");
		AjaxResult ajaxResult = new AjaxResult();
		ajaxResult.put("code",0);
		ajaxResult.put("msg","成功清除"+i+"条引用记录!");
		return ajaxResult;
	}

	/**
	 * 修改保存关注公众号推送广告
	 */
	@RequiresPermissions("dsp:gzhPushAdInfo:edit")
	@Log(title = "关注公众号推送广告", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(GzhPushAdInfo gzhPushAdInfo)
	{
		String inUrl = UUID.randomUUID().toString();
		gzhPushAdInfo.setUpdateBaseParams(getUserId().intValue());
		gzhPushAdInfo.setAdInsideUri(inUrl);
		return toAjax(gzhPushAdInfoService.updateGzhPushAdInfo(gzhPushAdInfo));
	}

	/**
	 * 删除关注公众号推送广告
	 */
	@RequiresPermissions("dsp:gzhPushAdInfo:remove")
	@Log(title = "关注公众号推送广告", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(gzhPushAdInfoService.deleteGzhPushAdInfoByIds(ids));
	}
	
}
