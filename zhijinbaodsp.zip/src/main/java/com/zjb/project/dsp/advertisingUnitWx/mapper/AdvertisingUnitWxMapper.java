package com.zjb.project.dsp.advertisingUnitWx.mapper;

import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;

import java.util.List;

/**
 * 广告池-微信 数据层
 *
 * @author ZH
 * @date 2019-08-13
 */
public interface AdvertisingUnitWxMapper {
    /**
     * 查询广告池信息
     *
     * @param id 广告池ID
     * @return 广告池信息
     */
    AdvertisingUnitWx selectAdvertisingUnitWxById(Integer id);

    /**
     * 查询广告池列表
     *
     * @param advertisingUnitWx 广告池信息
     * @return 广告池集合
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitWxList(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 新增广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    int insertAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 修改广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    int updateAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 删除广告池
     *
     * @param id 广告池ID
     * @return 结果
     */
    int deleteAdvertisingUnitWxById(Integer id);

    /**
     * 批量删除广告池
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingUnitWxByIds(String[] ids);

    /**
     * 通过广告方案ID查询广告单元
     *
     * @param combinationId
     * @return
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitListByCombinationId(Integer combinationId);

    /**
     * @param taskId 表【zjb_scan_task】主键ID
     * @return
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitByTaskId(String taskId);

}