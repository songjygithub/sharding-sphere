package com.zjb.project.dsp.agencyWeChatAccountStatistics.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 代理商维度公众号统计表 zjb_agency_we_chat_account_statistics
 *
 * @author songjy
 * @date 2020-01-02
 */
public class AgencyWeChatAccountStatistics extends BaseEntity {
    private static final long serialVersionUID = -1164868756889723994L;

    /**
     * 自增主键
     */
    private Long id;
    /**
     * 统计日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date statisticsDay;

    /**
     * 关注数
     */
    private Integer subscribeCount;
    /**
     * 取关数
     */
    private Integer unsubscribeCount;
    /**
     * 关注并当日取关数
     */
    private Integer sameDayUnsubscribeCount;
    /**
     * 代理商ID
     */
    private Integer agencyId;
    /**
     * 代理商名称
     */
    private String agencyName;

    /****以下非数据库映射字段****/

    /**
     * 根据agency_id、event、open_id分组统计数字，非数据库映射字段
     */
    private Integer count;

    /**
     * 是否关注事件，0：否 1：是
     */
    private Integer subscribe;

    /**
     * 用户唯一标识
     */
    private String openId;

    /**
     * 事件类型，subscribe：关注 unsubscribe：取关
     */
    private String event;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setStatisticsDay(Date statisticsDay) {
        this.statisticsDay = statisticsDay;
    }

    public Date getStatisticsDay() {
        return statisticsDay;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getEvent() {
        return event;
    }

    public void setSubscribeCount(Integer subscribeCount) {
        this.subscribeCount = subscribeCount;
    }

    public Integer getSubscribeCount() {
        return subscribeCount;
    }

    public void setUnsubscribeCount(Integer unsubscribeCount) {
        this.unsubscribeCount = unsubscribeCount;
    }

    public Integer getUnsubscribeCount() {
        return unsubscribeCount;
    }

    public void setSameDayUnsubscribeCount(Integer sameDayUnsubscribeCount) {
        this.sameDayUnsubscribeCount = sameDayUnsubscribeCount;
    }

    public Integer getSameDayUnsubscribeCount() {
        return sameDayUnsubscribeCount;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getSubscribe() {
        return subscribe;
    }

    public void setSubscribe(Integer subscribe) {
        this.subscribe = subscribe;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }
}
