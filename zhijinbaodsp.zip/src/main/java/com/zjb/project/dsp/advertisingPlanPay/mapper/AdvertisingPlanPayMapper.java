package com.zjb.project.dsp.advertisingPlanPay.mapper;

import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;

import java.util.List;

/**
 * 广告投放计划(支付) 数据层
 *
 * @author jiangbingjie
 * @date 2019-11-06
 */
public interface AdvertisingPlanPayMapper {
    /**
     * 查询广告投放计划(支付)信息
     *
     * @param id 广告投放计划(支付)ID
     * @return 广告投放计划(支付)信息
     */
    AdvertisingPlanPay selectAdvertisingPlanPayById(Integer id);

    /**
     * 查询广告投放计划(支付)列表
     *
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 广告投放计划(支付)集合
     */
    List<AdvertisingPlanPay> selectAdvertisingPlanPayList(AdvertisingPlanPay advertisingPlanPay);

    /**
     * 新增广告投放计划(支付)
     *
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
    int insertAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay);

    /**
     * 修改广告投放计划(支付)
     *
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
    int updateAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay);

    /**
     * 删除广告投放计划(支付)
     *
     * @param id 广告投放计划(支付)ID
     * @return 结果
     */
    int deleteAdvertisingPlanPayById(Integer id);

    /**
     * 批量删除广告投放计划(支付)
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanPayByIds(String[] ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param arr
     * @return
     */
    int logicDeleteAdvertisingPlanPayByIds(String[] arr);

    /**
     * 广告投放计划业务主键ID
     *
     * @param planId
     * @return
     */
    AdvertisingPlanPay selectAdvertisingPlanPayByPlanId(String planId);

    /**
     * 根据公众号查询广告投放计划
     *
     * @param adAppId
     * @return
     */
    List<AdvertisingPlanPay> selectByAdAppId(String adAppId);

}