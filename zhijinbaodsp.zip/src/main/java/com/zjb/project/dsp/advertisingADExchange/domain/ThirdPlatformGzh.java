package com.zjb.project.dsp.advertisingADExchange.domain;

import java.io.Serializable;

/**
 * 第三方平台公众号信息
 * @author jiangbingjie
 * @date 2020/4/18 3:07 下午
 */
public class ThirdPlatformGzh implements Serializable {
    private static final long serialVersionUID = -695245084115729212L;
    /**公众号ID*/
    private String appId;
    /**公众号名称*/
    private String appName;
    /**第三方渠道*/
    private String thirdPlatformChannel;
    /**用户openId*/
    private String openId;
    /**扫码流水号*/
    private String randomNum;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getThirdPlatformChannel() {
        return thirdPlatformChannel;
    }

    public void setThirdPlatformChannel(String thirdPlatformChannel) {
        this.thirdPlatformChannel = thirdPlatformChannel;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }
}
