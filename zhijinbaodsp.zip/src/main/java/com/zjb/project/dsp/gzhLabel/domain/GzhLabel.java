package com.zjb.project.dsp.gzhLabel.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
								import java.util.Date;

/**
 * 公众号粉丝标签详情表 zjb_gzh_label
 * 
 * @author shenlong
 * @date 2019-11-08
 */
public class GzhLabel extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** 公众号appid */
	private String appid;
	/** 标签id */
	private Integer labelId;
	/** 标签名称 */
	private String labelName;
	/** 标签人数 */
	private Integer labelCount;
	public void setId(Integer id) 
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setAppid(String appid) 
	{
		this.appid = appid;
	}

	public String getAppid() 
	{
		return appid;
	}
	public void setLabelId(Integer labelId) 
	{
		this.labelId = labelId;
	}

	public Integer getLabelId() 
	{
		return labelId;
	}
	public void setLabelName(String labelName) 
	{
		this.labelName = labelName;
	}

	public String getLabelName() 
	{
		return labelName;
	}
	public void setLabelCount(Integer labelCount) 
	{
		this.labelCount = labelCount;
	}

	public Integer getLabelCount() 
	{
		return labelCount;
	}


	@Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("appid", getAppid())
            .append("labelId", getLabelId())
            .append("labelName", getLabelName())
            .append("labelCount", getLabelCount())
            .append("remark", getRemark())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .toString();
    }
}
