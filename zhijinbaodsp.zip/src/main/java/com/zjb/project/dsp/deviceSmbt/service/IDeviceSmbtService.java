package com.zjb.project.dsp.deviceSmbt.service;

import com.zjb.project.dsp.deviceSmbt.domain.DeviceSmbt;

import java.util.Date;
import java.util.List;

/**
 * @author songjy
 * @Date 2020/01/03
 **/
public interface IDeviceSmbtService {

    /**
     * 根据事件流水号查询分成记录信息
     *
     * @param smbtDate      扫码日期：yyyy-MM-dd
     * @param deviceName 设备名称
     * @param zjbPrSn  设备出纸流水号
     * @return
     */
    List<DeviceSmbt> findByEventSerialNum(Date smbtDate, String deviceName, String zjbPrSn);
}
