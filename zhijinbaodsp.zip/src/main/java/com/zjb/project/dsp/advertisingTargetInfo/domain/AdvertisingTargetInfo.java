package com.zjb.project.dsp.advertisingTargetInfo.domain;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.mongodb.core.mapping.Document;

import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.zjbprresponse.domain.ZjbPrResponse;

/**
 * @author songjy
 * @date 2019/07/18
 */
@Document(collection = "ad_target_info")
public class AdvertisingTargetInfo implements Serializable {
    private static final long serialVersionUID = -2306893147237182033L;

    @Id
    private Long id;

    /**
     * 广告请求时间：yyyy-MM-dd HH:mm:ss
     */
    private Date gmtAdRequestTime;

    /**
     * 广告请求日期：yyyy-MM-dd
     */
    private Date adRequestDate;

    /**
     * 用户唯一标识
     */
    private String userId;
    /**
     * 用户微信|支付宝唯一标识
     */
    private String openId;

    /**
     * 胜出的广告计划id
     */
    private String adWinPlanId;

    /**
     * 首次胜出的广告计划id，即二次竞价
     */
    private String adFirstWinPlanId;

    /**
     * 胜出的广告方案id
     */
    private String adWinCombinationId;

    /**
     * 参与竞价的广告计划ID
     */
    private List<String> participateBidPlanId;

    /**
     * 广告设备定向信息
     */
    private AdvertisingDeviceInfo deviceInfo;

    /**
     * 广告人群定向信息
     */
    private AdvertisingPeopleInfo peopleInfo;

    /**
     * ZJBPR上报信息
     */
    private ZjbPrResponse prResponse;

    /**
     * 广告统计信息
     */
    private StatisticsAdInfo adInfo;

    /**
     * 取纸来源，0：普通免费取纸 1：小树叶极速取纸 2：小树叶付费取纸 3：纯付费取纸
     */
    private Integer takePaperSource;

    /**
     * 已完成小树叶极速取纸流水号集合
     */
    private Set<Long> leafSerialNums;

    /**
     * 参阅二次竞价计划ID
     */
    private Set<String> secondBidPlanId;

    /**
     * 开始日期(查询用)
     */
    @Transient
    private Date gmtAdRequestTimeStart;

    /**
     * 结束日期(查询用)
     */
    @Transient
    private Date gmtAdRequestTimeEnd;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getGmtAdRequestTime() {
        return gmtAdRequestTime;
    }

    public void setGmtAdRequestTime(Date gmtAdRequestTime) {
        this.gmtAdRequestTime = gmtAdRequestTime;
    }

    public Date getAdRequestDate() {
        return adRequestDate;
    }

    public void setAdRequestDate(Date adRequestDate) {
        this.adRequestDate = adRequestDate;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getAdWinPlanId() {
        return adWinPlanId;
    }

    public void setAdWinPlanId(String adWinPlanId) {
        this.adWinPlanId = adWinPlanId;
    }

    public String getAdFirstWinPlanId() {
        return adFirstWinPlanId;
    }

    public void setAdFirstWinPlanId(String adFirstWinPlanId) {
        this.adFirstWinPlanId = adFirstWinPlanId;
    }

    public String getAdWinCombinationId() {
        return adWinCombinationId;
    }

    public void setAdWinCombinationId(String adWinCombinationId) {
        this.adWinCombinationId = adWinCombinationId;
    }

    public List<String> getParticipateBidPlanId() {
        return participateBidPlanId;
    }

    public void setParticipateBidPlanId(List<String> participateBidPlanId) {
        this.participateBidPlanId = participateBidPlanId;
    }

    public AdvertisingDeviceInfo getDeviceInfo() {
        return deviceInfo;
    }

    public void setDeviceInfo(AdvertisingDeviceInfo deviceInfo) {
        this.deviceInfo = deviceInfo;
    }

    public AdvertisingPeopleInfo getPeopleInfo() {
        return peopleInfo;
    }

    public void setPeopleInfo(AdvertisingPeopleInfo peopleInfo) {
        this.peopleInfo = peopleInfo;
    }

    public ZjbPrResponse getPrResponse() {
        return prResponse;
    }

    public void setPrResponse(ZjbPrResponse prResponse) {
        this.prResponse = prResponse;
    }

    public StatisticsAdInfo getAdInfo() {
        return adInfo;
    }

    public void setAdInfo(StatisticsAdInfo adInfo) {
        this.adInfo = adInfo;
    }

    public Integer getTakePaperSource() {
        return takePaperSource;
    }

    public void setTakePaperSource(Integer takePaperSource) {
        this.takePaperSource = takePaperSource;
    }

    public Set<Long> getLeafSerialNums() {
        return leafSerialNums;
    }

    public void setLeafSerialNums(Set<Long> leafSerialNums) {
        this.leafSerialNums = leafSerialNums;
    }

    public Date getGmtAdRequestTimeStart() {
        return gmtAdRequestTimeStart;
    }

    public void setGmtAdRequestTimeStart(Date gmtAdRequestTimeStart) {
        this.gmtAdRequestTimeStart = gmtAdRequestTimeStart;
    }

    public Date getGmtAdRequestTimeEnd() {
        return gmtAdRequestTimeEnd;
    }

    public void setGmtAdRequestTimeEnd(Date gmtAdRequestTimeEnd) {
        this.gmtAdRequestTimeEnd = gmtAdRequestTimeEnd;
    }

    public Set<String> getSecondBidPlanId() {
        return secondBidPlanId;
    }

    public void setSecondBidPlanId(Set<String> secondBidPlanId) {
        this.secondBidPlanId = secondBidPlanId;
    }
}
