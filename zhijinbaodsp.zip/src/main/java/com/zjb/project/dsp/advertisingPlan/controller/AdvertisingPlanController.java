package com.zjb.project.dsp.advertisingPlan.controller;

import com.alibaba.fastjson.JSON;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.PageDomain;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.page.TableSupport;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.service.IAdvertisingCombinationService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.authorizationuserinfo.service.AuthorizationUserInfoServiceImpl;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.blackPersonalAccount.domain.OwnPersonAccount;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import com.zjb.project.dsp.manualAppidOpenidIndex.domain.ManualAppidOpenidIndex;
import com.zjb.project.dsp.manualAppidOpenidIndex.service.IManualAppidOpenidIndexService;
import com.zjb.project.dsp.scanUserBackup.domain.ScanUserBackup;
import com.zjb.project.dsp.scanUserBackup.service.IScanUserBackupService;
import com.zjb.project.system.user.domain.User;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.AdUnit;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

import static com.zjb.common.constant.AdvertisingConstants.KEY_AD_COMBINATION_INFO_WIN_OWN_EVENT;
import static com.zjb.common.constant.AdvertisingConstants.KEY_AD_PLAN_WIN_EVENT;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MINUTE;
import static com.zjb.project.dsp.advertisingADExchange.service.IAdExchangeService.*;
import static com.zjb.project.dsp.userPrintLogWhite.service.IUserPrintLogWhiteService.USER_PRINT_LOG_WHITE;
import static com.zjb.project.system.config.service.IConfigService.GUARANTEE_AD_PLAN_ID;

/**
 * 广告投放计划 信息操作处理
 *
 * @author songjy
 * @date 2019-07-13
 */
@Controller
@RequestMapping("/zjb/advertisingPlan")
public class AdvertisingPlanController extends BaseController implements InitializingBean {
    private static final Logger log = LoggerFactory.getLogger(AdvertisingPlanController.class);
    private String prefix = "zjb/advertisingPlan";

    @Autowired
    private IAdvertisingPlanService advertisingPlanService;
    @Autowired
    private IAgencyService agencyService;
    @Autowired
    private IAdvertisingCombinationService advertisingCombinationService;
    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    private IAdvertisingUserInfoService advertisingUserInfoService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IAdvertisingUnitService advertisingUnitService;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private IManualAppidOpenidIndexService manualAppIdOpenIdIndexService;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;
    @Autowired
    private IScanUserBackupService scanUserBackupService;

    @RequiresPermissions("zjb:advertisingPlan:view")
    @GetMapping()
    public String advertisingPlan(ModelMap mmap) {
        AdvertisingCombination advertisingCombination = new AdvertisingCombination();
        List<AdvertisingCombination> advertisingCombinations = advertisingCombinationService.selectAdvertisingCombinationList(advertisingCombination);
        mmap.put("advertisingCombinations", advertisingCombinations);

        return prefix + "/advertisingPlan";
    }

    /**
     * 查询广告投放计划列表
     */
    @RequiresPermissions("zjb:advertisingPlan:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingPlan advertisingPlan) {

        String searchVal = advertisingPlan.getSearchValue();
        if (StringUtils.isNumeric(searchVal)) {
            advertisingPlan.setId(Integer.parseInt(searchVal));
        }

        startPageForDiy();
        List<AdvertisingPlan> list = advertisingPlanService.selectAdvertisingPlanList(advertisingPlan);

        DecimalFormat decimalFormat = new DecimalFormat("0%");
        for (AdvertisingPlan e : list) {

            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + e.getPlanId();
            AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            if (null != planFromRedis) {
                /*今日花费*/
                e.setTodaySpend(planFromRedis.getTodaySpend());
                /*今日胜出次数*/
                e.setTodayWinNum(planFromRedis.getTodayWinNum());
                /*总胜出次数*/
                e.setTotalWinNum(planFromRedis.getTotalWinNum());
                /*总花费*/
                e.setTotalSpend(planFromRedis.getTotalSpend());
                /*竞价胜出次数*/
                e.setBidWinNum(planFromRedis.getBidWinNum());
                /*参与竞价次数*/
                e.setParticipateBidNum(planFromRedis.getParticipateBidNum());
            }

            boolean zero = (null == e.getBidWinNum() || 0 == e.getBidWinNum() || null == e.getParticipateBidNum()
                    || 0 == e.getParticipateBidNum());
            e.setWinRate(zero ? "--" : decimalFormat.format(1F * e.getBidWinNum() / e.getParticipateBidNum()));

            User user = getUser(e.getCreaterId());
            e.setCreateBy(null == user ? null : user.getUserName());

            user = getUser(e.getModifierId());
            e.setUpdateBy(null == user ? null : user.getUserName());

            AdvertisingCombination advertisingCombination = advertisingCombinationService.selectAdvertisingCombinationById(e.getCombinationId());
            e.setCombinationName(null == advertisingCombination ? null : advertisingCombination.getName());

        }

        PageDomain pageDomain = TableSupport.buildPageRequest();
        String orderBy = pageDomain.getOrderBy();
        if (StringUtils.isEmpty(orderBy)) {
            CollectionUtils.sortTheList(list, "todayWinNum", CollectionUtils.SORT_ORDER.DESC);
        }

        return getDataTable(list);
    }

    /**
     * 新增广告投放计划
     */
    @GetMapping("/add")
    public String add(ModelMap map) {

        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /* 过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());

        AdvertisingCombination advertisingCombination = new AdvertisingCombination();
        List<AdvertisingCombination> advertisingCombinations = advertisingCombinationService.selectAdvertisingCombinationList(advertisingCombination);

        map.put("agencyList", agencyList);
        map.put("advertisingCombinations", advertisingCombinations);
        map.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});

        return prefix + "/add";
    }

    /**
     * 新增保存广告投放计划
     */
    @RequiresPermissions("zjb:advertisingPlan:add")
    @Log(title = "广告投放计划", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlan advertisingPlan) {

        AjaxResult ajaxResult = check(advertisingPlan);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        handleFile(file, advertisingPlan, deviceService);

        User user = getUser();
        advertisingPlan.setCreaterId(user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlan.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlan.getRadioWeChatOfficialAccount() || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlan.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }

            advertisingPlan.setAdAppId(list.get(0).getAppId());
        }

        int r = advertisingPlanService.insertAdvertisingPlan(advertisingPlan);

        if (r > 0) {
            advertisingPlanService.mediumSellRuleThreeNotice();
        }

        return toAjax(r);
    }

    /**
     * 处理上传文件,即提取SN
     *
     * @param file
     * @param advertisingPlan
     * @param deviceService
     */
    public static void handleFile(MultipartFile file, AdvertisingPlan advertisingPlan, IDeviceService deviceService) {

        if (null == file || file.isEmpty() || null == advertisingPlan) {
            return;
        }

        try (InputStream is = file.getInputStream()) {
            ExcelUtil<AdvertisingPlan> util = new ExcelUtil<AdvertisingPlan>(AdvertisingPlan.class);
            /*sheetName必须是：addevice*/
            List<AdvertisingPlan> list = util.importExcel("addevice", is);
            if (null == list || list.isEmpty()) {
                log.warn("文件格式错误或空文件");
                return;
            }

            Set<String> set = new HashSet<>();
            for (AdvertisingPlan e : list) {
                if (StringUtils.isNotEmpty(e.getMixId())) {
                    String mixId = StringUtils.trim(e.getMixId().replaceAll("\\xa0", "").replaceAll("\u00A0", ""));
                    DeviceDTO device = deviceService.selectDeviceByMixId(mixId);
                    if (null != device && StringUtils.isNotBlank(device.getSn())) {
                        set.add(device.getSn());
                    } else {
                        log.warn("无效mixId：【{}】", e.getMixId());
                    }
                }
            }

            if (set.size() == 0) {
                return;
            }

            advertisingPlan.setDeviceSn(String.join(",", set));

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    /**
     * 修改广告投放计划
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {

        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /* 过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());

        AdvertisingPlan advertisingPlan = advertisingPlanService.selectAdvertisingPlanById(id);
        AdvertisingCombination advertisingCombination = new AdvertisingCombination();
        List<AdvertisingCombination> advertisingCombinations = advertisingCombinationService.selectAdvertisingCombinationList(advertisingCombination);
        if (StringUtils.isNotEmpty(advertisingPlan.getDeviceScene())) {
            String deviceSceneIds = deviceInstallSceneService.getSceneIdsByCode(advertisingPlan.getDeviceScene());
            mmap.put("deviceSceneIds", deviceSceneIds);
        }

        mmap.put("deviceSceneSelected", StringUtils.split(advertisingPlan.getDeviceScene(), ','));
        mmap.put("agencyIdSelected", null == advertisingPlan.getAgencyIdArray() ? null : Convert.toIntArray(advertisingPlan.getAgencyIdArray()));
        mmap.put("agencyList", agencyList);
        mmap.put("advertisingCombinations", advertisingCombinations);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
        mmap.put("paperTodayNumSelected", StringUtils.isBlank(advertisingPlan.getPaperTodayNum()) ? null : Convert.toIntArray(advertisingPlan.getPaperTodayNum()));
        return prefix + "/edit";
    }

    /**
     * 边界广告投放计划权重
     */
    @GetMapping("/weight/{id}")
    public String weight(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingPlan advertisingPlan = advertisingPlanService.selectAdvertisingPlanById(id);
        mmap.put("advertisingPlan", advertisingPlan);
        mmap.put("planWeightArray", new int[]{1, 2, 3, 4, 5});
        return prefix + "/weight";
    }

    /**
     * 边界广告投放计划权重
     */
    @RequiresPermissions("zjb:advertisingPlan:weight")
    @Log(title = "广告投放计划权重设置", businessType = BusinessType.UPDATE)
    @PostMapping("/weight")
    @ResponseBody
    public AjaxResult weight(AdvertisingPlan advertisingPlan, ModelMap mmap) {

        User user = getUser();
        advertisingPlan.setModifierId(user.getUserId().intValue());

        advertisingPlanService.updateAdvertisingPlan(advertisingPlan);

        return success();
    }

    /**
     * 广告投放计划手动暂停
     */
    @RequiresPermissions("zjb:advertisingPlan:pause")
    @Log(title = "广告投放计划手动暂停", businessType = BusinessType.UPDATE)
    @PostMapping("/pause")
    @ResponseBody
    public AjaxResult pause(String ids) {

        for (String id : StringUtils.split(ids)) {
            AdvertisingPlan advertisingPlan = advertisingPlanService.selectAdvertisingPlanById(Integer.parseInt(id));
            advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlanService.updateAdvertisingPlan(advertisingPlan);
        }

        return success();
    }

    /**
     * 广告投放计划手动恢复
     */
    @RequiresPermissions("zjb:advertisingPlan:resume")
    @Log(title = "广告投放计划手动恢复", businessType = BusinessType.UPDATE)
    @PostMapping("/resume")
    @ResponseBody
    public AjaxResult resume(String ids) {

        for (String id : StringUtils.split(ids)) {

            AdvertisingPlan advertisingPlan = advertisingPlanService.selectAdvertisingPlanById(Integer.parseInt(id));

            if (null == advertisingPlan) {
                return error("广告计划不存在");
            }

            AdCombinationInfo combinationInfo = adExchangeService.advertisingCombination(advertisingPlan);

            if (null == combinationInfo || null == combinationInfo.getScan() || combinationInfo.getScan().isEmpty()) {
                return error("该广告计划对应的扫码取纸广告已停用，如需恢复请先至广告池中将对应扫码取纸广告启用。");
            }

            for (AdUnit u : combinationInfo.getScan()) {
                String adId = u.getId().substring(AD_COMBINATION_UNIT_PREFIX.getValue().toString().length());
                AdvertisingUnit advertisingUnit = advertisingUnitService.selectAdvertisingUnitById(Integer.parseInt(adId));
                if (null == advertisingUnit || null == advertisingUnit.getAdUseStatus() || advertisingUnit.getAdUseStatus().equals(AD_USE_NO.getValue())) {
                    return error("该广告计划对应的扫码取纸广告已停用，如需恢复请先至广告池中将对应扫码取纸广告启用。");
                }
            }

            advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());
            advertisingPlan.setGmtModified(new Date());
            advertisingPlanService.updateAdvertisingPlan(advertisingPlan);
            advertisingPlanService.reloadPattern(advertisingPlan.getPlanId());
        }

        return success();
    }

    /**
     * 修改保存广告投放计划
     */
    /**
     * @param file
     * @param advertisingPlan
     * @return
     */
    @RequiresPermissions("zjb:advertisingPlan:edit")
    @Log(title = "广告投放计划", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlan advertisingPlan) {

        AdvertisingPlan advertisingPlanOld = advertisingPlanService.selectAdvertisingPlanById(advertisingPlan.getId());

        if (null == advertisingPlanOld) {
            return error("记录不存在");
        }

        AjaxResult ajaxResult = check(advertisingPlan);

        if (null != ajaxResult) {
            return ajaxResult;
        }

        handleFile(file, advertisingPlan, deviceService);

        User user = getUser();
        advertisingPlan.setModifierId(null == user ? null : user.getUserId().intValue());

        List<ComponentAuthorizationInfo> list = advertisingCombinationService.isWeChatOfficialAccountOnSpacePaperOutput(advertisingPlan.getCombinationId());
        if (null != list && !list.isEmpty()) {
            advertisingPlan.setWeChatOfficialAccounts(String.join(",", list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet())));
            if (null == advertisingPlan.getRadioWeChatOfficialAccount() || AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue().equals(advertisingPlan.getRadioWeChatOfficialAccount())) {
                return error("公众号定向必选");
            }
            advertisingPlan.setAdAppId(list.get(0).getAppId());
        } else {
            advertisingPlan.setAdAppId(null);
        }

        if (null != advertisingPlan.getOperationType()
                && advertisingPlan.getOperationType().equals(IAdPlanService.OPERATION_TYPE_UPDATE)) {
            advertisingPlan.setCategoryFinance(null == advertisingPlan.getCategoryFinance() ? NO.getValue() : advertisingPlan.getCategoryFinance());
            advertisingPlan.setWeChatAccount(null == advertisingPlan.getWeChatAccount() ? NO.getValue() : advertisingPlan.getWeChatAccount());
            advertisingPlan.setPersonalAccount(null == advertisingPlan.getPersonalAccount() ? NO.getValue() : advertisingPlan.getPersonalAccount());
        }

        advertisingPlan.setGmtModified(new Date());
        int r = advertisingPlanService.updateAdvertisingPlan(advertisingPlan);
        advertisingPlanService.mediumSellRuleThreeNotice();
        return toAjax(r);
    }

    /**
     * 参数校验
     *
     * @param advertisingPlan
     * @return
     */
    public static AjaxResult check(AdvertisingPlan advertisingPlan) {

        if (ZjbDictionaryEnum.NO.getValue().toString().equals(advertisingPlan.getLongTermEffective())
                && (null == advertisingPlan.getGmtShowEnd() || null == advertisingPlan.getGmtShowStart())) {
            return AjaxResult.error("开始|结束时间未指定");
        }

        if (null == advertisingPlan.getGmtShowEnd() && null != advertisingPlan.getGmtShowStart()) {
            return AjaxResult.error("结束时间未指定");
        }

        if (null != advertisingPlan.getGmtShowEnd() && null == advertisingPlan.getGmtShowStart()) {
            return AjaxResult.error("开始时间未指定");
        }

        if (null != advertisingPlan.getGmtShowEnd() && null != advertisingPlan.getGmtShowStart()
                && advertisingPlan.getGmtShowStart().after(advertisingPlan.getGmtShowEnd())) {
            return AjaxResult.error("开始时间不能大于结束时间");
        }

        Integer paperTodayLowerNum = advertisingPlan.getPaperTodayLowerNum();
        Integer paperTodayUpperNum = advertisingPlan.getPaperTodayUpperNum();

        if (null == paperTodayLowerNum && null != paperTodayUpperNum) {
            return AjaxResult.error("请指定当日取纸下限");
        }

        if (null != paperTodayLowerNum && null == paperTodayUpperNum) {
            return AjaxResult.error("请指定当日取纸上限");
        }

        if (null != paperTodayLowerNum && null != paperTodayUpperNum && paperTodayLowerNum > paperTodayUpperNum) {
            return AjaxResult.error("当日取纸下限不能大于上限");
        }

        Integer paperLowerNum = advertisingPlan.getPaperLowerNum();
        Integer paperUpperNum = advertisingPlan.getPaperUpperNum();

        if (null == paperLowerNum && null != paperUpperNum) {
            return AjaxResult.error("请指定总取纸下限");
        }

        if (null != paperLowerNum && null == paperUpperNum) {
            return AjaxResult.error("请指定总取纸上限");
        }

        if (null != paperLowerNum && null != paperUpperNum && paperLowerNum > paperUpperNum) {
            return AjaxResult.error("总取纸下限不能大于上限");
        }

        return null;
    }

    /**
     * 删除广告投放计划
     */
    @RequiresPermissions("zjb:advertisingPlan:remove")
    @Log(title = "广告投放计划", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingPlanService.logicDeleteAdvertisingPlanByIds(ids));
    }

    /**
     * 获取投放广告计划
     *
     * @param targetInfo
     * @return
     */
    @PostMapping("/target")
    @ResponseBody
    public AdvertisingPlan advertisingPlanTarget(@RequestBody(required = false) AdvertisingTargetInfo targetInfo) {
        long start = System.currentTimeMillis();

        if (null == targetInfo) {
            log.error("目标信息为空");
            return guaranteePlan(null);
        }

        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();

        if (null == peopleInfo) {
            log.error("用户信息缺失");
            return guaranteePlan(null);
        }

        String randomNum = peopleInfo.getRandomNum();

        if (!StringUtils.isNumeric(randomNum)) {
            log.error("随机数缺失或非数字");
            return guaranteePlan(randomNum);
        }

        AdvertisingPlan win = JedisPoolCacheUtils.getV(randomNum, ZJB_DB_50, AdvertisingPlan.class);

        if (null != win) {
            return win;
        }

        if (null == targetInfo.getDeviceInfo()) {
            log.error("设备信息缺失");
            return guaranteePlan(randomNum);
        }

        ADVERTISING_TARGET_INFO_THREAD_LOCAL.set(targetInfo);

        /*参与竞价的广告计划*/
        List<AdvertisingPlan> participatePlans = null;

        try {
            targetInfo.setId(Long.parseLong(randomNum));

            /*处理取纸次数*/
            handlePaperNum(targetInfo);

            /*处理公众号*/
            handleWeChatOfficialAccount(peopleInfo);

            /*处理人工授权公众号*/
            handleManualWeChatOfficialAccount(peopleInfo);

            /*广告请求时间*/
            targetInfo.setGmtAdRequestTime(new Date());
            targetInfo.setAdRequestDate(DateUtils.toDate(LocalDate.now()));

            if (USER_PRINT_LOG_WHITE.isEmpty() || USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
                log.info("设备人群定向数据：{}", JSON.toJSONString(targetInfo));
            }

            participatePlans = adExchangeService.filter(targetInfo.getDeviceInfo(), peopleInfo);

            /*参与竞价概率过滤*/
            adExchangeService.participateBidPercentageFilter(participatePlans);

            /*过滤第三方平台*/
            adExchangeService.thirdPartyPlatformFilterBeforeBid(participatePlans);

            win = adExchangeService.firstBid(participatePlans);

            if (null != win) {
                return win;
            }

            win = guaranteePlan(randomNum);
            log.info("扫码流水号{}未匹配到广告计划，已采用保底计划{}代替，定向信息：{}", randomNum, win.getPlanId(), JSON.toJSONString(targetInfo));

            return win;
        } catch (Exception e) {
            log.error("扫码流水号{}异常", randomNum + ":" + e.getMessage(), e);
            win = guaranteePlan(randomNum);
            return win;
        } finally {
            assert win != null;
            win.setRecentWinTimestamp(System.currentTimeMillis());
            win.setRandomNum(targetInfo.getId().toString());
            JedisPoolCacheUtils.setVExpire(peopleInfo.getOpenId(), win, EXRP_5_MINUTE, ZJB_DB_50);
            JedisPoolCacheUtils.setVExpire(randomNum, win, EXRP_5_MINUTE, ZJB_DB_50);
            /*设置域名*/
            adExchangeService.setDomainAddress(win);
            advertisingPlanDeviceService.localCacheWinPlan(win);
            /*处理竞价结果*/
            adExchangeService.asynchronousHandleBiddingResult(participatePlans, win, targetInfo);

            /*广告计划胜出事件发布*/
            Map<String, Object> map = new HashMap<>(6);
            map.put(KEY_AD_PLAN_WIN_EVENT, win);
            map.put(AdvertisingTargetInfo.class.getName(), targetInfo);
            map.put(AuthorizationUserInfoDTO.class.getName(), AUTHORIZATION_USER_INFO_THREAD_LOCAL.get());
            JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));

            /*QQ号胜出*/
            if (StringUtils.isNotEmpty(win.getQqPersonalId()) && StringUtils.isNotEmpty(win.getRandomNum())) {
                OwnPersonAccount ownPersonAccount = new OwnPersonAccount();
                ownPersonAccount.setOpenId(targetInfo.getPeopleInfo().getOpenId());
                ownPersonAccount.setPersonalAppId(win.getQqPersonalId());
                ownPersonAccount.setPersonalSourceType(PERSONAL_SOURCE_TYPE_OWN.getValue().toString());
                ownPersonAccount.setRandomNum(win.getRandomNum());
                Map<String, Object> map1 = new HashMap<>(4);
                map1.put(KEY_AD_COMBINATION_INFO_WIN_OWN_EVENT, ownPersonAccount);
                JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(map1));
            }

            /*微信号胜出*/
            if (StringUtils.isNotEmpty(win.getWeChatPersonalId()) && StringUtils.isNotEmpty(win.getRandomNum())) {
                OwnPersonAccount ownPersonAccount = new OwnPersonAccount();
                ownPersonAccount.setOpenId(targetInfo.getPeopleInfo().getOpenId());
                ownPersonAccount.setPersonalAppId(win.getWeChatPersonalId());
                ownPersonAccount.setPersonalSourceType(PERSONAL_SOURCE_TYPE_OWN.getValue().toString());
                ownPersonAccount.setRandomNum(win.getRandomNum());
                Map<String, Object> map1 = new HashMap<>(4);
                map1.put(KEY_AD_COMBINATION_INFO_WIN_OWN_EVENT, ownPersonAccount);
                JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(map1));
            }


            ADVERTISING_TARGET_INFO_THREAD_LOCAL.remove();
            ADVERTISING_USER_INFO_THREAD_LOCAL.remove();
            AUTHORIZATION_USER_INFO_THREAD_LOCAL.remove();
            // 竞价耗时
            long l = System.currentTimeMillis() - start;
            handleDataVAdTime(l, peopleInfo.getOpenId(), win.getPlanId());
            log.info("用户{}流水号{}匹配广告{}耗时（毫秒）：{}", peopleInfo.getOpenId(), randomNum, win.getPlanId(), l);
        }
    }

    /**
     * 处理datav竞价耗时
     *
     * @param time   耗时
     * @param openid 用户
     * @param palnId 计划id
     */
    private void handleDataVAdTime(long time, String openid, String palnId) {
        int device = 3;
        time = time / device;
        JedisPoolCacheUtils.sadd(ZjbConstantsRedis.DATAV_AD_TIME + "_" + DateUtils.getDate(), ZJB_DB_50, 10, time + "");
        String value = openid + "@" + palnId + "@" + time;
        JedisPoolCacheUtils.sadd(ZjbConstantsRedis.DATAV_AD_DETAIL + "_" + DateUtils.getDate(), ZJB_DB_50, 10, value);
        Map map = JedisPoolCacheUtils.getV(ZjbConstantsRedis.DATAV_AD_TIME_DISTRIBUTE + "_" + DateUtils.getDate(), ZJB_DB_50, HashMap.class);
        if (MapUtils.isNotEmpty(map)) {
            if (MapUtils.isNotEmpty(map) && time > 0 && time < 100 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_LT_100);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_LT_100, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_LT_100, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 200 / device && time >= 100 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_100_200);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_100_200, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_100_200, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 300 / device && time >= 200 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_200_300);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_200_300, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_200_300, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 400 / device && time >= 300 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_300_400);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_300_400, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_300_400, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 500 / device && time >= 400 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_400_500);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_400_500, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_400_500, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 600 / device && time >= 500 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_500_600);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_500_600, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_500_600, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 700 / device && time >= 600 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_600_700);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_600_700, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_600_700, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 800 / device && time >= 700 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_700_800);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_700_800, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_700_800, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 900 / device && time >= 800 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_800_900);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_800_900, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_800_900, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time < 1000 / device && time >= 900 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_900_1000);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_900_1000, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_900_1000, 1);
                }
            } else if (MapUtils.isNotEmpty(map) && time > 1000 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000, 1);
                }
            }
        } else {
            map = new HashMap();
            if (time > 0 && time < 100 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_LT_100);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_LT_100, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_LT_100, 1);
                }
            } else if (time < 200 / device && time >= 100 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_100_200);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_100_200, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_100_200, 1);
                }
            } else if (time < 300 / device && time >= 200 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_200_300);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_200_300, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_200_300, 1);
                }
            } else if (time < 400 / device && time >= 300 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_300_400);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_300_400, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_300_400, 1);
                }
            } else if (time < 500 / device && time >= 400 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_400_500);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_400_500, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_400_500, 1);
                }
            } else if (time < 600 / device && time >= 500 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_500_600);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_500_600, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_500_600, 1);
                }
            } else if (time < 700 / device && time >= 600 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_600_700);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_600_700, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_600_700, 1);
                }
            } else if (time < 800 / device && time >= 700 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_700_800);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_700_800, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_700_800, 1);
                }
            } else if (time < 900 / device && time >= 800 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_800_900);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_800_900, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_800_900, 1);
                }
            } else if (time < 1000 / device && time >= 900 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_900_1000);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_900_1000, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_900_1000, 1);
                }
            } else if (time > 1000 / device) {
                Object o = map.get(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000);
                if (null != o) {
                    int i = Integer.parseInt(o.toString());
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000, ++i);
                } else {
                    map.put(ZjbConstantsRedis.DATAV_AD_TIME_GT_1000, 1);
                }
            }
        }
        JedisPoolCacheUtils.setVExpire(ZjbConstantsRedis.DATAV_AD_TIME_DISTRIBUTE + "_" + DateUtils.getDate(), map, JedisPoolCacheUtils.EXRP_DAY, ZJB_DB_50);

    }

    /**
     * 根据广告计划ID获取广告详情信息
     *
     * @param plan
     * @return
     */
    @PostMapping("/query")
    @ResponseBody
    public AdvertisingPlan advertisingPlanTarget(@RequestBody AdvertisingPlan plan) {
        String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + plan.getPlanId();
        plan = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
        adExchangeService.setDomainAddress(plan);
        return plan;
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        /*缓存保底广告计划*/
        for (String planId : GUARANTEE_AD_PLAN_ID) {
            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + planId;
            AdvertisingPlan plan = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);

            if (null == plan) {
                log.error("保底广告计划ID【{}】不存在", planId);
                continue;
            }

            adExchangeService.setDomainAddress(plan);

            key = ZjbConstantsRedis.DSP_GUARANTEE_AD_PLAN_ID + '_' + planId;
            JedisPoolCacheUtils.setVExpire(key, plan, JedisPoolCacheUtils.EXRP_MONTH, ZJB_DB_50);
        }
    }

    /**
     * 处理公众号
     *
     * @param peopleInfo
     */
    private void handleWeChatOfficialAccount(AdvertisingPeopleInfo peopleInfo) {
        long start = System.currentTimeMillis();

        if (null == peopleInfo || StringUtils.isBlank(peopleInfo.getOpenId())) {
            return;
        }

        AuthorizationUserInfoDTO userInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(peopleInfo.getOpenId());

        if (null == userInfo || StringUtils.isBlank(userInfo.getSubscribeGzh())) {
            return;
        }

        String[] array = StringUtils.split(userInfo.getSubscribeGzh(), ',');
        Integer[] ids = new Integer[array.length];
        int len = array.length;
        for (int i = 0; i < len; i++) {
            ids[i] = StringUtils.isNumeric(array[i]) ? Integer.parseInt(array[i]) : 0;
        }

        List<ComponentAuthorizationInfo> list = componentAuthorizationInfoService.findByIds(ids);

        if (null == list || list.isEmpty()) {
            return;
        }

        Set<String> stringSet = list.stream().map(ComponentAuthorizationInfo::getAppId).collect(Collectors.toSet());
        Set<String> weChatOfficialAccounts = peopleInfo.getWeChatOfficialAccounts();
        Set<String> historyWeChatOfficialAccounts = peopleInfo.getHistoryWeChatOfficialAccounts();

        if (null == weChatOfficialAccounts) {
            peopleInfo.setWeChatOfficialAccounts(stringSet);
        } else {
            weChatOfficialAccounts.addAll(stringSet);
            peopleInfo.setWeChatOfficialAccounts(weChatOfficialAccounts);
        }

        if (null == historyWeChatOfficialAccounts) {
            peopleInfo.setHistoryWeChatOfficialAccounts(stringSet);
        } else {
            historyWeChatOfficialAccounts.addAll(stringSet);
            peopleInfo.setHistoryWeChatOfficialAccounts(historyWeChatOfficialAccounts);
        }

        if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            log.info("用户{}流水号{}处理公众号耗时（毫秒）：{}", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), System.currentTimeMillis() - start);
        }

    }

    /**
     * 处理取纸次数
     *
     * @param targetInfo
     */
    private void handlePaperNum(AdvertisingTargetInfo targetInfo) {
        /*从mongodb中获取总取纸次数*/
        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
        AdvertisingDeviceInfo deviceInfo = targetInfo.getDeviceInfo();
        String openId = peopleInfo.getOpenId();
        targetInfo.setOpenId(openId);
        AdvertisingUserInfo userInfo = new AdvertisingUserInfo();
        userInfo.setOpenId(openId);

        try {
            userInfo = advertisingUserInfoService.findByOpenId(openId);
        } catch (DataAccessResourceFailureException e) {
            log.error("扫码用户{}信息查询失败:{}" ,openId, e.getMessage());
            ScanUserBackup userBackup = scanUserBackupService.selectByOpenId(openId);
            if (null != userBackup && StringUtils.isNotBlank(userBackup.getJson())) {
                userInfo = JSON.parseObject(userBackup.getJson(), AdvertisingUserInfo.class);
            }
        }

        ADVERTISING_USER_INFO_THREAD_LOCAL.set(userInfo);

        /*用户总取纸次数*/
        Integer totalPaperNum = (null == userInfo ? 1 : (null == userInfo.getTotalPaperNum() ? 1 : userInfo.getTotalPaperNum()));
        /*用户当日取纸次数*/
        peopleInfo.setTodayPaperNum(AuthorizationUserInfoServiceImpl.todayTakePaperCount(openId, null) + 1);
        peopleInfo.setTotalPaperNum(totalPaperNum);
        deviceInfo.setTodayPaperNum(peopleInfo.getTodayPaperNum());
    }

    @Log(title = "广告投放计划", businessType = BusinessType.EXPORT)
    @PostMapping("/export/sn")
    @ResponseBody
    public AjaxResult exportDeviceSn(AdvertisingPlan advertisingPlan) {

        List<AdvertisingPlan> list = new ArrayList<>();
        ExcelUtil<AdvertisingPlan> util = new ExcelUtil<>(AdvertisingPlan.class);
        /*sheetName必须是：addevice，否则无法直接上传导入分成配置*/
        String sheetName = "addevice";

        AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceService.selectAdvertisingPlanDeviceByPlanId(advertisingPlan.getPlanId());

        if (null == advertisingPlanDevice) {
            return util.exportExcel(list, sheetName);
        }

        String[] array = StringUtils.split(advertisingPlanDevice.getDeviceSn(), ',');

        if (null == array || array.length == 0) {
            return util.exportExcel(list, sheetName);
        }

        for (String sn : array) {
            AdvertisingPlan record = new AdvertisingPlan();
            record.setMixId(sn);
            list.add(record);
        }

        return util.exportExcel(list, sheetName);
    }

    /**
     * 文件上传
     */
    @PostMapping("/uploadFile")
    @ResponseBody
    public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {

        if (file.isEmpty()) {
            return error("文件为空");
        }

        String fileName = FilenameUtils.getName(file.getOriginalFilename());
        String ext = FilenameUtils.getExtension(fileName);
        String md5 = DigestUtils.md5Hex(fileName);
        String fileKey = zjbConfig.getAdPlanDeviceFileUrl() + LocalDate.now()
                + '/' + md5 + '.' + ext;

        try {
            OssUtil.uploadFile(fileKey, file.getInputStream());
            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            log.warn("文件OSS路径：{}", fileUrl);
            AjaxResult ajaxResult = success();
            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);
            return ajaxResult;
        } catch (IOException e) {
            log.error(e.getMessage(), e);
            return error(e.getMessage());
        }
    }

    /**
     * 处理人工授权公众号
     *
     * @param peopleInfo
     */
    private void handleManualWeChatOfficialAccount(AdvertisingPeopleInfo peopleInfo) {
        long start = System.currentTimeMillis();

        if (null == peopleInfo || StringUtils.isBlank(peopleInfo.getOpenId())) {
            return;
        }

        List<ManualAppidOpenidIndex> list = manualAppIdOpenIdIndexService.selectManualAppidOpenidIndexByZjbOpenId(peopleInfo.getOpenId());


        if (null == list || list.isEmpty()) {
            return;
        }

        Set<String> stringSet = list.stream().map(ManualAppidOpenidIndex::getAppid).collect(Collectors.toSet());
        Set<String> weChatOfficialAccounts = peopleInfo.getWeChatOfficialAccounts();
        Set<String> historyWeChatOfficialAccounts = peopleInfo.getHistoryWeChatOfficialAccounts();

        if (null == weChatOfficialAccounts) {
            peopleInfo.setWeChatOfficialAccounts(stringSet);
        } else {
            weChatOfficialAccounts.addAll(stringSet);
            peopleInfo.setWeChatOfficialAccounts(weChatOfficialAccounts);
        }

        if (null == historyWeChatOfficialAccounts) {
            peopleInfo.setHistoryWeChatOfficialAccounts(stringSet);
        } else {
            historyWeChatOfficialAccounts.addAll(stringSet);
            peopleInfo.setHistoryWeChatOfficialAccounts(historyWeChatOfficialAccounts);
        }

        if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            log.info("用户{}流水号{}处理人工授权公众号耗时（毫秒）：{}", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), System.currentTimeMillis() - start);
        }

    }
}
