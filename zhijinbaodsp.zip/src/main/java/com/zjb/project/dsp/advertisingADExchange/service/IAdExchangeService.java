package com.zjb.project.dsp.advertisingADExchange.service;

import java.util.List;
import java.util.Set;

import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.CombinationRequest;
import com.zjb.qrcodego.domain.WeChatAccountTaskInfo;

/**
 * @author songjy
 * @date 2019/07/16
 */
public interface IAdExchangeService {

    /**
     * 广告方案请求信息
     */
    ThreadLocal<CombinationRequest> COMBINATION_REQUEST_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 广告计划请求信息
     */
    ThreadLocal<AdvertisingTargetInfo> ADVERTISING_TARGET_INFO_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 扫码用户信息
     */
    ThreadLocal<AdvertisingUserInfo> ADVERTISING_USER_INFO_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 授权用户信息
     */
    ThreadLocal<AuthorizationUserInfoDTO> AUTHORIZATION_USER_INFO_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 匹配该设备的所有投放计划ID集合
     *
     * @param advertisingDeviceInfo
     * @return
     */
    Set<String> matcher(AdvertisingDeviceInfo advertisingDeviceInfo);

    /**
     * 匹配该人群的所有投放计划ID集合
     *
     * @param advertisingPepoleInfo
     * @return
     */
    Set<String> matcher(AdvertisingPeopleInfo advertisingPepoleInfo);

    /**
     * 匹配设备和人群的所有投放计划ID集合
     *
     * @param advertisingDeviceInfo
     * @param advertisingPepoleInfo
     * @return
     */
    Set<String> matcher(AdvertisingDeviceInfo advertisingDeviceInfo, AdvertisingPeopleInfo advertisingPepoleInfo);

    /**
     * 按辅助条件过滤
     * <p>
     * 1总取纸次数
     * 2当日取纸次数
     * 3是否超过日预算
     * 4是否超过总预算
     * 5行业过滤：学校不允许投放金融类型广告
     * 6投放时间
     * 7是否投放中
     * </p>
     *
     * @param deviceInfo
     * @param peopleInfo
     * @return
     */
    List<AdvertisingPlan> filter(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo);

    /**
     * 参与竞价概率
     *
     * @param planList
     */
    void participateBidPercentageFilter(List<AdvertisingPlan> planList);

    /**
     * 第三方平台广告计划是否参与竞价
     *
     * @param planList
     */
    void thirdPartyPlatformFilterBeforeBid(List<AdvertisingPlan> planList);

    /**
     * 广告二次竞价
     *
     * @param randomNum 用户扫码流水号
     * @return
     */
    AdvertisingPlan secondBid(Long randomNum);

    /**
     * 广告第三次竞价
     *
     * @param combination
     * @param secondBidWinPlan 第二次竞价胜出计划
     * @return
     */
    AdCombinationInfo thirdBid(CombinationRequest combination, AdvertisingPlan secondBidWinPlan);

    /**
     * 广告是否直配置公众号
     *
     * @param win
     * @param combinationInfo
     * @return
     */
    boolean directWeChatAccount(AdvertisingPlan win, AdCombinationInfo combinationInfo);

    /**
     * 获取保底广告计划方案
     *
     * @param randomNum 用户扫码流水号
     * @return
     */
    AdCombinationInfo guaranteed(Long randomNum);

    /**
     * 获取公众号任务信息
     *
     * @param combinationInfo
     * @return
     */
    WeChatAccountTaskInfo getWeChatAccountTaskInfo(AdCombinationInfo combinationInfo);

    /**
     * 获取授权表直配公众务信息
     *
     * @param combinationInfo
     * @return
     */
    WeChatAccountTaskInfo getAuthWeChatAccountTaskInfo(AdCombinationInfo combinationInfo);

    /**
     * 广告第一竞价
     *
     * @param planList
     * @return
     */
    AdvertisingPlan firstBid(List<AdvertisingPlan> planList);

    /**
     * 设置域名
     *
     * @param plan
     */
    void setDomainAddress(AdvertisingPlan plan);

    /**
     * 广告竞价结果异步处理
     *
     * @param planList   参与竞价的广告计划(包含竞价胜出广告计划)
     * @param win        竞价胜出广告计划
     * @param targetInfo 程序化交易数据信息
     */
    void asynchronousHandleBiddingResult(List<AdvertisingPlan> planList, AdvertisingPlan win, AdvertisingTargetInfo targetInfo);

    /**
     * 根据广告计划获取投放广告方案
     *
     * @param win 胜出广告计划
     * @return
     */
    AdCombinationInfo advertisingCombination(AdvertisingPlan win);

    /**
     * 根据广告方案获取其关联的所有广告单元
     *
     * @param advertisingCombination
     * @return
     */
    List<AdvertisingUnit> selectAdvertisingUnitListByCombinationId(AdvertisingCombination advertisingCombination);

    /**
     * 根据广告计划获取对应的广告方案
     *
     * @param advertisingPlan
     * @return
     */
    AdvertisingCombination getAdvertisingCombination(AdvertisingPlan advertisingPlan);

    /**
     * 公众号任务是否有效
     *
     * @param taskInfo
     * @return
     */
    boolean isValid(WeChatAccountTaskInfo taskInfo);

    /**
     * 用户关注公众号事件数据库记录与微信官方记录是否一致
     *
     * @param combination
     * @param win
     * @return
     */
    boolean isEventMatch(CombinationRequest combination, AdvertisingPlan win);

    /**
     * 人工上架的公众号信息
     *
     * @param combination
     * @param win
     * @return
     */
    WeChatAccountTaskInfo manualWeChatAccount(CombinationRequest combination, AdvertisingPlan win);

    /**
     * 非竞价广告
     * @param adCombinationInfo
     * @param openId
     * @param combination
     */
    void withoutBiddingPriceAdvertising(AdCombinationInfo adCombinationInfo, String openId, String randomNum, CombinationRequest combination);

    /**
     * 新版付费特殊设备
     * @param adCombinationInfo
     * @param deviceInfo
     */
    void paySpecialDevice(AdCombinationInfo adCombinationInfo,AdvertisingDeviceInfo deviceInfo);

}
