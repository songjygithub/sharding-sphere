package com.zjb.project.dsp.advertisementPlanDevice.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisementPlanDevice.mapper.AdvertisementPlanDeviceMapper;
import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import com.zjb.project.dsp.advertisementPlanDevice.service.IAdvertisementPlanDeviceService;
import com.zjb.common.support.Convert;

/**
 * 非竞价广告投放设备定向 服务层实现
 * 
 * @author Nigel Yang
 * @date 2020-05-09
 */
@Service
public class AdvertisementPlanDeviceServiceImpl implements IAdvertisementPlanDeviceService 
{
	@Autowired
	private AdvertisementPlanDeviceMapper advertisementPlanDeviceMapper;

	/**
     * 查询非竞价广告投放设备定向信息
     * 
     * @param id 非竞价广告投放设备定向ID
     * @return 非竞价广告投放设备定向信息
     */
    @Override
	public AdvertisementPlanDevice selectAdvertisementPlanDeviceById(Integer id)
	{
	    return advertisementPlanDeviceMapper.selectAdvertisementPlanDeviceById(id);
	}
	
	/**
     * 查询非竞价广告投放设备定向列表
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 非竞价广告投放设备定向集合
     */
	@Override
	public List<AdvertisementPlanDevice> selectAdvertisementPlanDeviceList(AdvertisementPlanDevice advertisementPlanDevice)
	{
	    return advertisementPlanDeviceMapper.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
	}
	
    /**
     * 新增非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	@Override
	public int insertAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice)
	{
	    return advertisementPlanDeviceMapper.insertAdvertisementPlanDevice(advertisementPlanDevice);
	}
	
	/**
     * 修改非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	@Override
	public int updateAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice)
	{
	    return advertisementPlanDeviceMapper.updateAdvertisementPlanDevice(advertisementPlanDevice);
	}

	/**
     * 删除非竞价广告投放设备定向对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisementPlanDeviceByIds(String ids)
	{
		return advertisementPlanDeviceMapper.deleteAdvertisementPlanDeviceByIds(Convert.toStrArray(ids));
	}

	@Override
	public void deleteAdvertisementPlanDeviceByAdvertisementPlanIds(String[] toStrArray) {
		advertisementPlanDeviceMapper.deleteAdvertisementPlanDeviceByAdvertisementPlanIds(toStrArray);
	}

}
