package com.zjb.project.dsp.forbidPutPersonalAccountConfig.mapper;

import com.zjb.project.dsp.forbidPutPersonalAccountConfig.domain.ForbidPutPersonalAccountConfig;
import java.util.List;	

/**
 * 指定次数禁投个人号广告配置 数据层
 * 
 * @author jiangbingjie
 * @date 2020-04-22
 */
public interface ForbidPutPersonalAccountConfigMapper 
{
	/**
     * 查询指定次数禁投个人号广告配置信息
     * 
     * @param configId 指定次数禁投个人号广告配置ID
     * @return 指定次数禁投个人号广告配置信息
     */
	public ForbidPutPersonalAccountConfig selectForbidPutPersonalAccountConfigById(Integer configId);
	
	/**
     * 查询指定次数禁投个人号广告配置列表
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 指定次数禁投个人号广告配置集合
     */
	public List<ForbidPutPersonalAccountConfig> selectForbidPutPersonalAccountConfigList(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
	
	/**
     * 新增指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	public int insertForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
	
	/**
     * 修改指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	public int updateForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig);
	
	/**
     * 删除指定次数禁投个人号广告配置
     * 
     * @param configId 指定次数禁投个人号广告配置ID
     * @return 结果
     */
	public int deleteForbidPutPersonalAccountConfigById(Integer configId);
	
	/**
     * 批量删除指定次数禁投个人号广告配置
     * 
     * @param configIds 需要删除的数据ID
     * @return 结果
     */
	public int deleteForbidPutPersonalAccountConfigByIds(String[] configIds);

	/**
	 * 查询自动失效记录
	 * @return
	 */
	public List<ForbidPutPersonalAccountConfig> selectAutomaticInvalid();

	/**
	 * 获取配置状态为空的配置信息
	 * @return
	 */
	public List<ForbidPutPersonalAccountConfig> getForbidPutPersonalAccountListWithoutStatus();
	
}