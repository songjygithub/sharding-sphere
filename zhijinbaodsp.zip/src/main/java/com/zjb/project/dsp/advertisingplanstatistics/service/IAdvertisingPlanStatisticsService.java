package com.zjb.project.dsp.advertisingplanstatistics.service;

import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.project.dsp.advertisingplanstatistics.domain.AdvertisingPlanStatistics;

/**
 * @author songjy
 * @Date 2019/11/25
 **/
public interface IAdvertisingPlanStatisticsService extends IMgBaseService<AdvertisingPlanStatistics> {

    /**
     * 主键字段
     */
    String PRIMARY_KEY_ID = "id";

    /**
     * 保存记录
     *
     * @param record
     */
    void saveRecord(AdvertisingPlanStatistics record);

    /**
     * 根据统计日期和广告计划ID查询记录
     *
     * @param record
     * @return
     */
    AdvertisingPlanStatistics findByStatisticsDateAndPlanId(AdvertisingPlanStatistics record);
}
