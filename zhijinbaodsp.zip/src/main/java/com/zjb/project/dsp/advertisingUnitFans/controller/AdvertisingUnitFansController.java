package com.zjb.project.dsp.advertisingUnitFans.controller;

import com.google.common.collect.Range;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.file.FileUploadUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingType.domain.AdvertisingType;
import com.zjb.project.dsp.advertisingType.service.IAdvertisingTypeService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.service.IWeChatPersonalService;
import com.zjb.project.system.user.domain.User;
import org.apache.ibatis.annotations.Param;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MONTH;

/**
 * 粉丝通广告池 信息操作处理
 *
 * @author shenlong
 * @date 2019-11-22
 */
@Controller
@RequestMapping("/dsp/advertisingUnitFans")
public class AdvertisingUnitFansController extends BaseController {
    private static final Logger logger = LoggerFactory.getLogger(AdvertisingUnitFansController.class);
    private String prefix = "dsp/advertisingUnitFans";

    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IAdvertisingPlanFansService advertisingPlanFansService;
    @Autowired
    private IWeChatPersonalService weChatPersonalService;
    @Autowired
    private IAdvertisingTypeService advertisingTypeService;

    @RequiresPermissions("dsp:advertisingUnitFans:view")
    @GetMapping()
    public String advertisingUnitFans() {
        return prefix + "/advertisingUnitFans";
    }

    /**
     * 查询粉丝通广告池列表
     */
    @RequiresPermissions("dsp:advertisingUnitFans:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingUnitFans advertisingUnitFans) {
        startPage();
        List<AdvertisingUnitFans> list = advertisingUnitFansService.selectAdvertisingUnitFansList(advertisingUnitFans);

        for (AdvertisingUnit unit : list) {
            AdvertisingType advertisingType = advertisingTypeService.selectAdvertisingTypeById(unit.getAdTypeId());
            unit.setAdTypeName(null == advertisingType ? null : advertisingType.getTypeName());
        }

        return getDataTable(list);
    }

    /**
     * 广告图片上传
     */
    @PostMapping("/uploadImg")
    @ResponseBody
    public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {
        try {
            if (!file.isEmpty()) {
                //FileUploadUtils
                String fileKey = zjbConfig.getAdPhotoUrl() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(file.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, file.getInputStream());
                return success(ZjbConstants.File_Domain + "/" + fileKey);
            }
        } catch (Exception e) {
            logger.error("广告图片上传失败！", e);

        }
        return error();
    }

    /**
     * 新增粉丝通广告池
     */
    @GetMapping("/add")
    public String add(ModelMap modelMap) {

        AdvertisingType query = new AdvertisingType();
        query.setTypeStatus(YES.getValue());
        List<AdvertisingType> advertisingTypes = advertisingTypeService.selectAdvertisingTypeList(query);
        advertisingTypes.removeIf(e -> Range.closed(1, 2).contains(e.getId()));
        modelMap.put("advertisingTypes", advertisingTypes);

        return prefix + "/add";
    }

    /**
     * 新增保存粉丝通广告池
     */
    @RequiresPermissions("dsp:advertisingUnitFans:add")
    @Log(title = "粉丝通广告池", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingUnitFans advertisingUnitFans) {
        advertisingUnitFans.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());

        if (!AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnitFans.getAdSpaceIdentifier())) {
            advertisingUnitFans.setWeChatAccount(null);
            advertisingUnitFans.setWeChatAccountName(null);
        }

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            advertisingUnitFans.setRedirectUrl(advertisingUnitFans.getWeChatAccountName());
            ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(advertisingUnitFans.getAppId());
            if (null == componentAuthorizationInfo) {
                return error("公众号" + advertisingUnitFans.getAppId() + "不存在");
            }
            advertisingUnitFans.setWeChatAccount(componentAuthorizationInfo.getComponentId());
        }

        if (!AD_REDIRECT_WE_CHAT_PERSONAL.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            advertisingUnitFans.setWeChatPersonalId(null);
            advertisingUnitFans.setWeChatPersonalNickName(null);
        } else {
            advertisingUnitFans.setRedirectUrl(advertisingUnitFans.getWeChatPersonalNickName());
        }

        if (!AD_REDIRECT_QQ_PERSONAL.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            advertisingUnitFans.setQqPersonalId(null);
            advertisingUnitFans.setQqPersonalNickName(null);
        } else {
            advertisingUnitFans.setRedirectUrl(advertisingUnitFans.getQqPersonalNickName());
        }

        int r = advertisingUnitFansService.insertAdvertisingUnitFans(advertisingUnitFans);
        if (null != advertisingUnitFans.getAdTypeId()) {
            AdvertisingType advertisingType = new AdvertisingType();
            advertisingType.setId(advertisingUnitFans.getAdTypeId());
            advertisingTypeService.updateAdvertisingType(advertisingType);
        }

        return toAjax(r);
    }

    /**
     * 修改广告池
     */
    @GetMapping("/edit")
    public String edit(ModelMap modelMap) {

        AdvertisingType query = new AdvertisingType();
        query.setTypeStatus(YES.getValue());
        List<AdvertisingType> advertisingTypes = advertisingTypeService.selectAdvertisingTypeList(query);
        advertisingTypes.removeIf(e -> Range.closed(1, 2).contains(e.getId()));
        modelMap.put("advertisingTypes", advertisingTypes);

        return prefix + "/edit";
    }

    /**
     * 获取广告信息
     */
    @PostMapping("/getAdvertisingUnitFans/{id}")
    @ResponseBody
    public AjaxResult getAdvertisingUnitFans(@PathVariable("id") Integer id) {
        AdvertisingUnit advertisingUnit = advertisingUnitFansService.selectAdvertisingUnitFansById(id);
        if (null != advertisingUnit) {
            return success(advertisingUnit);
        }


        return error();
    }

    /**
     * 修改粉丝通广告池
     */
    @PostMapping("/namelist")
    @ResponseBody
    public List<ComponentAuthorizationInfo> nameList(String nickName) {
        return componentAuthorizationInfoService.selectComponentAuthorizationInfoByName(nickName);
    }

    /**
     * 修改保存粉丝通广告池
     */
    @RequiresPermissions("dsp:advertisingUnitFans:edit")
    @Log(title = "粉丝通广告池", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingUnitFans advertisingUnitFans) {

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(advertisingUnitFans.getAppId());
            if (null == componentAuthorizationInfo) {
                return error("公众号" + advertisingUnitFans.getAppId() + "不存在");
            }
            advertisingUnitFans.setWeChatAccount(componentAuthorizationInfo.getComponentId());
        }

        if (weChatOfficialAccountIsStop(advertisingUnitFans)) {
            return error("该取纸广告中配置的公众号已停用，如需启用请先至公众号开放平台将对应公众号改为生效状态。");
        }

        if (weChatPersonalAccountIsStop(advertisingUnitFans)) {
            return error("该取纸广告中配置的微信个人号已停用，如需启用请先至微信个人号池将对应个人号改为生效状态。");
        }

        if (!AD_REDIRECT_WE_CHAT_PERSONAL.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            advertisingUnitFans.setWeChatPersonalId(null);
            advertisingUnitFans.setWeChatPersonalNickName(null);
        } else {
            advertisingUnitFans.setRedirectUrl(advertisingUnitFans.getWeChatPersonalNickName());
        }

        if (!AD_REDIRECT_QQ_PERSONAL.getValue().equals(advertisingUnitFans.getRedirectUrlType())) {
            advertisingUnitFans.setQqPersonalId(null);
            advertisingUnitFans.setQqPersonalNickName(null);
        } else {
            advertisingUnitFans.setRedirectUrl(advertisingUnitFans.getQqPersonalNickName());
        }

        User user = getUser();
        advertisingUnitFans.setModifierId(null == user ? null : user.getUserId().intValue());
        advertisingUnitFans.setGmtModified(new Date());
        int r = advertisingUnitFansService.updateAdvertisingUnitFans(advertisingUnitFans);

        restartAdvertisingPlanFans(advertisingUnitFans);
        restartAdvertisingPlanFansWithWeChatPersonal(advertisingUnitFans);
        restartAdvertisingPlanFansWithQQPersonal(advertisingUnitFans);

        stopAdvertisingPlanFans(advertisingUnitFans);

        advertisingPlanFansService.mediumSellRuleThreeNotice();

        updateAdvertisingType(advertisingUnitFans);

        return toAjax(r);
    }

    /**
     * 已配置广告数量
     *
     * @param advertisingUnitFans
     */
    private void updateAdvertisingType(AdvertisingUnitFans advertisingUnitFans) {
        AdvertisingUnitFans old = advertisingUnitFansService.selectAdvertisingUnitFansById(advertisingUnitFans.getId());

        if (null != old.getAdTypeId()) {
            AdvertisingType advertisingType = new AdvertisingType();
            advertisingType.setId(old.getAdTypeId());
            advertisingTypeService.updateAdvertisingType(advertisingType);
        }

        if (null != advertisingUnitFans.getAdTypeId()) {
            AdvertisingType advertisingType = new AdvertisingType();
            advertisingType.setId(advertisingUnitFans.getAdTypeId());
            advertisingTypeService.updateAdvertisingType(advertisingType);
        }
    }

    /**
     * 取纸广告停用暂停对应的广告计划
     *
     * @param advertisingUnit
     */
    private void stopAdvertisingPlanFans(AdvertisingUnitFans advertisingUnit) {
        if (null == advertisingUnit
                || null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(AD_USE_NO.getValue())) {
            return;
        }

        if (!AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())) {
            return;
        }

        List<AdvertisingPlanFans> planList = advertisingPlanFansService.selectByUnitId(advertisingUnit.getId());

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlanFans advertisingPlan : planList) {

            String key = AD_PLAN_ID_PREFIX + '_' + advertisingPlan.getPlanId();
            AdvertisingPlanFans planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlanFans.class);
            planFromRedis.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);
            logger.warn("广告单元{}手动停用，对应广告计划{}自动停用", advertisingUnit.getAdName(), planFromRedis.getPlanId());
            advertisingPlanService.clearLocalCacheRegex(advertisingPlan.getPlanId());
        }

    }

    /**
     * 广告取纸位关联的公众号是否已停止
     *
     * @param advertisingUnit
     * @return true 非生效中
     */
    private boolean weChatOfficialAccountIsStop(AdvertisingUnitFans advertisingUnit) {

        if (null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(AD_USE_YES.getValue())
                || !AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                || !AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())) {
            return false;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(advertisingUnit.getAppId());

        if (null == componentAuthorizationInfo || null == componentAuthorizationInfo.getDeliveryStatus()) {
            return false;
        }

        if (!componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue())) {
            logger.warn("公众号【{}】状态：{}", componentAuthorizationInfo.getNickName(), componentAuthorizationInfo.getDeliveryStatus());
            return true;
        }

        return false;
    }

    /**
     * 广告取纸位关联的微信个人号是否已停止
     *
     * @param advertisingUnit
     * @return true 非生效中
     */
    private boolean weChatPersonalAccountIsStop(AdvertisingUnitFans advertisingUnit) {

        if (null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(AD_USE_YES.getValue())
                || !AD_FANS_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                || !AD_REDIRECT_WE_CHAT_PERSONAL.getValue().equals(advertisingUnit.getRedirectUrlType())) {
            return false;
        }

        WeChatPersonal weChatPersonal = weChatPersonalService.selectByPersonalId(advertisingUnit.getWeChatPersonalId());

        if (null == weChatPersonal || null == weChatPersonal.getDeliveryStatus()) {
            return false;
        }

        if (!weChatPersonal.getDeliveryStatus().equals(WE_CHAT_PERSONAL_DELIVERY_RUN.getValue())) {
            logger.warn("微信个人号【{}】状态：{}", weChatPersonal.getNickName(), weChatPersonal.getDeliveryStatus());
            return true;
        }

        return false;
    }

    /**
     * 删除粉丝通广告池
     */
    @RequiresPermissions("dsp:advertisingUnitFans:remove")
    @Log(title = "粉丝通广告池", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingUnitFansService.deleteAdvertisingUnitFansByIds(ids));
    }

    /**
     * 获取粉丝通广告池列表信息
     *
     * @param advertisingUnit
     * @return
     */
    @PostMapping("/getAdvertisingUnitFansList")
    @ResponseBody
    public List<AdvertisingUnitFans> getAdvertisingUnitFansList(AdvertisingUnitFans advertisingUnit) {
        List<AdvertisingUnitFans> advertisingUnitFansList = new ArrayList<>();
        if(StringUtils.isEmpty(advertisingUnit.getAdSpaceIdentifier())){
            return advertisingUnitFansList;
        }
        advertisingUnit.setAdSpaceIdentifier(advertisingUnit.getAdSpaceIdentifier());
        advertisingUnit.setAdUseStatus(AD_USE_YES.getValue());
        advertisingUnit.setRedirectUrlType(ZjbDictionaryEnum.AD_REDIRECT_H5.getValue());
        return advertisingUnitFansService.selectAdvertisingUnitFansList(advertisingUnit);
    }

    /**
     * 获取公众号关注后推送消息
     * @param appId appid
     * @return gzh_subscribe_msg
     * */
    @GetMapping("/getGzhSubscribeMsg")
    @ResponseBody
    public String getSubMsg(String appId){
        if (StringUtils.isBlank(appId)){
            return null;
        }
        return advertisingUnitFansService.getSubMsg(appId);
    }

}
