package com.zjb.project.dsp.advertisingTargetInfo.service;

import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.*;

import java.util.Date;
import java.util.List;

/**
 * @author songjy
 * @date 2019/08/07
 */
public interface IAdvertisingTargetInfoService extends IMgBaseService<AdvertisingTargetInfo> {

    /**
     * 主键字段
     */
    String PRIMARY_KEY_ID = "id";

    /**
     * 分页查询
     *
     * @param advertisingTargetInfo
     * @return
     */
    List<AdvertisingTargetInfo> selectAdvertisingTargetInfoList(AdvertisingTargetInfo advertisingTargetInfo);

    /**
     * 按照设备维度统计广告出纸次数
     *
     * @param startAdRequestDate 开始扫码日期
     * @param endAdRequestDate   截至扫码日期
     * @param adWinPlanIds       胜出广告计划集合
     * @return
     */
    @Deprecated
    List<StatisticsDeviceAdPlan> findGroupByDeviceSnAndPlanId(Date startAdRequestDate, Date endAdRequestDate, List<String> adWinPlanIds);

    /**
     * 重度及轻度用户数
     *
     * @param loyalUser 统计日期
     * @return
     */
    StatisticsLoyalUser loyalUsersCount(StatisticsLoyalUser loyalUser);

    /**
     * 数据需求：城市量级分布（时间维度选取11月1日日-11月7日，按省、市、区统计每日微信端的出纸数与出纸人数）
     *
     * @param startAdRequestDate
     * @param endAdRequestDate
     * @return
     */
    List<StatisticsAreaInfo> statisticsAreaInfo(Date startAdRequestDate, Date endAdRequestDate);

    /**
     * 广告计划UV数量统计
     *
     * @param startAdRequestDate yyyy-MM-dd
     * @param endAdRequestDate   yyyy-MM-dd
     * @return
     */
    List<StatisticsCommon> statisticsPlanUniqueVisitor(Date startAdRequestDate, Date endAdRequestDate);

    /**
     * 广告成功出纸次数
     *
     * @param startAdRequestDate yyyy-MM-dd
     * @param endAdRequestDate   yyyy-MM-dd
     * @return
     */
    List<StatisticsCommon> statisticsSuccessOutPaper(Date startAdRequestDate, Date endAdRequestDate);

    /**
     * 广告计划请求出纸次数：不含付费/小树叶出纸
     *
     * @param startAdRequestDate yyyy-MM-dd
     * @param endAdRequestDate   yyyy-MM-dd
     * @return
     */
    List<StatisticsCommon> statisticsCountOutPaper(Date startAdRequestDate, Date endAdRequestDate);


    /**
     * 扫码用户数统计
     *
     * @param start
     * @param end
     * @return
     */
    StatisticsCommon countUsers(Date start, Date end);

    /**
     * 数据需求：拉取最近一周目前支付宝端仍有用户进入访问的设备，及对应的代理商、场景、省、市、区、访问UV、PV（仅拉取数据即可，无需做成功能）
     *
     * @param start
     * @param end
     * @param scanTool
     * @return
     */
    List<StatisticsDevicePvUv> statisticsDevicePvUv(Date start, Date end, Integer scanTool);

    /**
     * 广告计划胜出次数
     *
     * @param start
     * @param end
     * @return
     */
    List<StatisticsCommon> statisticsAdWinCount(Date start, Date end);
}
