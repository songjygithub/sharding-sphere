package com.zjb.project.dsp.forbidPutPersonalAccountConfig.service;

import static com.zjb.common.constant.AdvertisingConstants.KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD;
import static com.zjb.common.constant.AdvertisingConstants.KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE;
import static com.zjb.common.enums.ZjbDictionaryEnum.FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_STATUS_HAND_STOP;
import static com.zjb.framework.config.RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.domain.ForbidPutPersonalAccountConfig;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.mapper.ForbidPutPersonalAccountConfigMapper;

import cn.hutool.core.collection.ConcurrentHashSet;

/**
 * 指定次数禁投个人号广告配置 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-04-22
 */
@Service
public class ForbidPutPersonalAccountConfigServiceImpl implements IForbidPutPersonalAccountConfigService, InitializingBean
{
	private static final Logger logger = LoggerFactory.getLogger(ForbidPutPersonalAccountConfigServiceImpl.class);
	@Autowired
	private ForbidPutPersonalAccountConfigMapper forbidPutPersonalAccountConfigMapper;

	/**
	 * 个人号次数屏蔽对应的设备SN：key=取纸次数  value=设备SN集合
	 */
	private static final Map<Integer, Set<String>> PERSONAL_TIMES_MAP_DEVICE_SN = new ConcurrentHashMap<>();

	/**
	 * 个人号不限次数屏蔽的设备
	 */
	private static final Set<String> PERSONAL_FORBID_ALL_DEVICE_SN = new ConcurrentHashSet<>();

	@Override
	public void afterPropertiesSet() throws Exception {

		/*初始化屏蔽公众号正则数据*/
		AsyncManager.me().execute(new TimerTask() {
			@Override
			public void run() {
				List<ForbidPutPersonalAccountConfig> list = forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigList(new ForbidPutPersonalAccountConfig());
				if (null == list || list.isEmpty()) {
					return;
				}

				for (ForbidPutPersonalAccountConfig config : list) {
					config.setTakePaperTimes(StringUtils.defaultString(config.getTakePaperTimes()));
					addPattern(config);
				}
			}
		});

	}

	@Override
	public boolean matcher(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo) {

		if (PERSONAL_FORBID_ALL_DEVICE_SN.contains(deviceInfo.getDeviceSn())) {
			return true;
		}

		Set<String> set = PERSONAL_TIMES_MAP_DEVICE_SN.get(peopleInfo.getTodayPaperNum());

		if (null != set && set.contains(deviceInfo.getDeviceSn())) {
			return true;
		}

		return false;
	}

	@Override
	public boolean effective(ForbidPutPersonalAccountConfig config) {

		if (null == config || null == config.getConfigId()) {
			logger.error("个人号屏蔽记录主键缺失");
			return false;
		}

		if (StringUtils.isAnyBlank(config.getDeviceSn())) {
			logger.error("个人号屏蔽记录{}缺失设备SN", config.getConfigId());
			return false;
		}

		if (null == config.getLoseEfficacyTime() || null == config.getEffectiveTime()) {
			logger.error("个人号屏蔽记录主键{}缺失生效时间||失效时间", config.getConfigId());
			return false;
		}

		if (config.getLoseEfficacyTime().before(new Date())) {
			logger.info("个人号屏蔽记录主键{}已过失效时间", config.getConfigId());
			return false;
		}

		if (config.getEffectiveTime().after(new Date())) {
			logger.info("个人号屏蔽记录主键{}生效时间未到", config.getConfigId());
			return false;
		}

		if (null != config.getConfigStatus()
				&& config.getConfigStatus().equals(FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_STATUS_HAND_STOP.getValue())) {
			logger.info("个人号屏蔽记录主键{}手动停止", config.getConfigId());
			return false;
		}

		return true;
	}

	@Override
	public void addPattern(ForbidPutPersonalAccountConfig config) {

		if (!effective(config)) {
			return;
		}

		if (StringUtils.isBlank(config.getTakePaperTimes())) {
			PERSONAL_FORBID_ALL_DEVICE_SN.add(config.getDeviceSn());
		} else {
			String[] array = StringUtils.split(config.getTakePaperTimes(), ',');

			for (String times : array) {
				Integer key = Integer.parseInt(times);
				Set<String> set = PERSONAL_TIMES_MAP_DEVICE_SN.computeIfAbsent(key, k -> new HashSet<>());
				set.add(config.getDeviceSn());
			}
		}
	}

	@Override
	public void removePattern(ForbidPutPersonalAccountConfig config) {
		if (null == config.getConfigId()) {
			logger.error("缺失主键");
			return;
		}

		if (StringUtils.isBlank(config.getTakePaperTimes())) {
			PERSONAL_FORBID_ALL_DEVICE_SN.remove(config.getDeviceSn());
		} else {
			String[] array = StringUtils.split(config.getTakePaperTimes(), ',');

			for (String times : array) {
				Integer key = Integer.parseInt(times);
				Set<String> set = PERSONAL_TIMES_MAP_DEVICE_SN.get(key);

				if (null == set || set.isEmpty()) {
					continue;
				}

				set.remove(config.getDeviceSn());

			}
		}

	}

	/**
     * 查询指定次数禁投个人号广告配置信息
     * 
     * @param configId 指定次数禁投个人号广告配置ID
     * @return 指定次数禁投个人号广告配置信息
     */
    @Override
	public ForbidPutPersonalAccountConfig selectForbidPutPersonalAccountConfigById(Integer configId)
	{
	    return forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigById(configId);
	}
	
	/**
     * 查询指定次数禁投个人号广告配置列表
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 指定次数禁投个人号广告配置集合
     */
	@Override
	public List<ForbidPutPersonalAccountConfig> selectForbidPutPersonalAccountConfigList(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig)
	{
	    return forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigList(forbidPutPersonalAccountConfig);
	}
	
    /**
     * 新增指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	@Override
	public int insertForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig)
	{
	    int r = forbidPutPersonalAccountConfigMapper.insertForbidPutPersonalAccountConfig(forbidPutPersonalAccountConfig);
		if (r > 0) {
			Map<String, ForbidPutPersonalAccountConfig> map = new HashMap<>(6);
			map.put(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD, forbidPutPersonalAccountConfig);
			JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
		}
		return r;
	}
	
	/**
     * 修改指定次数禁投个人号广告配置
     * 
     * @param forbidPutPersonalAccountConfig 指定次数禁投个人号广告配置信息
     * @return 结果
     */
	@Override
	public int updateForbidPutPersonalAccountConfig(ForbidPutPersonalAccountConfig forbidPutPersonalAccountConfig)
	{
		ForbidPutPersonalAccountConfig old = forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigById(forbidPutPersonalAccountConfig.getConfigId());
		if(null == old){
			return 0;
		}
	    int r = forbidPutPersonalAccountConfigMapper.updateForbidPutPersonalAccountConfig(forbidPutPersonalAccountConfig);
		if (r > 0) {
			ForbidPutPersonalAccountConfig newConfig = forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigById(forbidPutPersonalAccountConfig.getConfigId());
			Map<String, ForbidPutPersonalAccountConfig> map = new HashMap<>(6);
			map.put(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE, old);
			map.put(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD, newConfig);
			JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
		}

		return r;
	}

	/**
     * 删除指定次数禁投个人号广告配置对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteForbidPutPersonalAccountConfigByIds(String ids)
	{
		String[] arr = StringUtils.split(ids, ',');

		for (String id : arr) {
			ForbidPutPersonalAccountConfig config = forbidPutPersonalAccountConfigMapper.selectForbidPutPersonalAccountConfigById(Integer.parseInt(id));
			if (null == config) {
				continue;
			}
			Map<String, ForbidPutPersonalAccountConfig> map = new HashMap<>(6);
			map.put(KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE, config);
			JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
		}

		return forbidPutPersonalAccountConfigMapper.deleteForbidPutPersonalAccountConfigByIds(Convert.toStrArray(ids));
	}

	/**
	 * 查询自动失效记录
	 * @return
	 */
	@Override
	public List<ForbidPutPersonalAccountConfig> selectAutomaticInvalid() {
		return forbidPutPersonalAccountConfigMapper.selectAutomaticInvalid();
	}

	/**
	 * 获取配置状态为空的配置信息
	 * @return
	 */
	@Override
	public List<ForbidPutPersonalAccountConfig> getForbidPutPersonalAccountListWithoutStatus() {
		return forbidPutPersonalAccountConfigMapper.getForbidPutPersonalAccountListWithoutStatus();
	}

}
