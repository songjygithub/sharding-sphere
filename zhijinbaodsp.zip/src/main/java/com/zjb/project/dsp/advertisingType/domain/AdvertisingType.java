package com.zjb.project.dsp.advertisingType.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 广告类型表 zjb_advertising_type
 *
 * @author songjy
 * @date 2020-03-24
 */
public class AdvertisingType extends BaseEntity {
	private static final long serialVersionUID = 6396418942103464636L;

	/**
     * 自增主键
     */
    private Integer id;
    /**
     * 广告类型名称
     */
    private String typeName;
    /**
     * 广告类型描述
     */
    private String typeDesc;

    /**
     * 已配置广告数量
     */
    private Integer countAdConfig;

    /**
     * 使用状态,0：停用 1：启用
     */
    private Integer typeStatus;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeDesc(String typeDesc) {
        this.typeDesc = typeDesc;
    }

    public String getTypeDesc() {
        return typeDesc;
    }

    public Integer getCountAdConfig() {
        return countAdConfig;
    }

    public void setCountAdConfig(Integer countAdConfig) {
        this.countAdConfig = countAdConfig;
    }

    public void setTypeStatus(Integer typeStatus) {
        this.typeStatus = typeStatus;
    }

    public Integer getTypeStatus() {
        return typeStatus;
    }
}
