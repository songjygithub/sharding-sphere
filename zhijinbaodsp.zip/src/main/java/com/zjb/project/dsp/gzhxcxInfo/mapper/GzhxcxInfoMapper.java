package com.zjb.project.dsp.gzhxcxInfo.mapper;


import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;

import java.util.List;

/**
 * 公众号小程序 数据层
 * 
 * @author zjb
 * @date 2018-09-14
 */
public interface GzhxcxInfoMapper 
{
	/**
     * 查询公众号小程序信息
     * 
     * @param id 公众号小程序ID
     * @return 公众号小程序信息
     */
	public GzhxcxInfo selectGzhxcxInfoById(Integer id);
	
	/**
     * 查询公众号小程序列表
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 公众号小程序集合
     */
	public List<GzhxcxInfo> selectGzhxcxInfoList(GzhxcxInfo gzhxcxInfo);
	
	/**
     * 新增公众号小程序
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 结果
     */
	public int insertGzhxcxInfo(GzhxcxInfo gzhxcxInfo);
	
	/**
     * 修改公众号小程序
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 结果
     */
	public int updateGzhxcxInfo(GzhxcxInfo gzhxcxInfo);
	
	/**
     * 删除公众号小程序
     * 
     * @param id 公众号小程序ID
     * @return 结果
     */
	public int deleteGzhxcxInfoById(Integer id);
	
	/**
     * 批量删除公众号小程序
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhxcxInfoByIds(String[] ids);
	
}