package com.zjb.project.dsp.appidOpenidIndex.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * openid和appid关系表 zjb_appid_openid_index
 *
 * @author songjy
 * @date 2019-11-01
 */
public class AppIdOpenIdIndex extends BaseEntity {
    private static final long serialVersionUID = -1465199555297948587L;
    /**
     * 主键
     */
    private Integer id;
    /**
     * 用户微信unionid
     */
    private String zjbOpenid;
    /**
     * 用户openid
     */
    private String openid;
    /**
     * 公众号appid
     */
    private String appid;
    /**
     * 用户昵称
     */
    private String nickName;
    /**
     * 性别 0:未知,1:男,2:女
     */
    private Integer sex;
    /**
     * 头像地址
     */
    private String headImgUrl;
    /**
     * 国家
     */
    private String country;
    /**
     * 省份
     */
    private String province;
    /**
     * 城市
     */
    private String city;

    /**
     * 事件，subscribe：关注订阅  unsubscribe：取消关注订阅
     */
    private String event;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setZjbOpenid(String zjbOpenid) {
        this.zjbOpenid = zjbOpenid;
    }

    public String getZjbOpenid() {
        return zjbOpenid;
    }

    public void setOpenid(String openid) {
        this.openid = openid;
    }

    public String getOpenid() {
        return openid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getAppid() {
        return appid;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getNickName() {
        return nickName;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Integer getSex() {
        return sex;
    }

    public void setHeadImgUrl(String headImgUrl) {
        this.headImgUrl = headImgUrl;
    }

    public String getHeadImgUrl() {
        return headImgUrl;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getCountry() {
        return country;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public String getProvince() {
        return province;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCity() {
        return city;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }
}
