package com.zjb.project.dsp.advertisingUnit.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.mapper.AdvertisingPlanMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.mapper.ScanTaskMapper;
import org.apache.commons.lang3.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisingUnit.mapper.AdvertisingUnitMapper;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.common.support.Convert;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT;
import static com.zjb.common.enums.ZjbDictionaryEnum.NO;

/**
 * 广告池-支付宝 服务层实现
 *
 * @author zjb
 * @date 2019-07-12
 */
@Service
public class AdvertisingUnitServiceImpl implements IAdvertisingUnitService {
    @Autowired
    private AdvertisingUnitMapper advertisingUnitMapper;
    @Autowired
    private AdvertisingPlanMapper advertisingPlanMapper;
    @Autowired
    private GzhGroupMapper gzhGroupMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private ScanTaskMapper scanTaskMapper;

    /**
     * 查询广告池信息
     *
     * @param id 广告池ID
     * @return 广告池信息
     */
    @Override
    public AdvertisingUnit selectAdvertisingUnitById(Integer id) {
        return advertisingUnitMapper.selectAdvertisingUnitById(id);
    }

    /**
     * 查询广告池信息
     *
     * @param ids 广告池ids
     * @return 广告池集
     */
    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitByIds(String ids) {
        return advertisingUnitMapper.selectAdvertisingUnitByIds(Convert.toStrArray(ids));
    }

    /**
     * 获取所有未删除的广告
     *
     * @return
     */
    @Override
    public List<AdvertisingUnit> selectAdvertisingUnit() {
        return advertisingUnitMapper.selectAdvertisingUnit();
    }

    /**
     * 查询广告池列表
     *
     * @param advertisingUnit 广告池信息
     * @return 广告池集合
     */
    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitList(AdvertisingUnit advertisingUnit) {
        return advertisingUnitMapper.selectAdvertisingUnitList(advertisingUnit);
    }

    /**
     * 新增广告池
     *
     * @param advertisingUnit 广告池信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingUnit(AdvertisingUnit advertisingUnit) {

        int r = advertisingUnitMapper.insertAdvertisingUnit(advertisingUnit);

        if (r > 0) {
            advertisingUnit.setAdId(ZjbDictionaryEnum.AD_COMBINATION_UNIT_PREFIX.getValue().toString() + advertisingUnit.getId());
            r += advertisingUnitMapper.updateAdvertisingUnit(advertisingUnit);
        }

        return r;
    }

    /**
     * 修改广告池
     *
     * @param advertisingUnit 广告池信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingUnit(AdvertisingUnit advertisingUnit) {
        return advertisingUnitMapper.updateAdvertisingUnit(advertisingUnit);
    }

    /**
     * 删除广告池对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingUnitByIds(String ids) {
        return advertisingUnitMapper.deleteAdvertisingUnitByIds(Convert.toStrArray(ids));
    }

    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitListByCombinationId(Integer combinationId) {
        return advertisingUnitMapper.selectAdvertisingUnitListByCombinationId(combinationId);
    }

    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitListByPlanId(Integer planId) {
        AdvertisingPlan plan = advertisingPlanMapper.selectAdvertisingPlanById(planId);

        if (null == plan) {
            return Collections.emptyList();
        }

        return advertisingUnitMapper.selectAdvertisingUnitListByCombinationId(plan.getCombinationId());
    }

    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitByTaskId(Integer taskId) {
        if (null == taskId) {
            return Collections.emptyList();
        }

        return advertisingUnitMapper.selectAdvertisingUnitByTaskId(taskId.toString());
    }

    @Override
    public List<AdvertisingUnit> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(weChatOfficialAccount);

        if (null == componentAuthorizationInfo) {
            return Collections.emptyList();
        }

        AdvertisingUnit advertisingUnit = new AdvertisingUnit();
        advertisingUnit.setDeleted(NO.getValue());
        advertisingUnit.setAdSpaceIdentifier(AD_SPACE_PAPER_OUTPUT.getValue());
        advertisingUnit.setWeChatAccount(componentAuthorizationInfo.getComponentId());
        List<AdvertisingUnit> unitList = advertisingUnitMapper.selectAdvertisingUnitList(advertisingUnit);

        List<GzhGroup> gzhGroups = gzhGroupMapper.selectByGzhList(componentAuthorizationInfo.getId().toString());

        if (null == gzhGroups || gzhGroups.isEmpty()) {
            return unitList;
        }

        for (Iterator<GzhGroup> it = gzhGroups.iterator(); it.hasNext(); ) {
            String[] array = StringUtils.split(it.next().getGzhList(), ',');
            if (!ArrayUtils.contains(array, componentAuthorizationInfo.getId().toString())) {
                it.remove();
            }
        }

        if (gzhGroups.isEmpty()) {
            return unitList;
        }

        List<ScanTask> taskList = new ArrayList<>();

        for (GzhGroup gzhGroup : gzhGroups) {
            List<ScanTask> scanTasks = scanTaskMapper.selectByGzhGroupId(gzhGroup.getId().toString());
            if (null != scanTasks && !scanTasks.isEmpty()) {
                taskList.addAll(scanTasks);
            }
        }

        if (taskList.isEmpty()) {
            return unitList;
        }

        if (null == unitList) {
            unitList = new ArrayList<>(taskList.size());
        }

        for (ScanTask task : taskList) {
            List<AdvertisingUnit> units = advertisingUnitMapper.selectAdvertisingUnitByTaskId(task.getId().toString());
            if (null != units && !units.isEmpty()) {
                unitList.addAll(units);
            }
        }

        return unitList;
    }

}
