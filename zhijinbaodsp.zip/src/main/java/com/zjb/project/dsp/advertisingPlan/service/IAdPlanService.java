package com.zjb.project.dsp.advertisingPlan.service;

import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;

import java.util.List;

/**
 * @author songjy
 * @date 2019/08/19
 */
public interface IAdPlanService {

    /**
     * 修改操作
     */
    int OPERATION_TYPE_UPDATE = 1;

    /**
     * 清空本地缓存数据：正则表达式
     *
     * @param planId
     */
    void clearLocalCacheRegex(String planId);

    /**
     * 重新载入指定广告计划进行投放
     *
     * @param planId
     */
    void reloadPattern(String planId);

    /**
     * 保存广告投放定向信息
     *
     * @param advertisingPlan
     */
    int insertTargetingInfo(AdvertisingPlan advertisingPlan);

    /**
     * 修改广告投放定向信息
     *
     * @param advertisingPlan
     * @return
     */
    int updateTargetingInfo(AdvertisingPlan advertisingPlan);

    /**
     * 售卖规则3变动通知
     */
    void mediumSellRuleThreeNotice();

    /**
     * 根据计划ID查询计划信息
     *
     * @param planId 计划ID
     * @return
     */
    AdvertisingPlan findByPlanId(String planId);

    /**
     * 根据微信个人号编号查询广告计划
     *
     * @param weChatPersonalId 微信个人号编号
     * @return 广告计划
     */
    List<AdvertisingPlan> findByWeChatPersonalId(String weChatPersonalId);

    /**
     * 根据QQ个人号编号查询广告计划
     *
     * @param qqPersonalId QQ个人编号
     * @return 广告计划
     */
    List<AdvertisingPlan> findByQQPersonalId(String qqPersonalId);

    /**
     * 根据微信个人号编号重启广告投放计划
     *
     * @param weChatPersonalId 微信个人号编号
     */
    void restartAdvertisingPlanByWeChatPersonalId(String weChatPersonalId);

    /**
     * 根据QQ个人号编号重启广告投放计划
     *
     * @param qqPersonalId QQ个人号编号
     */
    void restartAdvertisingPlanByQQPersonalId(String qqPersonalId);

    /**
     * 本地缓存胜出广告计划
     *
     * @param plan
     */
    void localCacheWinPlan(AdvertisingPlan plan);

    /**
     * 从本地缓存获取胜出广告计划
     * @param planId
     * @return 本地缓存胜出广告计划
     */
    AdvertisingPlan fromLocalCacheWinPlan(String planId);
}
