package com.zjb.project.dsp.agency.service;

import com.zjb.common.constant.Constants;
import com.zjb.project.dsp.agency.domain.Agency;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;

/**
 * 代理商 服务层实现
 *
 * @author songjy
 * @date 2019-07-18
 */
@Service
public class AgencyServiceImpl implements IAgencyService {
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Override
    public Agency findById(Integer id) {
        String sql = "SELECT id, user_nick FROM `zjb_agency` WHERE id = ?";
        Object[] args = {id};
        int[] argTypes = {Types.INTEGER};
        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<Agency>() {
                @Override
                public Agency mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Agency agency = new Agency();
                    agency.setId(rs.getInt("id"));
                    agency.setUserNick(rs.getString("user_nick"));
                    return agency;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    /**
     * 查询代理商列表
     *
     * @param agency 代理商信息
     * @return 代理商集合
     */
    @Override
    public List<Agency> selectAgencyList(Agency agency) {

        String sql = "SELECT id,user_nick FROM zjb_agency WHERE deleted=0 AND parent_agency_id IS NULL";

        return jdbcTemplate.query(sql, new RowMapper<Agency>() {
            @Nullable
            @Override
            public Agency mapRow(ResultSet rs, int rowNum) throws SQLException {
                Agency agency = new Agency();
                agency.setId(rs.getInt("id"));
                agency.setUserNick(rs.getString("user_nick"));

                return agency;
            }
        });

    }

    @Override
    public Agency getMaxCount(Integer id) {
        String sql = "Select id, user_nick, wx_count, zfb_count FROM zjb_agency WHERE id = ? ";
        Object[] args = {id};
        try {
            return jdbcTemplate.queryForObject(sql, args, new RowMapper<Agency>() {
                @Override
                public Agency mapRow(ResultSet rs, int rowNum) throws SQLException {
                    Agency agency = new Agency();

                    agency.setId(rs.getInt("id"));
                    agency.setUserNick(rs.getString("user_nick"));
                    agency.setWxCount(rs.getInt("wx_count"));
                    agency.setZfbCount(rs.getInt("zfb_count"));
                    return agency;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }

    }

}
