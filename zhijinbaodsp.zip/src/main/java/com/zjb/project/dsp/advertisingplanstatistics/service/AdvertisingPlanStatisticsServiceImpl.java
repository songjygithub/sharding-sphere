package com.zjb.project.dsp.advertisingplanstatistics.service;

import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.web.mgservice.BaseMongoDbServiceImpl;
import com.zjb.project.dsp.advertisingplanstatistics.domain.AdvertisingPlanStatistics;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Date;

/**
 * @author songjy
 * @Date 2019/11/25
 **/
@Service
public class AdvertisingPlanStatisticsServiceImpl extends BaseMongoDbServiceImpl<AdvertisingPlanStatistics> implements IAdvertisingPlanStatisticsService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    protected Class<AdvertisingPlanStatistics> getEntityClass() {
        return AdvertisingPlanStatistics.class;
    }

    @Override
    public void saveRecord(AdvertisingPlanStatistics record) {
        record.setId(System.currentTimeMillis());

        LocalDate statisticsDate = DateUtils.toLocalDateTime(record.getStatisticsDate()).toLocalDate();
        record.setStatisticsDate(DateUtils.toDate(statisticsDate));
        record.setGmtCreated(new Date());
        record.setGmtModified(record.getGmtCreated());

        save(record);
    }

    @Override
    public AdvertisingPlanStatistics findByStatisticsDateAndPlanId(AdvertisingPlanStatistics record) {

        if (null == record || null == record.getStatisticsDate() || StringUtils.isBlank(record.getAdPlanId())) {
            logger.error("统计日期||广告计划ID为空");
            return null;
        }

        LocalDate statisticsDate = DateUtils.toLocalDateTime(record.getStatisticsDate()).toLocalDate();
        Criteria criteria = Criteria.where("statisticsDate").is(DateUtils.toDate(statisticsDate))
                .and("adPlanId").is(record.getAdPlanId());

        return mongoTemplate.findOne(Query.query(criteria), AdvertisingPlanStatistics.class);
    }
}
