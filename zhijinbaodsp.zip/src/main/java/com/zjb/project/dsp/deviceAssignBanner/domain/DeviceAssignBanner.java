package com.zjb.project.dsp.deviceAssignBanner.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
import java.util.Date;

/**
 * 定向投放展示广告表 zjb_device_assign_banner
 *
 * @author jiangbingjie
 * @date 2020-02-12
 */
public class DeviceAssignBanner extends BaseEntity
{
	private static final long serialVersionUID = 1L;

	/** 主键 */
	private Integer id;
	/** 设备id */
	private Integer deviceId;
	/** 设备名称 */
	private String deviceName;
	/** 设备SN */
	private String deviceSn;
	/** 代理商id */
	@Excel(name = "mixId")
	private Integer agencyId;
	/** 代理商名称 */
	private String agencyName;
	/** 安装场合 */
	private String installCode;
	/** 业务主键id 格式 “01+id” */
	private String adId;
	/** 广告名称 */
	private String adName;
	/** 创建人员id */
	private Integer createrId;

	/**
	 * 设备SN
	 */
	@Excel(name = "mixId")
	private String mixId;
	/**
	 * 定向投放广告位置
	 * */
	private Integer adPosition;

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getId()
	{
		return id;
	}
	public void setDeviceId(Integer deviceId)
	{
		this.deviceId = deviceId;
	}

	public Integer getDeviceId()
	{
		return deviceId;
	}
	public void setDeviceName(String deviceName)
	{
		this.deviceName = deviceName;
	}

	public String getDeviceName()
	{
		return deviceName;
	}
	public void setDeviceSn(String deviceSn)
	{
		this.deviceSn = deviceSn;
	}

	public String getDeviceSn()
	{
		return deviceSn;
	}
	public void setAgencyId(Integer agencyId)
	{
		this.agencyId = agencyId;
	}

	public Integer getAgencyId()
	{
		return agencyId;
	}
	public void setAgencyName(String agencyName)
	{
		this.agencyName = agencyName;
	}

	public String getAgencyName()
	{
		return agencyName;
	}
	public void setInstallCode(String installCode)
	{
		this.installCode = installCode;
	}

	public String getInstallCode()
	{
		return installCode;
	}
	public void setAdId(String adId)
	{
		this.adId = adId;
	}

	public String getAdId()
	{
		return adId;
	}
	public void setAdName(String adName)
	{
		this.adName = adName;
	}

	public String getAdName()
	{
		return adName;
	}


	public String getMixId() {
		return mixId;
	}

	public void setMixId(String mixId) {
		this.mixId = mixId;
	}

	public Integer getAdPosition() {
		return adPosition;
	}

	public void setAdPosition(Integer adPosition) {
		this.adPosition = adPosition;
	}

	public String toString() {
		return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
				.append("id", getId())
				.append("deviceId", getDeviceId())
				.append("deviceName", getDeviceName())
				.append("deviceSn", getDeviceSn())
				.append("agencyId", getAgencyId())
				.append("agencyName", getAgencyName())
				.append("installCode", getInstallCode())
				.append("adId", getAdId())
				.append("adName", getAdName())
				.append("createrId", getCreaterId())
				.append("modifierId", getModifierId())
				.append("gmtCreated", getGmtCreated())
				.append("gmtModified", getGmtModified())
				.append("deleted", getDeleted())
				.toString();
	}
}
