package com.zjb.project.dsp.agencyWeChatAccountStatistics.service;

import com.zjb.project.dsp.agencyWeChatAccountStatistics.domain.AgencyWeChatAccountStatistics;

import java.util.Date;
import java.util.List;

/**
 * 代理商维度公众号统计 服务层
 *
 * @author songjy
 * @date 2020-01-02
 */
public interface IAgencyWeChatAccountStatisticsService {

    /**
     * 查询代理商维度公众号统计信息
     *
     * @param id 代理商维度公众号统计ID
     * @return 代理商维度公众号统计信息
     */
    AgencyWeChatAccountStatistics selectAgencyWeChatAccountStatisticsById(Long id);

    /**
     * 查询代理商维度公众号统计列表
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 代理商维度公众号统计集合
     */
    List<AgencyWeChatAccountStatistics> selectAgencyWeChatAccountStatisticsList(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 根据指定日期查询代理商维度公众号信息
     *
     * @param statisticsDay 统计日期
     * @return
     */
    List<AgencyWeChatAccountStatistics> selectByStatisticsDay(Date statisticsDay);

    /**
     * 新增代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    int insertAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 修改代理商维度公众号统计
     *
     * @param agencyWeChatAccountStatistics 代理商维度公众号统计信息
     * @return 结果
     */
    int updateAgencyWeChatAccountStatistics(AgencyWeChatAccountStatistics agencyWeChatAccountStatistics);

    /**
     * 删除代理商维度公众号统计信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAgencyWeChatAccountStatisticsByIds(String ids);

    /**
     * 按天统计数据入库
     *
     * @param statisticsDay
     */
    void statisticsDayToDb(Date statisticsDay);

}
