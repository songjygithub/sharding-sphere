package com.zjb.project.dsp.advertisingADExchange.service;

import cn.hutool.core.lang.WeightRandom;
import cn.hutool.core.util.IdUtil;
import cn.hutool.extra.emoji.EmojiUtil;
import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Splitter;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbEnvConstants;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.WeChatUtil;
import com.zjb.common.utils.http.HttpClient;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.common.componentAuthorizationInfo.domain.OpenApiAccountDTO;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import com.zjb.project.dsp.advertisementPlanDevice.service.IAdvertisementPlanDeviceService;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.service.IAdvertisementWithoutBiddingPriceService;
import com.zjb.project.dsp.advertisingADExchange.domain.WechatParameter;
import com.zjb.project.dsp.advertisingADExchange.domain.WithoutBiddingAd;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.service.IAdvertisingCombinationService;
import com.zjb.project.dsp.advertisingCombinationFans.service.IAdvertisingCombinationFansService;
import com.zjb.project.dsp.advertisingCombinationPay.service.IAdvertisingCombinationPayService;
import com.zjb.project.dsp.advertisingCombinationWx.service.IAdvertisingCombinationWxService;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.AdvertisingPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.service.IAdvertisingPlanFansService;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;
import com.zjb.project.dsp.advertisingPlanPay.service.IAdvertisingPlanPayService;
import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;
import com.zjb.project.dsp.advertisingPlanPepole.service.IAdvertisingPlanPepoleService;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.service.IAdvertisingUnitWxService;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserDayRecord;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.appidOpenidIndex.service.IAppidOpenidIndexService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.blackPersonalAccount.domain.BlackPersonalAccount;
import com.zjb.project.dsp.blackPersonalAccount.service.IBlackPersonalAccountService;
import com.zjb.project.dsp.blackThirdPlatformGzh.domain.BlackThirdPlatformGzh;
import com.zjb.project.dsp.blackThirdPlatformGzh.service.IBlackThirdPlatformGzhService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ThirdPlatformData;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ThirdPlatformResponse;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceAssignBanner.domain.DeviceAssignBanner;
import com.zjb.project.dsp.deviceAssignBanner.service.IDeviceAssignBannerService;
import com.zjb.project.dsp.feign.service.IFeignAdminCoreService;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.service.IForbidPutOfficialAccountConfigService;
import com.zjb.project.dsp.forbidPutPersonalAccountConfig.service.IForbidPutPersonalAccountConfigService;
import com.zjb.project.dsp.grhAppidOpenidIndex.domain.GrhAppidOpenidIndex;
import com.zjb.project.dsp.grhAppidOpenidIndex.service.IGrhAppidOpenidIndexService;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.qqPersonal.service.IQqPersonalService;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.service.IScanTaskService;
import com.zjb.project.dsp.smallproceduresUnit.domain.SmallproceduresUnit;
import com.zjb.project.dsp.smallproceduresUnit.service.ISmallproceduresUnitService;
import com.zjb.project.dsp.subscribeUserInfo.domain.SubscribeUserInfo;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;
import com.zjb.project.dsp.weChatPersonal.service.IWeChatPersonalService;
import com.zjb.project.dsp.withoutBiddingAdidOpenidIndex.service.IWithoutBiddingAdidOpenidIndexService;
import com.zjb.project.system.config.service.IConfigService;
import com.zjb.qrcodego.domain.AdCombinationInfo;
import com.zjb.qrcodego.domain.AdUnit;
import com.zjb.qrcodego.domain.CombinationRequest;
import com.zjb.qrcodego.domain.WeChatAccountTaskInfo;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.zjb.common.constant.AdvertisingConstants.*;
import static com.zjb.common.constant.ZjbConstantsRedis.*;
import static com.zjb.common.enums.ZjbConfigEnum.*;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.common.utils.DateUtils.DATETIME_FORMAT;
import static com.zjb.framework.config.JedisPoolCacheUtils.*;
import static com.zjb.framework.config.RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON;
import static com.zjb.framework.web.mgservice.BaseMongoDbServiceImpl.SNOWFLAKE;
import static com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService.PRIMARY_KEY_ID;
import static com.zjb.project.dsp.feign.service.IFeignAdminCoreService.ADMIN_CORE_URL_TASK_INFO;
import static com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService.MEDIUM_SELL_RULES_FILTER_PLAN_ID;
import static com.zjb.project.dsp.userPrintLogWhite.service.IUserPrintLogWhiteService.USER_PRINT_LOG_WHITE;
import static com.zjb.project.system.config.service.IConfigService.GUARANTEE_AD_PLAN_ID;

/**
 * @author songjy
 * @date 2019/07/16
 */
@Service
public class AdExchangeServiceImpl implements IAdExchangeService, InitializingBean {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private static final Logger LOGGER = LoggerFactory.getLogger(AdExchangeServiceImpl.class);

    @Autowired
    private IAdvertisingPlanService advertisingPlanService;
    @Autowired
    private IAdvertisingPlanWxService advertisingPlanWxService;
    @Autowired
    private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
    @Autowired
    private IAdvertisingPlanPepoleService advertisingPlanPepoleService;
    @Autowired
    private ApplicationContext applicationContext;
    @Autowired
    private IAdvertisingCombinationService advertisingCombinationService;
    @Autowired
    private IAdvertisingCombinationWxService advertisingCombinationWxService;
    @Autowired
    private IAdvertisingUnitService advertisingUnitService;
    @Autowired
    private IAdvertisingUnitWxService advertisingUnitWxService;
    @Autowired
    private IConfigService configService;
    @Autowired
    private IScanTaskService sanTaskService;
    @Autowired
    private ISmallproceduresUnitService smallProceduresUnitService;
    @Autowired
    private IAdvertisingTargetInfoService advertisingTargetInfoService;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IAdvertisingPlanPayService advertisingPlanPayService;
    @Autowired
    private IAdvertisingPlanFansService advertisingPlanFansService;
    @Autowired
    private IAdvertisingCombinationPayService advertisingCombinationPayService;
    @Autowired
    private IAdvertisingCombinationFansService advertisingCombinationFansService;
    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    private IDeviceService deviceService;
    @Autowired
    private IAppidOpenidIndexService appIdOpenIdIndexService;
    @Autowired
    private IAgencyService agencyService;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private IDeviceAssignBannerService deviceAssignBannerService;
    @Autowired
    private IForbidPutOfficialAccountConfigService forbidPutOfficialAccountConfigService;
    @Autowired
    private IMediumSellRullService mediumSellRullService;
    @Autowired
    private IWeChatPersonalService weChatPersonalService;
    @Autowired
    private IQqPersonalService qqPersonalService;
    @Autowired
    private IBlackPersonalAccountService blackPersonalAccountService;
    @Autowired
    private IGrhAppidOpenidIndexService grhAppidOpenidIndexService;
    @Autowired
    private IWithoutBiddingAdidOpenidIndexService withoutBiddingAdidOpenidIndexService;
    @Autowired
    private IAdvertisementWithoutBiddingPriceService advertisementWithoutBiddingPriceService;
    @Autowired
    private IBlackThirdPlatformGzhService blackThirdPlatformGzhService;
    @Autowired
    private IForbidPutPersonalAccountConfigService forbidPutPersonalAccountConfigService;
    @Autowired
    private IAdvertisementPlanDeviceService iAdvertisementPlanDeviceService;
    @Autowired
    private IFeignAdminCoreService feignAdminCoreService;
    @Autowired
    private IAdvertisingUserInfoService advertisingUserInfoService;

    /**
     * 保底广告任务ID
     */
    private Set<String> GUARANTEED_TASK_SET = new HashSet<>(Arrays.asList(new String[]{
            "8", AD_PUBLIC_COMBINATION_UNIT.getValue() + "8",
            "12", AD_PUBLIC_COMBINATION_UNIT.getValue() + "12",
            "13", AD_PUBLIC_COMBINATION_UNIT.getValue() + "13",
            "14", AD_PUBLIC_COMBINATION_UNIT.getValue() + "14",
            "17", AD_PUBLIC_COMBINATION_UNIT.getValue() + "17",
            "18", AD_PUBLIC_COMBINATION_UNIT.getValue() + "18",
            "19", AD_PUBLIC_COMBINATION_UNIT.getValue() + "19",
            "26", AD_PUBLIC_COMBINATION_UNIT.getValue() + "26",
            "29", AD_PUBLIC_COMBINATION_UNIT.getValue() + "29",
            "30", AD_PUBLIC_COMBINATION_UNIT.getValue() + "30",
            "31", AD_PUBLIC_COMBINATION_UNIT.getValue() + "31",
            "32", AD_PUBLIC_COMBINATION_UNIT.getValue() + "32"}));

    /**
     * 地址代码格式
     */
    public static final Pattern DEVICE_INSTALL_CODE_UNIT = Pattern.compile("\\d{6}");

    /**
     * 设备定向正则单元组合顺序
     * <p>
     * 0：设备SN
     * 1：性别
     * 2：安装地址编码
     * 3：安装场景
     * 4：代理商ID集合
     * 5：安装场景：学校不允许投放金融类型广告(行业过滤)
     * 6：售卖规则4：支持配置设备的指定次数不出现公众号广告
     * 7：售卖规则4：支持配置代理商的指定次数不出现公众号广告
     * </p>
     */
    public static final int[] ORDER_NUM_DEVICE = {2, 3, 1, 4, 0, 5, 6, 7};

    /**
     * 人群定向正则单元组合顺序
     * <p>
     * 0：性别
     * 1：年龄
     * 2：平台类型
     * 3：扫码环境
     * 4：网络类型
     * 5：运营商
     * 6：黑名单用户
     * 7：当日取纸次数之指定次数
     * 8：公众号定向：关注中的
     * 9：公众号定向：关注过的
     * 10: 用户位置
     * </p>
     */
    private static final int[] ORDER_NUM_PEOPLE = {0, 2, 3, 4, 5, 7, 6, 1, 8, 9, 10};

    /**
     * 设备定向正则单元
     *
     * @param device
     * @return
     */
    public static String[] regexUnits(AdvertisingPlanDevice device) {
        int len = ORDER_NUM_DEVICE.length;
        String[] regexUnits = new String[len];
        List<MediumSellRull> mediumSellRules = IMediumSellRullService.MEDIUM_SELL_RULES;
        /*是否公众号*/
        boolean isWeChatAccount = (null != device.getWeChatAccount() && device.getWeChatAccount().equals(YES.getValue()));
        boolean ruleEmpty = mediumSellRules.isEmpty();
        /*售卖规则1：禁投金融行业	学校场景，禁投金融行业广告*/
        boolean ruleOneExist = (!ruleEmpty && mediumSellRules.stream().filter(e -> e.getRullId().equals(1)).count() == 1);
        /*售卖规则2：禁投公众号广告 该规则配置的设备将自动过滤标记“公众号”标签的广告计划*/
        boolean ruleTwoExist = (!ruleEmpty && mediumSellRules.stream().filter(e -> e.getRullId().equals(2)).count() == 1);
        MediumSellRull sellRuleTwo = ruleTwoExist ? mediumSellRules.stream().filter(e -> e.getRullId().equals(2)).findFirst().get() : null;
        /*售卖规则4：支持配置设备的指定次数不出现公众号广告*/
        boolean ruleTwoFourExist = (!ruleEmpty && mediumSellRules.stream().filter(e -> e.getRullId().equals(4)).count() == 1);
        MediumSellRull sellRuleFour = ruleTwoFourExist ? mediumSellRules.stream().filter(e -> e.getRullId().equals(4)).findFirst().get() : null;

        /*设备SN*/
        int index = 0;
        String[] array = StringUtils.split(device.getDeviceSn(), ',');

        if (null == array || 0 == array.length || null == device.getRadioDeviceSn()
                || AD_RADIO_DEVICE_SN_ALL.getValue().equals(device.getRadioDeviceSn())) {
            regexUnits[index] = ".+";

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getDeviceSn())) {
                String[] excludeDeviceSn = StringUtils.split(sellRuleTwo.getDeviceSn(), ',');
                regexUnits[index] = "(?!" + String.join("|", excludeDeviceSn) + ").+";
            }

        } else if (AD_RADIO_DEVICE_SN_INCLUDE.getValue().equals(device.getRadioDeviceSn())) {
            regexUnits[index] = "(" + String.join("|", array) + ")";

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getDeviceSn())) {
                String[] excludeDeviceSn = StringUtils.split(sellRuleTwo.getDeviceSn(), ',');
                Set<String> set1 = new HashSet<>(Arrays.asList(array));
                Set<String> set2 = new HashSet<>(Arrays.asList(excludeDeviceSn));
                set1.removeAll(set2);
                regexUnits[index] = "(" + String.join("|", set1) + ")";
            }

        } else if (AD_RADIO_DEVICE_SN_EXCLUDE.getValue().equals(device.getRadioDeviceSn())) {
            regexUnits[index] = "(?!" + String.join("|", array) + ").+";

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getDeviceSn())) {
                String[] excludeDeviceSn = StringUtils.split(sellRuleTwo.getDeviceSn(), ',');
                Set<String> set1 = new HashSet<>(Arrays.asList(array));
                Set<String> set2 = new HashSet<>(Arrays.asList(excludeDeviceSn));
                set1.addAll(set2);
                regexUnits[index] = "(?!" + String.join("|", set1) + ").+";
            }
        }

        /*性别*/
        index = 1;
        regexUnits[index] = (null == device.getSex()) ? "\\d+" : (2 == device.getSex()) ? "\\d+" : device.getSex().toString();

        /*安装地址编码*/
        index = 2;
        array = StringUtils.split(device.getDeviceInstallCode(), ',');
        if (null == array || 0 == array.length) {
            regexUnits[index] = "\\d{6}";
        } else if (1 == array.length) {
            regexUnits[index] = regexDeviceInstallCode(device.getDeviceInstallCode());
        } else {
            StringBuffer sb = new StringBuffer();
            for (String codeUnit : array) {
                sb.append(regexDeviceInstallCode(codeUnit)).append('|');
            }
            sb.deleteCharAt(sb.length() - 1);
            regexUnits[index] = sb.insert(0, '(').append(')').toString();
        }

        /*设备安装场合*/
        index = 3;
        array = StringUtils.split(device.getDeviceScene(), ',');
        if (null == array || 0 == array.length || null == device.getRadioDeviceScene()
                || AD_RADIO_DEVICE_SCENE_ALL.getValue().equals(device.getRadioDeviceScene())) {
            regexUnits[index] = ".+";
        } else if (AD_RADIO_DEVICE_SCENE_INCLUDE.getValue().equals(device.getRadioDeviceScene())) {
            regexUnits[index] = '(' + String.join("|", array) + ')';
        } else if (AD_RADIO_DEVICE_SCENE_EXCLUDE.getValue().equals(device.getRadioDeviceScene())) {
            regexUnits[index] = "(?!" + String.join("|", array) + ").+";
        }

        /*代理商ID集合*/
        index = 4;
        array = StringUtils.split(device.getAgencyIdArray(), ',');
        if (null == array || 0 == array.length || null == device.getRadioAgencyId()
                || AD_RADIO_DEVICE_AGENCY_ALL.getValue().equals(device.getRadioAgencyId())) {
            regexUnits[index] = "\\d+";

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getAgencyId())) {
                String[] excludeAgencyId = StringUtils.split(sellRuleTwo.getAgencyId(), ',');
                regexUnits[index] = "(?!" + String.join("|", excludeAgencyId) + ")\\d+";
            }

        } else if (AD_RADIO_DEVICE_AGENCY_INCLUDE.getValue().equals(device.getRadioAgencyId())) {
            regexUnits[index] = '(' + String.join("|", array) + ')';

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getAgencyId())) {
                String[] excludeAgencyId = StringUtils.split(sellRuleTwo.getAgencyId(), ',');
                Set<String> set1 = new HashSet<>(Arrays.asList(array));
                Set<String> set2 = new HashSet<>(Arrays.asList(excludeAgencyId));
                set1.removeAll(set2);
                regexUnits[index] = '(' + String.join("|", set1) + ')';
            }


        } else if (AD_RADIO_DEVICE_AGENCY_EXCLUDE.getValue().equals(device.getRadioAgencyId())) {
            regexUnits[index] = "(?!" + String.join("|", array) + ")\\d+";

            if (isWeChatAccount && null != sellRuleTwo && StringUtils.isNotBlank(sellRuleTwo.getAgencyId())) {
                String[] excludeAgencyId = StringUtils.split(sellRuleTwo.getAgencyId(), ',');
                Set<String> set1 = new HashSet<>(Arrays.asList(array));
                Set<String> set2 = new HashSet<>(Arrays.asList(excludeAgencyId));
                set1.addAll(set2);
                regexUnits[index] = "(?!" + String.join("|", set1) + ")\\d+";
            }
        }

        /*安装场景：学校不允许投放金融类型广告(行业过滤)*/
        index = 5;
        if (null != device.getCategoryFinance() && device.getCategoryFinance().equals(YES.getValue()) && ruleOneExist) {
            String[] sceneSchool = {SCENE_SCHOOL.getValue(), SCENE_UNIVERSITY.getValue(), SCENE_TRAINING_INSTITUTIONS.getValue(),
                    SCENE_MIDDLE_SCHOOL.getValue(), SCENE_ADULT_EDUCATION.getValue(), SCENE_KINDERGARTEN.getValue()};
            regexUnits[index] = "(?!" + String.join("|", sceneSchool) + ").+";
        } else {
            regexUnits[index] = ".+";
        }

        /*售卖规则4：支持配置设备的指定次数不出现公众号广告*/
        index = 6;
        if (isWeChatAccount
                && null != sellRuleFour
                && StringUtils.isNotBlank(sellRuleFour.getTakePaperTimes())
                && StringUtils.isNotBlank(sellRuleFour.getDeviceSn())) {
            List<String> takePaperTimes = Splitter.on(',').omitEmptyStrings().splitToList(sellRuleFour.getTakePaperTimes());
            List<String> deviceSn = Splitter.on(',').omitEmptyStrings().splitToList(sellRuleFour.getDeviceSn());
            StringBuilder sb = new StringBuilder("(?!");

            for (String time : takePaperTimes) {
                for (String sn : deviceSn) {
                    sb.append(time).append('，').append(sn).append('|');
                }
            }
            sb.deleteCharAt(sb.length() - 1);
            sb.append(").+");
            regexUnits[index] = sb.toString();
        } else {
            /*正则单元：用户取纸次数，设备SN*/
            regexUnits[index] = "\\d+，.+";
        }

        /*售卖规则4：支持配置代理商的指定次数不出现公众号广告*/
        index = 7;
        if (isWeChatAccount && null != sellRuleFour
                && StringUtils.isNotBlank(sellRuleFour.getTakePaperTimes())
                && StringUtils.isNotBlank(sellRuleFour.getAgencyId())) {
            List<String> takePaperTimes = Splitter.on(',').omitEmptyStrings().splitToList(sellRuleFour.getTakePaperTimes());
            List<String> agencyIds = Splitter.on(',').omitEmptyStrings().splitToList(sellRuleFour.getAgencyId());
            StringBuilder sb = new StringBuilder("(?!");
            for (String time : takePaperTimes) {
                for (String agencyId : agencyIds) {
                    sb.append(time).append('，').append(agencyId).append('|');
                }
            }

            sb.deleteCharAt(sb.length() - 1);
            sb.append(").+");
            regexUnits[index] = sb.toString();
        } else {
            /*正则单元：当日取纸次数，代理商ID*/
            regexUnits[index] = "\\d+，\\d+";
        }

        return regexUnits;
    }

    public static String regexDeviceInstallCode(String codeUnit) {

        Matcher m = DEVICE_INSTALL_CODE_UNIT.matcher(codeUnit);
        if (!m.matches() || "000000".equals(codeUnit)) {
            return "\\d{6}";
        }

        if (codeUnit.endsWith("0000")) {
            return codeUnit.substring(0, 2) + "\\d{4}";
        }

        if (codeUnit.endsWith("00")) {
            return codeUnit.substring(0, 4) + "\\d{2}";
        }

        return codeUnit;
    }

    public static String regexUserAddress(String addressUnit) {
        if (StringUtils.isEmpty(addressUnit)) {
            return ".*";
        }
        if (addressUnit.contains("_")) {
            String[] addressArray = addressUnit.split("_");
            if (addressArray == null) {
                return ".*";
            }
            if (addressArray.length == 1) {
                String provinceName = addressArray[0];
                if (StringUtils.isNotEmpty(provinceName) && provinceName.length() >= 2) {
                    return provinceName.substring(0, 2) + ".*";
                }
            }
            if (addressArray.length == 2) {
                String provinceName = addressArray[0];
                String cityName = addressArray[1];
                if (StringUtils.isNotEmpty(provinceName) && StringUtils.isNotEmpty(cityName) && provinceName.length() >= 2 && cityName.length() >= 2) {
                    return provinceName.substring(0, 2) + ".*" + cityName.substring(0, 2) + ".*";
                }
            }

        } else {
            if (StringUtils.isNotEmpty(addressUnit) && addressUnit.length() >= 2) {
                return addressUnit.substring(0, 2) + ".*";
            }
        }
        return addressUnit;

    }

    /**
     * 获取定向完整正则
     *
     * @param serializable
     * @return
     */
    public static String getRegex(Serializable serializable) {

        Class<?> clazz = serializable.getClass();
        int[] orderNum;
        String[] regexUnits;

        if (AdvertisingPlanPepole.class == clazz) {
            orderNum = ORDER_NUM_PEOPLE;
            regexUnits = regexUnits((AdvertisingPlanPepole) serializable);
        } else if (AdvertisingPlanDevice.class == clazz) {
            orderNum = ORDER_NUM_DEVICE;
            regexUnits = regexUnits((AdvertisingPlanDevice) serializable);
        } else {
            LOGGER.error("未处理的数据类型：{}", serializable.getClass().getName());
            return ".+";
        }

        StringBuffer sb = new StringBuffer();
        for (int index : orderNum) {
            sb.append(regexUnits[index]).append(',');
        }

        /*删除最后一个,*/
        sb.deleteCharAt(sb.length() - 1);

        return sb.toString();
    }

    public static String deviceInfo(AdvertisingDeviceInfo deviceInfo) {
        Object[] infos = new Object[ORDER_NUM_DEVICE.length];

        infos[0] = null == deviceInfo.getDeviceSn() ? "sn" : deviceInfo.getDeviceSn();
        infos[1] = null == deviceInfo.getFaceSex() ? AD_FACE_SEX_ALL.getValue() : deviceInfo.getFaceSex();
        infos[2] = null == deviceInfo.getInstallAddressCode() ? "000000" : deviceInfo.getInstallAddressCode();
        infos[3] = null == deviceInfo.getDeviceScene() ? "Scene" : deviceInfo.getDeviceScene();
        infos[4] = null == deviceInfo.getAgencyId() ? 0 : deviceInfo.getAgencyId();
        infos[5] = null == deviceInfo.getDeviceScene() ? "Scene" : deviceInfo.getDeviceScene();
        infos[6] = ((null == deviceInfo.getTodayPaperNum()) ? 0 : deviceInfo.getTodayPaperNum()) + "，" + deviceInfo.getDeviceSn();
        infos[7] = ((null == deviceInfo.getTodayPaperNum()) ? 0 : deviceInfo.getTodayPaperNum()) + "，" + deviceInfo.getAgencyId();
        StringBuffer sb = new StringBuffer();
        for (int index : ORDER_NUM_DEVICE) {
            sb.append(infos[index]).append(',');
        }

        /*删除最后一个,*/
        sb.deleteCharAt(sb.length() - 1);

        return sb.toString();
    }

    /**
     * 人群定向正则单元
     *
     * @param people
     * @return
     */
    public static String[] regexUnits(AdvertisingPlanPepole people) {
        String[] regexUnits = new String[ORDER_NUM_PEOPLE.length];

        /*性别*/
        int index = 0;
        regexUnits[index] = (null == people.getSex() || AD_FACE_SEX_ALL.getValue().equals(people.getSex())) ? "\\d+" : people.getSex().toString();
        /*年龄*/
        index = 1;
        regexUnits[index] = "\\d+";
        /*广告投放平台类型*/
        index = 2;
        regexUnits[index] = "\\d+";
        if (null == people.getPlatformType() || AD_PLATFORM_ALL.getValue().equals(people.getPlatformType())) {
            regexUnits[index] = "\\d+";
        } else if (AD_PLATFORM_OTHER.getValue().equals(people.getPlatformType())) {
            regexUnits[index] = "(?!" + String.join("|", AD_PLATFORM_IOS.getValue().toString(), AD_PLATFORM_ANDROID.getValue().toString()) + ")\\d+";
        } else {
            regexUnits[index] = people.getPlatformType().toString();
        }

        /*广告投放扫码环境*/
        index = 3;
        regexUnits[index] = "\\d+";
        if (null == people.getScanTool() || AD_SCAN_TOOL_ALL.getValue().equals(people.getScanTool())) {
            regexUnits[index] = "\\d+";
        } else if (AD_SCAN_TOOL_OTHER.getValue().equals(people.getScanTool())) {
            regexUnits[index] = "(?!" + String.join("|", AD_SCAN_TOOL_WX.getValue().toString(), AD_SCAN_TOOL_ALI_PAY.getValue().toString()) + ")\\d+";
        } else {
            regexUnits[index] = people.getScanTool().toString();
        }

        /*广告投放网络类型*/
        index = 4;
        regexUnits[index] = "\\d+";
        if (null == people.getNetworkType() || AD_NETWORK_ALL.getValue().equals(people.getNetworkType())) {
            regexUnits[index] = "\\d+";
        } else if (AD_NETWORK_OTHER.getValue().equals(people.getNetworkType())) {
            regexUnits[index] = "(?!" + String.join("|", AD_NETWORK_WIFI.getValue().toString(), AD_NETWORK_4G.getValue().toString(), AD_NETWORK_3G.getValue().toString(), AD_NETWORK_2G.getValue().toString()) + ")\\d+";
        } else {
            regexUnits[index] = people.getNetworkType().toString();
        }

        /*运营商*/
        index = 5;
        regexUnits[index] = "\\d+";
        if (null == people.getOperatorType() || AD_OPERATOR_ALL.getValue().equals(people.getOperatorType())) {
            regexUnits[index] = "\\d+";
        } else if (AD_OPERATOR_OTHER.getValue().equals(people.getOperatorType())) {
            regexUnits[index] = "(?!" + String.join("|", AD_OPERATOR_MOBILE.getValue().toString(), AD_OPERATOR_UNICOM.getValue().toString(), AD_OPERATOR_TELECOM.getValue().toString()) + ")\\d+";
        } else {
            regexUnits[index] = people.getOperatorType().toString();
        }

        /*黑名单用户*/
        index = 6;
        if (null == people.getBlackUserEnable() || 0 == people.getBlackUserEnable()) {
            regexUnits[index] = "\\d+";
        } else if (1 == people.getBlackUserEnable()) {
            regexUnits[index] = "0";
        } else {
            regexUnits[index] = "1";
        }
        /*当日取纸次数之指定次数*/
        index = 7;
        String[] array = StringUtils.split(people.getPaperTodayNum(), ',');
        if (null == array || 0 == array.length) {
            regexUnits[index] = "\\d+";
        } else {
            regexUnits[index] = '(' + String.join("|", array) + ')';
        }
        /*用户公众号关注中的不投*/
        index = 8;
        array = StringUtils.split(people.getWeChatOfficialAccounts(), ',');
        if (null == array || 0 == array.length || null == people.getRadioWeChatOfficialAccount()
                || people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue())
                || people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue())) {
            regexUnits[index] = ".+";
        } else if (people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_HISTORY_FOLLOW.getValue())) {
            regexUnits[index] = "((?!" + String.join("|", array) + ").)*";
        }

        /*用户公众号关注过的不投*/
        index = 9;
        if (null == array || 0 == array.length || null == people.getRadioWeChatOfficialAccount()
                || people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_ALL.getValue())
                || people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_HISTORY_FOLLOW.getValue())) {
            regexUnits[index] = ".+";
        } else if (people.getRadioWeChatOfficialAccount().equals(AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT_NEVER_FOLLOW.getValue())) {
            regexUnits[index] = "((?!" + String.join("|", array) + ").)*";
        }

        /*用户位置*/
        index = 10;
        array = StringUtils.split(people.getUserZone(), ',');
        if (null == array || 0 == array.length) {
            regexUnits[index] = ".*";
        } else if (1 == array.length) {
            regexUnits[index] = regexUserAddress(people.getUserZone());
        } else {
            StringBuffer sb = new StringBuffer();
            for (String codeUnit : array) {
                sb.append(regexUserAddress(codeUnit)).append('|');
            }
            sb.deleteCharAt(sb.length() - 1);
            regexUnits[index] = sb.insert(0, '(').append(')').toString();
        }

        return regexUnits;
    }

    public static String peopleInfo(AdvertisingPeopleInfo peopleInfo) {
        Object[] infos = new Object[ORDER_NUM_PEOPLE.length];
        infos[0] = null == peopleInfo.getSex() ? AD_FACE_SEX_ALL.getValue() : peopleInfo.getSex();
        infos[1] = null == peopleInfo.getAge() ? 0 : peopleInfo.getAge();
        infos[2] = null == peopleInfo.getPlatformType() ? AD_PLATFORM_ALL.getValue() : peopleInfo.getPlatformType();
        infos[3] = null == peopleInfo.getScanTool() ? AD_SCAN_TOOL_ALL.getValue() : peopleInfo.getScanTool();
        infos[4] = null == peopleInfo.getNetworkType() ? AD_NETWORK_ALL.getValue() : peopleInfo.getNetworkType();
        infos[5] = null == peopleInfo.getOperatorType() ? AD_OPERATOR_ALL.getValue() : peopleInfo.getOperatorType();
        infos[6] = null == peopleInfo.getBlackUserEnable() ? NO.getValue() : peopleInfo.getBlackUserEnable();
        infos[7] = null == peopleInfo.getTodayPaperNum() ? 0 : peopleInfo.getTodayPaperNum();
        infos[8] = (null == peopleInfo.getWeChatOfficialAccounts() || peopleInfo.getWeChatOfficialAccounts().isEmpty()) ? "N" : String.join("，", peopleInfo.getWeChatOfficialAccounts());
        infos[9] = (null == peopleInfo.getHistoryWeChatOfficialAccounts() || peopleInfo.getHistoryWeChatOfficialAccounts().isEmpty()) ? "N" : String.join("，", peopleInfo.getHistoryWeChatOfficialAccounts());
        StringBuffer address = new StringBuffer();
        if (StringUtils.isNotEmpty(peopleInfo.getProvinceName())) {
            address.append(peopleInfo.getProvinceName());
        }
        if (StringUtils.isNotEmpty(peopleInfo.getCityName())) {
            address.append(peopleInfo.getCityName());
        }
        String userAddress = null;
        if (address.length() > 0) {
            userAddress = address.toString();
        }
        infos[10] = null == userAddress ? "中国" : userAddress;


        StringBuffer sb = new StringBuffer();
        for (int index : ORDER_NUM_PEOPLE) {
            sb.append(infos[index]).append(',');
        }

        /*删除最后一个,*/
        sb.deleteCharAt(sb.length() - 1);

        return sb.toString();

    }

    @Override
    public void afterPropertiesSet() throws Exception {

        List<AdvertisingPlan> list = advertisingPlanService.selectAdvertisingPlanList(new AdvertisingPlan());
        for (AdvertisingPlan plan : list) {
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        List<AdvertisingPlanWx> wxList = advertisingPlanWxService.selectAdvertisingPlanWxList(new AdvertisingPlanWx());
        for (AdvertisingPlanWx plan : wxList) {
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        List<AdvertisingPlanPay> payList = advertisingPlanPayService.selectAdvertisingPlanPayList(new AdvertisingPlanPay());
        for (AdvertisingPlanPay plan : payList) {
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        List<AdvertisingPlanFans> planFans = advertisingPlanFansService.selectAdvertisingPlanFansList(new AdvertisingPlanFans());
        for (AdvertisingPlanFans plan : planFans) {
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        /*消息订阅*/
        redisSubscribe();
    }

    /**
     * 消息订阅
     */
    private void redisSubscribe() {
        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {
                try (Jedis jedis = new Jedis(ZjbEnvConstants.REDIS_HOST, 6379)) {
                    if (StringUtils.isNotBlank(ZjbEnvConstants.REDIS_PASSWORD)) {
                        jedis.auth(ZjbEnvConstants.REDIS_PASSWORD);
                    }

                    String[] channels = {RedisSubscribe.CHANNEL_AD_PATTERN_ADD_DEVICE, RedisSubscribe.CHANNEL_AD_PATTERN_ADD_PEOPLE,
                            RedisSubscribe.CHANNEL_AD_PATTERN_REMOVE_DEVICE, RedisSubscribe.CHANNEL_AD_PATTERN_REMOVE_PEOPLE,
                            RedisSubscribe.CHANNEL_AD_PATTERN_UPDATE_DEVICE, RedisSubscribe.CHANNEL_AD_PATTERN_UPDATE_PEOPLE,
                            RedisSubscribe.CHANNEL_CONFIG_UPDATE, RedisSubscribe.CHANNEL_DSP_LOGS,
                            RedisSubscribe.CHANNEL_ZJB_ADMIN_MQ_INFO, RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON,
                            RedisSubscribe.CHANNEL_ZJB_PL_IOT_INFO};
                    jedis.subscribe(new RedisSubscribe(applicationContext), channels);
                }
            }
        });
    }

    @Override
    public Set<String> matcher(AdvertisingDeviceInfo advertisingDeviceInfo) {

        Set<String> planId = new HashSet<>();
        String deviceInfo = deviceInfo(advertisingDeviceInfo);

        LOGGER.info("设备信息：{}", deviceInfo);

        for (Map.Entry<String, Pattern> entry : advertisingPlanDeviceService.deviceRegexMapPattern().entrySet()) {
            Pattern pattern = entry.getValue();
            Matcher matcher = pattern.matcher(deviceInfo);
            if (matcher.matches()) {
                planId.add(entry.getKey());
            }
        }

        return planId;
    }

    @Override
    public Set<String> matcher(AdvertisingPeopleInfo peopleInfo) {

        Set<String> planId = new HashSet<>(200);
        CharSequence input = peopleInfo(peopleInfo);

        if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            LOGGER.info("人群信息：{}", JSON.toJSONString(peopleInfo));
        }

        for (Map.Entry<String, Pattern> entry : advertisingPlanPepoleService.peopleRegexMapPattern().entrySet()) {
            Pattern pattern = entry.getValue();
            Matcher matcher = pattern.matcher(input);
            if (matcher.matches()) {
                planId.add(entry.getKey());
            }
        }

        return planId;
    }

    @Override
    public Set<String> matcher(AdvertisingDeviceInfo advertisingDeviceInfo, AdvertisingPeopleInfo peopleInfo) {
        long start = System.currentTimeMillis();
        Set<String> planIdMatcherDevice = matcher(advertisingDeviceInfo);
        Set<String> planIdMatcherPeople = matcher(peopleInfo);

        if (!planIdMatcherDevice.isEmpty() && (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId()) || USER_PRINT_LOG_WHITE.isEmpty())) {
            LOGGER.info("扫码流水号{}设备定向匹配广告计划条数：{}，计划ID：{}", peopleInfo.getRandomNum(), planIdMatcherDevice.size(), planIdMatcherDevice);
        }

        if (!planIdMatcherPeople.isEmpty() && (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId()) || USER_PRINT_LOG_WHITE.isEmpty())) {
            LOGGER.info("扫码流水号{}人群定向匹配广告计划条数：{}，计划ID：{}", peopleInfo.getRandomNum(), planIdMatcherPeople.size(), planIdMatcherPeople);
        }

        /*交集*/
        planIdMatcherDevice.retainAll(planIdMatcherPeople);

        if (USER_PRINT_LOG_WHITE.isEmpty() || USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            LOGGER.info("扫码流水号{}人群与设备定向匹配广告计划条数：{}，计划ID：{}", peopleInfo.getRandomNum(), planIdMatcherDevice.size(), planIdMatcherDevice);
            LOGGER.info("正则过滤耗时（毫秒）：{}", System.currentTimeMillis() - start);
        }

        return planIdMatcherDevice;
    }

    @Override
    public List<AdvertisingPlan> filter(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo) {
        long start = System.currentTimeMillis();
        Set<String> planIds = matcher(deviceInfo, peopleInfo);
        long startFilter = System.currentTimeMillis();
        String openId = peopleInfo.getOpenId();

        if (null == planIds || planIds.isEmpty()) {
            return null;
        }

        Date now = new Date();
        List<AdvertisingPlan> list = new ArrayList<>(400);
        List<MediumSellRull> mediumSellRules = IMediumSellRullService.MEDIUM_SELL_RULES;

        /*当日竞价次数：Data-V展示用*/
        incrBy(LocalDate.now() + "_bid_total", planIds.size(), EXRP_DAY, ZJB_DB_50);

        for (String planId : planIds) {
            String key = AD_PLAN_ID_PREFIX + '_' + planId;
            AdvertisingPlan plan = getV(key, ZJB_DB_50, AdvertisingPlan.class);
            if (null == plan) {
                LOGGER.error("扫码流水号{}广告计划ID{}不存在", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*0、是否投放中*/
            if (!AD_PLAN_STATUS_OK.getValue().equals(plan.getAdvertisingStatus())) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】未投放", peopleInfo.getRandomNum(), planId);
                advertisingPlanService.clearLocalCacheRegex(planId);
                continue;
            }

            /*1、总取纸次数过滤*/
            Integer totalPaperNum = peopleInfo.getTotalPaperNum();
            Integer paperUpperNum = plan.getPaperUpperNum();
            Integer paperLowerNum = plan.getPaperLowerNum();

            if (null != totalPaperNum && null != paperLowerNum && totalPaperNum < paperLowerNum) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】未达到总取纸次数下限", peopleInfo.getRandomNum(), planId);
                continue;
            }

            if (null != totalPaperNum && null != paperUpperNum && totalPaperNum > paperUpperNum) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】超过总取纸次数上限", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*2.1、用户当日取纸范围过滤*/
            Integer todayPaperNum = peopleInfo.getTodayPaperNum();
            Integer paperTodayLowerNum = plan.getPaperTodayLowerNum();
            Integer paperTodayUpperNum = plan.getPaperTodayUpperNum();
            if (null != todayPaperNum && null != paperTodayLowerNum && todayPaperNum < paperTodayLowerNum) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】未达到用户当日取纸下限", peopleInfo.getRandomNum(), planId);
                continue;
            }
            if (null != todayPaperNum && null != paperTodayUpperNum && todayPaperNum > paperTodayUpperNum) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】超过用户当日取纸上限", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*3、是否超过日预算*/
            BigDecimal dayBudget = plan.getDayBudget();
            BigDecimal todaySpend = plan.getTodaySpend();
            if (null != dayBudget && null != todaySpend && todaySpend.compareTo(dayBudget) >= 0) {
                /*超过日预算*/
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_DAY.getValue());
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                LOGGER.info("扫码流水号{}广告计划ID【{}】超过日预算", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*4、是否超过总预算*/
            BigDecimal totalBudget = plan.getTotalBudget();
            BigDecimal totalSpend = plan.getTotalSpend();
            if (null != totalBudget && null != totalSpend && totalSpend.compareTo(totalBudget) >= 0) {
                /*超过总预算*/
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_TOTAL.getValue());
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                LOGGER.info("扫码流水号{}广告计划ID【{}】超过总预算", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*5、行业过滤：学校不允许投放金融类型广告*/
            //已优化改为正则过滤

            /*6、投放时间*/
            Date gmtShowStart = plan.getGmtShowStart();
            Date gmtShowEnd = plan.getGmtShowEnd();
            if (null != gmtShowStart && gmtShowStart.after(now)) {
                /*投放未开始*/
                advertisingPlanService.clearLocalCacheRegex(planId);
                LOGGER.info("扫码流水号{}广告计划ID【{}】投放未开始", peopleInfo.getRandomNum(), planId);
                continue;
            }

            if (null != gmtShowEnd && gmtShowEnd.before(now)) {
                /*投放到期*/
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                LOGGER.info("扫码流水号{}广告计划ID【{}】投放到期", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*7、单用户投放频次*/
            Integer adsingleUserFrequency = plan.getAdSingleUserFrequency();
            if (StringUtils.isNotBlank(openId)
                    && AD_SINGLE_USER_ONCE_DAY.getValue().equals(adsingleUserFrequency)
                    && viewedToDay(planId, openId)) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】单用户每日仅投放一次", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*8、每个用户(openId)仅投一次*/
            if (StringUtils.isNotBlank(openId)
                    && AD_SINGLE_USER_ONCE_LIFE.getValue().equals(adsingleUserFrequency)
                    && viewedToLife(planId, openId)) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】单用户仅投放一次", peopleInfo.getRandomNum(), planId);
                continue;
            }

            /*9、公众号日投放量控制*/
            ComponentAuthorizationInfo componentAuthorizationInfo = null;
            if (StringUtils.isNotBlank(plan.getAdAppId())) {
                componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(plan.getAdAppId());
            }

            if (null != componentAuthorizationInfo && null != componentAuthorizationInfo.getDeliveryStatus()
                    && componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STOP_MANUAL.getValue())) {
                LOGGER.info("扫码流水号{}广告计划ID【{}】投放停止，公众号【{}】手动暂停", peopleInfo.getRandomNum(), planId, componentAuthorizationInfo.getNickName());
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_MANUAL.getValue());
                componentAuthorizationInfoService.clearLocalCache(componentAuthorizationInfo);
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                continue;
            }

            if (null != componentAuthorizationInfo
                    && null != componentAuthorizationInfo.getDayDeliveryLimit() && null != componentAuthorizationInfo.getDayFollowAmount()
                    && componentAuthorizationInfo.getDayDeliveryLimit() <= componentAuthorizationInfo.getDayFollowAmount()) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_DAY_LIMIT.getValue());
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                componentAuthorizationInfoService.clearLocalCache(componentAuthorizationInfo);
                componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue());
                componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);
                LOGGER.info("扫码流水号{}广告计划ID【{}】公众号【{}:{}】日投放量不足", peopleInfo.getRandomNum(), planId, componentAuthorizationInfo.getId(), componentAuthorizationInfo.getNickName());
                stopAdvertisingPlan(componentAuthorizationInfo);
                continue;
            }


            /*10、公众号总投放量控制*/
            if (null != componentAuthorizationInfo
                    && null != componentAuthorizationInfo.getTotalDeliveryLimit() && null != componentAuthorizationInfo.getTotalFollowAmount()
                    && componentAuthorizationInfo.getTotalDeliveryLimit() <= componentAuthorizationInfo.getTotalFollowAmount()) {
                plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_APP_TOTAL_LIMIT.getValue());
                setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                advertisingPlanService.clearLocalCacheRegex(planId);
                componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue());
                componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);
                componentAuthorizationInfoService.clearLocalCache(componentAuthorizationInfo);
                LOGGER.info("扫码流水号{}广告计划ID【{}】公众号【{}:{}】总投放量不足", peopleInfo.getRandomNum(), planId, componentAuthorizationInfo.getId(), componentAuthorizationInfo.getNickName());
                stopAdvertisingPlan(componentAuthorizationInfo);
                continue;
            }

            /*11、用户指定次数取纸扫描设备时，过滤标记“公众号”标签的广告计划*/
            if (null != plan.getWeChatAccount() && YES.getValue().equals(plan.getWeChatAccount())) {
                boolean ruleEmpty = mediumSellRules.isEmpty();
                /*售卖规则5：指定次数禁投公众号广告*/
                boolean ruleFiveExist = (!ruleEmpty && mediumSellRules.stream().filter(e -> e.getRullId().equals(5)).count() == 1);
                MediumSellRull sellRuleFive = ruleFiveExist ? mediumSellRules.stream().filter(e -> e.getRullId().equals(5)).findFirst().get() : null;
                if (null != sellRuleFive && (int) RULL_STATUS_EFFECTIV.getValue() == sellRuleFive.getRullStatus() && forbidPutOfficialAccountConfigService.matcher(deviceInfo, peopleInfo)) {
                    LOGGER.info("扫码流水号{}广告计划ID【{}】屏蔽公众号【{}:{}】", peopleInfo.getRandomNum(), planId, deviceInfo.getDeviceSn(), peopleInfo.getTodayPaperNum());
                    continue;
                }
            }

            /*12、参与竞价频次*/
            AdvertisingPlan localCacheWinPlan = advertisingPlanService.fromLocalCacheWinPlan(plan.getPlanId());
            if (null != localCacheWinPlan && null != localCacheWinPlan.getWinFrequency()
                    && null != localCacheWinPlan.getRecentWinTimestamp() && localCacheWinPlan.getWinFrequency() > 0L
                    && (System.currentTimeMillis() - localCacheWinPlan.getRecentWinTimestamp()) <= (localCacheWinPlan.getWinFrequency() * 1000L)) {
                LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】参与竞价频次未到，其最后胜出时间：{}",
                        peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, DATETIME_FORMAT.format(new Date(localCacheWinPlan.getRecentWinTimestamp())));
                continue;
            }

            /*13、微信个人号*/
            if (StringUtils.isNotBlank(plan.getWeChatPersonalId())) {
                AdvertisingUserInfo userInfo = ADVERTISING_USER_INFO_THREAD_LOCAL.get();

                if (null == userInfo) {
                    userInfo = advertisingUserInfoService.findByOpenId(openId);
                    if (null == userInfo) {
                        LOGGER.warn("扫码流水号{}用户{}信息查询失败", peopleInfo.getRandomNum(), openId);
                    } else {
                        ADVERTISING_USER_INFO_THREAD_LOCAL.set(userInfo);
                    }

                }

                WeChatPersonal weChatPersonal = weChatPersonalService.selectByPersonalId(plan.getWeChatPersonalId());

                if (null == weChatPersonal || YES.getValue().equals(weChatPersonal.getDeleted())) {
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}已删除", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    continue;
                }

                if (null != weChatPersonal.getDeliveryStatus() && weChatPersonal.getDeliveryStatus().equals(WE_CHAT_PERSONAL_STOP_MANUAL.getValue())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}手动暂停", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_WE_CHAT_PERSONAL_MANUAL.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    weChatPersonalService.clearLocalCache(weChatPersonal);
                    continue;
                }

                if (null == weChatPersonal.getDeliveryStatus() || !weChatPersonal.getDeliveryStatus().equals(WE_CHAT_PERSONAL_DELIVERY_RUN.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}不生效", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    continue;
                }

                if (null != weChatPersonal.getDayDeliveryLimit() && weChatPersonal.getDayDeliveryLimit() > 0
                        && weChatPersonal.getDayFollowAmount() > 0
                        && weChatPersonal.getDayDeliveryLimit() <= weChatPersonal.getDayFollowAmount()) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}日投放量不足", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_WE_CHAT_PERSONAL_DAY_LIMIT.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    weChatPersonal.setDeliveryStatus(WE_CHAT_PERSONAL_DAY_LIMIT.getValue());
                    weChatPersonalService.updateWeChatPersonal(weChatPersonal);
                    weChatPersonalService.clearLocalCache(weChatPersonal);
                    continue;
                }

                if (null != weChatPersonal.getTotalDeliveryLimit() && weChatPersonal.getTotalDeliveryLimit() > 0
                        && weChatPersonal.getTotalFollowAmount() > 0
                        && weChatPersonal.getTotalDeliveryLimit() <= weChatPersonal.getTotalFollowAmount()) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}总投放量不足", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_WE_CHAT_PERSONAL_TOTAL_LIMIT.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    weChatPersonal.setDeliveryStatus(WE_CHAT_PERSONAL_TOTAL_LIMIT.getValue());
                    weChatPersonalService.updateWeChatPersonal(weChatPersonal);
                    weChatPersonalService.clearLocalCache(weChatPersonal);
                    continue;
                }

                AuthorizationUserInfoDTO authorizationUserInfo = AUTHORIZATION_USER_INFO_THREAD_LOCAL.get();
                if (null == authorizationUserInfo) {
                    authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openId);
                    AUTHORIZATION_USER_INFO_THREAD_LOCAL.set(authorizationUserInfo);
                }

                if (StringUtils.isBlank(authorizationUserInfo.getUserNick()) || !EmojiUtil.toUnicode(authorizationUserInfo.getUserNick()).equals(authorizationUserInfo.getUserNick())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】昵称{}包含Emoji字符", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, authorizationUserInfo.getUserNick());
                    continue;
                }

                if (null != weChatPersonalService.weChatPersonal(authorizationUserInfo.getUserNick())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】昵称{}已胜出", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, authorizationUserInfo.getUserNick());
                    continue;
                }

                WeChatPersonal winWeChatPersonal = weChatPersonalService.weChatPersonal(weChatPersonal.getPersonalId());
                if (null != winWeChatPersonal) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人编号{}已被用户{}在{}时胜出", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId(), winWeChatPersonal.getWinWeChatOpenId(), winWeChatPersonal.getWinDateTime());
                    continue;
                }

                HashMap<Integer, Set<String>> weChatPersonalGroup = (null == userInfo ? null : userInfo.getWeChatPersonalGroup());

                if (null != weChatPersonalGroup && !weChatPersonal.getPersonalGroup().equals(-1)
                        && weChatPersonalGroup.containsKey(weChatPersonal.getPersonalGroup())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}属于组{}且已关注", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId(), weChatPersonal.getPersonalGroup());
                    continue;
                }

                boolean b = null != weChatPersonalGroup && !weChatPersonalGroup.isEmpty();
                Set<String> set = b ? weChatPersonalGroup.get(weChatPersonal.getPersonalGroup()) : null;
                if (null != set && set.contains(plan.getWeChatPersonalId())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}已关注", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    continue;
                }

                if (checkFilterPersonalAccount(plan.getWeChatPersonalId(), peopleInfo.getOpenId())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}已关注或者微信个人号已经进入黑名单", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, weChatPersonal.getPersonalId());
                    continue;
                }

            }

            /*14、QQ个人号*/
            if (StringUtils.isNotBlank(plan.getQqPersonalId())) {
                AdvertisingUserInfo userInfo = ADVERTISING_USER_INFO_THREAD_LOCAL.get();
                QqPersonal qqPersonal = qqPersonalService.selectByPersonalId(plan.getQqPersonalId());

                if (null == qqPersonal || YES.getValue().equals(qqPersonal.getDeleted())) {
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}已删除", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    continue;
                }

                if (null != qqPersonal.getDeliveryStatus() && qqPersonal.getDeliveryStatus().equals(QQ_PERSONAL_STOP_MANUAL.getValue())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}手动暂停", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_QQ_PERSONAL_MANUAL.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    qqPersonalService.clearLocalCache(qqPersonal);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    continue;
                }

                if (null == qqPersonal.getDeliveryStatus() || !qqPersonal.getDeliveryStatus().equals(QQ_PERSONAL_DELIVERY_RUN.getValue())) {
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}不生效", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    continue;
                }

                if (null != qqPersonal.getDayDeliveryLimit() && qqPersonal.getDayDeliveryLimit() > 0
                        && qqPersonal.getDayFollowAmount() > 0
                        && qqPersonal.getDayDeliveryLimit() <= qqPersonal.getDayFollowAmount()) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】微信个人号{}日投放量不足", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_QQ_PERSONAL_DAY_LIMIT.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    qqPersonal.setDeliveryStatus(QQ_PERSONAL_DAY_LIMIT.getValue());
                    qqPersonalService.updateQqPersonal(qqPersonal);
                    qqPersonalService.clearLocalCache(qqPersonal);
                    continue;
                }

                if (null != qqPersonal.getTotalDeliveryLimit() && qqPersonal.getTotalDeliveryLimit() > 0
                        && qqPersonal.getTotalFollowAmount() > 0
                        && qqPersonal.getTotalDeliveryLimit() <= qqPersonal.getTotalFollowAmount()) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}总投放量不足", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    plan.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_QQ_PERSONAL_TOTAL_LIMIT.getValue());
                    setVExpire(key, plan, EXRP_MONTH, ZJB_DB_50);
                    advertisingPlanService.clearLocalCacheRegex(planId);
                    qqPersonal.setDeliveryStatus(QQ_PERSONAL_TOTAL_LIMIT.getValue());
                    qqPersonalService.updateQqPersonal(qqPersonal);
                    qqPersonalService.clearLocalCache(qqPersonal);
                    continue;
                }

                AuthorizationUserInfoDTO authorizationUserInfo = AUTHORIZATION_USER_INFO_THREAD_LOCAL.get();
                if (null == authorizationUserInfo) {
                    authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openId);
                    AUTHORIZATION_USER_INFO_THREAD_LOCAL.set(authorizationUserInfo);
                }

                if (StringUtils.isBlank(authorizationUserInfo.getUserNick()) || !EmojiUtil.toUnicode(authorizationUserInfo.getUserNick()).equals(authorizationUserInfo.getUserNick())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】昵称{}包含Emoji字符", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, authorizationUserInfo.getUserNick());
                    continue;
                }

                if (null != qqPersonalService.qqPersonal(authorizationUserInfo.getUserNick())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】昵称{}已胜出", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, authorizationUserInfo.getUserNick());
                    continue;
                }

                QqPersonal winQqPersonal = qqPersonalService.qqPersonal(qqPersonal.getPersonalId());
                if (null != winQqPersonal) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}已被用户{}在{}时胜出", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId(), winQqPersonal.getWinWeChatOpenId(), winQqPersonal.getWinDateTime());
                    continue;
                }

                HashMap<Integer, Set<String>> qqPersonalGroup = userInfo.getQqPersonalGroup();

                if (null != qqPersonalGroup && !qqPersonal.getPersonalGroup().equals(-1)
                        && qqPersonalGroup.containsKey(qqPersonal.getPersonalGroup())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}属于组{}且已关注", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId(), qqPersonal.getPersonalGroup());
                    continue;
                }

                boolean b = null != qqPersonalGroup && !qqPersonalGroup.isEmpty();
                Set<String> set = b ? qqPersonalGroup.get(qqPersonal.getPersonalGroup()) : null;
                if (null != set && set.contains(plan.getWeChatPersonalId())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}已关注", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    continue;
                }
                if (checkFilterPersonalAccount(plan.getWeChatPersonalId(), peopleInfo.getOpenId())) {
                    LOGGER.info("用户{}扫码流水号{}广告计划ID【{}】QQ个人号{}已关注或者QQ个人号已经进入黑名单", peopleInfo.getOpenId(), peopleInfo.getRandomNum(), planId, qqPersonal.getPersonalId());
                    continue;
                }

            }



            /*15、用户指定次数取纸扫描设备时，过滤标记“个人号”标签的广告计划 */
            if (null != plan.getPersonalAccount() && YES.getValue().equals(plan.getPersonalAccount())) {
                boolean ruleEmpty = mediumSellRules.isEmpty();
                /*售卖规则8：指定次数禁投个人号广告*/
                boolean ruleEightExist = (!ruleEmpty && mediumSellRules.stream().filter(e -> e.getRullId().equals(8)).count() == 1);
                MediumSellRull sellRuleEight = ruleEightExist ? mediumSellRules.stream().filter(e -> e.getRullId().equals(8)).findFirst().get() : null;
                if (null != sellRuleEight && (int) RULL_STATUS_EFFECTIV.getValue() == sellRuleEight.getRullStatus() && forbidPutPersonalAccountConfigService.matcher(deviceInfo, peopleInfo)) {
                    LOGGER.info("扫码流水号{}广告计划ID【{}】屏蔽个人号【{}:{}】", peopleInfo.getRandomNum(), planId, deviceInfo.getDeviceSn(), peopleInfo.getTodayPaperNum());
                    continue;
                }
            }

            /*16、判断该公众号是否在黑名单*/
            if (null != componentAuthorizationInfo && null != componentAuthorizationInfo.getDeliveryStatus()
                    && componentAuthorizationInfo.getDeliveryStatus().equals(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue())) {
                BlackThirdPlatformGzh blackThirdPlatformGzh = new BlackThirdPlatformGzh();
                blackThirdPlatformGzh.setThirdPlatformAppId(plan.getAdAppId());
                blackThirdPlatformGzh.setThirdPlatformChannel(THIRD_PLATFORM_CHANNEL_ZJB.getValue());
                int count = blackThirdPlatformGzhService.getBlackThirdPlatformGzhCount(blackThirdPlatformGzh);
                if (count > 0) {
                    LOGGER.info("扫码流水号{}广告计划ID【{}】，公众号【{}】在黑名单", peopleInfo.getRandomNum(), planId, componentAuthorizationInfo.getNickName());
                    continue;
                }

            }

            plan.setRandomNum(peopleInfo.getRandomNum());
            list.add(plan);
        }

        if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            LOGGER.info("扫码流水号{}过滤后剩余广告计划条数：{}，计划ID：{}", peopleInfo.getRandomNum(), list.size(), list.stream().map(AdvertisingPlan::getPlanId).toArray());
            LOGGER.info("扫码流水号{}过滤广告耗时(毫秒)：{}", peopleInfo.getRandomNum(), System.currentTimeMillis() - start);
            LOGGER.info("扫码流水号{}纯过滤广告耗时(毫秒)：{}", peopleInfo.getRandomNum(), System.currentTimeMillis() - startFilter);
        }

        return list;
    }

    /**
     * 公众号停止之广告投放计划暂停联动事件
     *
     * @param componentAuthorizationInfo
     */
    private void stopAdvertisingPlan(ComponentAuthorizationInfo componentAuthorizationInfo) {

        Map<String, Object> map = new HashMap<>();
        map.put(KEY_APP_ID_STOP_AD_PLAN_EVENT, componentAuthorizationInfo);
        map.put(KEY_SYSTEM_ID, Constants.SYSTEM_ID);
        publish(RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
    }

    /**
     * 该用户是否已查看了指定的广告计划
     *
     * @param planId
     * @param openId
     * @return
     */
    private boolean viewedToLife(String planId, String openId) {

        if (StringUtils.isAnyBlank(planId, openId)) {
            return false;
        }

        //AdvertisingUserInfo userInfo = advertisingUserInfoService.findByOpenId(openId);
        AdvertisingUserInfo userInfo = ADVERTISING_USER_INFO_THREAD_LOCAL.get();
        if (null == userInfo) {
            return false;
        }

        HashMap<String, Integer> adRecord = userInfo.getAdRecord();

        if (null == adRecord) {
            return false;
        }

        return adRecord.containsKey(planId);
    }

    /**
     * 该用户当天是否已查看了指定的广告计划
     *
     * @param planId 广告计划ID
     * @param openId
     */
    private boolean viewedToDay(String planId, String openId) {

        if (StringUtils.isAnyBlank(planId, openId)) {
            return false;
        }

        //AdvertisingUserInfo userInfo = advertisingUserInfoService.findByOpenId(openId);
        AdvertisingUserInfo userInfo = ADVERTISING_USER_INFO_THREAD_LOCAL.get();

        if (null == userInfo) {
            return false;
        }

        AdvertisingUserDayRecord adUserDayRecord = userInfo.getAdUserDayRecord();
        if (null == adUserDayRecord) {
            return false;
        }

        Date gmtLastAdvertising = adUserDayRecord.getGmtLastAdvertising();

        if (null == gmtLastAdvertising) {
            return false;
        }

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(gmtLastAdvertising);

        if (calendar.get(Calendar.DAY_OF_MONTH) != Calendar.getInstance().get(Calendar.DAY_OF_MONTH)) {
            /*不是同一天*/
            return false;
        }

        if (planId.equals(adUserDayRecord.getLastPlanId())) {
            return true;
        }

        HashMap<String, Integer> advertisingRecord = adUserDayRecord.getAdvertisingRecord();

        if (null == advertisingRecord || advertisingRecord.isEmpty()) {
            return false;
        }

        return advertisingRecord.containsKey(planId);
    }

    @Override
    public void participateBidPercentageFilter(List<AdvertisingPlan> planList) {

        if (null == planList || planList.isEmpty()) {
            return;
        }

        /*参与竞价概率*/
        int participateBidPercentage = ThreadLocalRandom.current().nextInt(100);

        AdvertisingTargetInfo targetInfo = ADVERTISING_TARGET_INFO_THREAD_LOCAL.get();

        if (USER_PRINT_LOG_WHITE.contains(targetInfo.getOpenId())) {
            LOGGER.info("参与竞价概率：{}%", participateBidPercentage);
        }

        int size = planList.size();

        for (Iterator<AdvertisingPlan> it = planList.iterator(); it.hasNext(); ) {
            Integer participateBidPer = it.next().getParticipateBidPercentage();
            if (null != participateBidPer && participateBidPer <= participateBidPercentage) {
                /*不参与竞价*/
                it.remove();
            }
        }

        if (planList.size() < size) {
            LOGGER.info("参与竞价概率过滤后剩余广告计划条数：{}，计划ID：{}", planList.size(), planList.stream().map(AdvertisingPlan::getPlanId).toArray());
        }

    }

    @Override
    public void thirdPartyPlatformFilterBeforeBid(List<AdvertisingPlan> planList) {

        long start = System.currentTimeMillis();

        if (null == planList || planList.isEmpty() || MEDIUM_SELL_RULES_FILTER_PLAN_ID.isEmpty()) {
            return;
        }

        AdvertisingTargetInfo targetInfo = ADVERTISING_TARGET_INFO_THREAD_LOCAL.get();

        if (null == targetInfo) {
            LOGGER.error("广告交易数据信息缺失");
            return;
        }

        int count = 0;
        /*需要排除竞价的广告计划ID*/
        Set<String> excludePlanId = new HashSet<>(planList.size());
        CompletionService<String> completionService = new ExecutorCompletionService<>(AsyncManager.me().getExecutor());

        for (AdvertisingPlan plan : planList) {
            if (!MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(plan.getPlanId())) {
                continue;
            }

            plan.setRandomNum(targetInfo.getId().toString());
            completionService.submit(new Callable<String>() {
                @Override
                public String call() throws Exception {
                    ADVERTISING_TARGET_INFO_THREAD_LOCAL.set(targetInfo);
                    AdCombinationInfo adCombinationInfo = advertisingCombination(plan);
                    adCombinationInfo.setRandomNum(targetInfo.getId());
                    WeChatAccountTaskInfo taskInfo = getWeChatAccountTaskInfo(adCombinationInfo);
                    ADVERTISING_TARGET_INFO_THREAD_LOCAL.remove();

                    if (isValid(taskInfo)) {
                        /*有效，参与竞价*/
                        return "";
                    }

                    excludePlanId.add(plan.getPlanId());
                    return plan.getPlanId();
                }
            });
            count += 1;
        }

        try {
            for (int i = 0; i < count; i++) {
                completionService.take().get();
            }
        } catch (InterruptedException | ExecutionException e) {
            LOGGER.error(e.getMessage(), e);
        }

        StringBuilder sb = new StringBuilder();
        for (Iterator<AdvertisingPlan> it = planList.iterator(); it.hasNext(); ) {
            AdvertisingPlan plan = it.next();
            if (excludePlanId.contains(plan.getPlanId())) {
                it.remove();
                sb.append(plan.getPlanId()).append(',');
            }
        }

        if (sb.length() > 0) {
            LOGGER.info("用户{}扫码流水号{}广告计划【{}】属第三方平台且拉取数据无效，不参与竞价，耗时(毫秒)：{}", targetInfo.getOpenId(), targetInfo.getId(), sb.deleteCharAt(sb.length() - 1), System.currentTimeMillis() - start);
        }

    }

    @Override
    public AdvertisingPlan secondBid(Long randomNum) {

        if (null == randomNum) {
            return null;
        }

        AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(randomNum);

        if (null == targetInfo || StringUtils.isBlank(targetInfo.getAdWinPlanId())) {
            LOGGER.error("交易记录【{}】不存在", randomNum);
            return null;
        }

        String oldPlanId = targetInfo.getAdWinPlanId();
        String prefix = oldPlanId.substring(0, 2);
        List<String> participateBidPlanId = targetInfo.getParticipateBidPlanId();

        if (null == participateBidPlanId || participateBidPlanId.isEmpty()) {
            LOGGER.warn("交易记录【{}】未有广告参与竞价", randomNum);
            return null;
        }

        List<AdvertisingPlan> planList = new ArrayList<>(participateBidPlanId.size());
        Set<String> secondBidPlanId = targetInfo.getSecondBidPlanId();

        if (null == secondBidPlanId) {
            secondBidPlanId = new HashSet<>(4);
            targetInfo.setSecondBidPlanId(secondBidPlanId);
        }

        /*乱序*/
        Collections.shuffle(participateBidPlanId);

        for (String planId : participateBidPlanId) {

            if (!planId.substring(0, 2).equals(prefix)) {
                /*竞价结果必须是同一类型下的广告*/
                continue;
            }

            if (MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(planId) && MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(oldPlanId)) {
                /*第三方平台不参与竞价*/
                continue;
            }

            if (planId.equals(oldPlanId) || secondBidPlanId.contains(oldPlanId)) {
                /*排除上次竞价胜出计划ID*/
                continue;
            }

            String key = AD_PLAN_ID_PREFIX + '_' + planId;
            AdvertisingPlan plan = getV(key, ZJB_DB_50, AdvertisingPlan.class);

            if (null == plan || !plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
                continue;
            }

            planList.add(plan);
        }

        if (planList.isEmpty()) {
            return null;
        }

        Collections.sort(planList, new Comparator<AdvertisingPlan>() {
            @Override
            public int compare(AdvertisingPlan o1, AdvertisingPlan o2) {
                int r = o2.getPlanWeight().compareTo(o1.getPlanWeight());
                return 0 == r ? o2.getPlanBid().compareTo(o1.getPlanBid()) : r;
            }
        });

        AdvertisingPlan win = planList.get(0);

        /*更新胜出广告计划ID*/
        targetInfo.setAdWinPlanId(win.getPlanId());
        targetInfo.setAdFirstWinPlanId(oldPlanId);
        secondBidPlanId.add(oldPlanId);
        win.setRandomNum(String.valueOf(randomNum));
        advertisingTargetInfoService.updateByKey(targetInfo, PRIMARY_KEY_ID);

        setDomainAddress(win);

        LOGGER.info("扫码流水号【{}】首次胜出计划：{}，二次竞价胜出计划：{}", randomNum, oldPlanId, win.getPlanId());

        setVExpire(String.valueOf(randomNum), win, EXRP_5_MINUTE, ZJB_DB_50);

        return win;
    }


    @Override
    public AdCombinationInfo thirdBid(CombinationRequest combination, AdvertisingPlan secondBidWinPlan) {
        AdCombinationInfo adCombinationInfo = advertisingCombination(secondBidWinPlan);
        adCombinationInfo.setRandomNum(Long.parseLong(secondBidWinPlan.getRandomNum()));

        /***********************1***********************/
        /*二次胜出广告计划是否第三方平台任务*/
        boolean isThirdPartyPlatformTaskInfo = MEDIUM_SELL_RULES_FILTER_PLAN_ID.contains(secondBidWinPlan.getPlanId());
        WeChatAccountTaskInfo taskInfo = isThirdPartyPlatformTaskInfo ? getWeChatAccountTaskInfo(adCombinationInfo) : null;
        /*第三方平台公众号任务是否有效*/
        boolean valid = isThirdPartyPlatformTaskInfo && isValid(taskInfo);
        if (isThirdPartyPlatformTaskInfo && !valid) {
            /*二次胜出广告计划无效，直接保底*/
            adCombinationInfo = guaranteed(adCombinationInfo.getRandomNum());
            AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(adCombinationInfo.getRandomNum());
            String adFirstWinPlanId = targetInfo.getAdFirstWinPlanId();

            /*更新胜出广告计划ID*/
            String key = AD_PLAN_ID_PREFIX + '_' + adCombinationInfo.getPlanId();
            AdvertisingPlan win = getV(key, ZJB_DB_50, AdvertisingPlan.class);
            targetInfo.setAdWinPlanId(win.getPlanId());
            targetInfo.setAdFirstWinPlanId(secondBidWinPlan.getPlanId());
            win.setRandomNum(adCombinationInfo.getRandomNum().toString());

            Set<String> secondBidPlanId = targetInfo.getSecondBidPlanId();
            if (null == secondBidPlanId) {
                secondBidPlanId = new HashSet<>(4);
                targetInfo.setSecondBidPlanId(secondBidPlanId);
            }
            secondBidPlanId.add(secondBidWinPlan.getPlanId());

            advertisingTargetInfoService.updateByKey(targetInfo, PRIMARY_KEY_ID);

            LOGGER.info("用户{}扫码流水号【{}】首次胜出计划【{}】二次竞价胜出广告计划【{}】无效，采用随机保底广告计划ID：{}", combination.getOpenId(), adCombinationInfo.getRandomNum(), adFirstWinPlanId, secondBidWinPlan.getPlanId(), win.getPlanId());

            return adCombinationInfo;
        }

        if (isThirdPartyPlatformTaskInfo && valid) {
            adCombinationInfo.setWeChatAccountTaskInfo(taskInfo);
            return adCombinationInfo;
        }

        /***********************2***********************/
        if (MANUAL_ADD.getValue().equals(secondBidWinPlan.getComponentAuthorizationType())) {
            WeChatAccountTaskInfo manualTaskInfo = manualWeChatAccount(combination, secondBidWinPlan);
            if (null == manualTaskInfo) {
                /*二次胜出广告计划无效，直接保底*/
                adCombinationInfo = guaranteed(adCombinationInfo.getRandomNum());
                AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(adCombinationInfo.getRandomNum());
                String adFirstWinPlanId = targetInfo.getAdFirstWinPlanId();
                String key = AD_PLAN_ID_PREFIX + '_' + adCombinationInfo.getPlanId();
                AdvertisingPlan win = getV(key, ZJB_DB_50, AdvertisingPlan.class);

                /*更新胜出广告计划ID*/
                targetInfo.setAdWinPlanId(win.getPlanId());
                targetInfo.setAdFirstWinPlanId(secondBidWinPlan.getPlanId());
                win.setRandomNum(adCombinationInfo.getRandomNum().toString());

                Set<String> secondBidPlanId = targetInfo.getSecondBidPlanId();
                if (null == secondBidPlanId) {
                    secondBidPlanId = new HashSet<>(4);
                    targetInfo.setSecondBidPlanId(secondBidPlanId);
                }
                secondBidPlanId.add(secondBidWinPlan.getPlanId());

                advertisingTargetInfoService.updateByKey(targetInfo, PRIMARY_KEY_ID);

                LOGGER.info("用户{}扫码流水号【{}】首次胜出计划【{}】二次竞价胜出广告计划【{}】无效，采用随机保底广告计划ID：{}", combination.getOpenId(), adCombinationInfo.getRandomNum(), adFirstWinPlanId, secondBidWinPlan.getPlanId(), win.getPlanId());
                return adCombinationInfo;
            }

            adCombinationInfo.setWeChatAccountTaskInfo(manualTaskInfo);
            List<AdUnit> scan = new ArrayList<>(4);
            AdUnit unit = new AdUnit();
            unit.setFrom_type(FROM_TYPE_MANUAL_WE_CHAT_ACCOUNT.getValue());
            scan.add(unit);
            adCombinationInfo.setScan(scan);

            return adCombinationInfo;
        }


        /***********************3***********************/
        /*广告直配公众号是否有效*/
        boolean onceAgainBiddingWeChatAccount = (AUTHORIZE_ADD.getValue().equals(secondBidWinPlan.getComponentAuthorizationType())
                && directWeChatAccount(secondBidWinPlan, adCombinationInfo)
                && !isEventMatch(combination, secondBidWinPlan));

        if (onceAgainBiddingWeChatAccount) {
            /*二次胜出广告计划无效，直接保底*/
            adCombinationInfo = guaranteed(adCombinationInfo.getRandomNum());

            AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(adCombinationInfo.getRandomNum());
            String adFirstWinPlanId = targetInfo.getAdFirstWinPlanId();
            String key = AD_PLAN_ID_PREFIX + '_' + adCombinationInfo.getPlanId();
            AdvertisingPlan win = getV(key, ZJB_DB_50, AdvertisingPlan.class);

            /*更新胜出广告计划ID*/
            targetInfo.setAdWinPlanId(win.getPlanId());
            targetInfo.setAdFirstWinPlanId(secondBidWinPlan.getPlanId());
            win.setRandomNum(adCombinationInfo.getRandomNum().toString());

            Set<String> secondBidPlanId = targetInfo.getSecondBidPlanId();
            if (null == secondBidPlanId) {
                secondBidPlanId = new HashSet<>(4);
                targetInfo.setSecondBidPlanId(secondBidPlanId);
            }
            secondBidPlanId.add(secondBidWinPlan.getPlanId());

            advertisingTargetInfoService.updateByKey(targetInfo, PRIMARY_KEY_ID);

            LOGGER.info("用户{}扫码流水号【{}】首次胜出计划【{}】二次竞价胜出广告计划【{}】无效，采用随机保底广告计划ID：{}", combination.getOpenId(), adCombinationInfo.getRandomNum(), adFirstWinPlanId, secondBidWinPlan.getPlanId(), win.getPlanId());
            return adCombinationInfo;
        }

        return adCombinationInfo;
    }

    @Override
    public boolean directWeChatAccount(AdvertisingPlan win, AdCombinationInfo combinationInfo) {

        if (null == win || StringUtils.isBlank(win.getAdAppId()) || null == combinationInfo) {
            return false;
        }

        List<AdUnit> scannerObj = combinationInfo.getScan();

        if (null == scannerObj || scannerObj.isEmpty()) {
            LOGGER.error("扫码取纸广告位未设置");
            return false;
        }


        AdUnit mapUnit = scannerObj.get(0);
        Integer redirectUrlType = mapUnit.getRedirectUrlType();
        return AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(redirectUrlType);
    }


    @Override
    public AdCombinationInfo guaranteed(Long randomNum) {
        /*保底广告方案*/
        int index = ThreadLocalRandom.current().nextInt(GUARANTEE_AD_PLAN_ID.size());
        String planId = GUARANTEE_AD_PLAN_ID.get(index);
        String key = AD_PLAN_ID_PREFIX + '_' + planId;
        AdvertisingPlan win = getV(key, ZJB_DB_50, AdvertisingPlan.class);
        win.setRandomNum(null == randomNum ? null : randomNum.toString());
        AdCombinationInfo adCombinationInfo = advertisingCombination(win);
        adCombinationInfo.setRandomNum(randomNum);
        adCombinationInfo.setAppDownUrl(configService.selectConfigByKey(ZJB_DSP_APP_DOWN_URL.getKey()));
        return adCombinationInfo;
    }

    /**
     * 获取公众号任务信息
     *
     * @param combinationInfo
     * @return
     */
    @Override
    public WeChatAccountTaskInfo getWeChatAccountTaskInfo(AdCombinationInfo combinationInfo) {

        String planId = combinationInfo.getPlanId();

        if (StringUtils.isBlank(planId)) {
            LOGGER.error("缺失广告投放计划ID");
            return null;
        }

        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_PAY.getValue())) {
            LOGGER.warn("纯付费付费取纸不允许配置任务");
            return null;
        }

        List<AdUnit> scanner = combinationInfo.getScan();

        if (null == scanner || scanner.isEmpty()) {
            LOGGER.error("广告计划【{}】未配置扫码取纸位", planId);
            return null;
        }

        AdUnit mapUnit = scanner.get(0);
        String taskId = mapUnit.getAppid();

        AdvertisingTargetInfo targetInfo = ADVERTISING_TARGET_INFO_THREAD_LOCAL.get();

        if (null == targetInfo) {
            targetInfo = advertisingTargetInfoService.find(combinationInfo.getRandomNum());
        }

        if (null == targetInfo) {
            LOGGER.error("扫码流水号【{}】交易数据不存在", combinationInfo.getRandomNum());
            return null;
        }

        String key = AD_PLAN_ID_PREFIX + '_' + planId;
        AdvertisingPlan plan = getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null == plan) {
            LOGGER.error("广告计划【{}】不存在", planId);
            return null;
        }

        String keyWeChatAccountTaskInfo = "we_chat_account_task_info_" + combinationInfo.getRandomNum() + '_' + taskId;
        WeChatAccountTaskInfo taskInfo = getV(keyWeChatAccountTaskInfo, ZJB_DB_50, WeChatAccountTaskInfo.class);

        if (null != taskInfo) {
            return taskInfo;
        }

        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
        AdvertisingDeviceInfo deviceInfo = targetInfo.getDeviceInfo();

        if (null == peopleInfo || null == deviceInfo || StringUtils.isAnyBlank(peopleInfo.getOpenId(), deviceInfo.getQrcode())) {
            LOGGER.error("缺失用户||设备信息");
            return null;
        }

        String requestId = String.valueOf(System.currentTimeMillis());
        int millisecond = 1000;

        while (!tryGetDistributedLock(keyWeChatAccountTaskInfo, requestId, millisecond)) {
            /*防止一个任务被多个计划关联重复调用接口*/
            try {
                TimeUnit.MILLISECONDS.sleep(100L);
            } catch (InterruptedException e) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        try {

            /*拿到锁后二次确认缓存中是否存在数据*/
            taskInfo = getV(keyWeChatAccountTaskInfo, ZJB_DB_50, WeChatAccountTaskInfo.class);
            if (null != taskInfo) {
                return taskInfo;
            }

            String content = feignAdminCoreService.taskInfo(peopleInfo.getOpenId(),
                    taskId,
                    deviceInfo.getQrcode(),
                    combinationInfo.getRandomNum(),
                    plan.getAdAppId());


            logger.info("获取第三方公众号调用地址{}，参数：【openId:{},taskId:{},qrcode:{},randomNum:{},adAppId:{}】，返回结果：{}", ADMIN_CORE_URL_TASK_INFO, peopleInfo.getOpenId(), taskId,
                    deviceInfo.getQrcode(),
                    combinationInfo.getRandomNum(),
                    plan.getAdAppId(), content);


            if (StringUtils.isBlank(content)) {
                logger.warn("调用地址{}失败，参数：[{}，{}，{}，{}，{}]", ADMIN_CORE_URL_TASK_INFO, peopleInfo.getOpenId(),
                        taskId,
                        deviceInfo.getQrcode(),
                        combinationInfo.getRandomNum(),
                        plan.getAdAppId());
                return null;
            }

            if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
                logger.info("调用地址{}，参数：【{},{},{},{},{}】，返回结果：{}", ADMIN_CORE_URL_TASK_INFO, peopleInfo.getOpenId(),
                        taskId,
                        deviceInfo.getQrcode(),
                        combinationInfo.getRandomNum(),
                        plan.getAdAppId(), content);
            }

            char c = content.charAt(0);

            if (c != '{') {
                logger.error("调用地址{}返回数据【{}】格式错误，参数：[{},{},{},{},{}]", ADMIN_CORE_URL_TASK_INFO, content,
                        peopleInfo.getOpenId(),
                        taskId,
                        deviceInfo.getQrcode(),
                        combinationInfo.getRandomNum(),
                        plan.getAdAppId());
                return null;
            }

            taskInfo = JSON.parseObject(content, WeChatAccountTaskInfo.class);

            if (null != taskInfo) {
                taskInfo.setTaskId(Integer.parseInt(taskId));
                taskInfo.setOpenId(peopleInfo.getOpenId());
                taskInfo.setQrCode(deviceInfo.getQrcode());
                taskInfo.setRandomNum(targetInfo.getId());
                taskInfo.setWeChatAccount(plan.getAdAppId());
                setVExpire(keyWeChatAccountTaskInfo, taskInfo, EXRP_5_MINUTE, ZJB_DB_50);
            }

        } finally {
            releaseDistributedLock(keyWeChatAccountTaskInfo, requestId);
        }

        return taskInfo;
    }


    @Override
    public WeChatAccountTaskInfo getAuthWeChatAccountTaskInfo(AdCombinationInfo combinationInfo) {


        String planId = combinationInfo.getPlanId();

        if (StringUtils.isBlank(planId)) {
            LOGGER.error("缺失广告投放计划ID");
            return null;
        }
        if (StringUtils.startsWith(planId, AD_UNIT_TYPE_PAY.getValue())) {
            LOGGER.warn("纯付费付费取纸不允许配置任务");
            return null;
        }

        List<AdUnit> scanner = combinationInfo.getScan();

        if (null == scanner || scanner.isEmpty()) {
            LOGGER.error("广告计划【{}】未配置扫码取纸位", planId);
            return null;
        }
        AdvertisingTargetInfo targetInfo = ADVERTISING_TARGET_INFO_THREAD_LOCAL.get();

        if (null == targetInfo) {
            targetInfo = advertisingTargetInfoService.find(combinationInfo.getRandomNum());
        }
        if (null == targetInfo) {
            LOGGER.error("扫码流水号【{}】交易数据不存在", combinationInfo.getRandomNum());
            return null;
        }
        String key = AD_PLAN_ID_PREFIX + '_' + planId;
        AdvertisingPlan plan = getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null == plan) {
            LOGGER.error("广告计划【{}】不存在", planId);
            return null;
        }

        String keyWeChatAccountTaskInfo = "we_chat_account_task_info_" + combinationInfo.getRandomNum() + '_' + plan.getAdAppId();
        WeChatAccountTaskInfo taskInfo = getV(keyWeChatAccountTaskInfo, ZJB_DB_50, WeChatAccountTaskInfo.class);

        if (null != taskInfo) {
            return taskInfo;
        }
        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
        AdvertisingDeviceInfo deviceInfo = targetInfo.getDeviceInfo();

        if (null == peopleInfo || null == deviceInfo || StringUtils.isAnyBlank(peopleInfo.getOpenId(), deviceInfo.getQrcode())) {
            LOGGER.error("缺失用户||设备信息");
            return null;
        }
        String requestId = String.valueOf(System.currentTimeMillis());
        int millisecond = 1000;

        while (!tryGetDistributedLock(keyWeChatAccountTaskInfo, requestId, millisecond)) {
            /*防止一个任务被多个计划关联重复调用接口*/
            try {
                TimeUnit.MILLISECONDS.sleep(100L);
            } catch (InterruptedException e) {
                LOGGER.error(e.getMessage(), e);
            }
        }
        try {

            /*拿到锁后二次确认缓存中是否存在数据*/
            taskInfo = getV(keyWeChatAccountTaskInfo, ZJB_DB_50, WeChatAccountTaskInfo.class);
            if (null != taskInfo) {
                return taskInfo;
            }

            WechatParameter wechatParameter = new WechatParameter();
            wechatParameter.setOpenId(peopleInfo.getOpenId());
            wechatParameter.setQrCode(deviceInfo.getQrcode());
            wechatParameter.setRandomNum(combinationInfo.getRandomNum());
            wechatParameter.setWeChatAccount(plan.getAdAppId());
            wechatParameter.setGmtRequest(LocalDateTime.now());

            taskInfo = feignAdminCoreService.weChatInfo(wechatParameter);

            if (null != taskInfo) {
                taskInfo.setWeChatAccount(plan.getAdAppId());
                taskInfo.setOpenId(peopleInfo.getOpenId());
                taskInfo.setQrCode(deviceInfo.getQrcode());
                taskInfo.setRandomNum(targetInfo.getId());
                setVExpire(keyWeChatAccountTaskInfo, taskInfo, EXRP_5_MINUTE, ZJB_DB_50);
            }
        } finally {
            releaseDistributedLock(keyWeChatAccountTaskInfo, requestId);
        }
        return taskInfo;
    }


    @Override
    public AdvertisingPlan firstBid(List<AdvertisingPlan> planList) {
        long start = System.currentTimeMillis();

        if (null == planList || planList.isEmpty()) {
            return null;
        }

        AdvertisingTargetInfo targetInfo = ADVERTISING_TARGET_INFO_THREAD_LOCAL.get();

        if (1 == planList.size()) {
            AdvertisingPlan win = planList.get(0);
            if (USER_PRINT_LOG_WHITE.contains(targetInfo.getOpenId())) {
                LOGGER.info("用户{}扫码流水号{}过滤胜出广告计划ID：{}，耗时（毫秒）：{}", targetInfo.getOpenId(), targetInfo.getId(), win.getPlanId(), System.currentTimeMillis() - start);
            }
            return win;
        }

        /*按权重大小排序，权重越大越靠前*/
        planList.sort(new Comparator<AdvertisingPlan>() {
            @Override
            public int compare(AdvertisingPlan o1, AdvertisingPlan o2) {
                /*倒序*/
                return o2.getPlanWeight().compareTo(o1.getPlanWeight());
            }
        });


        /*1、集合的第一个和第二个权重比较*/
        if (planList.get(0).getPlanWeight() > planList.get(1).getPlanWeight()) {
            AdvertisingPlan win = planList.get(0);
            if (USER_PRINT_LOG_WHITE.contains(targetInfo.getOpenId())) {
                LOGGER.info("用户{}扫码流水号{}权重胜出广告计划ID：{}，耗时（毫秒）：{}", targetInfo.getOpenId(), targetInfo.getId(), win.getPlanId(), System.currentTimeMillis() - start);
            }
            return win;
        }

        /*2、价高者优先胜出*/
        int maxWeight = planList.get(0).getPlanWeight();
        List<AdvertisingPlan> planMaxWeight = new ArrayList<>();
        for (AdvertisingPlan plan : planList) {
            if (plan.getPlanWeight().equals(maxWeight)) {
                /*提取相同权重最高的广告计划*/
                planMaxWeight.add(plan);
            }
        }

        /**按出价大小排序，出价越大越靠前*/
        Collections.sort(planMaxWeight, new Comparator<AdvertisingPlan>() {
            @Override
            public int compare(AdvertisingPlan o1, AdvertisingPlan o2) {
                /*倒序*/
                return o2.getPlanBid().compareTo(o1.getPlanBid());
            }
        });

        /*集合的第一个和第二个出价比较*/
        if (planMaxWeight.get(0).getPlanBid().compareTo(planMaxWeight.get(1).getPlanBid()) > 0) {
            AdvertisingPlan win = planMaxWeight.get(0);
            if (USER_PRINT_LOG_WHITE.contains(targetInfo.getOpenId())) {
                LOGGER.info("用户{}扫码流水号{}价高胜出广告计划ID：{}，耗时（毫秒）：{}", targetInfo.getOpenId(), targetInfo.getId(), win.getPlanId(), System.currentTimeMillis() - start);
            }
            return win;
        }

        /*3、价高相同随机胜出*/
        BigDecimal maxBid = planMaxWeight.get(0).getPlanBid();
        List<AdvertisingPlan> planMaxBid = new ArrayList<>();
        for (AdvertisingPlan plan : planMaxWeight) {
            if (0 == plan.getPlanBid().compareTo(maxBid)) {
                /*提取相同权重相同价格最高的广告计划*/
                planMaxBid.add(plan);
            }
        }

        /*随机索引数字*/
        int index = ThreadLocalRandom.current().nextInt(planMaxBid.size());
        AdvertisingPlan win = planMaxBid.get(index);

        if (USER_PRINT_LOG_WHITE.contains(targetInfo.getOpenId())) {
            LOGGER.info("用户{}扫码流水号{}随机胜出广告计划ID：{}, 耗时（毫秒）：{}", targetInfo.getOpenId(), targetInfo.getId(), win.getPlanId(), System.currentTimeMillis() - start);
        }

        return win;
    }

    /**
     * 设置域名
     *
     * @param plan
     */
    @Override
    public void setDomainAddress(AdvertisingPlan plan) {

        if (null == plan) {
            return;
        }

        plan.setDomainAddress(configService.selectConfigByKey(DOMAIN_ADDRESS_OTHER.getKey()));

        if (StringUtils.isBlank(plan.getPlanId())) {
            return;
        }

        /*是否跳转至小树叶落地页*/
        if (plan.getPlanId().startsWith(AD_UNIT_TYPE_WX.getValue())) {
            plan.setLoc("/xsy/");
        } else if (plan.getPlanId().startsWith(AD_UNIT_TYPE_FANS.getValue())) {
            plan.setLoc("/fst/");
        } else {
            plan.setLoc("/");
        }

        boolean isScGdt = isScGdt(plan);

        if (!isScGdt && plan.getPlanId().startsWith(AD_UNIT_TYPE_WX.getValue())) {
            String leafPrivateDomain = configService.selectConfigByKey(ZJB_LEAF_PRIVATE_DOMAIN.getKey());
            int index = StringUtils.lastIndexOf(leafPrivateDomain, "/");
            plan.setDomainAddress(leafPrivateDomain.substring(index + 1));
            return;
        }

        if (!isScGdt && plan.getPlanId().startsWith(AD_UNIT_TYPE_FANS.getValue())) {
            String fansPrivateDomain = configService.selectConfigByKey(ZJB_FANS_PRIVATE_DOMAIN.getKey());
            int index = StringUtils.lastIndexOf(fansPrivateDomain, "/");
            plan.setDomainAddress(fansPrivateDomain.substring(index + 1));
            return;
        }

        if (isScGdt) {
            plan.setDomainAddress(configService.selectConfigByKey(DOMAIN_ADDRESS_66K22_TOP.getKey()));
        }

    }

    /**
     * 是否数策广点通域名
     *
     * @param plan
     * @return
     */
    private boolean isScGdt(AdvertisingPlan plan) {
        AdvertisingCombination advertisingCombination = getAdvertisingCombination(plan);

        if (null == advertisingCombination || StringUtils.isBlank(advertisingCombination.getComId())) {
            return false;
        }

        List<AdvertisingUnit> list = selectAdvertisingUnitListByCombinationId(advertisingCombination);

        if (null == list || list.isEmpty()) {
            return false;
        }

        for (AdvertisingUnit advertisingUnit : list) {

            if (!AD_REDIRECT_TASK.getValue().equals(advertisingUnit.getRedirectUrlType())) {
                continue;
            }

            if (IConfigService.S66K22_TOP_TASK_ID.contains(advertisingUnit.getAppId())) {
                return true;
            }
        }

        return false;
    }

    @Override
    public void asynchronousHandleBiddingResult(List<AdvertisingPlan> planParticipateBid, AdvertisingPlan win, AdvertisingTargetInfo targetInfo) {

        long start = System.currentTimeMillis();
        Map<String, Serializable> map = new HashMap<>(6);
        map.put(KEY_HANDLE_BIDDING_RESULT_EVENT, targetInfo);
        targetInfo.setAdWinPlanId(null == win ? null : win.getPlanId());


        if (null != planParticipateBid && !planParticipateBid.isEmpty()) {
            map.put(MAP_KEY_PARTICIPATE_BID_AD_PLAN, JSON.toJSONString(planParticipateBid));
            List<String> participateBidPlanId = new ArrayList<>(planParticipateBid.size());

            /*参与竞价广告计划*/
            for (AdvertisingPlan plan : planParticipateBid) {
                participateBidPlanId.add(plan.getPlanId());
            }

            targetInfo.setParticipateBidPlanId(participateBidPlanId);
        }

        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();
        try {
            advertisingTargetInfoService.save(targetInfo);
        } catch (DataAccessResourceFailureException e) {
            LOGGER.error("广告交易记录保存失败：" + e.getMessage());
        }

        if (null != win) {
            map.put(MAP_KEY_AD_PLAN_WIN, win);
        }

        lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(map));

        if (USER_PRINT_LOG_WHITE.contains(peopleInfo.getOpenId())) {
            LOGGER.info("用户{}流水号{}广告竞价结果异步处理耗时（毫秒）：{}", peopleInfo.getOpenId(), targetInfo.getId(), System.currentTimeMillis() - start);
        }
    }

    /**
     * 广告计费
     *
     * @param planId     胜出广告计划ID
     * @param incrOrDecr 递增（减） true：递增 false：递减
     */
    public static void advertisingBilling(String planId, boolean incrOrDecr) {

        String key = AD_PLAN_ID_PREFIX + '_' + planId;
        AdvertisingPlan win = getV(key, ZJB_DB_50, AdvertisingPlan.class);

        if (null == win) {
            return;
        }

        /*今日胜出次数*/
        String keyTodayWinNum = "today_win_num_" + LocalDate.now() + '_' + planId;
        Long todayWinNum = incrOrDecr ? incr(keyTodayWinNum, EXRP_DAY) : decr(keyTodayWinNum, EXRP_DAY);
        win.setTodayWinNum(todayWinNum.intValue());
        win.setTodayWinNum(win.getTodayWinNum() < 0 ? 0 : win.getTodayWinNum());
        /*今日花费*/
        String keyTodaySpend = "today_spend_" + LocalDate.now() + '_' + planId;
        Double todaySpend = incrByFloat(keyTodaySpend, EXRP_DAY, incrOrDecr ? win.getPlanBid().doubleValue() : -win.getPlanBid().doubleValue());
        win.setTodaySpend(BigDecimal.valueOf(todaySpend));
        win.setTodaySpend(win.getTodaySpend().compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : win.getTodaySpend());
        /*总胜出次数*/
        String keyTotalWinNum = "total_win_num_" + planId;
        String keyTotalSpend = "total_spend_" + planId;
        String keyBidWinNum = "bid_win_num_" + planId;

        if (!exists(keyTotalWinNum, false, 0)) {

            try (Jedis jedis = getJedisPool().getResource()) {
                jedis.select(0);
                jedis.set(keyTotalWinNum, win.getTotalWinNum().toString());
                jedis.expire(keyTotalWinNum, EXRP_DAY);

                jedis.set(keyTotalSpend, win.getTotalSpend().toString());
                jedis.expire(keyTotalSpend, EXRP_DAY);

                jedis.set(keyBidWinNum, win.getBidWinNum().toString());
                jedis.expire(keyBidWinNum, EXRP_DAY);
            } catch (Exception e) {
                LOGGER.error(e.getMessage(), e);
            }
        }

        Long totalWinNum = incrOrDecr ? incr(keyTotalWinNum, EXRP_DAY) : decr(keyTotalWinNum, EXRP_DAY);
        win.setTotalWinNum(totalWinNum.intValue());
        win.setTotalWinNum(win.getTotalWinNum() < 0 ? 0 : win.getTotalWinNum());
        /*总花费*/
        Double totalSpend = incrByFloat(keyTotalSpend, EXRP_DAY, incrOrDecr ? win.getPlanBid().doubleValue() : -win.getPlanBid().doubleValue());
        win.setTotalSpend(BigDecimal.valueOf(totalSpend));
        win.setTotalSpend(win.getTotalSpend().compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : win.getTotalSpend());
        /*竞价胜出次数*/
        Long bidWinNum = incrOrDecr ? incr(keyBidWinNum, EXRP_DAY) : decr(keyBidWinNum, EXRP_DAY);
        win.setBidWinNum(bidWinNum.intValue());
        win.setBidWinNum(win.getBidWinNum() < 0 ? 0 : win.getBidWinNum());
        /*广告投放状态之日预算不足暂停*/
        if (null != win.getDayBudget()
                && null != win.getTodaySpend()
                && win.getDayBudget().compareTo(BigDecimal.ZERO) > 0
                && win.getTodaySpend().compareTo(win.getDayBudget()) >= 0) {
            win.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_DAY.getValue());
        }

        /*广告投放状态之总预算不足暂停*/
        if (null != win.getTotalBudget()
                && null != win.getTotalSpend()
                && win.getTotalBudget().compareTo(BigDecimal.ZERO) > 0
                && win.getTotalSpend().compareTo(win.getTotalBudget()) >= 0) {
            win.setAdvertisingStatus(AD_PLAN_STATUS_PAUSE_BUDGET_NOT_ENOUGH_TOTAL.getValue());
        }

        win.setRecentWinTimestamp(System.currentTimeMillis());
        setVExpire(key, win, EXRP_MONTH, ZJB_DB_50);
    }

    @Override
    public AdCombinationInfo advertisingCombination(AdvertisingPlan win) {
        AdCombinationInfo adCombinationInfo = new AdCombinationInfo();
        adCombinationInfo.setScan(new ArrayList<>(4));
        adCombinationInfo.setBanners(new ArrayList<>());
        adCombinationInfo.setItems(new ArrayList<>(8));
        adCombinationInfo.setItems_task(new ArrayList<>(8));
        adCombinationInfo.setItems_baidu_task(new ArrayList<>(8));
        adCombinationInfo.setTabs(new ArrayList<>(8));
        adCombinationInfo.setAssignItems(new ArrayList<>(8));
        adCombinationInfo.setBeancurd(new ArrayList<>(8));
        adCombinationInfo.setAppDownUrl(configService.selectConfigByKey(ZJB_DSP_APP_DOWN_URL.getKey()));
        adCombinationInfo.setNotAliPayAllowedPlanId(IConfigService.NOT_ALI_PAY_ALLOWED_TAKE_PAPER_PLAN_ID);
        adCombinationInfo.setRandomNum(StringUtils.isNumeric(win.getRandomNum()) ? Long.parseLong(win.getRandomNum()) : null);
        //是否显示故障上报按钮
        adCombinationInfo.setDisplay(Boolean.parseBoolean(configService.selectConfigByKey(ABNORMAL_TYPE.getKey())));

        /*缓存用户最后胜出的广告计划*/
        cacheUserLastWinPlan(win);

        /*广点通心跳域名*/
        String[] gdtServerDomains = StringUtils.split(configService.selectConfigByKey(ZJB_GDT_SERVER_DOMAIN.getKey()), ',');
        if (gdtServerDomains.length > 0) {
            int index = ThreadLocalRandom.current().nextInt(gdtServerDomains.length);
            adCombinationInfo.setGdtServerDomain(gdtServerDomains[index]);
        } else {
            adCombinationInfo.setGdtServerDomain("admin.zhijinbao.net");
        }

        setDomainAddress(win);

        adCombinationInfo.setPlanId(win.getPlanId());
        adCombinationInfo.setDomainAddress(win.getDomainAddress());
        adCombinationInfo.setLoc(StringUtils.defaultIfBlank(win.getLoc(), "/"));

        if (StringUtils.isNotBlank(win.getPlanId()) && win.getPlanId().startsWith(AD_UNIT_TYPE_PAY.getValue())) {
            return adCombinationInfo;
        }

        AdvertisingCombination advertisingCombination = getAdvertisingCombination(win);

        List<AdvertisingUnit> advertisingUnits = selectAdvertisingUnitListByCombinationId(advertisingCombination);

        if (null == advertisingUnits || advertisingUnits.isEmpty()) {
            return adCombinationInfo;
        }

        Map<Integer, AdUnit> advertisingUnitMap = new HashMap<>();

        for (AdvertisingUnit advertisingUnit : advertisingUnits) {
            if (AD_USE_NO.getValue().equals(advertisingUnit.getAdUseStatus())) {
                continue;
            }

            String adSpaceIdentifier = advertisingUnit.getAdSpaceIdentifier();
            Integer redirectUrlType = advertisingUnit.getRedirectUrlType();

            if (AD_SPACE_BANNER_CAROUSEL.getValue().equals(adSpaceIdentifier)
                    || AD_SPACE_BANNER_CAROUSEL_WX.getValue().equals(adSpaceIdentifier)) {
                /*轮播-Banner*/
                AdUnit adUnit = new AdUnit();
                handleAdvertisingUnit(adUnit, advertisingUnit, win.getRandomNum());
                adCombinationInfo.getBanners().add(adUnit);
            } else if (AD_SPACE_SUSPENSION.getValue().equals(adSpaceIdentifier)) {
                /*悬浮广告*/
                adCombinationInfo.setRedPacket(new AdUnit());
                handleAdvertisingUnit(adCombinationInfo.getRedPacket(), advertisingUnit, win.getRandomNum());
            } else if (AD_SPACE_PERSON_TEXT.getValue().equals(adSpaceIdentifier)) {
                /*个人中心-文字链*/
                adCombinationInfo.setTitle(new AdUnit());
                handleAdvertisingUnit(adCombinationInfo.getTitle(), advertisingUnit, win.getRandomNum());
            } else if (AD_SPACE_PAPER_OUTPUT.getValue().equals(adSpaceIdentifier)
                    || AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(adSpaceIdentifier)
                    || AD_FANS_PAPER_OUTPUT.getValue().equals(adSpaceIdentifier)) {
                if (!adCombinationInfo.getScan().isEmpty()) {
                    continue;
                }

                /*扫码取纸*/
                AdUnit mapUnit = new AdUnit();
                handleAdvertisingUnit(mapUnit, advertisingUnit, win.getRandomNum());
                adCombinationInfo.getScan().add(mapUnit);
            } else if (AD_SPACE_TAB.getValue().equals(adSpaceIdentifier)) {
                /*Tab广告*/
                AdUnit mapUnit = new AdUnit();
                handleAdvertisingUnit(mapUnit, advertisingUnit, win.getRandomNum());
                adCombinationInfo.getTabs().add(mapUnit);
            } else if (AD_SPACE_PERSON_BANNER.getValue().equals(adSpaceIdentifier)) {
                /*个人中心-Banner*/
                adCombinationInfo.setBottom(new AdUnit());
                handleAdvertisingUnit(adCombinationInfo.getBottom(), advertisingUnit, win.getRandomNum());
            } else if (AD_SPACE_BANNER_HOME.getValue().equals(adSpaceIdentifier)
                    || AD_SPACE_BANNER_HOME_WX.getValue().equals(adSpaceIdentifier)
                    || AD_FANS_BANNER.getValue().equals(adSpaceIdentifier)) {
                /*首页-Banner*/
                AdUnit mapUnit = new AdUnit();
                handleAdvertisingUnit(mapUnit, advertisingUnit, win.getRandomNum());
                if (AD_REDIRECT_TASK.getValue().equals(redirectUrlType)
                        && (AD_PUBLIC_COMBINATION_UNIT.getValue() + "9").equals(advertisingUnit.getAppId())) {
                    adCombinationInfo.getItems_baidu_task().add(mapUnit);
                } else if (AD_REDIRECT_TASK.getValue().equals(redirectUrlType)) {
                    adCombinationInfo.getItems_task().add(mapUnit);
                } else {
                    adCombinationInfo.getItems().add(mapUnit);
                }

            } else if (AD_FANS_BEANCURD_CUBE.getValue().equals(adSpaceIdentifier)) {
                //首页-豆腐块
                AdUnit mapUnit = new AdUnit();
                handleAdvertisingUnit(mapUnit, advertisingUnit, win.getRandomNum());
                if (null != mapUnit.getPosition()) {
                    advertisingUnitMap.put(mapUnit.getPosition(), mapUnit);
                }
            }
        }

        //定向投放展示广告
        if (null != win.getDeviceId()) {
            getAssignBanner(adCombinationInfo, win.getDeviceId(), advertisingUnitMap);
        } else {
            if (StringUtils.isNotEmpty(advertisingUnitMap)) {
                for (Map.Entry<Integer, AdUnit> entry : advertisingUnitMap.entrySet()) {
                    if (null != entry.getValue()) {
                        adCombinationInfo.getBeancurd().add(entry.getValue());
                    }
                }
            }
        }
        return adCombinationInfo;
    }

    /**
     * 缓存用户最后胜出的广告计划
     *
     * @param win
     */
    private void cacheUserLastWinPlan(AdvertisingPlan win) {
        if (null == win || !StringUtils.isNumeric(win.getRandomNum())) {
            return;
        }

        AdvertisingTargetInfo targetInfo;
        try {
            targetInfo = advertisingTargetInfoService.find(win.getRandomNum());
        } catch (DataAccessResourceFailureException e) {
            LOGGER.error("根据扫码流水号{}查询广告交易数据失败！：{}", win.getRandomNum(), e.getMessage());
            return;
        }
        if (null == targetInfo || null == targetInfo.getPeopleInfo()) {
            return;
        }

        AdvertisingPeopleInfo peopleInfo = targetInfo.getPeopleInfo();

        if (StringUtils.isBlank(peopleInfo.getOpenId())) {
            return;
        }

        setVExpire(peopleInfo.getOpenId(), win, EXRP_5_MINUTE, ZJB_DB_50);

    }

    @Override
    public List<AdvertisingUnit> selectAdvertisingUnitListByCombinationId(AdvertisingCombination advertisingCombination) {
        String comId = advertisingCombination.getComId();
        List list = new ArrayList<>();
        if (comId.startsWith(AD_UNIT_TYPE_ZFB.getValue())) {
            return advertisingUnitService.selectAdvertisingUnitListByCombinationId(advertisingCombination.getId());
        } else if (comId.startsWith(AD_UNIT_TYPE_WX.getValue())) {
            List<AdvertisingUnitWx> wxList = advertisingUnitWxService.selectAdvertisingUnitListByCombinationId(advertisingCombination.getId());
            if (null != wxList && !wxList.isEmpty()) {
                list.addAll(wxList);
            }
        } else if (comId.startsWith(AD_UNIT_TYPE_PAY.getValue())) {
            return list;
        } else if (comId.startsWith(AD_UNIT_TYPE_FANS.getValue())) {
            List<AdvertisingUnitFans> wxList = advertisingUnitFansService.selectAdvertisingUnitListByCombinationId(advertisingCombination.getId());
            if (null != wxList && !wxList.isEmpty()) {
                list.addAll(wxList);
            }
        } else {
            LOGGER.error("广告方案ID格式错误");
        }

        return list;
    }

    @Override
    public AdvertisingCombination getAdvertisingCombination(AdvertisingPlan advertisingPlan) {
        String planId = advertisingPlan.getPlanId();
        AdvertisingCombination advertisingCombination = null;
        if (planId.startsWith(AD_UNIT_TYPE_ZFB.getValue())) {
            advertisingCombination = advertisingCombinationService.selectAdvertisingCombinationById(advertisingPlan.getCombinationId());
        } else if (planId.startsWith(AD_UNIT_TYPE_WX.getValue())) {
            advertisingCombination = advertisingCombinationWxService.selectAdvertisingCombinationWxById(advertisingPlan.getCombinationId());
        } else if (planId.startsWith(AD_UNIT_TYPE_PAY.getValue())) {
            advertisingCombination = advertisingCombinationPayService.selectAdvertisingCombinationPayById(advertisingPlan.getCombinationId());
        } else if (planId.startsWith(AD_UNIT_TYPE_FANS.getValue())) {
            advertisingCombination = advertisingCombinationFansService.selectAdvertisingCombinationFansById(advertisingPlan.getCombinationId());
        } else {
            LOGGER.error("广告投放计划ID格式错误");
        }
        return advertisingCombination;
    }

    private void handleAdvertisingUnit(AdUnit adUnit, AdvertisingUnit unit, String randomNum) {
        Integer redirectUrlType = unit.getRedirectUrlType();

        adUnit.setId(unit.getAdId());
        adUnit.setAdTypeId(unit.getAdTypeId());
        adUnit.setGeneralName(unit.getGeneralName());
        adUnit.setAdName(unit.getAdName());
        adUnit.setProgramUrl(unit.getProgramUrl());
        adUnit.setGzhSubscribeMsg(unit.getGzhSubscribeMsg());
        /*出纸延迟时间*/
        adUnit.setDelayTime(unit.getOutPaperDelay());

        if (StringUtils.isNotBlank(unit.getWeChatAccount()) && AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(redirectUrlType)) {
            /*微信公众号直配*/
            ComponentAuthorizationInfo authInfo = componentAuthorizationInfoService.selectByComponentId(unit.getWeChatAccount());
            adUnit.setWeChatAccount(null == authInfo ? "" : authInfo.getAppId());
            if (null == authInfo || StringUtils.isBlank(authInfo.getAppId())) {
                LOGGER.error("根据主键【{}】查询公众号信息失败", unit.getWeChatAccount());
            }
        }

        //用户点击图片地址
        adUnit.setUrl(StringUtils.defaultString(unit.getAdPhotoUrl()));

        /*跳转类型处理*/
        handleFromType(adUnit, unit);

        adUnit.setRedirectUrlType(redirectUrlType);
        adUnit.setTakeThePaperProcess(unit.getTakeThePaperProcess());

        /*出纸流程处理*/
        handleTakeThePaperProcess(adUnit, unit, randomNum);

        /*展示通恢复公众号投放处理*/
        if (StringUtils.startsWith(unit.getAdId(), AD_UNIT_TYPE_ZFB.getValue())) {
            adUnit.setTakeThePaperProcess("30");
        }

        adUnit.setTitle(StringUtils.defaultString(unit.getTitile()));
        String appId = StringUtils.defaultString(unit.getAppId());

        if (AD_REDIRECT_TASK.getValue().equals(redirectUrlType)
                && StringUtils.isNotBlank(appId)
                && appId.startsWith(AD_PUBLIC_COMBINATION_UNIT.getValue())) {
            adUnit.setAppid(StringUtils.removeFirst(appId, AD_PUBLIC_COMBINATION_UNIT.getValue()));
        } else {
            adUnit.setAppid(appId);
        }

        //小程序路径
        adUnit.setPageurl(StringUtils.defaultString(unit.getRedirectUrl()));
        //红包是否显示
        adUnit.setIsview("true");
        adUnit.setMarkId(StringUtils.defaultString(unit.getSupplementParam1()));
        adUnit.setPlacementId(StringUtils.defaultString(unit.getSupplementParam2()));
        adUnit.setText(StringUtils.defaultString(unit.getGeneralName()));

        if (AD_SPACE_PAPER_OUTPUT.getValue().equals(unit.getAdSpaceIdentifier())
                && StringUtils.isNumeric(appId)
                && AD_REDIRECT_TASK.getValue().equals(redirectUrlType)) {

            ScanTask scanTask = sanTaskService.selectScanTaskByTaskId(appId);

            if (null != scanTask && StringUtils.isNotBlank(scanTask.getExpansionA())) {
                adUnit.setExpansionA(scanTask.getExpansionA());
            }
            if (null != scanTask && StringUtils.isNotBlank(scanTask.getExpansionB())) {
                adUnit.setExpansionB(scanTask.getExpansionB());
            }
            if (null != scanTask && StringUtils.isNotBlank(scanTask.getExpansionC())) {
                adUnit.setExpansionC(scanTask.getExpansionC());
            }
        }

        if (IConfigService.WEI_XIN_APP_UNIT_SET.contains(appId)) {
            smallproceduresUnit(adUnit, appId);
        } else if (GUARANTEED_TASK_SET.contains(appId)) {
            guaranteedTask(adUnit, appId);
        }

        adUnit.setPosition(unit.getPosition());

    }

    /**
     * 跳转类型处理
     *
     * @param adUnit
     * @param unit
     */
    private void handleFromType(AdUnit adUnit, AdvertisingUnit unit) {

        Integer redirectUrlType = unit.getRedirectUrlType();

        //跳转类型
        String fromType = "";
        if (AD_REDIRECT_H5.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_H5.getValue();
        } else if (AD_REDIRECT_TASK.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_TASK.getValue();
        } else if (AD_REDIRECT_LIFE_CODE.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_ALI_PAY_LIFE_NUM.getValue();
        } else if (AD_REDIRECT_PROGRAM.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_ALI_PAY_APPLETS.getValue();
        } else if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_WE_CHAT_ACCOUNT.getValue();
        } else if (AD_REDIRECT_WE_CHAT_PERSONAL.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_WE_CHAT_PERSONAL.getValue();
            adUnit.setWeChatPersonalId(unit.getWeChatPersonalId());
            adUnit.setWeChatPersonalNickName(unit.getWeChatPersonalNickName());
            WeChatPersonal weChatPersonal = weChatPersonalService.selectByPersonalId(unit.getWeChatPersonalId());
            adUnit.setWeChatPersonalQrCodeUrl(null == weChatPersonal ? "" : weChatPersonal.getQrCodeUrl());
        } else if (AD_REDIRECT_QQ_PERSONAL.getValue().equals(redirectUrlType)) {
            fromType = FROM_TYPE_QQ_PERSONAL.getValue();
            adUnit.setQqPersonalId(unit.getQqPersonalId());
            adUnit.setQqPersonalNickName(unit.getQqPersonalNickName());
            QqPersonal qqPersonal = qqPersonalService.selectByPersonalId(unit.getQqPersonalId());
            adUnit.setQqPersonalQrCodeUrl(null == qqPersonal ? "" : qqPersonal.getQrCodeUrl());
        }

        adUnit.setFrom_type(StringUtils.isBlank(fromType) ? redirectUrlType.toString() : fromType);
    }

    /**
     * 出纸流程处理
     *
     * @param adUnit
     * @param unit
     */
    private void handleTakeThePaperProcess(AdUnit adUnit, AdvertisingUnit unit, String randomNum) {

        Integer redirectUrlType = unit.getRedirectUrlType();

        if (!AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(redirectUrlType)) {
            return;
        }

        // 计算概率
        if (unit.getProbability() == null || unit.getProbability().equals(0) || unit.getProbability() > 100) {
            return;
        }
        if (unit.getProbability() == 100) {
            adUnit.setTakeThePaperProcess("40");
            if (StringUtils.isNotBlank(randomNum)) {
                setNotRExpire(ZJB_AD_URL + "_" + randomNum, unit.getAdUrl(), EXRP_5_MINUTE, ZJB_DB_57);
            }
            return;
        }
        // 直接出纸假设为 1 , 点击出纸假设为 2 ,则下面获取的概率为 2的权重
        int auto = 1;
        int click = 2;
        // 获取当前公众号点击图文消息出纸的概率
        BigDecimal divide = new BigDecimal(unit.getProbability()).divide(new BigDecimal(100), 2, BigDecimal.ROUND_HALF_UP);
        WeightRandom.WeightObj<Object> integerWeightObj = new WeightRandom.WeightObj<>(click, divide.doubleValue());
        BigDecimal subtract = new BigDecimal(1).subtract(divide);
        WeightRandom.WeightObj<Object> integerWeightObj1 = new WeightRandom.WeightObj<>(auto, subtract.doubleValue());
        WeightRandom<Object> objectWeightRandom = WeightRandom.create();
        objectWeightRandom.add(integerWeightObj);
        objectWeightRandom.add(integerWeightObj1);
        Object next = objectWeightRandom.next();
        if (Objects.nonNull(next)) {
            int integer = Integer.parseInt(next + "");
            if (integer == 1) {
                // 直接本次为直接出纸 修改C端出纸流程显示
                adUnit.setTakeThePaperProcess("30");
            } else if (integer == 2) {
                // 直接本次为点击图文消息出纸 修改C端出纸流程显示
                adUnit.setTakeThePaperProcess("40");
                if (StringUtils.isNotBlank(randomNum)) {
                    setNotRExpire(ZJB_AD_URL + "_" + randomNum, unit.getAdUrl(), EXRP_5_MINUTE, ZJB_DB_57);
                }
            }
        } else {
            adUnit.setTakeThePaperProcess(unit.getTakeThePaperProcess());
        }
    }

    /**
     * 保底任务广告
     *
     * @param adUnit
     * @param appId
     */
    private void guaranteedTask(AdUnit adUnit, String appId) {
        ScanTask scanTask = sanTaskService.selectScanTaskByTaskId(appId);

        if (null == scanTask) {
            return;
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionAImg())) {
            adUnit.setExpansionAImg(scanTask.getExpansionAImg());
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionAUrl())) {
            adUnit.setExpansionAUrl(scanTask.getExpansionAUrl());
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionBImg())) {
            adUnit.setExpansionBImg(scanTask.getExpansionBImg());
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionBUrl())) {
            adUnit.setExpansionBUrl(scanTask.getExpansionBUrl());
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionCImg())) {
            adUnit.setExpansionCImg(scanTask.getExpansionCImg());
        }

        if (StringUtils.isNotBlank(scanTask.getExpansionCUrl())) {
            adUnit.setExpansionCUrl(scanTask.getExpansionCUrl());
        }

    }

    /**
     * 微信小程序
     *
     * @param adUnit
     * @param appId
     */
    private void smallproceduresUnit(AdUnit adUnit, String appId) {
        ScanTask scanTask = sanTaskService.selectScanTaskByTaskId(appId);

        if (null == scanTask) {
            return;
        }

        if (!StringUtils.isNumeric(scanTask.getExpansionA())) {
            return;
        }

        SmallproceduresUnit smallproceduresUnit = smallProceduresUnitService.selectSmallproceduresUnitById(scanTask.getExpansionA());

        if (null == smallproceduresUnit) {
            return;
        }

        if (StringUtils.isNotBlank(smallproceduresUnit.getSpName())) {
            // update by guojing on 2019-10-14
            // 公众号名称最大限制8个字
            adUnit.setSpName("本次取纸由 "
                    + (smallproceduresUnit.getSpName().length() > 8 ? smallproceduresUnit.getSpName().substring(0, 8) + "..." : smallproceduresUnit.getSpName())
                    + " 赞助");
        }

        if (StringUtils.isNotBlank(smallproceduresUnit.getSpCode())) {
            adUnit.setSpCode(smallproceduresUnit.getSpCode());
        }
    }

    @Override
    public boolean isValid(WeChatAccountTaskInfo taskInfo) {
        if (null == taskInfo) {
            return false;
        }

        if (null == taskInfo.getData() || taskInfo.getData().isEmpty()) {
            return false;
        }

        WeChatAccountTaskInfo.Data data = taskInfo.getData().get(0);

        if (null == taskInfo.getRandomNum()
                || null == data
                || StringUtils.isAnyBlank(taskInfo.getOpenId(), taskInfo.getQrCode(), data.getQrcodeImgUrl(), data.getGzh_text())) {
            LOGGER.warn("公众号任务【{}】信息不全", taskInfo.getTaskId());
            return false;
        }

        String key = taskInfo.getRandomNum() + "_" + taskInfo.getTaskId() + "_we_chat_account_task_info_valid";
        String valid = getVStr(key, ZJB_DB_50);
        if (StringUtils.isNotBlank(valid)) {
            return Boolean.parseBoolean(valid);
        }
//
//        if ("1".equals(data.getType()) || "0".equals(data.getType())) {
//
//            String timeout = configService.selectConfigByKey(ZJB_HTTP_THIRD_SOCKET_TIMEOUT.getKey());
//            Integer socketTimeout = Integer.parseInt(timeout);
//            RequestConfig defaultRequestConfig = RequestConfig.copy(HttpClient.defaultRequestConfig).setSocketTimeout(socketTimeout).build();
//
//            String adminUrl = configService.selectConfigByKey(ZJB_ADMIN_ZHIJINBAO_URI.getKey());
//            String uri = String.format("%s/wechat/outPaper/%s/%s/%s", adminUrl, taskInfo.getOpenId(), data.getAppid(), taskInfo.getQrCode());
//            String content = HttpClient.get(uri, defaultRequestConfig);
//            if (StringUtils.isBlank(content)) {
//                LOGGER.error("调用地址{}失败", uri);
//                JedisPoolCacheUtils.setRExpire(key, String.valueOf(false), EXRP_15_SECOND, ZJB_DB_50);
//                return false;
//            }
//
//            LOGGER.info("调用地址{}结果：{}", uri, content);
//
//            if (content.charAt(0) != '{') {
//                LOGGER.error("扫码流水号{}调用地址{}返回数据格式错误:{}", taskInfo.getRandomNum(), uri, content);
//                JedisPoolCacheUtils.setRExpire(key, String.valueOf(false), EXRP_15_SECOND, ZJB_DB_50);
//                return false;
//            }
//
//            JSONObject jsonObject = JSON.parseObject(content);
//
//            Object obj = jsonObject.get("code");
//
//            if (null == obj || !obj.equals(0)) {
//                LOGGER.warn("扫码流水号{}调用地址{}返回业务数据【{}】不满足", taskInfo.getRandomNum(), uri, content);
//                JedisPoolCacheUtils.setRExpire(key, String.valueOf(false), EXRP_15_SECOND, ZJB_DB_50);
//                return false;
//            }
//        }

        setRExpire(key, String.valueOf(true), EXRP_15_SECOND, ZJB_DB_50);
        return true;
    }

    @Override
    public boolean isEventMatch(CombinationRequest combination, AdvertisingPlan win) {
        AppIdOpenIdIndex appIdOpenIdIndex = appIdOpenIdIndexService.selectByZjbOpenIdAndAppId(combination.getOpenId(), win.getAdAppId());

        if (null == appIdOpenIdIndex) {
            //未知，当一致处理
            LOGGER.info("用户【{}】公众号【{}】记录不存在", combination.getOpenId(), win.getAdAppId());
            return true;
        }

        if (StringUtils.isAnyBlank(appIdOpenIdIndex.getOpenid(), appIdOpenIdIndex.getAppid())) {
            //未知，当一致处理
            LOGGER.info("用户【{}】公众号【{}】记录不存在", combination.getOpenId(), win.getAdAppId());
            return true;
        }

        // 获取授权token
        String accessToken = WeChatUtil.getAuthorizerAccessToken(appIdOpenIdIndex.getAppid());

        if (StringUtils.isBlank(accessToken)) {
            //未知，当一致处理
            LOGGER.info("用户【{}】公众号【{}】Token获取失败", combination.getOpenId(), win.getAdAppId());
            return true;
        }

        SubscribeUserInfo subscribeUserInfo = WeChatUtil.subscribeUserInfo(accessToken, appIdOpenIdIndex.getOpenid());

        if (null == subscribeUserInfo || null == subscribeUserInfo.getSubscribe()) {
            //未知，当一致处理
            LOGGER.info("用户【{}】公众号【{}】关注信息查询失败", combination.getOpenId(), win.getAdAppId());
            return true;
        }

        LOGGER.info("用户【{}】公众号【{}】关注信息：{}", combination.getOpenId(), win.getAdAppId(), JSON.toJSON(subscribeUserInfo));

        if (YES.getValue().equals(subscribeUserInfo.getSubscribe())
                && AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue().equals(appIdOpenIdIndex.getEvent())) {
            return true;
        }

        if (NO.getValue().equals(subscribeUserInfo.getSubscribe())
                && AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue().equals(appIdOpenIdIndex.getEvent())) {
            return true;
        }

        /*不一致，同步记录*/
        if (YES.getValue().equals(subscribeUserInfo.getSubscribe())) {
            appIdOpenIdIndex.setEvent(AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue());
            appIdOpenIdIndexService.updateAppIdOpenIdIndexEvent(appIdOpenIdIndex);
        }

        if (NO.getValue().equals(subscribeUserInfo.getSubscribe())) {
            appIdOpenIdIndex.setEvent(AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue());
            appIdOpenIdIndexService.updateAppIdOpenIdIndexEvent(appIdOpenIdIndex);
        }

        return false;
    }

    @Override
    public WeChatAccountTaskInfo manualWeChatAccount(CombinationRequest combination, AdvertisingPlan win) {

        String keyWeChatAccountTaskInfo = "we_chat_account_task_info_" + combination.getRandomNum() + "_" + win.getPlanId();
        WeChatAccountTaskInfo taskInfo = getV(keyWeChatAccountTaskInfo, ZJB_DB_50, WeChatAccountTaskInfo.class);

        if (null != taskInfo) {
            return taskInfo;
        }

        if (StringUtils.isBlank(win.getAdAppId())) {
            LOGGER.info("扫码流水号{}广告计划{}缺失公众号", combination.getRandomNum(), win.getPlanId());
            return null;
        }

        //根据appid获取第三方公众号信息
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(win.getAdAppId());
        if (componentAuthorizationInfo == null || StringUtils.isEmpty(componentAuthorizationInfo.getZjbAppId())) {
            LOGGER.error("缺失第三方公众号信息,adAppId:" + win.getAdAppId());
            return null;
        }

        try {
            //获取第三方开放平台对接渠道账号信息
            OpenApiAccountDTO openApiAccount = feignAdminCoreService.getOpenApiAccountInfoByAppId(componentAuthorizationInfo.getZjbAppId());
            if (openApiAccount == null || StringUtils.isEmpty(openApiAccount.getAppid()) || StringUtils.isEmpty(openApiAccount.getSecret())) {
                LOGGER.error("缺失公众号授权信息,adAppId:" + win.getAdAppId());
                return null;
            }
            if (StringUtils.isEmpty(componentAuthorizationInfo.getPublicPlatformUrl())) {
                LOGGER.warn("缺失获取第三方公众号URL信息,adAppId:" + win.getAdAppId());
                return null;
            }

            String outPaperIdentify = DateUtils.dateTimeNow() + SNOWFLAKE.nextId();
            String timestamp = String.valueOf(System.currentTimeMillis());
            //将设备及用户信息放入缓存
            Map<String, String> rmap = new HashMap<>(6);
            rmap.put("openId", combination.getOpenId());
            rmap.put("qrcode", combination.getQrcode());
            rmap.put("randomNum", combination.getRandomNum().toString());
            rmap.put("thirdPlatFormChannel", THIRD_PLATFORM_CHANNEL_WPT.getValue());
            setVExpire(RDEIS_THIRD_PARTY_OUT_PAPER_IDENTIFY + "_" + outPaperIdentify, rmap, 300, ZJB_DB_6);

            String nonce_str = IdUtil.simpleUUID();
            StringBuffer sb = new StringBuffer();
            sb.append("nonce_str=");
            sb.append(nonce_str);
            sb.append("&out_paper_identify=");
            sb.append(outPaperIdentify);
            sb.append("&timestamp=");
            sb.append(timestamp);
            sb.append("&zjb_appid=");
            sb.append(openApiAccount.getAppid());
            sb.append("&zjb_secret=");
            sb.append(openApiAccount.getSecret());
            String sign = DigestUtils.md5Hex(sb.toString()).toUpperCase();
            //获取该openid剩余出纸次数
            String curate = DateUtils.getDate();
            DeviceDTO device;
            try {
                device = deviceService.selectDeviceByQrcode(combination.getQrcode());
            } catch (Exception e) {
                device = deviceService.selectDeviceByQrcodeb(combination.getQrcode());
            }
            //检查
            String day_qrcount = getVStr(REDIS_MINI_OPENID_DAY_QRCOUNT + curate + combination.getOpenId(), ZJB_DB_1);
            //从系统配置中读取最大扫码次数
            String max_count = configService.selectConfigByKey(DEVICE_OUTPAPER_MAX_COUNT.getKey());
            //获取用户信息
            AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(combination.getOpenId());
            if (null != device.getAgencyId()) {
                // 2019/12/20 获取该设备所属代理商设置的最大扫码数
                Agency agency = agencyService.getMaxCount(device.getAgencyId());
                if (null != agency) {
                    if (BROWSER_TYPE_WX.getValue().equals(authorizationUserInfo.getSourceType()) && null != agency.getWxCount()) {
                        max_count = agency.getWxCount().toString();
                    } else if (BROWSER_TYPE_ZFB.getValue().equals(authorizationUserInfo.getSourceType()) && null != agency.getZfbCount()) {
                        max_count = agency.getZfbCount().toString();
                    }
                }
            }

            if (StringUtils.isEmpty(day_qrcount)) {
                day_qrcount = "0";
            }
            if (StringUtils.isEmpty(max_count)) {
                max_count = "5"; //默认5次
            }
            int haveTime = 0;
            haveTime = Integer.parseInt(max_count) - Integer.parseInt(day_qrcount) - 1;
            String haveTimes = "0";
            if (haveTime > 0) {
                haveTimes = String.valueOf(haveTime);
            }
            String adminUrl = StringUtils.defaultIfBlank(configService.selectConfigByKey(ZJB_ADMIN_HOST.getKey()), ZJB_ADMIN_HOST.getValue());
            String code = UUID.randomUUID().toString();
            String url = adminUrl + "/wechat/gzh_redirect_url?code=" + code;
            if (device != null && StringUtils.isNotEmpty(device.getQrcode())) {
                setRExpire(GZH_PUSH_URL + "_" + code, device.getQrcode(), EXRP_5_MINUTE, ZJB_DB_6);
            }
            //新用户推送消息文案
            String message_content = "领取成功，正在出纸..\n\n"
                    + "<a href='" + url + "'>点击继续取纸，免扫码速度更快，今日剩余" + haveTimes + "次</a>";
            //已关注过用户推送消息文案
            int followUserhaveTime = 0;
            followUserhaveTime = Integer.parseInt(max_count) - Integer.parseInt(day_qrcount);
            String followUserhaveTimes = "0";
            if (followUserhaveTime > 0) {
                followUserhaveTimes = String.valueOf(followUserhaveTime);
            }
            String followed_message_content = "您已关注该公众号，重复关注不出纸哦~\n\n"
                    + "<a href='" + url + "'>点击继续取纸，免扫码速度更快，今日剩余" + followUserhaveTimes + "次</a>";
            HashMap<String, Object> paramMap = new HashMap<String, Object>();
            paramMap.put("out_paper_identify", outPaperIdentify);
            paramMap.put("nonce_str", nonce_str);
            paramMap.put("timestamp", timestamp);
            paramMap.put("sign", sign);
            paramMap.put("message_content", message_content);
            paramMap.put("followed_message_content", followed_message_content);
            String param = JSON.toJSON(paramMap).toString();
            LOGGER.info("调用第三方公众号接口：URL：" + componentAuthorizationInfo.getPublicPlatformUrl() + ";adAppId:" + win.getAdAppId() + "请求参数：out_paper_identify:" + outPaperIdentify + ",nonce_str:" + nonce_str + ",timestamp:" + timestamp + ",sign:" + sign + ",message_content:" + message_content + ",followed_message_content" + followed_message_content);
            LOGGER.info("调用第三方公众号接口：URL：" + componentAuthorizationInfo.getPublicPlatformUrl() + ";adAppId:" + win.getAdAppId() + "验签参数：out_paper_identify:" + outPaperIdentify + ",nonce_str:" + nonce_str + ",zjb_appid:" + openApiAccount.getAppid() + ",zjb_secret:" + openApiAccount.getSecret() + ",timestamp:" + timestamp + ",sign:" + sign);
            String returnResult = HttpUtil.post(componentAuthorizationInfo.getPublicPlatformUrl(), param);
            LOGGER.info("调用第三方公众号接口：URL：" + componentAuthorizationInfo.getPublicPlatformUrl() + ";APPID:" + win.getAdAppId() + "返回数据：" + returnResult);
            if (StringUtils.isBlank(returnResult)) {
                LOGGER.warn("第三方公众号返回结果为空,adAppId:" + win.getAdAppId());
                return null;
            }
            try {
                ThirdPlatformResponse thirdPlatformResponse = JSON.parseObject(returnResult, ThirdPlatformResponse.class);
                if (thirdPlatformResponse == null || 0 != thirdPlatformResponse.getCode() || thirdPlatformResponse.getData() == null) {
                    LOGGER.warn("第三方公众号返回结果有误,adAppId:" + win.getAdAppId());
                    return null;
                }
                ThirdPlatformData data = thirdPlatformResponse.getData();
                if (data == null || StringUtils.isEmpty(data.getQrcode_url())) {
                    LOGGER.warn("第三方公众号返回结果为空,adAppId:" + win.getAdAppId());
                    return null;
                }
                String qrcode_url = data.getQrcode_url();
                String gzh_name = componentAuthorizationInfo.getNickName();
                BlackThirdPlatformGzh blackThirdPlatformGzh = new BlackThirdPlatformGzh();
                blackThirdPlatformGzh.setThirdPlatformAppId(win.getAdAppId());
                blackThirdPlatformGzh.setThirdPlatformChannel(THIRD_PLATFORM_CHANNEL_WPT.getValue());
                int blackThirdPlatformCount = blackThirdPlatformGzhService.getBlackThirdPlatformGzhCount(blackThirdPlatformGzh);
                if (StringUtils.isNotEmpty(qrcode_url) && StringUtils.isNotEmpty(gzh_name) && blackThirdPlatformCount <= 0) {


                    taskInfo = new WeChatAccountTaskInfo();
                    List<WeChatAccountTaskInfo.Data> dataList = new ArrayList<>();
                    WeChatAccountTaskInfo.Data weChatAccount = new WeChatAccountTaskInfo.Data();

                    weChatAccount.setAppid(win.getAdAppId());
                    weChatAccount.setGzh_text("本次取纸由  " + (gzh_name.length() > 8 ? gzh_name.substring(0, 8) + "..." : gzh_name) + "  赞助");
                    weChatAccount.setQrcodeUrl(qrcode_url);
                    weChatAccount.setQrcodeImgUrl(qrcode_url);
                    //用于点击时将公众号信息记录到公众号记录表中
                    weChatAccount.setType("98");
                    weChatAccount.setThirdPlatformChannel(THIRD_PLATFORM_CHANNEL_WPT.getValue());
                    weChatAccount.setAppName("微拍堂");

                    dataList.add(weChatAccount);
                    taskInfo.setData(dataList);

                    setVExpire(keyWeChatAccountTaskInfo, taskInfo, EXRP_5_MINUTE, ZJB_DB_50);

                    return taskInfo;
                }
            } catch (Exception e) {
                LOGGER.error("第三方公众号返回结果解析异常：" + ExceptionUtils.getFullStackTrace(e));
                return null;
            }

        } catch (Exception e) {
            LOGGER.error("获取人工上架的第三方公众号信息异常：" + e.getMessage(), e);
        }

        return null;
    }

    /**
     * 非竞价广告
     *
     * @param adCombinationInfo
     * @param openId
     * @param combination
     */
    @Override
    public void withoutBiddingPriceAdvertising(AdCombinationInfo adCombinationInfo, String openId, String randomNum, CombinationRequest combination) {

        //非竞价广告首页浮层弹窗
        getWithoutBiddingPriceAd(adCombinationInfo,openId,randomNum,combination);
        //付费取纸成功页面广告
        getPayAdWithoutBiddingPrice(adCombinationInfo,openId,randomNum,combination);
        //极速取纸页面广告
        getJisuAdWithoutBiddingPrice(adCombinationInfo,openId,randomNum,combination);
        //个人中心广告
        getPersonalAdWithoutBiddingPrice(adCombinationInfo,openId,randomNum,combination);
    }

    /**
     * 新版付费特殊设备
     *
     * @param adCombinationInfo
     * @param deviceInfo
     */
    @Override
    public void paySpecialDevice(AdCombinationInfo adCombinationInfo, AdvertisingDeviceInfo deviceInfo) {
        if (null == adCombinationInfo || null == deviceInfo) {
            return;
        }
        String deviceSn = deviceInfo.getDeviceSn();
        if (StringUtils.isEmpty(deviceSn)) {
            return;
        }
        String paySpecialDeviceSn = configService.selectConfigByKey("zjb_pay_special_device_sn");
        if (StringUtils.isNotEmpty(paySpecialDeviceSn)) {
            String[] paySpecialDeviceSnArray = paySpecialDeviceSn.split(";");
            if (paySpecialDeviceSnArray != null && paySpecialDeviceSnArray.length > 0) {
                if (Arrays.asList(paySpecialDeviceSnArray).contains(deviceSn)) {
                    adCombinationInfo.setSpecialPay(true);
                    return;
                }
            }
        }
        adCombinationInfo.setSpecialPay(false);
    }

    /**
     * 获取设备定向投放广告
     *
     * @param adCombinationInfo
     * @param deviceId
     */
    private void getAssignBanner(AdCombinationInfo adCombinationInfo, Integer deviceId, Map<Integer, AdUnit> map) {
        if (null == adCombinationInfo || null == deviceId) {
            return;
        }
        //获取设备配置的定向广告信息
        DeviceAssignBanner deviceAssignBanner = new DeviceAssignBanner();
        deviceAssignBanner.setDeviceId(deviceId);
        deviceAssignBanner.setDeleted(0);
        List<DeviceAssignBanner> deviceAssignBannerList = deviceAssignBannerService.selectDeviceAssignBannerList(deviceAssignBanner);
        if (deviceAssignBannerList == null || deviceAssignBannerList.isEmpty()) {
            if (StringUtils.isNotEmpty(map)) {
                for (Map.Entry<Integer, AdUnit> entry : map.entrySet()) {
                    if (null != entry.getValue()) {
                        adCombinationInfo.getBeancurd().add(entry.getValue());
                    }
                }
            }
            return;
        }
        for (DeviceAssignBanner deviceAssignBanner_db : deviceAssignBannerList) {
            if (deviceAssignBanner_db == null || deviceAssignBanner_db.getAdId() == null) {
                continue;
            }
            AdvertisingUnit advertisingUnit = advertisingUnitFansService.selectAdvertisingUnitFansByAdId(deviceAssignBanner_db.getAdId());
            if (null == advertisingUnit || null == advertisingUnit.getAdUseStatus()) {
                continue;
            }
            if (null != advertisingUnit.getAdUseStatus() && !(AD_USE_YES.getValue().equals(advertisingUnit.getAdUseStatus()))) {
                continue;
            }
            String adSpaceIdentifier = advertisingUnit.getAdSpaceIdentifier();
            if (AD_FANS_BANNER.getValue().equals(adSpaceIdentifier)) {
                /*指定-Banner*/
                AdUnit mapUnit = new AdUnit();
                handleAdvertisingUnit(mapUnit, advertisingUnit, null);
                adCombinationInfo.getAssignItems().add(mapUnit);
            } else if (AD_FANS_BEANCURD_CUBE.getValue().equals(adSpaceIdentifier)) {
                //指定-豆腐块
                if (StringUtils.isNotEmpty(map)) {
                    for (Iterator<Map.Entry<Integer, AdUnit>> paramMap = map.entrySet().iterator(); paramMap.hasNext(); ) {
                        Map.Entry<Integer, AdUnit> entry = paramMap.next();
                        if (entry.getKey().equals(deviceAssignBanner_db.getAdPosition())) {
                            paramMap.remove();
                        }
                    }
                }
                AdUnit mapUnit = new AdUnit();
                advertisingUnit.setPosition(deviceAssignBanner_db.getAdPosition());
                handleAdvertisingUnit(mapUnit, advertisingUnit, null);
                adCombinationInfo.getBeancurd().add(mapUnit);
            }
        }
        if (StringUtils.isNotEmpty(map)) {
            for (Map.Entry<Integer, AdUnit> entry : map.entrySet()) {
                if (null != entry.getValue()) {
                    adCombinationInfo.getBeancurd().add(entry.getValue());
                }
            }
        }
    }

    /**
     * 获取用户通过某台设备在某次取纸是是否屏蔽公众号
     *
     * @return 返回值大于0屏蔽，否则不屏蔽
     */
    private int getForbidPutOfficialAccountCount(String deviceSn, String openId) {
        if (StringUtils.isEmpty(deviceSn) || StringUtils.isEmpty(openId)) {
            return 0;
        }
        //获取设备信息
        DeviceDTO device = deviceService.selectDeviceBySn(deviceSn);
        if (device == null) {
            return 0;
        }

        //售卖规则五
        MediumSellRull mediumSellRull = mediumSellRullService.selectMediumSellRullById(5);
        if (mediumSellRull == null || (mediumSellRull != null && RULL_STATUS_LOSE_EFFECTIV.getValue() == mediumSellRull.getRullStatus())) {
            return 0;
        }
        //获取该用户取纸次数
        Integer takePaperTime = null;
        String curate = DateUtils.getDate();
        String day_qrcount = getVStr(REDIS_MINI_OPENID_DAY_QRCOUNT + curate + openId, ZJB_DB_1);
        if (StringUtils.isEmpty(day_qrcount)) {
            takePaperTime = 1;
        } else {
            takePaperTime = Integer.parseInt(day_qrcount) + 1;
        }

        ForbidPutOfficialAccountConfig config = new ForbidPutOfficialAccountConfig();
        config.setDeviceId(device.getId());
        config.setTakePaperTime(takePaperTime);
        return forbidPutOfficialAccountConfigService.getForbidPutOfficialAccountCount(config);
    }

    /**
     * 校验是否过滤自有平台个人号
     *
     * @param personalAppId
     * @param openId
     * @return
     */
    private boolean checkFilterPersonalAccount(String personalAppId, String openId) {
        boolean result = false;
        if (StringUtils.isEmpty(personalAppId) || StringUtils.isEmpty(openId)) {
            return true;
        }
        //校验该appid是否在黑名单
        BlackPersonalAccount blackPersonalAccount = new BlackPersonalAccount();
        blackPersonalAccount.setPersonalAppId(personalAppId);
        blackPersonalAccount.setDeleted(0);
        List<BlackPersonalAccount> blackPersonalAccountList = blackPersonalAccountService.selectBlackPersonalAccountList(blackPersonalAccount);
        if (blackPersonalAccountList != null && !(blackPersonalAccountList.isEmpty())) {
            return true;
        }
        //校验该用户是否已关注过该个人号
        GrhAppidOpenidIndex grhAppidOpenidIndex = grhAppidOpenidIndexService.selectByZjbOpenIdAndPersonalAppId(openId, personalAppId);
        if (grhAppidOpenidIndex != null) {
            return true;
        }
        return result;
    }

    /**
     * 付费取纸成功页面广告
     * @param adCombinationInfo
     * @param openId
     * @param randomNum
     * @param combination
     */
    private void getPayAdWithoutBiddingPrice(AdCombinationInfo adCombinationInfo,String openId,String randomNum,CombinationRequest combination){
        if(null == adCombinationInfo || StringUtils.isEmpty(openId) || StringUtils.isEmpty(randomNum) || null == combination){
            LOGGER.info("获取付费取纸成功页面广告用户【{}】投放广告方案【{}】不存在,随机数【{}】,combination：【{}】", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
            return;
        }
        try{
            AdvertisingDeviceInfo deviceInfo = combination.getDeviceInfo();
            if(null == deviceInfo || StringUtils.isEmpty(deviceInfo.getDeviceSn())){
                LOGGER.info("获取付费取纸成功页面广告用户【{}】投放广告方案【{}】,随机数【{}】,combination：【{}】设备信息不存在", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
                return;
            }
            String deviceSn = deviceInfo.getDeviceSn();
            WithoutBiddingAd withoutBiddingAd = new WithoutBiddingAd();
            withoutBiddingAd.setAdUseStatus(AD_USE_YES.getValue());
            withoutBiddingAd.setAdSpaceIdentifier(AD_FANS_PAY_AD.getValue());
            withoutBiddingAd.setAdvertisementStatus(ADVERTISEMENT_STATUS_RUN.getValue());
            List<AdvertisingUnit> advertisingUnitList = advertisementWithoutBiddingPriceService.getAdvertisingUnitFansInfo(withoutBiddingAd);
            if(advertisingUnitList != null && !(advertisingUnitList.isEmpty())) {
                boolean adEffective = false;
                for (AdvertisingUnit advertisingUnitFans : advertisingUnitList) {
                    if (advertisingUnitFans != null && StringUtils.isNotEmpty(advertisingUnitFans.getRedirectUrl()) && StringUtils.isNotEmpty(advertisingUnitFans.getAdPhotoUrl()) && null != advertisingUnitFans.getId()) {
                        //该胜出广告是否指定了该设备
                        AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
                        advertisementPlanDevice.setDeleted(NO.getValue());
                        advertisementPlanDevice.setAdvertisingUnitId(advertisingUnitFans.getId());
                        List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
                        if (advertisementPlanDevices != null && !(advertisementPlanDevices.isEmpty())) {
                            for (AdvertisementPlanDevice planDevice : advertisementPlanDevices) {
                                if (null == planDevice.getRadioDeviceSn()) {
                                    logger.error("zjb_advertisement_plan_device中的id为{}，的设备SN定向为空！", planDevice.getId());
                                    continue;
                                }
                                if (AD_RADIO_DEVICE_SN_ALL.getValue().equals(planDevice.getRadioDeviceSn())) {
                                    adEffective = true;
                                    break;
                                }
                                if (StringUtils.isEmpty(planDevice.getRegex())) {
                                    continue;
                                }
                                Pattern pattern = Pattern.compile(planDevice.getRegex());
                                Matcher matcher = pattern.matcher(deviceSn);
                                if (matcher.matches()) {
                                    adEffective = true;
                                    break;
                                }
                            }
                        }

                    }
                    if(adEffective){
                        logger.info("获取付费取纸成功页面广告用户【{}】随机数【{}】获取付费取纸成功页面广告成功【{}】",openId,randomNum,JSON.toJSONString(advertisingUnitFans));
                        /*扫码取纸*/
                        AdUnit mapUnit = new AdUnit();
                        handleAdvertisingUnit(mapUnit, advertisingUnitFans, randomNum);
                        adCombinationInfo.setPayAd(mapUnit);
                        //临时记录点击次数
                        Map<String, Object> mapQueue = new HashMap<>(4);
                        mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_EVENT, advertisingUnitFans.getId() + "@" + openId);
                        // 公众号展示数据发送给dsp
                        lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));

                        return;
                    }

                }
            }
        }catch(Exception e){
            LOGGER.error("获取付费取纸成功页面广告信息异常：" + e.getMessage(), e);
            return;
        }
    }

    /**
     * 极速取纸成功页面广告
     * @param adCombinationInfo
     * @param openId
     * @param randomNum
     * @param combination
     */
    private void getJisuAdWithoutBiddingPrice(AdCombinationInfo adCombinationInfo,String openId,String randomNum,CombinationRequest combination){
        if(null == adCombinationInfo || StringUtils.isEmpty(openId) || StringUtils.isEmpty(randomNum) || null == combination){
            LOGGER.info("获取极速取纸成功页面广告用户【{}】投放广告方案【{}】不存在,随机数【{}】,combination：【{}】", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
            return;
        }
        try{
            AdvertisingDeviceInfo deviceInfo = combination.getDeviceInfo();
            if(null == deviceInfo || StringUtils.isEmpty(deviceInfo.getDeviceSn())){
                LOGGER.info("获取极速取纸成功页面广告用户【{}】投放广告方案【{}】,随机数【{}】,combination：【{}】设备信息不存在", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
                return;
            }
            String deviceSn = deviceInfo.getDeviceSn();
            WithoutBiddingAd withoutBiddingAd = new WithoutBiddingAd();
            withoutBiddingAd.setAdUseStatus(AD_USE_YES.getValue());
            withoutBiddingAd.setAdSpaceIdentifier(AD_FANS_JISU_AD.getValue());
            withoutBiddingAd.setAdvertisementStatus(ADVERTISEMENT_STATUS_RUN.getValue());
            List<AdvertisingUnit> advertisingUnitList = advertisementWithoutBiddingPriceService.getAdvertisingUnitFansInfo(withoutBiddingAd);
            if(advertisingUnitList != null && !(advertisingUnitList.isEmpty())) {
                boolean adEffective = false;
                for (AdvertisingUnit advertisingUnitFans : advertisingUnitList) {
                    if (advertisingUnitFans != null && StringUtils.isNotEmpty(advertisingUnitFans.getRedirectUrl()) && StringUtils.isNotEmpty(advertisingUnitFans.getAdPhotoUrl()) && null != advertisingUnitFans.getId()) {
                        //该胜出广告是否指定了该设备
                        AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
                        advertisementPlanDevice.setDeleted(NO.getValue());
                        advertisementPlanDevice.setAdvertisingUnitId(advertisingUnitFans.getId());
                        List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
                        if (advertisementPlanDevices != null && !(advertisementPlanDevices.isEmpty())) {
                            for (AdvertisementPlanDevice planDevice : advertisementPlanDevices) {
                                if (null == planDevice.getRadioDeviceSn()) {
                                    logger.error("zjb_advertisement_plan_device中的id为{}，的设备SN定向为空！", planDevice.getId());
                                    continue;
                                }
                                if (AD_RADIO_DEVICE_SN_ALL.getValue().equals(planDevice.getRadioDeviceSn())) {
                                    adEffective = true;
                                    break;
                                }
                                if (StringUtils.isEmpty(planDevice.getRegex())) {
                                    continue;
                                }
                                Pattern pattern = Pattern.compile(planDevice.getRegex());
                                Matcher matcher = pattern.matcher(deviceSn);
                                if (matcher.matches()) {
                                    adEffective = true;
                                    break;
                                }
                            }
                        }

                    }
                    if(adEffective){
                        logger.info("获取极速取纸成功页面广告用户【{}】随机数【{}】获取付费取纸成功页面广告成功【{}】",openId,randomNum,JSON.toJSONString(advertisingUnitFans));
                        /*扫码取纸*/
                        AdUnit mapUnit = new AdUnit();
                        handleAdvertisingUnit(mapUnit, advertisingUnitFans, randomNum);
                        adCombinationInfo.setJisuAd(mapUnit);
                        //临时记录点击次数
                        Map<String, Object> mapQueue = new HashMap<>(4);
                        mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_EVENT, advertisingUnitFans.getId() + "@" + openId);
                        // 公众号展示数据发送给dsp
                        lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));
                        return;
                    }

                }
            }
        }catch(Exception e){
            LOGGER.error("获取极速取纸成功页面广告信息异常：" + e.getMessage(), e);
            return;
        }
    }

    /**
     * 个人中心取纸成功页面广告
     * @param adCombinationInfo
     * @param openId
     * @param randomNum
     * @param combination
     */
    private void getPersonalAdWithoutBiddingPrice(AdCombinationInfo adCombinationInfo,String openId,String randomNum,CombinationRequest combination){
        if(null == adCombinationInfo || StringUtils.isEmpty(openId) || StringUtils.isEmpty(randomNum) || null == combination){
            LOGGER.info("获取个人中心页面广告用户【{}】投放广告方案【{}】不存在,随机数【{}】,combination：【{}】", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
            return;
        }
        try{
            AdvertisingDeviceInfo deviceInfo = combination.getDeviceInfo();
            if(null == deviceInfo || StringUtils.isEmpty(deviceInfo.getDeviceSn())){
                LOGGER.info("获取个人中心页面广告用户【{}】投放广告方案【{}】,随机数【{}】,combination：【{}】设备信息不存在", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
                return;
            }
            String deviceSn = deviceInfo.getDeviceSn();
            WithoutBiddingAd withoutBiddingAd = new WithoutBiddingAd();
            withoutBiddingAd.setAdUseStatus(AD_USE_YES.getValue());
            withoutBiddingAd.setAdSpaceIdentifier(AD_FANS_PERSONAL_AD.getValue());
            withoutBiddingAd.setAdvertisementStatus(ADVERTISEMENT_STATUS_RUN.getValue());
            List<AdvertisingUnit> advertisingUnitList = advertisementWithoutBiddingPriceService.getAdvertisingUnitFansInfo(withoutBiddingAd);
            if(advertisingUnitList != null && !(advertisingUnitList.isEmpty())) {
                boolean adEffective = false;
                for (AdvertisingUnit advertisingUnitFans : advertisingUnitList) {
                    if (advertisingUnitFans != null && StringUtils.isNotEmpty(advertisingUnitFans.getRedirectUrl()) && StringUtils.isNotEmpty(advertisingUnitFans.getAdPhotoUrl()) && null != advertisingUnitFans.getId()) {
                        //该胜出广告是否指定了该设备
                        AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
                        advertisementPlanDevice.setDeleted(NO.getValue());
                        advertisementPlanDevice.setAdvertisingUnitId(advertisingUnitFans.getId());
                        List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
                        if (advertisementPlanDevices != null && !(advertisementPlanDevices.isEmpty())) {
                            for (AdvertisementPlanDevice planDevice : advertisementPlanDevices) {
                                if (null == planDevice.getRadioDeviceSn()) {
                                    logger.error("zjb_advertisement_plan_device中的id为{}，的设备SN定向为空！", planDevice.getId());
                                    continue;
                                }
                                if (AD_RADIO_DEVICE_SN_ALL.getValue().equals(planDevice.getRadioDeviceSn())) {
                                    adEffective = true;
                                    break;
                                }
                                if (StringUtils.isEmpty(planDevice.getRegex())) {
                                    continue;
                                }
                                Pattern pattern = Pattern.compile(planDevice.getRegex());
                                Matcher matcher = pattern.matcher(deviceSn);
                                if (matcher.matches()) {
                                    adEffective = true;
                                    break;
                                }
                            }
                        }

                    }
                    if(adEffective){
                        logger.info("获取个人中心页面广告用户【{}】随机数【{}】获取付费取纸成功页面广告成功【{}】",openId,randomNum,JSON.toJSONString(advertisingUnitFans));
                        /*扫码取纸*/
                        AdUnit mapUnit = new AdUnit();
                        handleAdvertisingUnit(mapUnit, advertisingUnitFans, randomNum);
                        adCombinationInfo.setPersonalAd(mapUnit);
                        //临时记录点击次数
                        Map<String, Object> mapQueue = new HashMap<>(4);
                        mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_EVENT, advertisingUnitFans.getId() + "@" + openId);
                        // 公众号展示数据发送给dsp
                        lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));
                        return;
                    }
                }
            }
        }catch(Exception e){
            LOGGER.error("获取个人中心页面广告信息异常：" + e.getMessage(), e);
            return;
        }
    }

    /**
     * 获取浮层弹窗非竞价广告
     * @param adCombinationInfo
     * @param openId
     * @param randomNum
     * @param combination
     */
    private void getWithoutBiddingPriceAd(AdCombinationInfo adCombinationInfo,String openId,String randomNum,CombinationRequest combination){
        try {
            if (null == adCombinationInfo || StringUtils.isEmpty(openId)) {
                LOGGER.info("用户【{}】投放广告方案【{}】不存在", openId, JSON.toJSONString(adCombinationInfo));
                return;
            }
            AdvertisingDeviceInfo deviceInfo = combination.getDeviceInfo();
            if(null == deviceInfo || StringUtils.isEmpty(deviceInfo.getDeviceSn())){
                LOGGER.info("获取个人中心页面广告用户【{}】投放广告方案【{}】,随机数【{}】,combination：【{}】设备信息不存在", openId, JSON.toJSONString(adCombinationInfo),randomNum,JSON.toJSONString(combination));
                return;
            }
            String deviceSn = deviceInfo.getDeviceSn();
            //判断是否为第一次请求广告
            String first = getVStr(REDIS_OPENID_DAY_SHOW_AD_FIRST + "_" + DateUtils.getDate() + "_" + openId, ZJB_DB_59);
            if (StringUtils.isNotEmpty(first)) {
                return;
            }
            //将第一次获取广告记入缓存
            setRExpire(REDIS_OPENID_DAY_SHOW_AD_FIRST + "_" + DateUtils.getDate() + "_" + openId, "false", EXRP_DAY, ZJB_DB_59);
            //第一次获取广告概率
            String showWithoutBiddingPriceAdRate = configService.selectConfigByKey("show_without_bidding_price_ad_rate");
            if (StringUtils.isEmpty(showWithoutBiddingPriceAdRate)) {
                showWithoutBiddingPriceAdRate = "40";
            }

            int withoutBiddingPriceAdRate = Integer.parseInt(showWithoutBiddingPriceAdRate);
            //生成1到100之间到一个随机数
            int participateBidPercentage = ThreadLocalRandom.current().nextInt(1, 100);
            LOGGER.info("非竞价广告获取随机数【{}】,用户openId【{}】", participateBidPercentage, openId);


            if (participateBidPercentage > withoutBiddingPriceAdRate) {
                return;
            }
            //获取要过滤的广告id列表
            List<Integer> adIdList = withoutBiddingAdidOpenidIndexService.getFilterAdIdList(openId);
            //获取胜出的非竞价广告信息
            WithoutBiddingAd withoutBiddingAd = new WithoutBiddingAd();
            if (adIdList != null && !(adIdList.isEmpty())) {
                withoutBiddingAd.setAdIdList(adIdList);
            }

            withoutBiddingAd.setAdUseStatus(AD_USE_YES.getValue());
            withoutBiddingAd.setAdvertisementStatus(ADVERTISEMENT_STATUS_RUN.getValue());
            withoutBiddingAd.setAdSpaceIdentifier(AD_FANS_WITHOUT_BIDDING_PRICE_AD.getValue());
            List<AdvertisingUnit> advertisingUnitList = advertisementWithoutBiddingPriceService.getAdvertisingUnitFansInfo(withoutBiddingAd);
            if(advertisingUnitList != null && !(advertisingUnitList.isEmpty())) {
                boolean adEffective = false;
                for (AdvertisingUnit advertisingUnitFans : advertisingUnitList) {
                    if (advertisingUnitFans != null && StringUtils.isNotEmpty(advertisingUnitFans.getRedirectUrl()) && StringUtils.isNotEmpty(advertisingUnitFans.getAdPhotoUrl()) && null != advertisingUnitFans.getId()) {
                        //该胜出广告是否指定了该设备
                        AdvertisementPlanDevice advertisementPlanDevice = new AdvertisementPlanDevice();
                        advertisementPlanDevice.setDeleted(NO.getValue());
                        advertisementPlanDevice.setAdvertisingUnitId(advertisingUnitFans.getId());
                        List<AdvertisementPlanDevice> advertisementPlanDevices = iAdvertisementPlanDeviceService.selectAdvertisementPlanDeviceList(advertisementPlanDevice);
                        if (advertisementPlanDevices != null && !(advertisementPlanDevices.isEmpty())) {
                            for (AdvertisementPlanDevice planDevice : advertisementPlanDevices) {
                                if (null == planDevice.getRadioDeviceSn()) {
                                    logger.error("zjb_advertisement_plan_device中的id为{}，的设备SN定向为空！", planDevice.getId());
                                    continue;
                                }
                                if (AD_RADIO_DEVICE_SN_ALL.getValue().equals(planDevice.getRadioDeviceSn())) {
                                    adEffective = true;
                                    break;
                                }
                                if (StringUtils.isEmpty(planDevice.getRegex())) {
                                    continue;
                                }
                                Pattern pattern = Pattern.compile(planDevice.getRegex());
                                Matcher matcher = pattern.matcher(deviceSn);
                                if (matcher.matches()) {
                                    adEffective = true;
                                    break;
                                }
                            }
                        }

                    }
                    if(adEffective){
                        logger.info("获取非竞价广告浮层弹窗广告用户【{}】随机数【{}】获取付费取纸成功页面广告成功【{}】",openId,randomNum,JSON.toJSONString(advertisingUnitFans));
                        /*扫码取纸*/
                        AdUnit mapUnit = new AdUnit();
                        handleAdvertisingUnit(mapUnit, advertisingUnitFans, randomNum);
                        adCombinationInfo.setNoBiddingPriceAd(mapUnit);
                        //临时记录点击次数
                        Map<String, Object> mapQueue = new HashMap<>(4);
                        mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_SHOW_EVENT, advertisingUnitFans.getId() + "@" + openId);
                        // 公众号展示数据发送给dsp
                        lpush(MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));
                        return;
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("获取非竞价广告浮层弹窗信息异常：" + e.getMessage(), e);
        }

    }


}