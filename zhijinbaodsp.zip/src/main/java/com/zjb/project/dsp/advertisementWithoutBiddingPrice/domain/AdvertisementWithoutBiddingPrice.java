package com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
										import java.util.Date;

/**
 * 非竞价广告投放表 zjb_advertisement_without_bidding_price
 * 
 * @author jiangbingjie
 * @date 2020-03-30
 */
public class AdvertisementWithoutBiddingPrice extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 自增主键 */
	private Integer id;
	/** 广告池id,即表【zjb_advertising_unit_fans】主键id */
	private Integer advertisingUnitId;
	/** 广告位标识  zjb_ad_space_identifier */
	private String adSpaceIdentifier;
	/** 非竞价广告状态，参考字典 */
	private Integer advertisementStatus;
	/** 权重 */
	private Integer advertisementWeight;
	/**广告池名称  非数据库映射字段*/
	private String advertisingUnitName;
	/**广告名称  非数据库映射字段*/
	private String adName;
	/**图片地址  非数据库映射字段*/
	private String adPhotoUrl;
	/**展示次数  非数据库映射字段*/
	private Integer showTimes;
	/**展示人数  非数据库映射字段*/
	private Integer showPerson;
	/**转化点击次数  非数据库映射字段*/
	private Integer clickTimes;
	/**转化点击人数  非数据库映射字段*/
	private Integer clickPerson;
	/**广告id  非数据库映射字段*/
	private String adId;
	/**创建人员 非数据库映射字段*/
	private String createBy;
	/**修改人员 非数据库映射字段*/
	private String updateBy;

	/**
	 * 广告投放指定设备文件名
	 */
	private String adPlanDeviceExcel;

	/**
	 * 广告投放指定设备文件路径
	 */
	private String adPlanDeviceUrl;

	/**
	 * 设备SN定向，0：不限 1：指定设备 2：不投设备
	 */
	private Integer radioDeviceSn;

	/**
	 * 投放指定设备SN，多个之间用;分隔
	 */
	private String deviceSn;
	/**
	 * 设备SN
	 * 设备ID
	 * 设备qrcode
	 */
	@Excel(name = "mixId")
	private String mixId;

	/**广告投放设备正则表达式 非数据库映射字段*/
	private String regex;

	public Integer getRadioDeviceSn() {
		return radioDeviceSn;
	}

	public void setRadioDeviceSn(Integer radioDeviceSn) {
		this.radioDeviceSn = radioDeviceSn;
	}

	public String getDeviceSn() {
		return deviceSn;
	}

	public void setDeviceSn(String deviceSn) {
		this.deviceSn = deviceSn;
	}

	public String getAdPlanDeviceExcel() {
		return adPlanDeviceExcel;
	}

	public void setAdPlanDeviceExcel(String adPlanDeviceExcel) {
		this.adPlanDeviceExcel = adPlanDeviceExcel;
	}

	public String getAdPlanDeviceUrl() {
		return adPlanDeviceUrl;
	}

	public void setAdPlanDeviceUrl(String adPlanDeviceUrl) {
		this.adPlanDeviceUrl = adPlanDeviceUrl;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setAdvertisingUnitId(Integer advertisingUnitId) 
	{
		this.advertisingUnitId = advertisingUnitId;
	}

	public Integer getAdvertisingUnitId() 
	{
		return advertisingUnitId;
	}
	public void setAdSpaceIdentifier(String adSpaceIdentifier) 
	{
		this.adSpaceIdentifier = adSpaceIdentifier;
	}

	public String getAdSpaceIdentifier() 
	{
		return adSpaceIdentifier;
	}
	public void setAdvertisementStatus(Integer advertisementStatus) 
	{
		this.advertisementStatus = advertisementStatus;
	}

	public Integer getAdvertisementStatus() 
	{
		return advertisementStatus;
	}
	public void setAdvertisementWeight(Integer advertisementWeight) 
	{
		this.advertisementWeight = advertisementWeight;
	}

	public Integer getAdvertisementWeight() 
	{
		return advertisementWeight;
	}

	public String getAdvertisingUnitName() {
		return advertisingUnitName;
	}

	public void setAdvertisingUnitName(String advertisingUnitName) {
		this.advertisingUnitName = advertisingUnitName;
	}

	public String getAdName() {
		return adName;
	}

	public void setAdName(String adName) {
		this.adName = adName;
	}

	public String getAdPhotoUrl() {
		return adPhotoUrl;
	}

	public void setAdPhotoUrl(String adPhotoUrl) {
		this.adPhotoUrl = adPhotoUrl;
	}

	public Integer getShowTimes() {
		return showTimes;
	}

	public void setShowTimes(Integer showTimes) {
		this.showTimes = showTimes;
	}

	public Integer getShowPerson() {
		return showPerson;
	}

	public void setShowPerson(Integer showPerson) {
		this.showPerson = showPerson;
	}

	public Integer getClickTimes() {
		return clickTimes;
	}

	public void setClickTimes(Integer clickTimes) {
		this.clickTimes = clickTimes;
	}

	public Integer getClickPerson() {
		return clickPerson;
	}

	public void setClickPerson(Integer clickPerson) {
		this.clickPerson = clickPerson;
	}

	public String getAdId() {
		return adId;
	}

	public void setAdId(String adId) {
		this.adId = adId;
	}

	@Override
	public String getCreateBy() {
		return createBy;
	}

	@Override
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}

	@Override
	public String getUpdateBy() {
		return updateBy;
	}

	@Override
	public void setUpdateBy(String updateBy) {
		this.updateBy = updateBy;
	}

	public String getMixId() {
		return mixId;
	}

	public void setMixId(String mixId) {
		this.mixId = mixId;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

	public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("advertisingUnitId", getAdvertisingUnitId())
            .append("adSpaceIdentifier", getAdSpaceIdentifier())
            .append("advertisementStatus", getAdvertisementStatus())
            .append("advertisementWeight", getAdvertisementWeight())
            .append("gmtCreated", getGmtCreated())
            .append("createrId", getCreaterId())
            .append("gmtModified", getGmtModified())
            .append("modifierId", getModifierId())
            .append("deleted", getDeleted())
            .toString();
    }
}
