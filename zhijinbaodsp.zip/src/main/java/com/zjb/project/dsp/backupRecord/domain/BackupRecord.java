package com.zjb.project.dsp.backupRecord.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.zjb.framework.web.domain.BaseEntity;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 数据备份记录表 zjb_backup_record
 *
 * @author songjy
 * @date 2020-04-17
 */
public class BackupRecord extends BaseEntity {
    private static final long serialVersionUID = 7828968499144021229L;

    /**
     * 自增主键
     */
    private Long id;
    /**
     * 备份数据的日期
     */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate dayData;

    /**
     * 备份数据的小时：0~23
     */
    private Integer hour;

    /**
     * 备份条数
     */
    private Integer countData;
    /**
     * 备份数据类型：用表名代替即可
     */
    private String typeData;
    /**
     * 备份开始时间
     */
    private LocalDateTime gmtStartBackup;
    /**
     * 备份结束时间
     */
    private LocalDateTime gmtEndBackup;
    /**
     * 备份文件路径
     */
    private String fileUrl;

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public LocalDate getDayData() {
        return dayData;
    }

    public void setDayData(LocalDate dayData) {
        this.dayData = dayData;
    }

    public void setCountData(Integer countData) {
        this.countData = countData;
    }

    public Integer getCountData() {
        return countData;
    }

    public void setTypeData(String typeData) {
        this.typeData = typeData;
    }

    public String getTypeData() {
        return typeData;
    }

    public LocalDateTime getGmtStartBackup() {
        return gmtStartBackup;
    }

    public void setGmtStartBackup(LocalDateTime gmtStartBackup) {
        this.gmtStartBackup = gmtStartBackup;
    }

    public LocalDateTime getGmtEndBackup() {
        return gmtEndBackup;
    }

    public void setGmtEndBackup(LocalDateTime gmtEndBackup) {
        this.gmtEndBackup = gmtEndBackup;
    }

    public void setFileUrl(String fileUrl) {
        this.fileUrl = fileUrl;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public Integer getHour() {
        return hour;
    }

    public void setHour(Integer hour) {
        this.hour = hour;
    }
}
