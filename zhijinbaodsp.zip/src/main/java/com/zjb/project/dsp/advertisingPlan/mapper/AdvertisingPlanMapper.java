package com.zjb.project.dsp.advertisingPlan.mapper;

import java.util.List;

import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;

/**
 * 广告投放计划 数据层
 *
 * @author songjy
 * @date 2019-07-13
 */
public interface AdvertisingPlanMapper {
    /**
     * 查询广告投放计划信息
     *
     * @param id 广告投放计划ID
     * @return 广告投放计划信息
     */
    AdvertisingPlan selectAdvertisingPlanById(Integer id);

    /**
     * 查询广告投放计划列表
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 广告投放计划集合
     */
    List<AdvertisingPlan> selectAdvertisingPlanList(AdvertisingPlan advertisingPlan);

    /**
     * 新增广告投放计划
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 结果
     */
    int insertAdvertisingPlan(AdvertisingPlan advertisingPlan);

    /**
     * 修改广告投放计划
     *
     * @param advertisingPlan 广告投放计划信息
     * @return 结果
     */
    int updateAdvertisingPlan(AdvertisingPlan advertisingPlan);

    /**
     * 删除广告投放计划
     *
     * @param id 广告投放计划ID
     * @return 结果
     */
    int deleteAdvertisingPlanById(Integer id);

    /**
     * 批量删除广告投放计划
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanByIds(String[] ids);

    /**
     * 逻辑删除广告投放计划信息
     *
     * @param strings
     * @return
     */
    int logicDeleteAdvertisingPlanByIds(String[] strings);

    /**
     * 查询广告投放计划信息
     *
     * @param planId 广告投放计划业务主键ID
     * @return 广告投放计划信息
     */
    AdvertisingPlan selectAdvertisingPlanByPlanId(String planId);

    /**
     * 根据公众号查询广告投放计划
     * @param adAppId
     * @return
     */
    List<AdvertisingPlan> selectByAdAppId(String adAppId);
}