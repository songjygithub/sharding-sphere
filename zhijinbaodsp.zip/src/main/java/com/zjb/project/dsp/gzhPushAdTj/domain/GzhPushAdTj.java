package com.zjb.project.dsp.gzhPushAdTj.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
						import java.util.Date;

/**
 * 消息广告点击统计表 zjb_gzh_push_ad_tj
 * 
 * @author shenlong
 * @date 2019-08-26
 */
public class GzhPushAdTj extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** 消息广告id */
	private String msgId;
	/** 外部链接 */
	private String outUrl;
	/** 内部跳转标识 */
	private String insideUri;
	/** 点击事件 */
	private Date clickTime;
	/** 设备码 */
	private String qrcode;

	/**
	 * 用户标识
	 */
	private String openid;

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setMsgId(String msgId) 
	{
		this.msgId = msgId;
	}

	public String getMsgId() 
	{
		return msgId;
	}
	public void setOutUrl(String outUrl) 
	{
		this.outUrl = outUrl;
	}

	public String getOutUrl() 
	{
		return outUrl;
	}
	public void setInsideUri(String insideUri) 
	{
		this.insideUri = insideUri;
	}

	public String getInsideUri() 
	{
		return insideUri;
	}
	public void setClickTime(Date clickTime) 
	{
		this.clickTime = clickTime;
	}

	public Date getClickTime() 
	{
		return clickTime;
	}
	public void setQrcode(String qrcode) 
	{
		this.qrcode = qrcode;
	}

	public String getQrcode() 
	{
		return qrcode;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("msgId", getMsgId())
            .append("outUrl", getOutUrl())
            .append("insideUri", getInsideUri())
            .append("clickTime", getClickTime())
            .append("qrcode", getQrcode())
            .toString();
    }
}
