package com.zjb.project.dsp.deviceInstallInfo.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 设备安装表 zjb_device_install_info
 *
 * @author songjy
 * @date 2019-11-30
 */
public class DeviceInstallInfo extends BaseEntity {
    private static final long serialVersionUID = -8469850482906392799L;

    /**
     * 自增主鍵
     */
    private Integer id;
    /**
     * 设备的id
     */
    private Integer deviceId;
    /**
     * 设备Sn
     */
    private String deviceSn;
    /**
     * 代理商id
     */
    private Integer agencyId;

    /**
     * 代理商名称
     */
    private String agencyName;

    /**
     * 安装人员id
     */
    private Integer installerUserId;
    /**
     * 安装人员姓名
     */
    private String installerUserNick;
    /**
     * 安装人员联系方式
     */
    private String installerUserContact;
    /**
     * 安装时间
     */
    private Date installTime;
    /**
     * 安装照片
     */
    private String installPhoto;

    /**
     * 安装场合类型code 参考 字典 安装场合 SCENE
     */
    private String installLocationCodeType;
    /**
     * 安装场合code 参考 字典 安装场合 SCENE
     */
    private String installLocationCode;
    /**
     * 安装状态 参考 安装状态 INSTALL_STATUS
     */
    private Integer installStatus;
    /**
     * 省id 参考 省市区表
     */
    private Integer provinceId;
    /**
     * 省 参考 省市区表
     */
    private String provinceName;
    /**
     * 市id 参考 省市区表
     */
    private Integer cityId;
    /**
     * 市 参考 省市区表
     */
    private String cityName;
    /**
     * 区id 参考 省市区表
     */
    private Integer areaId;
    /**
     * 区 参考 省市区表
     */
    private String areaName;
    /**
     * 详细地址
     */
    private String detailAddress;
    /**
     * 经度
     */
    private String longitude;
    /**
     * 经度-lbs/平均值
     */
    private String longitudeLbs;
    /**
     * 纬度
     */
    private String latitude;
    /**
     * 纬度-LBS/平均值
     */
    private String latitudeLbs;
    /**
     * 经纬度获取方式 0：自动获取；1：手动输入
     */
    private Integer accessType;
    /**
     * 上报时间
     */
    private Date lbsTime;
    /**
     * 经度1
     */
    private String longitudeLbs1;
    /**
     * 经度2
     */
    private String longitudeLbs2;
    /**
     * 经度3
     */
    private String longitudeLbs3;
    /**
     * 时间戳1
     */
    private Date lbsTime1;
    /**
     * 时间戳2
     */
    private Date lbsTime2;
    /**
     * 时间戳3
     */
    private Date lbsTime3;
    /**
     * 纬度1
     */
    private String latitudeLbs1;
    /**
     * 纬度2
     */
    private String latitudeLbs2;
    /**
     * 纬度3
     */
    private String latitudeLbs3;
    /**
     * geohash
     */
    private String geohash;
    /**
     * 性别 参考字典安装地人群属性SEX
     */
    private String sex;
    /**
     * 创建方式code 参考字典创建方式CREAT_TYPE
     */
    private String createTypeCode;
    /**
     * 上电状态 参考 字典 上电状态 POWER_STATUS
     */
    private Integer powerStatus;
    /**
     * 设备运维人员id
     */
    private Integer maintainerDeviceUserId;
    /**
     * 设备运维人员联系方式
     */
    private String maintainerDeviceUserPhone;
    /**
     * 设备运维人员名称
     */
    private String maintainerDeviceUserName;
    /**
     * 扫码总次数
     */
    private Integer smTimes;
    /**
     * 扫码分成次数
     */
    private Integer plTimes;
    /**
     * 总扫码分成
     */
    private BigDecimal smAccount;
    /**
     * 设备创建时间
     */
    private String createdTimes;
    /**
     * 最近上线时间
     */
    private String onlineTimes;
    
    /**
     * 历史ID
     */
    private Integer historyId;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setDeviceId(Integer deviceId) {
        this.deviceId = deviceId;
    }

    public Integer getDeviceId() {
        return deviceId;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setInstallerUserId(Integer installerUserId) {
        this.installerUserId = installerUserId;
    }

    public Integer getInstallerUserId() {
        return installerUserId;
    }

    public void setInstallerUserNick(String installerUserNick) {
        this.installerUserNick = installerUserNick;
    }

    public String getInstallerUserNick() {
        return installerUserNick;
    }

    public void setInstallerUserContact(String installerUserContact) {
        this.installerUserContact = installerUserContact;
    }

    public String getInstallerUserContact() {
        return installerUserContact;
    }

    public void setInstallTime(Date installTime) {
        this.installTime = installTime;
    }

    public Date getInstallTime() {
        return installTime;
    }

    public void setInstallPhoto(String installPhoto) {
        this.installPhoto = installPhoto;
    }

    public String getInstallPhoto() {
        return installPhoto;
    }

    public String getInstallLocationCodeType() {
        return installLocationCodeType;
    }

    public void setInstallLocationCodeType(String installLocationCodeType) {
        this.installLocationCodeType = installLocationCodeType;
    }

    public void setInstallLocationCode(String installLocationCode) {
        this.installLocationCode = installLocationCode;
    }

    public String getInstallLocationCode() {
        return installLocationCode;
    }

    public void setInstallStatus(Integer installStatus) {
        this.installStatus = installStatus;
    }

    public Integer getInstallStatus() {
        return installStatus;
    }

    public void setProvinceId(Integer provinceId) {
        this.provinceId = provinceId;
    }

    public Integer getProvinceId() {
        return provinceId;
    }

    public void setProvinceName(String provinceName) {
        this.provinceName = provinceName;
    }

    public String getProvinceName() {
        return provinceName;
    }

    public void setCityId(Integer cityId) {
        this.cityId = cityId;
    }

    public Integer getCityId() {
        return cityId;
    }

    public void setCityName(String cityName) {
        this.cityName = cityName;
    }

    public String getCityName() {
        return cityName;
    }

    public void setAreaId(Integer areaId) {
        this.areaId = areaId;
    }

    public Integer getAreaId() {
        return areaId;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    public String getAreaName() {
        return areaName;
    }

    public void setDetailAddress(String detailAddress) {
        this.detailAddress = detailAddress;
    }

    public String getDetailAddress() {
        return detailAddress;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitudeLbs(String longitudeLbs) {
        this.longitudeLbs = longitudeLbs;
    }

    public String getLongitudeLbs() {
        return longitudeLbs;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitudeLbs(String latitudeLbs) {
        this.latitudeLbs = latitudeLbs;
    }

    public String getLatitudeLbs() {
        return latitudeLbs;
    }

    public void setAccessType(Integer accessType) {
        this.accessType = accessType;
    }

    public Integer getAccessType() {
        return accessType;
    }

    public void setLbsTime(Date lbsTime) {
        this.lbsTime = lbsTime;
    }

    public Date getLbsTime() {
        return lbsTime;
    }

    public void setLongitudeLbs1(String longitudeLbs1) {
        this.longitudeLbs1 = longitudeLbs1;
    }

    public String getLongitudeLbs1() {
        return longitudeLbs1;
    }

    public void setLongitudeLbs2(String longitudeLbs2) {
        this.longitudeLbs2 = longitudeLbs2;
    }

    public String getLongitudeLbs2() {
        return longitudeLbs2;
    }

    public void setLongitudeLbs3(String longitudeLbs3) {
        this.longitudeLbs3 = longitudeLbs3;
    }

    public String getLongitudeLbs3() {
        return longitudeLbs3;
    }

    public void setLbsTime1(Date lbsTime1) {
        this.lbsTime1 = lbsTime1;
    }

    public Date getLbsTime1() {
        return lbsTime1;
    }

    public void setLbsTime2(Date lbsTime2) {
        this.lbsTime2 = lbsTime2;
    }

    public Date getLbsTime2() {
        return lbsTime2;
    }

    public void setLbsTime3(Date lbsTime3) {
        this.lbsTime3 = lbsTime3;
    }

    public Date getLbsTime3() {
        return lbsTime3;
    }

    public void setLatitudeLbs1(String latitudeLbs1) {
        this.latitudeLbs1 = latitudeLbs1;
    }

    public String getLatitudeLbs1() {
        return latitudeLbs1;
    }

    public void setLatitudeLbs2(String latitudeLbs2) {
        this.latitudeLbs2 = latitudeLbs2;
    }

    public String getLatitudeLbs2() {
        return latitudeLbs2;
    }

    public void setLatitudeLbs3(String latitudeLbs3) {
        this.latitudeLbs3 = latitudeLbs3;
    }

    public String getLatitudeLbs3() {
        return latitudeLbs3;
    }

    public void setGeohash(String geohash) {
        this.geohash = geohash;
    }

    public String getGeohash() {
        return geohash;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getSex() {
        return sex;
    }

    public void setCreateTypeCode(String createTypeCode) {
        this.createTypeCode = createTypeCode;
    }

    public String getCreateTypeCode() {
        return createTypeCode;
    }

    public void setPowerStatus(Integer powerStatus) {
        this.powerStatus = powerStatus;
    }

    public Integer getPowerStatus() {
        return powerStatus;
    }

    public void setMaintainerDeviceUserId(Integer maintainerDeviceUserId) {
        this.maintainerDeviceUserId = maintainerDeviceUserId;
    }

    public Integer getMaintainerDeviceUserId() {
        return maintainerDeviceUserId;
    }

    public void setMaintainerDeviceUserPhone(String maintainerDeviceUserPhone) {
        this.maintainerDeviceUserPhone = maintainerDeviceUserPhone;
    }

    public String getMaintainerDeviceUserPhone() {
        return maintainerDeviceUserPhone;
    }

    public void setMaintainerDeviceUserName(String maintainerDeviceUserName) {
        this.maintainerDeviceUserName = maintainerDeviceUserName;
    }

    public String getMaintainerDeviceUserName() {
        return maintainerDeviceUserName;
    }

    public void setSmTimes(Integer smTimes) {
        this.smTimes = smTimes;
    }

    public Integer getSmTimes() {
        return smTimes;
    }

    public void setPlTimes(Integer plTimes) {
        this.plTimes = plTimes;
    }

    public Integer getPlTimes() {
        return plTimes;
    }

    public void setSmAccount(BigDecimal smAccount) {
        this.smAccount = smAccount;
    }

    public BigDecimal getSmAccount() {
        return smAccount;
    }

    public void setCreatedTimes(String createdTimes) {
        this.createdTimes = createdTimes;
    }

    public String getCreatedTimes() {
        return createdTimes;
    }

    public void setOnlineTimes(String onlineTimes) {
        this.onlineTimes = onlineTimes;
    }

    public String getOnlineTimes() {
        return onlineTimes;
    }

    public void setHistoryId(Integer historyId) {
        this.historyId = historyId;
    }

    public Integer getHistoryId() {
        return historyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }
}
