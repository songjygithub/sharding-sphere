package com.zjb.project.dsp.advertisingPlanDevice.service;

import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * 广告投放设备定向 服务层
 *
 * @author songjy
 * @date 2019-07-12
 */
public interface IAdvertisingPlanDeviceService extends IAdPlanService {
    /**
     * 查询广告投放设备定向信息
     *
     * @param id 广告投放设备定向ID
     * @return 广告投放设备定向信息
     */
    AdvertisingPlanDevice selectAdvertisingPlanDeviceById(Integer id);

    /**
     * 查询广告投放设备定向列表
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 广告投放设备定向集合
     */
    List<AdvertisingPlanDevice> selectAdvertisingPlanDeviceList(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 新增广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    int insertAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 修改广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    int updateAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 删除广告投放设备定向信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanDeviceByIds(String ids);

    /**
     * 设备定向计划对应的预编译类(Pattern)
     *
     * @return 设备定向计划对应的预编译类(Pattern)
     */
    Map<String, Pattern> deviceRegexMapPattern();

    /**
     * 添加设备定向正则对应的预编译类(Pattern)
     *
     * @param advertisingPlanDevice
     */
    void addPattern(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 移除设备定向正则对应的预编译类(Pattern)
     *
     * @param advertisingPlanDevice
     */
    void removePattern(AdvertisingPlanDevice advertisingPlanDevice);

    /**
     * 通过计划ID查询设备定向信息
     *
     * @param planId
     * @return
     */
    AdvertisingPlanDevice selectAdvertisingPlanDeviceByPlanId(String planId);

    /**
     * 广告计划对应的设备正则
     *
     * @param planId 广告计划
     * @return 正则
     */
    Pattern pattern(String planId);
}
