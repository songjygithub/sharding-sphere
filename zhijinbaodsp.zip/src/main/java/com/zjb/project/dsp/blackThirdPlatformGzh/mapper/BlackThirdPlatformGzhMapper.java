package com.zjb.project.dsp.blackThirdPlatformGzh.mapper;

import com.zjb.project.dsp.blackThirdPlatformGzh.domain.BlackThirdPlatformGzh;
import java.util.List;	

/**
 * 第三方平台公众号黑名单 数据层
 * 
 * @author jiangbingjie
 * @date 2020-04-17
 */
public interface BlackThirdPlatformGzhMapper 
{
	/**
     * 查询第三方平台公众号黑名单信息
     * 
     * @param id 第三方平台公众号黑名单ID
     * @return 第三方平台公众号黑名单信息
     */
	public BlackThirdPlatformGzh selectBlackThirdPlatformGzhById(Integer id);
	
	/**
     * 查询第三方平台公众号黑名单列表
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 第三方平台公众号黑名单集合
     */
	public List<BlackThirdPlatformGzh> selectBlackThirdPlatformGzhList(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
	/**
     * 新增第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	public int insertBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
	/**
     * 修改第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	public int updateBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
	/**
     * 删除第三方平台公众号黑名单
     * 
     * @param id 第三方平台公众号黑名单ID
     * @return 结果
     */
	public int deleteBlackThirdPlatformGzhById(Integer id);
	
	/**
     * 批量删除第三方平台公众号黑名单
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteBlackThirdPlatformGzhByIds(String[] ids);

	/**
	 * 逻辑删除第三方平台公众号黑名单
	 * @param ids
	 * @return
	 */
	public int logicDeleteBlackThirdPlatformGzhByIds(String[] ids);
	
}