package com.zjb.project.dsp.gzhLabel.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.feign.service.IFeignAdminCoreService;
import com.zjb.project.dsp.gzhLabel.domain.GzhLabel;
import com.zjb.project.dsp.gzhLabel.service.IGzhLabelService;

import cn.hutool.http.HttpUtil;


/**
 * 公众号粉丝标签详情 信息操作处理
 *
 * @author shenlong
 * @date 2019-11-08
 */
@Controller
@RequestMapping("/dsp/gzhLabel")
public class GzhLabelController extends BaseController {
    private String prefix = "dsp/gzhLabel";

    @Autowired
    private IGzhLabelService gzhLabelService;
    @Autowired
    private IFeignAdminCoreService feignAdminCoreService;

    @RequiresPermissions("dsp:gzhLabel:view")
    @GetMapping()
    public String gzhLabel() {
        return prefix + "/gzhLabel";
    }

    /**
     * 查询公众号粉丝标签详情列表
     */
    @RequiresPermissions("dsp:gzhLabel:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GzhLabel gzhLabel) {
        startPage();
        List<GzhLabel> list = gzhLabelService.selectGzhLabelList(gzhLabel);
        return getDataTable(list);
    }

    /**
     * 新增公众号粉丝标签详情
     */
    @GetMapping("/add/{id}")
    public String add(@PathVariable("id") String appid, ModelMap modelMap) {

        modelMap.addAttribute("appid", appid);
        return prefix + "/add";
    }

    /**
     * 新增保存公众号粉丝标签详情
     */
    @RequiresPermissions("dsp:gzhLabel:add")
    @Log(title = "公众号粉丝标签详情", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GzhLabel gzhLabel) {
        String result = feignAdminCoreService.getAccessToken(gzhLabel.getAppid());
        if (StringUtils.isNotBlank(result)) {
            String TAGS_URL = "https://api.weixin.qq.com/cgi-bin/tags/create?access_token=" + result;
            HashMap<Object, Object> map = new HashMap<>();
            HashMap<Object, Object> map1 = new HashMap<>();
            map1.put("name", gzhLabel.getLabelName());
            map.put("tag", map1);
            String s = JSONObject.toJSONString(map);
            String post = HttpUtil.post(TAGS_URL, s);
            if (StringUtils.isNotEmpty(post)) {
                JSONObject jsonObject = JSON.parseObject(post);
                String tag = jsonObject.getString("tag");
                JSONObject jsonObject1 = JSON.parseObject(tag);
                if (jsonObject1 != null && StringUtils.isNotEmpty(jsonObject1.getString("name")) && jsonObject1.getInteger("id") != null) {
                    gzhLabel.setLabelId(jsonObject1.getInteger("id"));
                    gzhLabel.setGmtCreated(new Date());
                    return toAjax(gzhLabelService.insertGzhLabel(gzhLabel));
                }
            }
        }
        return toAjax(0);
    }

    /**
     * 修改公众号粉丝标签详情
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        GzhLabel gzhLabel = gzhLabelService.selectGzhLabelById(id);
        mmap.put("gzhLabel", gzhLabel);
        return prefix + "/edit";
    }

    /**
     * 修改保存公众号粉丝标签详情
     */
    @RequiresPermissions("dsp:gzhLabel:edit")
    @Log(title = "公众号粉丝标签详情", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GzhLabel gzhLabel) {
        return toAjax(gzhLabelService.updateGzhLabel(gzhLabel));
    }

    /**
     * 删除公众号粉丝标签详情
     */
    @RequiresPermissions("dsp:gzhLabel:remove")
    @Log(title = "公众号粉丝标签详情", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(gzhLabelService.deleteGzhLabelByIds(ids));
    }


}
