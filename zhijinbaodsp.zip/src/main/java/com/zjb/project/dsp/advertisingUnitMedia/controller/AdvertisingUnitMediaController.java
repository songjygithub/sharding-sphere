package com.zjb.project.dsp.advertisingUnitMedia.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.websocket.server.PathParam;

import org.apache.logging.log4j.util.PerformanceSensitive;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.MultipartFileToFile;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.WeChatUtil;
import com.zjb.common.utils.file.FileUploadUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingUnitMedia.domain.AdvertisingUnitMedia;
import com.zjb.project.dsp.advertisingUnitMedia.service.IAdvertisingUnitMediaService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.weChatNews.domain.WeChatNews;
import com.zjb.project.dsp.weChatNews.service.IWeChatNewsService;

/**
 * 媒体矩阵广告池 信息操作处理
 *
 * @author zh
 * @date 2020-03-19
 */
@Controller
@RequestMapping("/dsp/advertisingUnitMedia")
public class AdvertisingUnitMediaController extends BaseController {
    private static final Logger logger = LoggerFactory.getLogger(AdvertisingUnitMedia.class);
    private String prefix = "dsp/advertisingUnitMedia";
    //已认证
    private static final String CERTIFIED = "0";
    // 授权成功
    private static final String AUTH_SUCCESS = "1";
    /*//图片素材map
    private Map<String, String> imgmap = new HashMap<>();
    //图文图片map
    private Map<String, String> urlmap = new HashMap<>();*/
    private static final String addMaterialImageKey  = "addMaterialImage";
    private static final String uploadimgkey = "uploadimg";
    @Autowired
    private IAdvertisingUnitMediaService advertisingUnitMediaService;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IWeChatNewsService weChatNewsService;

    @RequiresPermissions("dsp:advertisingUnitMedia:view")
    @GetMapping()
    public String advertisingUnitMedia() {
        return prefix + "/advertisingUnitMedia";
    }

    /**
     * 查询媒体矩阵广告池列表
     */
    @RequiresPermissions("dsp:advertisingUnitMedia:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingUnitMedia advertisingUnitMedia) {
        startPage();
        List<AdvertisingUnitMedia> list = advertisingUnitMediaService.selectAdvertisingUnitMediaList(advertisingUnitMedia);
        for (AdvertisingUnitMedia advertisingUnitMediaDb:list) {
            WeChatNews weChatNews = new WeChatNews();
            weChatNews.setNewsId(advertisingUnitMediaDb.getId());
            List<WeChatNews> weChatNewsList = weChatNewsService.selectWeChatNewsList(weChatNews);
            Integer sendSuccess = 0;
            Integer sendErr = 0;
            for (WeChatNews weChatNews_db:weChatNewsList) {
                if (null != weChatNews_db.getErrcode()) {
                    if (weChatNews_db.getErrcode() == 0) {
                        sendSuccess++;
                    } else {
                        sendErr++;
                    }
                }
            }
            advertisingUnitMediaDb.setSendSuccess(sendSuccess);
            advertisingUnitMediaDb.setSendErr(sendErr);
        }
        return getDataTable(list);
    }

    /**
     * 新增媒体矩阵广告池
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 待推送的媒体
     */
    @PerformanceSensitive("dsp:advertisingUnitMedia:getGzhInfo")
    @PostMapping("/getGzhInfo")
    @ResponseBody
    public AjaxResult getGzhInfo(ComponentAuthorizationInfo componentAuthorizationInfo) {
        //已授权
        componentAuthorizationInfo.setAuthorizationStatus(AUTH_SUCCESS);
        //已认证
        componentAuthorizationInfo.setVerifyTypeInfo(CERTIFIED);
        List<ComponentAuthorizationInfo> list = componentAuthorizationInfoService.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
        return success(list);
    }

    /**
     * 上传图文以外的其他素材
     */
    @PostMapping("/addMaterialImage")
    @ResponseBody
    public AjaxResult addMaterialImage(@RequestParam("file") MultipartFile multipartFile, @RequestParam("appids") List<String> appids) {
        if (appids.isEmpty() || multipartFile.isEmpty()) {
            return null;
        }
        try {
            if (!multipartFile.isEmpty()) {
                String fileKey = zjbConfig.getMediaUrl() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(multipartFile.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, multipartFile.getInputStream());
                String image = ZjbConstants.File_Domain + "/" + fileKey;
                File file = MultipartFileToFile.multipartFileToFile(multipartFile);
                if (null != file) {
                    for (String appid : appids) {
                        String gzhToken = WeChatUtil.getAuthorizerAccessToken(appid);
                        logger.info("addMaterialImage：appid=>{}，gzhToken=>{}",appid,gzhToken);
                        if (StringUtils.isNotBlank(gzhToken)) {
                            WeChatNews weChatNews = WeChatUtil.addMaterialImage(file, gzhToken, "image", false, null, null);
                            if (null != weChatNews) {
                                logger.info("addMaterialImage：appid=>{}，gzhToken=>{},mediaId=>{}",appid,gzhToken,weChatNews.getMediaId());
                                JedisPoolCacheUtils.setRExpire(addMaterialImageKey + "_" + appid,weChatNews.getMediaId(),JedisPoolCacheUtils.EXRP_HOUR, ZjbConstantsRedis.ZJB_DB_59);
                                logger.info(addMaterialImageKey + "_" + appid+":=>{}",weChatNews.getMediaId());
                                logger.info("图片媒体id=>{}",weChatNews.getMediaId());
                            }
                        }
                    }
                    return success(image);
                }
            }

        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return error();
    }

    /**
     * 上传图文消息内的图片获取URL【订阅号与服务号认证后均可用】
     */
    @PostMapping("/uploadimg")
    @ResponseBody
    public String uploadimg(@RequestParam("file") MultipartFile multipartFile, @RequestParam("appids") List<String> appids) {
        if (appids.isEmpty() || multipartFile.isEmpty()) {
            return null;
        }
        try {
            if (!multipartFile.isEmpty()) {
                String fileKey = zjbConfig.getMediaUrl() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(multipartFile.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, multipartFile.getInputStream());
                String image = ZjbConstants.File_Domain + "/" + fileKey;
                File file = MultipartFileToFile.multipartFileToFile(multipartFile);
                if (null != file) {

                    for (String appid : appids) {
                        String gzhToken = WeChatUtil.getAuthorizerAccessToken(appid);
                        if (StringUtils.isNotBlank(gzhToken)) {
                            logger.info("uploadimg：appid=>{}，gzhToken=>{}",appid,gzhToken);
                            String imgUrl = WeChatUtil.uploadimg(file, gzhToken);
                            logger.info("uploadimg：appid=>{}，gzhToken=>{},imgUrl=>{}",appid,gzhToken,imgUrl);
                            if (StringUtils.isNotBlank(imgUrl)) {
                                JedisPoolCacheUtils.setRExpire(uploadimgkey + "_" + appid + image,imgUrl,JedisPoolCacheUtils.EXRP_HOUR, ZjbConstantsRedis.ZJB_DB_59);
                                logger.info(uploadimgkey + "_" + appid+image+":=>{}",imgUrl);
                            }
                        }
                    }
                    return image;
                }
            }

        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return null;
    }

    /**
     * 新增保存媒体矩阵广告池
     */
    @RequiresPermissions("dsp:advertisingUnitMedia:add")
    @Log(title = "媒体矩阵广告池", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingUnitMedia advertisingUnitMedia) {
        advertisingUnitMedia.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
        advertisingUnitMedia.setSendStatus(0);
        int i = advertisingUnitMediaService.insertAdvertisingUnitMedia(advertisingUnitMedia);
        if (i > 0) {
            List<WeChatNews> weChatNewsList = new ArrayList<>();
            WeChatNews weChatNews = new WeChatNews();
            weChatNews.setNewsId(advertisingUnitMedia.getId());
            weChatNews.setIsToAll(0);
            weChatNews.setTitle(advertisingUnitMedia.getTitle());
            weChatNews.setMsgtype(advertisingUnitMedia.getMsgtype());
            weChatNews.setAuthor(advertisingUnitMedia.getAuthor());
            weChatNews.setDigest(advertisingUnitMedia.getDigest());
            String content = advertisingUnitMedia.getContent();
            weChatNews.setContentSourceUrl(advertisingUnitMedia.getContentSourceUrl());
            String msgType = advertisingUnitMedia.getMsgtype();
            String[] appids = advertisingUnitMedia.getAppid().split(",");
            String contentUrl = advertisingUnitMedia.getContentImg();


            for (String appid : appids) {
                weChatNews.setAppid(appid);
                if ("mpnews".equals(msgType)) {
                    logger.info("mpnews："+addMaterialImageKey + "_" + appid+":=>{}");
                    String imgmap = JedisPoolCacheUtils.getVStr(addMaterialImageKey + "_"+appid, ZjbConstantsRedis.ZJB_DB_59);
                    if (StringUtils.isNotBlank(imgmap)) {
                        weChatNews.setThumbMediaId(imgmap);
                        logger.info("mpnews："+addMaterialImageKey + "_" + appid+":=>{}",imgmap);
                        JedisPoolCacheUtils.setRExpire(addMaterialImageKey + "_" + appid,"",JedisPoolCacheUtils.EXRP_SECOND, ZjbConstantsRedis.ZJB_DB_59);
                    }
                    logger.info("mpnews：contentUrl="+uploadimgkey + "_" + appid+":=>{}",contentUrl);
                    if (StringUtils.isNotBlank(contentUrl)){
                        String[] contentImg = contentUrl.split(",");
                        for (String img:contentImg) {
                            if (StringUtils.isNotBlank(img)) {
                                String url = JedisPoolCacheUtils.getVStr(uploadimgkey + "_" + appid + img, ZjbConstantsRedis.ZJB_DB_59);
                                logger.info("mpnews：contentUrl="+uploadimgkey + "_" + appid+img+":=>{}",url);
                                if (StringUtils.isNotBlank(url)) {
                                    content = content.replace(img, url);
                                    JedisPoolCacheUtils.setRExpire(uploadimgkey + "_" + appid + img, "", JedisPoolCacheUtils.EXRP_SECOND, ZjbConstantsRedis.ZJB_DB_59);
                                }
                            }
                        }
                    }

                    weChatNews.setContent(content);
                    String gzhToken = WeChatUtil.getAuthorizerAccessToken(appid);
                    if (StringUtils.isNotBlank(gzhToken)) {
                        String media_id = WeChatUtil.addN_news(gzhToken, weChatNews);
                        logger.info("addNews：appid=>{}，gzhToken=>{},weChatNews=>{}",appid,gzhToken,weChatNews);
                        if (StringUtils.isNotBlank(media_id)) {
                            logger.info("addNews：appid=>{}，gzhToken=>{},weChatNews=>{}",appid,gzhToken,weChatNews);
                            weChatNews.setMediaId(media_id);
                        }
                    }
                } else if ("image".equals(msgType)) {
                    String imgmap = JedisPoolCacheUtils.getVStr(addMaterialImageKey + "_"+appid, ZjbConstantsRedis.ZJB_DB_59);
                    if (StringUtils.isNotBlank(imgmap)) {
                        weChatNews.setMediaId(imgmap);
                        JedisPoolCacheUtils.setRExpire(addMaterialImageKey + "_" + appid,"",JedisPoolCacheUtils.EXRP_SECOND, ZjbConstantsRedis.ZJB_DB_59);
                    }
                }else if ("text".equals(msgType)){
                    weChatNews.setContent(content);
                }
                weChatNews.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
                weChatNewsList.add(weChatNews);
            }
            for (WeChatNews weChatNewsnew : weChatNewsList) {
                weChatNewsService.insertWeChatNews(weChatNewsnew);
            }
            return success();
        }
        return error();
    }

    /**
     * 修改保存媒体矩阵广告池
     */
    @RequiresPermissions("dsp:advertisingUnitMedia:send")
    @Log(title = "媒体矩阵广告池", businessType = BusinessType.UPDATE)
    @PostMapping("/send")
    @ResponseBody
    public AjaxResult editSave(AdvertisingUnitMedia advertisingUnitMedia) {
        WeChatNews weChatNews = new WeChatNews();
        weChatNews.setNewsId(advertisingUnitMedia.getId());
        weChatNews.setErrcode(1);
        List<WeChatNews> weChatNewsList = weChatNewsService.selectWeChatNewsList(weChatNews);
        for (WeChatNews weChatNewsnew : weChatNewsList) {
            //推送公众号消息
            String gzhToken = WeChatUtil.getAuthorizerAccessToken(weChatNewsnew.getAppid());
            if (StringUtils.isNotBlank(gzhToken)) {
                WeChatNews weChatNewsResult = WeChatUtil.sendall(gzhToken, weChatNewsnew);
                if (null != weChatNewsResult) {
                    weChatNewsResult.setId(weChatNewsnew.getId());
                    weChatNewsResult.setUpdateBaseParams(getUserId().intValue());
                    weChatNewsService.updateWeChatNews(weChatNewsResult);
                }
            }
        }
        advertisingUnitMedia.setUpdateBaseParams(getUserId().intValue());
        advertisingUnitMedia.setSendStatus(1);
        advertisingUnitMedia.setSendTime(DateUtils.getNowDate());
        return toAjax(advertisingUnitMediaService.updateAdvertisingUnitMedia(advertisingUnitMedia));
    }

    /**
     * 查看媒体矩阵广告池
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingUnitMedia advertisingUnitMedia = advertisingUnitMediaService.selectAdvertisingUnitMediaById(id);
        mmap.put("advertisingUnitMedia", advertisingUnitMedia);
        return prefix + "/edit";
    }

    /**
     * 查看公众号发送状态
     * */
    @GetMapping("/weChatNews/{id}")
    public String weChatNews(@PathVariable("id") Integer id, @PathParam("code") String code, ModelMap mmap){
        WeChatNews weChatNews = new WeChatNews();
        weChatNews.setNewsId(id);
        weChatNews.setErrcode(Integer.parseInt(code));
        mmap.put("weChatNews",weChatNews);
        return prefix + "/weChatMedis";
    }
    @PostMapping("/weChatMedis")
    @ResponseBody
    public TableDataInfo weChatMedis(WeChatNews weChatNews){
        startPage();
        List<WeChatNews> weChatNewsList = weChatNewsService.selectWeChatNewsList(weChatNews);
        return getDataTable(weChatNewsList);
    }


    /**
     * 删除媒体矩阵广告池
     */
    @RequiresPermissions("dsp:advertisingUnitMedia:remove")
    @Log(title = "媒体矩阵广告池", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingUnitMediaService.deleteAdvertisingUnitMediaByIds(ids));
    }

}
