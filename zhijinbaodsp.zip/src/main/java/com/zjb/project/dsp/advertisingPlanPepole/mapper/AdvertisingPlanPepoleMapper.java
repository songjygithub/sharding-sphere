package com.zjb.project.dsp.advertisingPlanPepole.mapper;

import com.zjb.project.dsp.advertisingPlanPepole.domain.AdvertisingPlanPepole;

import java.util.List;

/**
 * 广告投放人群定向 数据层
 *
 * @author songjy
 * @date 2019-07-12
 */
public interface AdvertisingPlanPepoleMapper {
    /**
     * 查询广告投放人群定向信息
     *
     * @param id 广告投放人群定向ID
     * @return 广告投放人群定向信息
     */
    AdvertisingPlanPepole selectAdvertisingPlanPepoleById(Integer id);

    /**
     * 查询广告投放人群定向列表
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 广告投放人群定向集合
     */
    List<AdvertisingPlanPepole> selectAdvertisingPlanPepoleList(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 新增广告投放人群定向
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 结果
     */
    int insertAdvertisingPlanPepole(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 修改广告投放人群定向
     *
     * @param advertisingPlanPepole 广告投放人群定向信息
     * @return 结果
     */
    int updateAdvertisingPlanPepole(AdvertisingPlanPepole advertisingPlanPepole);

    /**
     * 删除广告投放人群定向
     *
     * @param id 广告投放人群定向ID
     * @return 结果
     */
    int deleteAdvertisingPlanPepoleById(Integer id);

    /**
     * 批量删除广告投放人群定向
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingPlanPepoleByIds(String[] ids);

    /**
     * 查询广告投放人群定向信息
     *
     * @param planId 广告计划ID
     * @return 广告投放人群定向信息
     */
    AdvertisingPlanPepole selectAdvertisingPlanPepoleByPlanId(String planId);

}