package com.zjb.project.dsp.blackThirdPlatformGzh.controller;

import java.util.List;

import com.alibaba.fastjson.JSON;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.blackThirdPlatformGzh.domain.BlackThirdPlatformGzh;
import com.zjb.project.dsp.blackThirdPlatformGzh.service.IBlackThirdPlatformGzhService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 第三方平台公众号黑名单 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-04-17
 */
@Controller
@RequestMapping("/dsp/blackThirdPlatformGzh")
public class BlackThirdPlatformGzhController extends BaseController
{
	private static final Logger logger = LoggerFactory.getLogger(BlackThirdPlatformGzhController.class);
    private String prefix = "dsp/blackThirdPlatformGzh";
	
	@Autowired
	private IBlackThirdPlatformGzhService blackThirdPlatformGzhService;
	
	@RequiresPermissions("dsp:blackThirdPlatformGzh:view")
	@GetMapping()
	public String blackThirdPlatformGzh()
	{
	    return prefix + "/blackThirdPlatformGzh";
	}
	
	/**
	 * 查询第三方平台公众号黑名单列表
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzh:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{
		startPage();
		blackThirdPlatformGzh.setDeleted(0);
        List<BlackThirdPlatformGzh> list = blackThirdPlatformGzhService.selectBlackThirdPlatformGzhList(blackThirdPlatformGzh);
		return getDataTable(list);
	}
	
	/**
	 * 新增第三方平台公众号黑名单
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存第三方平台公众号黑名单
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzh:add")
	@Log(title = "第三方平台公众号黑名单", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{		
		return toAjax(blackThirdPlatformGzhService.insertBlackThirdPlatformGzh(blackThirdPlatformGzh));
	}

	/**
	 * 修改第三方平台公众号黑名单
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		BlackThirdPlatformGzh blackThirdPlatformGzh = blackThirdPlatformGzhService.selectBlackThirdPlatformGzhById(id);
		mmap.put("blackThirdPlatformGzh", blackThirdPlatformGzh);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存第三方平台公众号黑名单
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzh:edit")
	@Log(title = "第三方平台公众号黑名单", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(BlackThirdPlatformGzh blackThirdPlatformGzh)
	{		
		return toAjax(blackThirdPlatformGzhService.updateBlackThirdPlatformGzh(blackThirdPlatformGzh));
	}
	
	/**
	 * 删除第三方平台公众号黑名单
	 */
	@RequiresPermissions("dsp:blackThirdPlatformGzh:remove")
	@Log(title = "第三方平台公众号黑名单", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(blackThirdPlatformGzhService.deleteBlackThirdPlatformGzhByIds(ids));
	}

	/**
	 * 获取第三方平台公众号黑名单数量
	 * @param blackThirdPlatformGzh
	 * @return
	 */
	@PostMapping( "/getBlackThirdPlatformGzhCount")
	@ResponseBody
	public Integer getBlackThirdPlatformGzhCount(@RequestBody BlackThirdPlatformGzh blackThirdPlatformGzh){
		blackThirdPlatformGzh.setDeleted(0);
		return blackThirdPlatformGzhService.getBlackThirdPlatformGzhCount(blackThirdPlatformGzh);
	}
	
}
