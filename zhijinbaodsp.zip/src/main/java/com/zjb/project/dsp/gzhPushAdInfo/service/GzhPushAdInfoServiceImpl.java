package com.zjb.project.dsp.gzhPushAdInfo.service;

import java.util.Date;
import java.util.List;

import com.zjb.common.enums.ZjbDictionaryEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.gzhPushAdInfo.mapper.GzhPushAdInfoMapper;
import com.zjb.project.dsp.gzhPushAdInfo.domain.GzhPushAdInfo;
import com.zjb.common.support.Convert;

/**
 * 关注公众号推送广告 服务层实现
 * 
 * @author shenlong
 * @date 2019-08-24
 */
@Service
public class GzhPushAdInfoServiceImpl implements IGzhPushAdInfoService
{
	@Autowired
	private GzhPushAdInfoMapper gzhPushAdInfoMapper;

	/**
     * 查询关注公众号推送广告信息
     * 
     * @param id 关注公众号推送广告ID
     * @return 关注公众号推送广告信息
     */
    @Override
	public GzhPushAdInfo selectGzhPushAdInfoById(Integer id)
	{
	    return gzhPushAdInfoMapper.selectGzhPushAdInfoById(id);
	}

	@Override
	public GzhPushAdInfo selectGzhPushAdInfoByAdId(String adId) {
		return gzhPushAdInfoMapper.selectGzhPushAdInfoByAdId(adId);
	}

	/**
     * 查询关注公众号推送广告列表
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 关注公众号推送广告集合
     */
	@Override
	public List<GzhPushAdInfo> selectGzhPushAdInfoList(GzhPushAdInfo gzhPushAdInfo)
	{
	    return gzhPushAdInfoMapper.selectGzhPushAdInfoList(gzhPushAdInfo);
	}

	@Override
	public List<GzhPushAdInfo> selectGzhPushAdInfoListByName(GzhPushAdInfo gzhPushAdInfo) {
		return gzhPushAdInfoMapper.selectGzhPushAdInfoListByName(gzhPushAdInfo);
	}

	/**
     * 新增关注公众号推送广告
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 结果
     */
	@Override
	public int insertGzhPushAdInfo(GzhPushAdInfo gzhPushAdInfo)
	{
		gzhPushAdInfo.setGmtCreated(new Date());
		int i = gzhPushAdInfoMapper.insertGzhPushAdInfo(gzhPushAdInfo);
		if (i > 0) {
			gzhPushAdInfo.setAdId(ZjbDictionaryEnum.AD_UNIT_TYPE_MESSAGE.getValue().toString() + gzhPushAdInfo.getId());
			i += gzhPushAdInfoMapper.updateGzhPushAdInfo(gzhPushAdInfo);
		}
		return i;

	}
	
	/**
     * 修改关注公众号推送广告
     * 
     * @param gzhPushAdInfo 关注公众号推送广告信息
     * @return 结果
     */
	@Override
	public int updateGzhPushAdInfo(GzhPushAdInfo gzhPushAdInfo)
	{

		gzhPushAdInfo.setGmtModified(new Date());
	    return gzhPushAdInfoMapper.updateGzhPushAdInfo(gzhPushAdInfo);
	}

	/**
     * 删除关注公众号推送广告对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGzhPushAdInfoByIds(String ids)
	{
		return gzhPushAdInfoMapper.deleteGzhPushAdInfoByIds(Convert.toStrArray(ids));
	}
	
}
