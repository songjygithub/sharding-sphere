package com.zjb.project.dsp.advertisingPlanDevice.service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.dsp.advertisingADExchange.service.AdExchangeServiceImpl;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.mapper.AdvertisingPlanMapper;
import com.zjb.project.dsp.advertisingPlan.service.AdPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlan.service.AdvertisingPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.mapper.AdvertisingPlanDeviceMapper;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanFans.mapper.AdvertisingPlanFansMapper;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;
import com.zjb.project.dsp.advertisingPlanPay.mapper.AdvertisingPlanPayMapper;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.mapper.AdvertisingPlanWxMapper;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.mapper.MediumSellRullMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

import static com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService.MEDIUM_SELL_RULES;

/**
 * 广告投放设备定向 服务层实现
 *
 * @author songjy
 * @date 2019-07-12
 */
@Service
public class AdvertisingPlanDeviceServiceImpl extends AdPlanServiceImpl implements IAdvertisingPlanDeviceService, InitializingBean {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private AdvertisingPlanDeviceMapper advertisingPlanDeviceMapper;
    @Autowired
    private AdvertisingPlanMapper advertisingPlanMapper;
    @Autowired
    private AdvertisingPlanWxMapper advertisingPlanWxMapper;
    @Autowired
    private MediumSellRullMapper mediumSellRullMapper;
    @Autowired
    private AdvertisingPlanPayMapper advertisingPlanPayMapper;
    @Autowired
    private AdvertisingPlanFansMapper advertisingPlanFansMapper;

    /**
     * 设备定向计划对应的预编译类(Pattern)
     * <key=广告计划ID, Pattern>
     */
    private static final Map<String, Pattern> DEVICE_PLAN_MAP_PATTERN = new ConcurrentHashMap<>();

    /**
     * 查询广告投放设备定向信息
     *
     * @param id 广告投放设备定向ID
     * @return 广告投放设备定向信息
     */
    @Override
    public AdvertisingPlanDevice selectAdvertisingPlanDeviceById(Integer id) {
        return advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceById(id);
    }

    /**
     * 查询广告投放设备定向列表
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 广告投放设备定向集合
     */
    @Override
    public List<AdvertisingPlanDevice> selectAdvertisingPlanDeviceList(AdvertisingPlanDevice advertisingPlanDevice) {
        return advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceList(advertisingPlanDevice);
    }

    /**
     * 新增广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice) {

        String regex = AdExchangeServiceImpl.getRegex(advertisingPlanDevice);
        advertisingPlanDevice.setRegex(regex);

        int r = advertisingPlanDeviceMapper.insertAdvertisingPlanDevice(advertisingPlanDevice);

        if (r <= 0) {
            return r;
        }

        addPattern(advertisingPlanDevice);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_ADD_DEVICE, advertisingPlanDevice);

        return r;
    }

    /**
     * 修改广告投放设备定向
     *
     * @param advertisingPlanDevice 广告投放设备定向信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingPlanDevice(AdvertisingPlanDevice advertisingPlanDevice) {

        AdvertisingPlanDevice oldRecord = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceById(advertisingPlanDevice.getId());

        if (null == oldRecord) {
            return 0;
        }


        String regexOld = AdExchangeServiceImpl.getRegex(oldRecord);
        int r = advertisingPlanDeviceMapper.updateAdvertisingPlanDevice(advertisingPlanDevice);

        if (r <= 0) {
            return r;
        }

        AdvertisingPlanDevice newRecord = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceById(advertisingPlanDevice.getId());
        String regexNew = AdExchangeServiceImpl.getRegex(newRecord);
        newRecord.setRegex(regexNew);

        if (!regexNew.equals(regexOld)) {
            r += advertisingPlanDeviceMapper.updateAdvertisingPlanDevice(newRecord);
            Map<String, AdvertisingPlanDevice> map = new HashMap<>();
            map.put("oldRecord", oldRecord);
            map.put("newRecord", newRecord);
            JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_AD_PATTERN_UPDATE_DEVICE, JSON.toJSONString(map));
        }

        return r;
    }

    /**
     * 删除广告投放设备定向对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingPlanDeviceByIds(String ids) {
        return advertisingPlanDeviceMapper.deleteAdvertisingPlanDeviceByIds(Convert.toStrArray(ids));
    }

    @Override
    public void afterPropertiesSet() throws Exception {

        mediumSellRules();

        reloadPatternPlanAlipay();
        reloadPatternPlanWx();
        reloadPatternPlanPay();
        reloadPatternPlanFans();
    }

    /**
     * 有效的售卖规则
     */
    private void mediumSellRules() {
        MediumSellRull mediumSellRull = new MediumSellRull();
        mediumSellRull.setRullStatus(ZjbDictionaryEnum.RULL_STATUS_EFFECTIV.getValue());
        mediumSellRull.setDeleted(ZjbDictionaryEnum.NO.getValue());

        List<MediumSellRull> list = mediumSellRullMapper.selectMediumSellRullList(mediumSellRull);

        if (null == list || list.isEmpty()) {
            return;
        }

        MEDIUM_SELL_RULES.addAll(list);
    }

    /**
     * 载入支付宝相关广告计划正则
     */
    private void reloadPatternPlanAlipay() {
        AdvertisingPlan advertisingPlan = new AdvertisingPlan();
        advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());

        List<AdvertisingPlan> list = advertisingPlanMapper.selectAdvertisingPlanList(advertisingPlan);

        if (null == list || list.isEmpty()) {
            return;
        }

        Date now = new Date();

        for (AdvertisingPlan plan : list) {

            if (null != plan.getGmtShowEnd() && plan.getGmtShowEnd().before(now)) {
                plan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
                advertisingPlanMapper.updateAdvertisingPlan(plan);
                continue;
            }

            /*设备定向正则对应广告计划处理*/
            AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(plan.getPlanId());
            addPattern(advertisingPlanDevice);
        }
    }

    /**
     * 载入微信相关广告计划正则
     */
    private void reloadPatternPlanWx() {
        AdvertisingPlanWx advertisingPlan = new AdvertisingPlanWx();
        advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());

        List<AdvertisingPlanWx> list = advertisingPlanWxMapper.selectAdvertisingPlanWxList(advertisingPlan);

        if (null == list || list.isEmpty()) {
            return;
        }

        Date now = new Date();

        for (AdvertisingPlanWx plan : list) {

            AdvertisingPlanServiceImpl.synchronizeRedis(plan);

            if (null != plan.getGmtShowEnd() && plan.getGmtShowEnd().before(now)) {
                plan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
                advertisingPlanWxMapper.updateAdvertisingPlanWx(plan);
                continue;
            }

            /*设备定向正则对应广告计划处理*/
            AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(plan.getPlanId());
            addPattern(advertisingPlanDevice);
        }
    }

    /**
     * 载入付费取纸相关广告计划正则
     */
    private void reloadPatternPlanPay() {
        AdvertisingPlanPay advertisingPlan = new AdvertisingPlanPay();
        advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());

        List<AdvertisingPlanPay> list = advertisingPlanPayMapper.selectAdvertisingPlanPayList(advertisingPlan);

        if (null == list || list.isEmpty()) {
            return;
        }

        Date now = new Date();

        for (AdvertisingPlanPay plan : list) {

            AdvertisingPlanServiceImpl.synchronizeRedis(plan);

            if (null != plan.getGmtShowEnd() && plan.getGmtShowEnd().before(now)) {
                plan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
                advertisingPlanPayMapper.updateAdvertisingPlanPay(plan);
                continue;
            }

            /*设备定向正则对应广告计划处理*/
            AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(plan.getPlanId());
            addPattern(advertisingPlanDevice);
        }
    }

    /**
     * 载入粉丝通相关广告计划正则
     */
    private void reloadPatternPlanFans() {
        AdvertisingPlanFans advertisingPlan = new AdvertisingPlanFans();
        advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());

        List<AdvertisingPlanFans> list = advertisingPlanFansMapper.selectAdvertisingPlanFansList(advertisingPlan);

        if (null == list || list.isEmpty()) {
            return;
        }

        Date now = new Date();

        for (AdvertisingPlanFans plan : list) {

            AdvertisingPlanServiceImpl.synchronizeRedis(plan);

            if (null != plan.getGmtShowEnd() && plan.getGmtShowEnd().before(now)) {
                plan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_TIME_END.getValue());
                advertisingPlanFansMapper.updateAdvertisingPlanFans(plan);
                continue;
            }

            /*设备定向正则对应广告计划处理*/
            AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(plan.getPlanId());
            addPattern(advertisingPlanDevice);
        }
    }

    @Override
    public Map<String, Pattern> deviceRegexMapPattern() {
        return DEVICE_PLAN_MAP_PATTERN;
    }

    @Override
    public void addPattern(AdvertisingPlanDevice advertisingPlanDevice) {

        String planId = advertisingPlanDevice.getAdPlanId();

        if (StringUtils.isBlank(planId)) {
            logger.error("广告投放计划ID缺失");
            return;
        }

        if (!planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_PAY.getValue())
                && !planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_FANS.getValue())) {
            logger.error("广告投放计划ID格式错误");
            return;
        }

        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_ZFB.getValue())) {
            AdvertisingPlan plan = advertisingPlanMapper.selectAdvertisingPlanByPlanId(planId);
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_WX.getValue())) {
            AdvertisingPlan plan = advertisingPlanWxMapper.selectAdvertisingPlanWxByPlanId(planId);
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }
        if (planId.startsWith(ZjbDictionaryEnum.AD_UNIT_TYPE_PAY.getValue())) {
            AdvertisingPlan plan = advertisingPlanPayMapper.selectAdvertisingPlanPayByPlanId(planId);
            AdvertisingPlanServiceImpl.synchronizeRedis(plan);
        }

        String regex = AdExchangeServiceImpl.getRegex(advertisingPlanDevice);
        advertisingPlanDevice.setRegex(regex);

        DEVICE_PLAN_MAP_PATTERN.put(planId, Pattern.compile(regex));

    }

    @Override
    public void removePattern(AdvertisingPlanDevice advertisingPlanDevice) {
        String planId = advertisingPlanDevice.getAdPlanId();
        DEVICE_PLAN_MAP_PATTERN.remove(planId);
    }

    @Override
    public AdvertisingPlanDevice selectAdvertisingPlanDeviceByPlanId(String planId) {
        return advertisingPlanDeviceMapper.selectAdvertisingPlanDeviceByPlanId(planId);
    }

    @Override
    public Pattern pattern(String planId) {
        return DEVICE_PLAN_MAP_PATTERN.get(planId);
    }
}