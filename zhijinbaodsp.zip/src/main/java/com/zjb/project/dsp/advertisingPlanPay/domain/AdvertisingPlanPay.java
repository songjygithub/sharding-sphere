package com.zjb.project.dsp.advertisingPlanPay.domain;

import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;

/**
 * 广告投放计划(支付)表 zjb_advertising_plan_pay
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
public class AdvertisingPlanPay extends AdvertisingPlan
{
	private static final long serialVersionUID = 2353329730239009143L;
}
