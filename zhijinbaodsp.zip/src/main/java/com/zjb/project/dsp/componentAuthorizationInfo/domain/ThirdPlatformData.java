package com.zjb.project.dsp.componentAuthorizationInfo.domain;

import java.io.Serializable;

/**
 * 调用第三方公众号返回数据
 *
 * @author jiangbingjie
 */
public class ThirdPlatformData implements Serializable{
    private static final long serialVersionUID = -1358929458634765166L;

    /**
     * 开发者公众号appid
     */
    private String appid;

    /**
     * 第三方公众号对应的二维码地址
     */
    private String qrcode_url;

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getQrcode_url() {
        return qrcode_url;
    }

    public void setQrcode_url(String qrcode_url) {
        this.qrcode_url = qrcode_url;
    }
}
