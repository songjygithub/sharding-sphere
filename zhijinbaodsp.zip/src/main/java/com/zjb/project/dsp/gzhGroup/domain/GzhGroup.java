package com.zjb.project.dsp.gzhGroup.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * 公众号组表 zjb_gzh_group
 *
 * @author zjb
 * @date 2019-07-12
 */
public class GzhGroup extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    private Integer id;
    /**
     *
     */
    private String groupId;
    /**
     * 组名
     */
    private String groupName;
    /**
     * 公众号列表
     */
    private String gzhList;
    /**
     * 描述
     */
    private String groupDesc;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupName() {
        return groupName;
    }

    public String getGroupDesc() {
        return groupDesc;
    }

    public String getGzhList() {
        return gzhList;
    }

    public void setGzhList(String gzhList) {
        this.gzhList = gzhList;
    }

    public void setGroupDesc(String groupDesc) {
        this.groupDesc = groupDesc;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

}
