package com.zjb.project.dsp.gzhTjData.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.*;

import cn.hutool.core.date.DateUtil;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.componentgzhevent.service.IComponentGzhEventService;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.gzhTjData.domain.GzhTjData;
import com.zjb.project.dsp.gzhTjData.service.IGzhTjDataService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 公众号关注数据 信息操作处理
 *
 * @author shenlong
 * @date 2020-01-04
 */
@Controller
@RequestMapping("/dsp/gzhTjData")
public class GzhTjDataController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "dsp/gzhTjData";

    @Autowired
    private IGzhTjDataService gzhTjDataService;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IComponentGzhEventService componentGzhEventService;

    @RequiresPermissions("dsp:gzhTjData:view")
    @GetMapping()
    public String gzhTjData(ModelMap modelMap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = new ComponentAuthorizationInfo();
        List<ComponentAuthorizationInfo> componentAuthorizationInfos = componentAuthorizationInfoService.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
        modelMap.addAttribute("list", componentAuthorizationInfos);
        return prefix + "/gzhTjData";
    }

    /**
     * 查询公众号关注数据列表
     */
    @RequiresPermissions("dsp:gzhTjData:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GzhTjData gzhTjData) {
        if(StringUtils.isBlank(gzhTjData.getAppid()) && StringUtils.isBlank(gzhTjData.getSelectDate())){
            return getDataTable(Collections.EMPTY_LIST);
        }
        if (StringUtils.isNotBlank(gzhTjData.getAppid())) {
            String[] appIds = gzhTjData.getAppid().split(",");
            gzhTjData.setAppIds(appIds);
        }
        if (StringUtils.isNotBlank(gzhTjData.getSelectDate())) {
            String[] date = gzhTjData.getSelectDate().split(" - ");
            gzhTjData.setStartDate(date[0]);
            gzhTjData.setEndDate(date[1]);
        }

        startPage();
        List<GzhTjData> list = gzhTjDataService.selectGzhTjDataListByAppIds(gzhTjData);
        return getDataTable(list);
    }

    /**
     * 新增公众号关注数据
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 下载公众号数据
     */
    @GetMapping("/download")
    public String download(ModelMap modelMap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = new ComponentAuthorizationInfo();
        List<ComponentAuthorizationInfo> componentAuthorizationInfos = componentAuthorizationInfoService.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
        modelMap.addAttribute("list", componentAuthorizationInfos);
        return prefix + "/downLoadData";
    }

    /**
     * 下载公众号数据
     */
    @PostMapping("/download")
    @ResponseBody
    public AjaxResult downloadData(GzhTjData gzhTjData) {
        if (StringUtils.isBlank(gzhTjData.getAppid())) {
            return error("请选择公众号!");

        }
        if (StringUtils.isBlank(gzhTjData.getSelectDate())) {
            return error("请选择日期!");
        }
        // 处理日期
        String[] split = gzhTjData.getSelectDate().split(" - ");
        List<UserInfo> userInfos = new ArrayList<>();
        if (DateUtil.isSameDay(DateUtils.dateTime("yyyy-MM-dd", split[0]), DateUtils.dateTime("yyyy-MM-dd", split[1]))) {
            userInfos = componentGzhEventService.exportSubscribeUserInfo(gzhTjData.getAppid(), DateUtils.dateTime("yyyy-MM-dd", split[0]));
        } else {
            List<String> days = DateUtils.getDays(split[0], split[1]);
            for (String d:days){
                Date date = DateUtils.dateTime("yyyy-MM-dd", d);
                List<UserInfo> userInfosTmp = componentGzhEventService.exportSubscribeUserInfo(gzhTjData.getAppid(), date);
                userInfos.addAll(userInfosTmp);
            }
        }
        if (userInfos == null || userInfos.isEmpty()) {
            return error("未查询到数据");
        }

        try {

            ExcelUtil<UserInfo> excelUtil = new ExcelUtil<>(UserInfo.class);
            AjaxResult ajaxResult = excelUtil.exportExcel(userInfos, "userInfo");
            String fileName = ajaxResult.get("msg").toString();
            String ext = FilenameUtils.getExtension(fileName);
            String md5 = DigestUtils.md5Hex(gzhTjData.getAppid() + DateUtils.getDate());
            String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + md5 + '.' + ext;
            File file = new File(FileUtils.getTempDirectory(), fileName);

            try {
                OssUtil.uploadFile(fileKey, new FileInputStream(file));
            } catch (FileNotFoundException e) {
                logger.error(e.getMessage(), e);
            }

            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            logger.info("文件OSS路径：{}", fileUrl);

            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);
            return ajaxResult;
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }
    }

    /**
     * 新增保存公众号关注数据
     */
    @RequiresPermissions("dsp:gzhTjData:add")
    @Log(title = "公众号关注数据", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GzhTjData gzhTjData) {
        return toAjax(gzhTjDataService.insertGzhTjData(gzhTjData));
    }

    /**
     * 修改公众号关注数据
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        GzhTjData gzhTjData = gzhTjDataService.selectGzhTjDataById(id);
        mmap.put("gzhTjData", gzhTjData);
        return prefix + "/edit";
    }

    /**
     * 修改保存公众号关注数据
     */
    @RequiresPermissions("dsp:gzhTjData:edit")
    @Log(title = "公众号关注数据", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GzhTjData gzhTjData) {
        return toAjax(gzhTjDataService.updateGzhTjData(gzhTjData));
    }

    /**
     * 删除公众号关注数据
     */
    @RequiresPermissions("dsp:gzhTjData:remove")
    @Log(title = "公众号关注数据", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(gzhTjDataService.deleteGzhTjDataByIds(ids));
    }

}
