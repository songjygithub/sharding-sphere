package com.zjb.project.dsp.advertisingCombinationPay.domain;

import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;

/**
 * 广告方案-支付表 zjb_advertising_combination_pay
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
public class AdvertisingCombinationPay extends AdvertisingCombination
{
	private static final long serialVersionUID = 1L;
	

	/** 方案路径 */
	private String programUrl;

	public String getProgramUrl() {
		return programUrl;
	}

	public void setProgramUrl(String programUrl) {
		this.programUrl = programUrl;
	}
}
