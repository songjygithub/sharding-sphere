package com.zjb.project.dsp.backupFileRecord.domain;

import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 文件备份记录表 zjb_backup_file_record
 *
 * @author songjy
 * @date 2019-08-27
 */
public class BackupFileRecord extends BaseEntity {
    private static final long serialVersionUID = -7210800144712507238L;

    /**
     * 自增主键
     */
    private Integer id;
    /**
     * 源文件名
     */
    private String srcFileName;
    /**
     * 备份文件名
     */
    private String backupFileName;
    /**
     * 文件MD5
     */
    private String md5;
    /**
     * 源文件创建时间
     */
    private Date gmtFileCreate;
    /**
     * 源文件修改时间
     */
    private Date gmtFileModify;

    /**
     * 本机IP
     */
    private String localIp;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setSrcFileName(String srcFileName) {
        this.srcFileName = srcFileName;
    }

    public String getSrcFileName() {
        return srcFileName;
    }

    public void setBackupFileName(String backupFileName) {
        this.backupFileName = backupFileName;
    }

    public String getBackupFileName() {
        return backupFileName;
    }

    public void setMd5(String md5) {
        this.md5 = md5;
    }

    public String getMd5() {
        return md5;
    }

    public void setGmtFileCreate(Date gmtFileCreate) {
        this.gmtFileCreate = gmtFileCreate;
    }

    public Date getGmtFileCreate() {
        return gmtFileCreate;
    }

    public void setGmtFileModify(Date gmtFileModify) {
        this.gmtFileModify = gmtFileModify;
    }

    public Date getGmtFileModify() {
        return gmtFileModify;
    }

    public String getLocalIp() {
        return localIp;
    }

    public void setLocalIp(String localIp) {
        this.localIp = localIp;
    }
}
