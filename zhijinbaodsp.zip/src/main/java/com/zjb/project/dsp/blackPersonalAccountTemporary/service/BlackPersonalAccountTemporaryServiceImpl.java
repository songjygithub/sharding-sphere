package com.zjb.project.dsp.blackPersonalAccountTemporary.service;

import java.util.List;

import cn.hutool.extra.emoji.EmojiUtil;
import com.vdurmont.emoji.EmojiParser;
import com.zjb.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.blackPersonalAccountTemporary.mapper.BlackPersonalAccountTemporaryMapper;
import com.zjb.project.dsp.blackPersonalAccountTemporary.domain.BlackPersonalAccountTemporary;
import com.zjb.project.dsp.blackPersonalAccountTemporary.service.IBlackPersonalAccountTemporaryService;
import com.zjb.common.support.Convert;

/**
 * 个人号黑名单临时 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-05-08
 */
@Service
public class BlackPersonalAccountTemporaryServiceImpl implements IBlackPersonalAccountTemporaryService 
{
	@Autowired
	private BlackPersonalAccountTemporaryMapper blackPersonalAccountTemporaryMapper;

	/**
     * 查询个人号黑名单临时信息
     * 
     * @param id 个人号黑名单临时ID
     * @return 个人号黑名单临时信息
     */
    @Override
	public BlackPersonalAccountTemporary selectBlackPersonalAccountTemporaryById(Integer id)
	{
	    return blackPersonalAccountTemporaryMapper.selectBlackPersonalAccountTemporaryById(id);
	}
	
	/**
     * 查询个人号黑名单临时列表
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 个人号黑名单临时集合
     */
	@Override
	public List<BlackPersonalAccountTemporary> selectBlackPersonalAccountTemporaryList(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{
	    return blackPersonalAccountTemporaryMapper.selectBlackPersonalAccountTemporaryList(blackPersonalAccountTemporary);
	}
	
    /**
     * 新增个人号黑名单临时
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 结果
     */
	@Override
	public int insertBlackPersonalAccountTemporary(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{
		//个人号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackPersonalAccountTemporary.getPersonalNickName())){
			String personalNickName = EmojiParser.parseToAliases(blackPersonalAccountTemporary.getPersonalNickName());
			blackPersonalAccountTemporary.setPersonalNickName(personalNickName);
		}
	    return blackPersonalAccountTemporaryMapper.insertBlackPersonalAccountTemporary(blackPersonalAccountTemporary);
	}
	
	/**
     * 修改个人号黑名单临时
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 结果
     */
	@Override
	public int updateBlackPersonalAccountTemporary(BlackPersonalAccountTemporary blackPersonalAccountTemporary)
	{
		//个人号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackPersonalAccountTemporary.getPersonalNickName())){
			String personalNickName = EmojiParser.parseToAliases(blackPersonalAccountTemporary.getPersonalNickName());
			blackPersonalAccountTemporary.setPersonalNickName(personalNickName);
		}
	    return blackPersonalAccountTemporaryMapper.updateBlackPersonalAccountTemporary(blackPersonalAccountTemporary);
	}

	/**
     * 删除个人号黑名单临时对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteBlackPersonalAccountTemporaryByIds(String ids)
	{
		return blackPersonalAccountTemporaryMapper.deleteBlackPersonalAccountTemporaryByIds(Convert.toStrArray(ids));
	}

	/**
	 * 清除个人号黑名单临时数据
	 * @return
	 */
	@Override
	public int removeBlackPersonalAccountTemporary() {
		return blackPersonalAccountTemporaryMapper.removeBlackPersonalAccountTemporary();
	}

}
