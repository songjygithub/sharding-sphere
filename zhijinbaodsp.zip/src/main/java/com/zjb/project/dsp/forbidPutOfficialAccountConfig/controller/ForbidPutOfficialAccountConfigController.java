package com.zjb.project.dsp.forbidPutOfficialAccountConfig.controller;

import java.io.InputStream;
import java.util.*;

import com.zjb.common.support.Convert;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.project.common.device.domain.DeviceDTO;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.mediumSellRull.controller.MediumSellRullController;
import com.zjb.project.system.dict.domain.DictData;
import com.zjb.project.system.dict.service.IDictDataService;
import org.apache.shiro.authz.annotation.Logical;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.service.IForbidPutOfficialAccountConfigService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;
import org.springframework.web.multipart.MultipartFile;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 指定次数禁投公众号广告配置 信息操作处理
 *
 * @author jiangbingjie
 * @date 2020-02-20
 */
@Controller
@RequestMapping("/dsp/forbidPutOfficialAccountConfig")
public class ForbidPutOfficialAccountConfigController extends BaseController {
    private String prefix = "dsp/forbidPutOfficialAccountConfig";
    private static final Logger log = LoggerFactory.getLogger(ForbidPutOfficialAccountConfigController.class);
    @Autowired
    private IAgencyService agencyService;
    @Autowired
    private IDictDataService dictDataService;
    @Autowired
    private IDeviceService deviceService;

    @Autowired
    private IForbidPutOfficialAccountConfigService forbidPutOfficialAccountConfigService;

    @RequiresPermissions(value = {"dsp:forbidPutOfficialAccountConfig:view", "dsp:mediumSellRull:config"}, logical = Logical.OR)
    @GetMapping()
    public String forbidPutOfficialAccountConfig(ModelMap map) {
        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /**过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());

        map.put("agencyList", agencyList);

        /**获取售卖规则不出现公众号广告当日取纸次数 */
        List<DictData> dictDataList = dictDataService.selectDictDataByType("zjb_take_paper_times");
        map.put("dictDataList", dictDataList);
        return prefix + "/forbidPutOfficialAccountConfig";
    }

    /**
     * 查询指定次数禁投公众号广告配置列表
     */
    @RequiresPermissions(value = {"dsp:forbidPutOfficialAccountConfig:list", "dsp:mediumSellRull:config"}, logical = Logical.OR)
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        Date date = new Date();
        if (StringUtils.isNotEmpty(forbidPutOfficialAccountConfig.getAgencyIds())) {
            String[] agencyIdList = forbidPutOfficialAccountConfig.getAgencyIds().split(",");
            if (agencyIdList.length > 0) {
                forbidPutOfficialAccountConfig.setAgencyIdList(Arrays.asList(agencyIdList));
            }
        }
        if (null != forbidPutOfficialAccountConfig.getTakePaperTime()) {
            forbidPutOfficialAccountConfig.setTakePaperTimes(forbidPutOfficialAccountConfig.getTakePaperTime() + ",");
        }
        String nowTime = DateUtils.getTime();
        forbidPutOfficialAccountConfig.setNowTime(nowTime);
        startPage();
        List<ForbidPutOfficialAccountConfig> list = forbidPutOfficialAccountConfigService.selectForbidPutOfficialAccountConfigList(forbidPutOfficialAccountConfig);
        if (list != null && list.size() > 0) {
            for (ForbidPutOfficialAccountConfig config : list) {
                if (null == config.getConfigStatus()) {
                    if (null != config.getEffectiveTime() && null != config.getLoseEfficacyTime()) {
                        if (DateUtils.getDateBetweenStartAndEndDate(date, config.getEffectiveTime(), config.getLoseEfficacyTime())) {
                            config.setConfigStatus(FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_RUN.getValue());
                        } else {
                            config.setConfigStatus(FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_AUTOMATIC_STOP.getValue());
                        }
                    }
                }

                if (null != config.getForbidPutOfficialAccountType()) {
                    if (FORBID_PUT_OFFICIAL_ACCOUNT_TYPE_ALL.getValue() == config.getForbidPutOfficialAccountType()) {
                        config.setTakePaperTimesDesc("全部次数");
                    } else {
                        if (StringUtils.isNotEmpty(config.getTakePaperTimes())) {
                            String[] takePaperTime = config.getTakePaperTimes().split(",");
                            if (takePaperTime.length > 0) {
                                StringBuffer sb = new StringBuffer();
                                for (String times : takePaperTime) {
                                    sb.append("第");
                                    sb.append(times);
                                    sb.append("次");
                                    sb.append("，");
                                }
                                if (sb.length() > 0) {
                                    String takePaperTimesDesc = sb.toString();
                                    takePaperTimesDesc = takePaperTimesDesc.substring(0, takePaperTimesDesc.length() - 1);
                                    config.setTakePaperTimesDesc(takePaperTimesDesc);
                                }
                            }
                        }
                    }
                }
            }
        }
        return getDataTable(list);
    }

    /**
     * 新增指定次数禁投公众号广告配置
     */
    @GetMapping("/add")
    public String add(ModelMap map) {
        List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

        /**过滤掉子代理商 */
        agencyList.removeIf(agency -> null != agency.getParentAgencyId());

        map.put("agencyList", agencyList);

        /**获取售卖规则不出现公众号广告当日取纸次数 */
        List<DictData> dictDataList = dictDataService.selectDictDataByType("zjb_take_paper_times");
        map.put("dictDataList", dictDataList);
        return prefix + "/configForbidPutOfficialAccountView";
    }

    /**
     * 新增保存指定次数禁投公众号广告配置
     */
    @RequiresPermissions("dsp:mediumSellRull:config")
    @Log(title = "指定次数禁投公众号广告配置", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        return toAjax(forbidPutOfficialAccountConfigService.insertForbidPutOfficialAccountConfig(forbidPutOfficialAccountConfig));
    }

    /**
     * 修改指定次数禁投公众号广告配置
     */
    @GetMapping("/edit/{configId}")
    public String edit(@PathVariable("configId") Integer configId, ModelMap mmap) {
        ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig = forbidPutOfficialAccountConfigService.selectForbidPutOfficialAccountConfigById(configId);
        mmap.put("forbidPutOfficialAccountConfig", forbidPutOfficialAccountConfig);
        return prefix + "/edit";
    }

    /**
     * 修改保存指定次数禁投公众号广告配置
     */
    @RequiresPermissions("dsp:forbidPutOfficialAccountConfig:edit")
    @Log(title = "指定次数禁投公众号广告配置", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        return toAjax(forbidPutOfficialAccountConfigService.updateForbidPutOfficialAccountConfig(forbidPutOfficialAccountConfig));
    }

    /**
     * 删除指定次数禁投公众号广告配置
     */
    @RequiresPermissions("dsp:forbidPutOfficialAccountConfig:remove")
    @Log(title = "指定次数禁投公众号广告配置", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(forbidPutOfficialAccountConfigService.deleteForbidPutOfficialAccountConfigByIds(ids));
    }

    /**
     * 新增指定次数禁投公众号广告配置
     *
     * @param file
     * @param forbidPutOfficialAccountConfig
     * @return
     */
    @RequiresPermissions("dsp:mediumSellRull:config")
    @Log(title = "指定次数禁投公众号广告配置", businessType = BusinessType.UPDATE)
    @PostMapping("/configForbidPutOfficialAccounts")
    @ResponseBody
    public AjaxResult configForbidPutOfficialAccounts(@RequestParam(value = "fileExcel", required = false) MultipartFile file, ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig) {
        Integer modifierId = getUserId().intValue();
		Date date = new Date();
        if ((null == file || file.isEmpty()) && null == forbidPutOfficialAccountConfig) {
            return error("设备及代理商信息不能同时为空");
        }
        if (null == forbidPutOfficialAccountConfig.getLoseEfficacyTime()) {
            return error("失效时间不能为空");
        }
        if (null == forbidPutOfficialAccountConfig.getForbidPutOfficialAccountType()) {
            return error("取纸次数类型不能为空");
        }
        if (FORBID_PUT_OFFICIAL_ACCOUNT_TYPE_PART.getValue() == forbidPutOfficialAccountConfig.getForbidPutOfficialAccountType() && StringUtils.isEmpty(forbidPutOfficialAccountConfig.getTakePaperTimes())) {
            return error("指定次数取纸时指定次数不能为空");
        }
        Set<String> set = new HashSet<>();
        //指定设备
        try (InputStream is = file.getInputStream()) {
            ExcelUtil<ForbidPutOfficialAccountConfig> util = new ExcelUtil<ForbidPutOfficialAccountConfig>(ForbidPutOfficialAccountConfig.class);
            List<ForbidPutOfficialAccountConfig> list = util.importExcel(is);
            if (null == list || list.isEmpty()) {
                log.warn("文件格式错误或空文件");
            } else {
                for (ForbidPutOfficialAccountConfig e : list) {
                    if (StringUtils.isNotEmpty(e.getMixId())) {
                        String mixId = StringUtils.trim(e.getMixId().replaceAll("\\xa0", "").replaceAll("\u00A0", ""));
                        set.add(mixId);
                    }
                }
            }

        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        //指定代理商
        try {
            if (StringUtils.isNotEmpty(forbidPutOfficialAccountConfig.getAgencyIds())) {
                String[] agencyIdList = forbidPutOfficialAccountConfig.getAgencyIds().split(",");
                if (agencyIdList.length > 0) {
                    for (String agencyId : agencyIdList) {
                        if (StringUtils.isNotEmpty(agencyId)) {
                            //获取该代理商的设备信息
                            List<String> deviceSnList = deviceService.selectDeviceSnByAgencyId(Integer.parseInt(agencyId));
                            if (deviceSnList != null && !(deviceSnList.isEmpty())) {
                                set.addAll(deviceSnList);
                            }
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (set.size() == 0) {
            return error("请至少选择一台设备信息");
        }
        Iterator<String> it = set.iterator();
        while (it.hasNext()) {
            String deviceSn = it.next();

            DeviceDTO device = deviceService.selectDeviceByMixId(deviceSn);
            if (null != device && StringUtils.isNotBlank(device.getSn())) {
                ForbidPutOfficialAccountConfig config = new ForbidPutOfficialAccountConfig();
                config.setDeviceId(device.getId());
                config.setDeviceName(device.getName());
                config.setInstallSceneTypeCode(device.getInstallCodeType());
                config.setInstallSceneCode(device.getInstallCode());
                config.setDeviceSn(device.getSn());
                config.setAgencyId(device.getAgencyId());
                config.setAgencyName(device.getAgencyName());
                config.setForbidPutOfficialAccountType(forbidPutOfficialAccountConfig.getForbidPutOfficialAccountType());
                if (StringUtils.isNotEmpty(forbidPutOfficialAccountConfig.getTakePaperTimes())) {
                    config.setTakePaperTimes(forbidPutOfficialAccountConfig.getTakePaperTimes() + ",");
                }
                config.setEffectiveTime(date);
                config.setLoseEfficacyTime(forbidPutOfficialAccountConfig.getLoseEfficacyTime());
                config.setInsertBaseParams(modifierId, modifierId);
                forbidPutOfficialAccountConfigService.insertForbidPutOfficialAccountConfig(config);
            } else {
                log.warn("无效设备SN：【{}】", deviceSn);
            }
        }
        return success();
    }


    /**
     * 停止生效指定次数禁投公众号广告配置
     */
    @RequiresPermissions("dsp:forbidPutOfficialAccountConfig:stop")
    @Log(title = "指定次数禁投公众号广告配置", businessType = BusinessType.UPDATE)
    @PostMapping("/stop")
    @ResponseBody
    public AjaxResult stop(String ids) {
        Integer modifierId = getUserId().intValue();
		Date date = new Date();
        if (StringUtils.isEmpty(ids)) {
            return error("请至少选择一条信息");
        }
        String[] idList = ids.split(",");
        if (idList.length <= 0) {
            return error("请至少选择一条信息");
        }
        try {
            for (String id : idList) {
                ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig = forbidPutOfficialAccountConfigService.selectForbidPutOfficialAccountConfigById(Integer.parseInt(id));
                if (forbidPutOfficialAccountConfig != null) {
                    if (forbidPutOfficialAccountConfig.getEffectiveTime() != null && forbidPutOfficialAccountConfig.getLoseEfficacyTime() != null) {
                        if (DateUtils.getDateBetweenStartAndEndDate(date, forbidPutOfficialAccountConfig.getEffectiveTime(), forbidPutOfficialAccountConfig.getLoseEfficacyTime())) {
                            if (null == forbidPutOfficialAccountConfig.getConfigStatus() || FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_RUN.getValue() == forbidPutOfficialAccountConfig.getConfigStatus()) {
                                forbidPutOfficialAccountConfig.setConfigStatus(FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS_HAND_STOP.getValue());
                                forbidPutOfficialAccountConfig.setUpdateBaseParams(modifierId);
                                forbidPutOfficialAccountConfigService.updateForbidPutOfficialAccountConfig(forbidPutOfficialAccountConfig);
                            }
                        }
                    }
                } else {
                    log.warn("无效代理商广告配置：【{}】", id);
                }
            }
        } catch (Exception e) {
            log.error(e.getMessage(), e);
            return error("停止生效指定次数禁投公众号广告配置失败");
        }
        return success();
    }

}
