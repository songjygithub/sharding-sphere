package com.zjb.project.dsp.advertisementWithoutBiddingPrice.service;

import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.AdvertisementWithoutBiddingPrice;
import com.zjb.project.dsp.advertisingADExchange.domain.WithoutBiddingAd;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;

import java.util.List;

/**
 * 非竞价广告投放 服务层
 * 
 * @author jiangbingjie
 * @date 2020-03-30
 */
public interface IAdvertisementWithoutBiddingPriceService 
{
	/**
     * 查询非竞价广告投放信息
     * 
     * @param id 非竞价广告投放ID
     * @return 非竞价广告投放信息
     */
	public AdvertisementWithoutBiddingPrice selectAdvertisementWithoutBiddingPriceById(Integer id);
	
	/**
     * 查询非竞价广告投放列表
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 非竞价广告投放集合
     */
	public List<AdvertisementWithoutBiddingPrice> selectAdvertisementWithoutBiddingPriceList(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
	
	/**
     * 新增非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	public int insertAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
	
	/**
     * 修改非竞价广告投放
     * 
     * @param advertisementWithoutBiddingPrice 非竞价广告投放信息
     * @return 结果
     */
	public int updateAdvertisementWithoutBiddingPrice(AdvertisementWithoutBiddingPrice advertisementWithoutBiddingPrice);
		
	/**
     * 删除非竞价广告投放信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisementWithoutBiddingPriceByIds(String ids);

	/**
	 * 暂停非竞价广告投放
	 * @param ids
	 * @param userId
	 * @return
	 */
	public int stopAdvertisementWithoutBiddingPrice(String ids,Integer userId);

	/**
	 * 投放非竞价广告
	 * @param ids
	 * @param userId
	 * @return
	 */
	public int startAdvertisementWithoutBiddingPrice(String ids,Integer userId);

	/**
	 * 获取胜出的非竞价广告信息
	 * @param withoutBiddingAd
	 * @return
	 */
	public List<AdvertisingUnit> getAdvertisingUnitFansInfo(WithoutBiddingAd withoutBiddingAd);
	
}
