package com.zjb.project.dsp.advertisingplanstatistics.domain;

import org.springframework.data.mongodb.core.mapping.Document;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

/**
 * @author songjy
 * @Date 2019/11/25
 **/
@Document(collection = "ad_plan_statistics")
public class AdvertisingPlanStatistics implements Serializable {

    /**
     * 主键
     */
    private Long id;

    /**
     * 业务标识自增主键，且必须是01开头，即01 + id
     */
    private String adPlanId;

    /**
     * 统计日期，yyyy-MM-dd
     */
    private Date statisticsDate;

    /**
     * 创建时间
     */
    protected Date gmtCreated;
    /**
     * 修改时间
     */
    protected Date gmtModified;

    /**
     * 微信用户当日胜出数量
     */
    private Integer winWeChatDayAmount;

    /**
     * 微信用户当日数量
     */
    private Integer openIdWeChatDayAmount;

    /**
     * 支付宝用户当日胜出数量
     */
    private Integer winAliPayDayAmount;

    /**
     * 支付宝用户当日数量
     */
    private Integer openIdAliPayDayAmount;

    /**
     * 其他用户当日胜出数量
     */
    private Integer winOtherDayAmount;

    /**
     * 其他用户当日数量
     */
    private Integer openIdOtherDayAmount;

    /**
     * 微信用户查看记录
     */
    private Set<String> openIdWeChats;

    /**
     * 支付宝用户查看记录
     */
    private Set<String> openIdAliPays;

    /**
     * 其他用户查看记录
     */
    private Set<String> openIdOthers;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getAdPlanId() {
        return adPlanId;
    }

    public void setAdPlanId(String adPlanId) {
        this.adPlanId = adPlanId;
    }

    public Date getStatisticsDate() {
        return statisticsDate;
    }

    public void setStatisticsDate(Date statisticsDate) {
        this.statisticsDate = statisticsDate;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }
    

    public Integer getWinWeChatDayAmount() {
        return winWeChatDayAmount;
    }

    public void setWinWeChatDayAmount(Integer winWeChatDayAmount) {
        this.winWeChatDayAmount = winWeChatDayAmount;
    }

    public Integer getWinAliPayDayAmount() {
        return winAliPayDayAmount;
    }

    public void setWinAliPayDayAmount(Integer winAliPayDayAmount) {
        this.winAliPayDayAmount = winAliPayDayAmount;
    }

    public Integer getWinOtherDayAmount() {
        return winOtherDayAmount;
    }

    public void setWinOtherDayAmount(Integer winOtherDayAmount) {
        this.winOtherDayAmount = winOtherDayAmount;
    }

    public Set<String> getOpenIdWeChats() {
        return openIdWeChats;
    }

    public void setOpenIdWeChats(Set<String> openIdWeChats) {
        this.openIdWeChats = openIdWeChats;
    }

    public Set<String> getOpenIdAliPays() {
        return openIdAliPays;
    }

    public void setOpenIdAliPays(Set<String> openIdAliPays) {
        this.openIdAliPays = openIdAliPays;
    }

    public Set<String> getOpenIdOthers() {
        return openIdOthers;
    }

    public void setOpenIdOthers(Set<String> openIdOthers) {
        this.openIdOthers = openIdOthers;
    }

    public Integer getOpenIdWeChatDayAmount() {
        return openIdWeChatDayAmount;
    }

    public void setOpenIdWeChatDayAmount(Integer openIdWeChatDayAmount) {
        this.openIdWeChatDayAmount = openIdWeChatDayAmount;
    }

    public Integer getOpenIdAliPayDayAmount() {
        return openIdAliPayDayAmount;
    }

    public void setOpenIdAliPayDayAmount(Integer openIdAliPayDayAmount) {
        this.openIdAliPayDayAmount = openIdAliPayDayAmount;
    }

    public Integer getOpenIdOtherDayAmount() {
        return openIdOtherDayAmount;
    }

    public void setOpenIdOtherDayAmount(Integer openIdOtherDayAmount) {
        this.openIdOtherDayAmount = openIdOtherDayAmount;
    }
}
