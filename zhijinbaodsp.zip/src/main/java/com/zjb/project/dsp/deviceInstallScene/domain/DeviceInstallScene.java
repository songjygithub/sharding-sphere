package com.zjb.project.dsp.deviceInstallScene.domain;

import com.zjb.framework.web.domain.BaseEntity;

/**
 * @author jiangbingjie
 * @date 2020/2/27 1:30 AM
 */
public class DeviceInstallScene extends BaseEntity {

    private static final long serialVersionUID = 1L;

    /** 场景ID */
    private Integer sceneId;
    /** 父场景ID */
    private Integer parentId;
    /** 场景名称 */
    private String sceneName;
    /** 场景编码 */
    private String sceneCode;

    public Integer getSceneId() {
        return sceneId;
    }

    public void setSceneId(Integer sceneId) {
        this.sceneId = sceneId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public String getSceneName() {
        return sceneName;
    }

    public void setSceneName(String sceneName) {
        this.sceneName = sceneName;
    }

    public String getSceneCode() {
        return sceneCode;
    }

    public void setSceneCode(String sceneCode) {
        this.sceneCode = sceneCode;
    }
}
