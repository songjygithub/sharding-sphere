package com.zjb.project.dsp.componentAuthorizationInfo.service;

import com.alibaba.fastjson.JSON;
import com.zjb.common.constant.Constants;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.mapper.AdvertisingUnitMapper;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.mapper.AdvertisingUnitFansMapper;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.advertisingUnitWx.mapper.AdvertisingUnitWxMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.mapper.GzhGroupMapper;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.mapper.ScanTaskMapper;
import org.apache.commons.lang3.ArrayUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Caching;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.Types;
import java.time.LocalDate;
import java.util.*;

import static com.zjb.common.constant.AdvertisingConstants.KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE;
import static com.zjb.common.constant.ConstantsEhCache.CACHE_WE_CHAT_OFFICIAL_ACCOUNT;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON;

/**
 * 公众号或小程序的授权
 * 服务层实现
 *
 * @author zjb
 * @date 2019-07-09
 */
@Service
public class ComponentAuthorizationInfoServiceImpl implements IComponentAuthorizationInfoService, InitializingBean {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private GzhGroupMapper gzhGroupMapper;
    @Autowired
    private ScanTaskMapper scanTaskMapper;
    @Autowired
    private AdvertisingUnitWxMapper advertisingUnitWxMapper;
    @Autowired
    private AdvertisingUnitMapper advertisingUnitMapper;
    @Autowired
    private AdvertisingUnitFansMapper advertisingUnitFansMapper;
    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;
    @Autowired
    private CacheManager cacheManager;
    private Cache cacheWeChatOfficialAccount;

    @Override
    public void afterPropertiesSet() throws Exception {
        cacheWeChatOfficialAccount = cacheManager.getCache(CACHE_WE_CHAT_OFFICIAL_ACCOUNT);
    }

    /**
     * 查询公众号或小程序的授权
     * 信息
     *
     * @param id 公众号或小程序的授权
     *           ID
     * @return 公众号或小程序的授权
     * 信息
     */
    @Override
    public ComponentAuthorizationInfo selectComponentAuthorizationInfoById(Integer id) {
        return componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(id);
    }

    @Override
    public ComponentAuthorizationInfo selectByComponentId(String componentId) {
        return componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(componentId);
    }

    /**
     * 查询公众号或小程序的授权信息
     *
     * @param appId 公众号或小程序的授权ID
     * @return 公众号或小程序的授权信息
     */
    @Override
    public ComponentAuthorizationInfo selectComponentAuthorizationInfoByAppId(String appId) {
        return componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(appId);
    }

    /**
     * 查询公众号或小程序的授权
     * 列表
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 公众号或小程序的授权
     * 集合
     */
    @Override
    public List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoList(ComponentAuthorizationInfo componentAuthorizationInfo) {
        return componentAuthorizationInfoMapper.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
    }

    /**
     * 新增公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 结果
     */
    @Override
    public int insertComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo) {
        componentAuthorizationInfo.setGmtCreated(new Date());
        componentAuthorizationInfo.setGmtModified(componentAuthorizationInfo.getGmtCreated());
        if (!ZjbDictionaryEnum.MANUAL_ADD.getValue().equals(componentAuthorizationInfo.getComponentAuthorizationType())) {
            componentAuthorizationInfo.setLeapingLink("https://zhidage.top/?user_name=" + componentAuthorizationInfo.getUserName() + "#/gzhJump");
        }
        int r = componentAuthorizationInfoMapper.insertComponentAuthorizationInfo(componentAuthorizationInfo);

        if (r > 0) {
            logger.info("公众号{}生成的主键为:[{}]", componentAuthorizationInfo.getAppId(), componentAuthorizationInfo.getId());
            ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(componentAuthorizationInfo.getId());
            componentAuthorizationInfo1.setComponentId(AD_ZJB_OPEN_PLATFORM_PREFIX.getValue().toString() + componentAuthorizationInfo.getId());
            logger.info("公众号{}生成的编号为:[{}]", componentAuthorizationInfo1.getAppId(), componentAuthorizationInfo1.getComponentId());
            r += componentAuthorizationInfoMapper.updateComponentAuthorizationInfo(componentAuthorizationInfo1);
            logger.info("公众号{}之r={}", componentAuthorizationInfo1.getAppId(), r);
        } else {
            logger.info("公众号{}插入失败!", componentAuthorizationInfo.getAppId());
        }
        return r;
    }

    /**
     * 修改公众号或小程序的授权
     *
     * @param componentAuthorizationInfo 公众号或小程序的授权
     *                                   信息
     * @return 结果
     */
    @Override
    public int updateComponentAuthorizationInfo(ComponentAuthorizationInfo componentAuthorizationInfo) {

        ComponentAuthorizationInfo old = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(componentAuthorizationInfo.getId());

        if (null == old) {
            return 0;
        }

        componentAuthorizationInfo.setAppId(old.getAppId());
        int r = componentAuthorizationInfoMapper.updateComponentAuthorizationInfo(componentAuthorizationInfo);

        ComponentAuthorizationInfo newRecord = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(componentAuthorizationInfo.getId());

        Map<String, ComponentAuthorizationInfo> map = new HashMap<>(6);
        map.put(KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE, newRecord);
        JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));

        return r;
    }

    @Override
    public int updateComponentAuthorizationInfoLabel(ComponentAuthorizationInfo componentAuthorizationInfo) {

        ComponentAuthorizationInfo old = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(componentAuthorizationInfo.getId());

        if (null == old) {
            return 0;
        }

        componentAuthorizationInfo.setAppId(old.getAppId());
        int r = componentAuthorizationInfoMapper.updateComponentAuthorizationInfoLabel(componentAuthorizationInfo);

        ComponentAuthorizationInfo newRecord = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoById(componentAuthorizationInfo.getId());

        Map<String, ComponentAuthorizationInfo> map = new HashMap<>(6);
        map.put(KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE, newRecord);
        JedisPoolCacheUtils.publish(CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));

        clearLocalCache(old);

        return r;
    }

    /**
     * 删除公众号或小程序的授权
     * 对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteComponentAuthorizationInfoByIds(String ids) {
        return componentAuthorizationInfoMapper.deleteComponentAuthorizationInfoByIds(Convert.toStrArray(ids));
    }

    @Override
    public List<ComponentAuthorizationInfo> findByIds(Integer[] ids) {

        if (null == ids || 0 == ids.length) {
            return Collections.emptyList();
        }

        return componentAuthorizationInfoMapper.findByIds(ids);
    }

    @Override
    public void cleanDayFollowAmount() {

        /*日关注量清零*/
        int count = componentAuthorizationInfoMapper.cleanDayFollowAmount();
        logger.info("共{}条公众号日关注量清零", count);

        ComponentAuthorizationInfo query = new ComponentAuthorizationInfo();
        query.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue());
        List<ComponentAuthorizationInfo> list = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoList(query);

        if (null == list || list.isEmpty()) {
            return;
        }

        for (ComponentAuthorizationInfo authorizationInfo : list) {
            authorizationInfo.setDayFollowAmount(0);
            authorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());

            int r = componentAuthorizationInfoMapper.updateComponentAuthorizationInfo(authorizationInfo);
            if (r > 0) {
                logger.info("公众号【{}：{}】状态从{}变更为{}", authorizationInfo.getNickName(), authorizationInfo.getAppId(),
                        AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue(), AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
                restartAdvertisingUnit(authorizationInfo);
            }
            clearLocalCache(authorizationInfo);

        }
    }

    /**
     * 广告池优化：当公众号启用后，对应广告单元自动切换为启用状态
     *
     * @param authorizationInfo
     */
    private void restartAdvertisingUnit(ComponentAuthorizationInfo authorizationInfo) {
        List<AdvertisingUnit> unitList = selectUnit(authorizationInfo);

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnit unit : unitList) {
            if (unit.getClass() == AdvertisingUnit.class
                    && !unit.getAdUseStatus().equals(AD_USE_YES.getValue())
                    && AD_SPACE_PAPER_OUTPUT.getValue().equals(unit.getAdSpaceIdentifier())) {
                unit.setAdUseStatus(AD_USE_YES.getValue());
                int r = advertisingUnitMapper.updateAdvertisingUnit(unit);
                if (r > 0) {
                    logger.info("公众号【{}】状态变更为【{}】广告单元【{}】启用", authorizationInfo.getNickName(), authorizationInfo.getDeliveryStatus(), unit.getAdName());
                }
                continue;
            }

            if (unit.getClass() == AdvertisingUnitWx.class
                    && !unit.getAdUseStatus().equals(AD_USE_YES.getValue())
                    && AD_SPACE_PAPER_OUTPUT_WX.getValue().equals(unit.getAdSpaceIdentifier())) {
                unit.setAdUseStatus(AD_USE_YES.getValue());
                int r = advertisingUnitWxMapper.updateAdvertisingUnitWx((AdvertisingUnitWx) unit);
                if (r > 0) {
                    logger.info("公众号【{}】状态变更为【{}】广告单元【{}】启用", authorizationInfo.getNickName(), authorizationInfo.getDeliveryStatus(), unit.getAdName());
                }

                continue;
            }

            if (unit.getClass() == AdvertisingUnitFans.class
                    && !unit.getAdUseStatus().equals(AD_USE_YES.getValue())
                    && AD_FANS_PAPER_OUTPUT.getValue().equals(unit.getAdSpaceIdentifier())) {
                unit.setAdUseStatus(AD_USE_YES.getValue());
                int r = advertisingUnitFansMapper.updateAdvertisingUnitFans((AdvertisingUnitFans) unit);
                if (r > 0) {
                    logger.info("公众号【{}】状态变更为【{}】广告单元【{}】启用", authorizationInfo.getNickName(), authorizationInfo.getDeliveryStatus(), unit.getAdName());
                }
            }
        }
    }

    @Override
    public List<AdvertisingUnit> selectUnit(ComponentAuthorizationInfo componentAuthorizationInfo) {

        AdvertisingUnit advertisingUnit = new AdvertisingUnit();
        advertisingUnit.setDeleted(NO.getValue());
        advertisingUnit.setAdSpaceIdentifier(AD_SPACE_PAPER_OUTPUT.getValue());
        advertisingUnit.setWeChatAccount(componentAuthorizationInfo.getComponentId());
        List<AdvertisingUnit> unitList = advertisingUnitMapper.selectAdvertisingUnitList(advertisingUnit);

        if (null == unitList) {
            unitList = new ArrayList<>();
        }

        AdvertisingUnitWx advertisingUnitWx = new AdvertisingUnitWx();
        advertisingUnitWx.setDeleted(NO.getValue());
        advertisingUnitWx.setAdSpaceIdentifier(AD_SPACE_PAPER_OUTPUT_WX.getValue());
        advertisingUnitWx.setWeChatAccount(componentAuthorizationInfo.getComponentId());

        List<AdvertisingUnitWx> unitWxList = advertisingUnitWxMapper.selectAdvertisingUnitWxList(advertisingUnitWx);

        if (null != unitWxList && !unitWxList.isEmpty()) {
            unitList.addAll(unitWxList);
        }

        AdvertisingUnitFans unitFans = new AdvertisingUnitFans();
        unitFans.setDeleted(NO.getValue());
        unitFans.setAdSpaceIdentifier(AD_FANS_PAPER_OUTPUT.getValue());
        unitFans.setWeChatAccount(componentAuthorizationInfo.getComponentId());

        List<AdvertisingUnitFans> unitFansList = advertisingUnitFansMapper.selectAdvertisingUnitFansList(unitFans);
        if (null != unitFansList && !unitFansList.isEmpty()) {
            unitList.addAll(unitFansList);
        }

        List<GzhGroup> gzhGroups = gzhGroupMapper.selectByGzhList(componentAuthorizationInfo.getId().toString());

        if (null == gzhGroups || gzhGroups.isEmpty()) {
            return unitList;
        }

        for (Iterator<GzhGroup> it = gzhGroups.iterator(); it.hasNext(); ) {
            String[] array = StringUtils.split(it.next().getGzhList(), ',');
            if (!ArrayUtils.contains(array, componentAuthorizationInfo.getId().toString())) {
                it.remove();
            }
        }

        if (gzhGroups.isEmpty()) {
            return unitList;
        }

        List<ScanTask> taskList = new ArrayList<>();

        for (GzhGroup gzhGroup : gzhGroups) {
            List<ScanTask> scanTasks = scanTaskMapper.selectByGzhGroupId(gzhGroup.getId().toString());
            if (null != scanTasks && !scanTasks.isEmpty()) {
                taskList.addAll(scanTasks);
            }
        }

        if (taskList.isEmpty()) {
            return unitList;
        }

        for (ScanTask task : taskList) {
            List<AdvertisingUnitWx> advertisingUnitWxList = advertisingUnitWxMapper.selectAdvertisingUnitByTaskId(task.getId().toString());
            if (null != advertisingUnitWxList && !advertisingUnitWxList.isEmpty()) {
                unitList.addAll(advertisingUnitWxList);
            }
        }

        for (ScanTask task : taskList) {
            List<AdvertisingUnit> units = advertisingUnitMapper.selectAdvertisingUnitByTaskId(task.getId().toString());
            if (null != units && !units.isEmpty()) {
                unitList.addAll(units);
            }
        }

        return unitList;
    }

    @Override
    public List<ComponentAuthorizationInfo> selectComponentAuthorizationInfoByName(String nickName) {
        return componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByName(nickName);
    }

    @Override
    @Caching(evict = {@CacheEvict(value = CACHE_WE_CHAT_OFFICIAL_ACCOUNT, key = "#p0.id")})
    @CacheEvict(value = CACHE_WE_CHAT_OFFICIAL_ACCOUNT, key = "#p0.appId")
    public void clearLocalCache(ComponentAuthorizationInfo info) {
        logger.info("公众号【{}：{}：{}】本地缓存已清理", info.getAppId(), info.getId(), info.getNickName());
    }

    @Override
    @CacheEvict(value = CACHE_WE_CHAT_OFFICIAL_ACCOUNT, allEntries = true)
    public void clearAllLocalCache() {
        logger.warn("本地缓存【{}】中的元素已全部清理", CACHE_WE_CHAT_OFFICIAL_ACCOUNT);
    }

    @Override
    public int deleteComponentAuthorizationInfoPickPaperUrl(Integer id) {
        return componentAuthorizationInfoMapper.deleteComponentAuthorizationInfoPickPaperUrl(id);
    }


    @Override
    public int countSubscribeBeforeToday(String appId) {

        String key = "count_subscribe_before_today_" + appId + "_" + LocalDate.now().minusDays(1L);
        Integer countSubscribeBeforeToday = cacheWeChatOfficialAccount.get(key, Integer.class);

        if (null != countSubscribeBeforeToday) {
            return countSubscribeBeforeToday;
        }

        String sql = "SELECT COUNT(*) FROM `zjb_component_gzh_event` WHERE `appid` = ?  AND `gmt_date` <= ? AND `event` = ?";
        Object[] args = {appId, java.sql.Date.valueOf(LocalDate.now().minusDays(1L)), AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue()};
        int[] argTypes = {Types.VARCHAR, Types.DATE, Types.VARCHAR};
        countSubscribeBeforeToday = jdbcTemplate.queryForObject(sql, args, argTypes, Integer.class);
        cacheWeChatOfficialAccount.put(key, countSubscribeBeforeToday);
        return countSubscribeBeforeToday;
    }
}
