package com.zjb.project.dsp.advertisingUnit.controller;

import static com.zjb.common.constant.ZjbConstantsRedis.AD_PLAN_ID_PREFIX;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_MONTH;

import java.util.List;

import com.google.common.collect.Range;
import com.zjb.project.dsp.advertisingType.domain.AdvertisingType;
import com.zjb.project.dsp.advertisingType.service.IAdvertisingTypeService;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.file.FileUploadUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.service.IGzhGroupService;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.service.IScanTaskService;

/**
 * 广告池-支付宝 信息操作处理
 *
 * @author zjb
 * @date 2019-07-12
 */
@Controller
@RequestMapping("/zjb/advertisingUnit")
public class AdvertisingUnitController extends BaseController {
    private static final Logger logger = LoggerFactory.getLogger(AdvertisingUnitController.class);
    private String prefix = "zjb/advertisingUnit";

    @Autowired
    private IAdvertisingUnitService advertisingUnitService;
    @Autowired
    private IScanTaskService scanTaskService;
    @Autowired
    private IGzhGroupService gzhGroupService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IAdvertisingPlanService advertisingPlanService;
    @Autowired
    private IAdvertisingTypeService advertisingTypeService;

    @RequiresPermissions("zjb:advertisingUnit:view")
    @GetMapping()
    public String advertisingUnit() {
        return prefix + "/advertisingUnit";
    }

    /**
     * 查询广告池列表
     */
    @RequiresPermissions("zjb:advertisingUnit:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingUnit advertisingUnit) {
        startPage();
        List<AdvertisingUnit> list = advertisingUnitService.selectAdvertisingUnitList(advertisingUnit);

        for (AdvertisingUnit unit : list) {
            AdvertisingType advertisingType = advertisingTypeService.selectAdvertisingTypeById(unit.getAdTypeId());
            unit.setAdTypeName(null == advertisingType ? null : advertisingType.getTypeName());
        }

        return getDataTable(list);
    }

    /**
     * 新增广告池
     */
    @GetMapping("/add")
    public String add(ModelMap modelMap) {

        AdvertisingType query = new AdvertisingType();
        query.setTypeStatus(YES.getValue());
        List<AdvertisingType> advertisingTypes = advertisingTypeService.selectAdvertisingTypeList(query);
        advertisingTypes.removeIf(e -> Range.closed(1, 2).contains(e.getId()));
        modelMap.put("advertisingTypes", advertisingTypes);

        return prefix + "/add";
    }

    /**
     * 广告图片上传
     */
    @PostMapping("/uploadImg")
    @ResponseBody
    public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {
        try {
            if (!file.isEmpty()) {
                String fileKey = zjbConfig.getAdPhotoUrl() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(file.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, file.getInputStream());
                return success(ZjbConstants.File_Domain + "/" + fileKey);
            }
        } catch (Exception e) {
            logger.error("广告图片上传失败！", e);
        }
        return error();
    }

    /**
     * 新增保存广告池
     */
    @RequiresPermissions("zjb:advertisingUnit:add")
    @Log(title = "广告池", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingUnit advertisingUnit) {
        advertisingUnit.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());

        if (!AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())) {
            advertisingUnit.setWeChatAccount(null);
            advertisingUnit.setWeChatAccountName(null);
        }

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())) {
            advertisingUnit.setRedirectUrl(advertisingUnit.getWeChatAccountName());
        }

        return toAjax(advertisingUnitService.insertAdvertisingUnit(advertisingUnit));

    }

    /**
     * 修改广告池
     */
    @GetMapping("/edit")
    public String edit(ModelMap modelMap) {

        AdvertisingType query = new AdvertisingType();
        query.setTypeStatus(YES.getValue());
        List<AdvertisingType> advertisingTypes = advertisingTypeService.selectAdvertisingTypeList(query);
        advertisingTypes.removeIf(e -> Range.closed(1, 2).contains(e.getId()));
        modelMap.put("advertisingTypes", advertisingTypes);

        return prefix + "/edit";
    }

    /**
     * 获取广告信息
     */
    @PostMapping("/getAdvertisingUnit/{id}")
    @ResponseBody
    public AjaxResult advertisingUnit(@PathVariable("id") Integer id) {
        AdvertisingUnit advertisingUnit = advertisingUnitService.selectAdvertisingUnitById(id);
        if (null != advertisingUnit) {
            return success(advertisingUnit);
        }
        return error();
    }

    /**
     * 修改保存广告池
     */
    @RequiresPermissions("zjb:advertisingUnit:edit")
    @Log(title = "广告池", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingUnit advertisingUnit) {
        advertisingUnit.setUpdateBaseParams(getUserId().intValue());
        //置空
        if (StringUtils.isEmpty(advertisingUnit.getSupplementParam1())) {
            advertisingUnit.setSupplementParam1("-1");
        }
        if (StringUtils.isEmpty(advertisingUnit.getSupplementParam2())) {
            advertisingUnit.setSupplementParam2("-1");
        }

        if (AD_REDIRECT_WE_CHAT_ACCOUNT.getValue().equals(advertisingUnit.getRedirectUrlType())) {
            advertisingUnit.setRedirectUrl(advertisingUnit.getWeChatAccountName());
        }

        boolean stop = weChatOfficialAccountIsStop(advertisingUnit);
        if (stop) {
            return error("该取纸广告中配置的公众号已停用，如需启用请先至公众号开放平台将对应公众号改为生效状态。");
        }

        int r = advertisingUnitService.updateAdvertisingUnit(advertisingUnit);

        restartAdvertisingPlan(advertisingUnit);
        stopAdvertisingPlan(advertisingUnit);
        advertisingPlanService.mediumSellRuleThreeNotice();

        return toAjax(r);
    }

    /**
     * 广告取纸位关联的公众号是否已停止
     *
     * @param advertisingUnit
     * @return true 非生效中
     */
    private boolean weChatOfficialAccountIsStop(AdvertisingUnit advertisingUnit) {

        if (null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(ZjbDictionaryEnum.AD_USE_YES.getValue())
                || !ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())
                || !StringUtils.isNumeric(advertisingUnit.getAppId())
                || !ZjbDictionaryEnum.AD_REDIRECT_TASK.getValue().equals(advertisingUnit.getRedirectUrlType())) {
            return false;
        }

        ScanTask scanTask = scanTaskService.selectScanTaskById(Integer.parseInt(advertisingUnit.getAppId()));

        if (null == scanTask || !StringUtils.isNumeric(scanTask.getExpansionA())) {
            return false;
        }

        GzhGroup gzhGroup = gzhGroupService.selectGzhGroupById(Integer.parseInt(scanTask.getExpansionA()));
        if (null == gzhGroup || StringUtils.isBlank(gzhGroup.getGzhList())) {
            return false;
        }

        String[] arr = StringUtils.split(gzhGroup.getGzhList(), ',');

        for (String id : arr) {
            if (!StringUtils.isNumeric(id)) {
                continue;
            }

            ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(Integer.parseInt(id));

            if (null == componentAuthorizationInfo || null == componentAuthorizationInfo.getDeliveryStatus()) {
                continue;
            }

            if (!componentAuthorizationInfo.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue())) {
                logger.warn("公众号【{}】状态：{}", componentAuthorizationInfo.getNickName(), componentAuthorizationInfo.getDeliveryStatus());
                return true;
            }

        }

        return false;
    }

    /**
     * 取纸广告停用暂停对应的广告计划
     *
     * @param advertisingUnit
     */
    private void stopAdvertisingPlan(AdvertisingUnit advertisingUnit) {
        if (null == advertisingUnit
                || null == advertisingUnit.getAdUseStatus()
                || !advertisingUnit.getAdUseStatus().equals(ZjbDictionaryEnum.AD_USE_NO.getValue())) {
            return;
        }

        if (!ZjbDictionaryEnum.AD_SPACE_PAPER_OUTPUT.getValue().equals(advertisingUnit.getAdSpaceIdentifier())) {
            return;
        }

        List<AdvertisingPlan> planList = advertisingPlanService.selectByUnitId(advertisingUnit.getId());

        if (null == planList || planList.isEmpty()) {
            return;
        }

        for (AdvertisingPlan advertisingPlan : planList) {

            String key = AD_PLAN_ID_PREFIX + '_' + advertisingPlan.getPlanId();
            AdvertisingPlan planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlan.class);
            planFromRedis.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
            JedisPoolCacheUtils.setVExpire(key, planFromRedis, EXRP_MONTH, ZJB_DB_50);
            logger.warn("扫码取纸位【{}】停用", advertisingUnit.getAdName());
            advertisingPlanService.clearLocalCacheRegex(advertisingPlan.getPlanId());
        }

    }

    /**
     * 删除广告池
     */
    @RequiresPermissions("zjb:advertisingUnit:remove")
    @Log(title = "广告池", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {

        String[] array = StringUtils.split(ids, ',');
        for (String idStr : array) {
            AdvertisingUnit advertisingUnit = advertisingUnitService.selectAdvertisingUnitById(Integer.parseInt(idStr));
            advertisingUnit.setAdUseStatus(ZjbDictionaryEnum.AD_USE_NO.getValue());
            stopAdvertisingPlan(advertisingUnit);
        }

        int r = advertisingUnitService.deleteAdvertisingUnitByIds(ids);
        //删除广告方案的广告
        r += advertisingCombinationService.deleteAdvertisingCombinationUnitByUnitId(ids);

        return toAjax(r);
    }
}
