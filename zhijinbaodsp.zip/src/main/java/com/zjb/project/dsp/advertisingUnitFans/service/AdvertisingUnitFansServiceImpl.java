package com.zjb.project.dsp.advertisingUnitFans.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.project.dsp.advertisingUnit.service.BaseAdUnitServiceImpl;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;

/**
 * 粉丝通广告池 服务层实现
 *
 * @author shenlong
 * @date 2019-11-22
 */
@Service
public class AdvertisingUnitFansServiceImpl extends BaseAdUnitServiceImpl implements IAdvertisingUnitFansService {

    /**
     * 查询粉丝通广告池信息
     *
     * @param id 粉丝通广告池ID
     * @return 粉丝通广告池信息
     */
    @Override
    public AdvertisingUnitFans selectAdvertisingUnitFansById(Integer id) {
        return advertisingUnitFansMapper.selectAdvertisingUnitFansById(id);
    }

    /**
     * 查询粉丝通广告池列表
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 粉丝通广告池集合
     */
    @Override
    public List<AdvertisingUnitFans> selectAdvertisingUnitFansList(AdvertisingUnitFans advertisingUnitFans) {
        return advertisingUnitFansMapper.selectAdvertisingUnitFansList(advertisingUnitFans);
    }

    /**
     * 新增粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans) {
        int r = advertisingUnitFansMapper.insertAdvertisingUnitFans(advertisingUnitFans);

        if (r > 0) {
            advertisingUnitFans.setAdId(ZjbDictionaryEnum.AD_UNIT_TYPE_FANS.getValue().toString() + advertisingUnitFans.getId());
            r += advertisingUnitFansMapper.updateAdvertisingUnitFans(advertisingUnitFans);
        }

        return r;
    }

    /**
     * 修改粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans) {
        return advertisingUnitFansMapper.updateAdvertisingUnitFans(advertisingUnitFans);
    }

    /**
     * 删除粉丝通广告池对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingUnitFansByIds(String ids) {
        return advertisingUnitFansMapper.deleteAdvertisingUnitFansByIds(Convert.toStrArray(ids));
    }


    @Override
    public List<AdvertisingUnitFans> selectAdvertisingUnitListByCombinationId(Integer combinationId) {
        return advertisingUnitFansMapper.selectAdvertisingUnitListByCombinationId(combinationId);
    }

    @Override
    public List<AdvertisingUnitFans> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(weChatOfficialAccount);

        if (null == componentAuthorizationInfo) {
            return Collections.emptyList();
        }

        AdvertisingUnitFans query = new AdvertisingUnitFans();
        query.setDeleted(NO.getValue());
        query.setAdSpaceIdentifier(AD_FANS_PAPER_OUTPUT.getValue());
        query.setWeChatAccount(componentAuthorizationInfo.getComponentId());
        query.setRedirectUrlType(AD_REDIRECT_WE_CHAT_ACCOUNT.getValue());

        return advertisingUnitFansMapper.selectAdvertisingUnitFansList(query);
    }

    /**
     * 根据广告池业务主键ID查询粉丝通广告池信息
     *
     * @param adId 粉丝通广告池业务主键ID
     * @return
     */
    @Override
    public AdvertisingUnitFans selectAdvertisingUnitFansByAdId(String adId) {
        return advertisingUnitFansMapper.selectAdvertisingUnitFansByAdId(adId);
    }

    /**
     * 获取公众号关注后推送消息
     *
     * @param appId appid
     * @return gzh_subscribe_msg
     */
    @Override
    public String getSubMsg(String appId) {
        return advertisingUnitFansMapper.getSubMsg(appId);
    }
}
