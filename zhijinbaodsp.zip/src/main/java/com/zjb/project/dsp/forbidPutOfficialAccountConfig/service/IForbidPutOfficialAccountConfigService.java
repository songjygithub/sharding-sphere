package com.zjb.project.dsp.forbidPutOfficialAccountConfig.service;

import java.util.List;

import com.zjb.project.common.ad.domain.AdvertisingDeviceInfo;
import com.zjb.project.common.ad.domain.AdvertisingPeopleInfo;
import com.zjb.project.dsp.forbidPutOfficialAccountConfig.domain.ForbidPutOfficialAccountConfig;

/**
 * 指定次数禁投公众号广告配置 服务层
 *
 * @author jiangbingjie
 * @date 2020-02-20
 */
public interface IForbidPutOfficialAccountConfigService {

    /**
     * 查询指定次数禁投公众号广告配置信息
     *
     * @param configId 指定次数禁投公众号广告配置ID
     * @return 指定次数禁投公众号广告配置信息
     */
    ForbidPutOfficialAccountConfig selectForbidPutOfficialAccountConfigById(Integer configId);

    /**
     * 查询指定次数禁投公众号广告配置列表
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 指定次数禁投公众号广告配置集合
     */
    List<ForbidPutOfficialAccountConfig> selectForbidPutOfficialAccountConfigList(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 查询自动失效记录
     *
     * @return
     */
    List<ForbidPutOfficialAccountConfig> selectAutomaticInvalid();

    /**
     * 新增指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    int insertForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 修改指定次数禁投公众号广告配置
     *
     * @param forbidPutOfficialAccountConfig 指定次数禁投公众号广告配置信息
     * @return 结果
     */
    int updateForbidPutOfficialAccountConfig(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);

    /**
     * 删除指定次数禁投公众号广告配置信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteForbidPutOfficialAccountConfigByIds(String ids);

    /**
     * 获取用户通过某台设备在某次取纸是是否屏蔽公众号
     *
     * @return 返回值大于0屏蔽，否则不屏蔽
     */
    int getForbidPutOfficialAccountCount(ForbidPutOfficialAccountConfig forbidPutOfficialAccountConfig);


    /**
     * 获取配置状态为空的配置信息
     *
     * @return
     */
    List<ForbidPutOfficialAccountConfig> getForbidPutOfficialAccountListWithoutStatus();

    /**
     * 添加公众号屏蔽正则匹配
     *
     * @param config
     */
    void addPattern(ForbidPutOfficialAccountConfig config);

    /**
     * 公众号屏蔽记录是否生效
     *
     * @param config
     * @return
     */
    boolean effective(ForbidPutOfficialAccountConfig config);

    /**
     * 移除公众号屏蔽正则
     *
     * @param config
     */
    void removePattern(ForbidPutOfficialAccountConfig config);

    /**
     * 公众号屏蔽正则
     *
     * @param deviceInfo
     * @param peopleInfo
     * @return
     */
    boolean matcher(AdvertisingDeviceInfo deviceInfo, AdvertisingPeopleInfo peopleInfo);
}
