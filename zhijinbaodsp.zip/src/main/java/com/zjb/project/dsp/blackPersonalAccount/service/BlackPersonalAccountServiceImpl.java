package com.zjb.project.dsp.blackPersonalAccount.service;

import java.util.*;

import com.vdurmont.emoji.EmojiParser;
import com.zjb.common.enums.ZjbConfigEnum;
import com.zjb.project.dsp.blackPersonalAccountTemporary.domain.BlackPersonalAccountTemporary;
import com.zjb.project.dsp.blackPersonalAccountTemporary.service.IBlackPersonalAccountTemporaryService;
import com.zjb.project.system.config.service.IConfigService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.blackPersonalAccount.domain.BlackPersonalAccount;
import com.zjb.project.dsp.blackPersonalAccount.mapper.BlackPersonalAccountMapper;
import com.zjb.project.dsp.mediumSellRull.domain.MediumSellRull;
import com.zjb.project.dsp.mediumSellRull.service.IMediumSellRullService;
import com.zjb.project.dsp.personalAccountWinRecord.domain.PersonalAccountWinRecord;
import com.zjb.project.dsp.personalAccountWinRecord.service.IPersonalAccountWinRecordService;

import cn.hutool.extra.mail.MailUtil;

/**
 * 个人号黑名单 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
@Service
public class BlackPersonalAccountServiceImpl implements IBlackPersonalAccountService 
{
	private static final Logger logger = LoggerFactory.getLogger(BlackPersonalAccountServiceImpl.class);

	@Autowired
	private BlackPersonalAccountMapper blackPersonalAccountMapper;
	@Autowired
	private IMediumSellRullService mediumSellRullService;
	@Autowired
	private IPersonalAccountWinRecordService personalAccountWinRecordService;
	@Autowired
	private IConfigService configService;
	@Autowired
	private IBlackPersonalAccountTemporaryService blackPersonalAccountTemporaryService;

	/**
     * 查询个人号黑名单信息
     * 
     * @param id 个人号黑名单ID
     * @return 个人号黑名单信息
     */
    @Override
	public BlackPersonalAccount selectBlackPersonalAccountById(Integer id)
	{
	    return blackPersonalAccountMapper.selectBlackPersonalAccountById(id);
	}
	
	/**
     * 查询个人号黑名单列表
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 个人号黑名单集合
     */
	@Override
	public List<BlackPersonalAccount> selectBlackPersonalAccountList(BlackPersonalAccount blackPersonalAccount)
	{
	    return blackPersonalAccountMapper.selectBlackPersonalAccountList(blackPersonalAccount);
	}
	
    /**
     * 新增个人号黑名单
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 结果
     */
	@Override
	public int insertBlackPersonalAccount(BlackPersonalAccount blackPersonalAccount)
	{
		//个人号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackPersonalAccount.getPersonalNickName())){
			String personalNickName = EmojiParser.parseToAliases(blackPersonalAccount.getPersonalNickName());
			blackPersonalAccount.setPersonalNickName(personalNickName);
		}
	    return blackPersonalAccountMapper.insertBlackPersonalAccount(blackPersonalAccount);
	}
	
	/**
     * 修改个人号黑名单
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 结果
     */
	@Override
	public int updateBlackPersonalAccount(BlackPersonalAccount blackPersonalAccount)
	{
		//个人号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackPersonalAccount.getPersonalNickName())){
			String personalNickName = EmojiParser.parseToAliases(blackPersonalAccount.getPersonalNickName());
			blackPersonalAccount.setPersonalNickName(personalNickName);
		}
	    return blackPersonalAccountMapper.updateBlackPersonalAccount(blackPersonalAccount);
	}

	/**
     * 删除个人号黑名单对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteBlackPersonalAccountByIds(String ids)
	{
		return blackPersonalAccountMapper.logicDeleteBlackPersonalAccountByIds(Convert.toStrArray(ids));
	}

	/**
	 * 获取个人号黑名单数量
	 * @param blackPersonalAccount
	 * @return
	 */
	@Override
	public int getBlackPersonalAccountCount(BlackPersonalAccount blackPersonalAccount) {
		if(StringUtils.isNotEmpty(blackPersonalAccount.getPersonalAppId())){
			List<BlackPersonalAccount> blackPersonalAccountList = blackPersonalAccountMapper.selectBlackPersonalAccountList(blackPersonalAccount);
			if(blackPersonalAccountList != null && !(blackPersonalAccountList.isEmpty())){
				return blackPersonalAccountList.size();
			}
		}
		return 0;
	}

	@Override
	public void cacheAdCombinationInfo(String personalAppId, String openId,String personalAccountChannel,String personalAccountName,String randomNum) {
		logger.info("个人号广告方案胜出事件personalAppId:{},openId:{},randomNum:{}",personalAppId,openId,randomNum);
		String time = DateUtils.getTime();
		//获取媒体售卖规则6的相关信息
		MediumSellRull mediumSellRull = mediumSellRullService.selectMediumSellRullById(6);
		boolean checkBlackPersonalAccount = false;
		if(mediumSellRull != null && 0 == mediumSellRull.getDeleted() && (int) ZjbDictionaryEnum.RULL_STATUS_EFFECTIV.getValue() == mediumSellRull.getRullStatus()){
			checkBlackPersonalAccount = true;
			if(null == mediumSellRull.getSuccessTimes() && null == mediumSellRull.getSuccessPerson()){
				checkBlackPersonalAccount = false;
			}
		}
		if(!checkBlackPersonalAccount){
			return;
		}
		//获取该个人号第一次胜出时间
		String personalAccountFirstSuccessTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_FIRST_SUCCESS_TIME +"_" +personalAppId, ZjbConstantsRedis.ZJB_DB_58);
		Date date = DateUtils.dateTime("yyyy-MM-dd HH:mm:ss",time);
		PersonalAccountWinRecord personalAccountWinRecord = new PersonalAccountWinRecord();
		personalAccountWinRecord.setPersonalAppId(personalAppId);
		personalAccountWinRecord.setOpenId(openId);
		personalAccountWinRecord.setRandomNum(randomNum);
		personalAccountWinRecord.setIssuePlStatus(0);
		personalAccountWinRecord.setWinDate(date);
		personalAccountWinRecord.setInsertBaseParamsBySys();
		personalAccountWinRecordService.insertPersonalAccountWinRecord(personalAccountWinRecord);

		int personalSuccessTimes = 0;
		//判断该个人号是否已经在黑名单中
		boolean blackPersonal = false;
		BlackPersonalAccount blackPersonalAccount = new BlackPersonalAccount();
		blackPersonalAccount.setPersonalAppId(personalAppId);
		blackPersonalAccount.setDeleted(0);
		List<BlackPersonalAccount> blackPersonalAccountList = blackPersonalAccountMapper.selectBlackPersonalAccountList(blackPersonalAccount);
		if(blackPersonalAccountList != null && !(blackPersonalAccountList.isEmpty())){
			blackPersonal = true;
		}
		if(blackPersonal){
			return;
		}else{
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_LAST_SUCCESS_TIME +"_" +personalAppId, DateUtils.parseDateToStr("yyyy-MM-dd HH:mm:ss",date), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}


		if(StringUtils.isEmpty(personalAccountFirstSuccessTime)){
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_FIRST_SUCCESS_TIME +"_" +personalAppId, time, JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}
		JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_LAST_SUCCESS_TIME +"_" +personalAppId, time, JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		//获取该个人号胜出次数
		String personalAccountSuccessTimes = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_TIMES+"_"+personalAppId,ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isNotEmpty(personalAccountSuccessTimes)){
			personalSuccessTimes = Integer.parseInt(personalAccountSuccessTimes);
		}
		personalSuccessTimes++;
		JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_TIMES +"_" +personalAppId, String.valueOf(personalSuccessTimes), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		JedisPoolCacheUtils.sadd(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_PERSON+"_" +personalAppId, ZjbConstantsRedis.ZJB_DB_58, JedisPoolCacheUtils.EXRP_DAY, openId);
		JedisPoolCacheUtils.sadd(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_RANDOM_NUM+"_" +personalAppId, ZjbConstantsRedis.ZJB_DB_58, JedisPoolCacheUtils.EXRP_DAY, randomNum);


		//获取该用户该个人号胜出次数
		String personalAccountSuccessPersonTimes = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_PERSON_TIMES+"_"+personalAppId+"_"+openId,ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isEmpty(personalAccountSuccessPersonTimes)){
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_PERSON_TIMES +"_" +personalAppId+"_"+openId,"1", JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}else{
			int personalAccountSuccessPersonTime = Integer.parseInt(personalAccountSuccessPersonTimes);
			personalAccountSuccessPersonTime++;
			JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_PERSON_TIMES +"_" +personalAppId+"_"+openId,String.valueOf(personalAccountSuccessPersonTime), JedisPoolCacheUtils.EXRP_DAY, ZjbConstantsRedis.ZJB_DB_58);
		}



		//获取该个人号最后一次胜出时间
		String personalAccountLastSuccessTime = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.PERSONAL_ACCOUNT_LAST_SUCCESS_TIME+"_"+personalAppId,ZjbConstantsRedis.ZJB_DB_58);
		if(StringUtils.isEmpty(personalAccountLastSuccessTime)){
			personalAccountLastSuccessTime = time;
		}
		//获取该个人号胜出人数
		Set<String> personalAccountSuccessPerson = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_PERSON+"_"+personalAppId,ZjbConstantsRedis.ZJB_DB_58);
		int personalAccountSuccessPersonCount = 0;
		if(personalAccountSuccessPerson != null && !(personalAccountSuccessPerson.isEmpty())){
			personalAccountSuccessPersonCount = personalAccountSuccessPerson.size();
		}
		//获取该个人号胜出流水号
		Set<String> personalAccountSuccessRandomNum = JedisPoolCacheUtils.smembers(ZjbConstantsRedis.PERSONAL_ACCOUNT_SUCCESS_RANDOM_NUM+"_"+personalAppId,ZjbConstantsRedis.ZJB_DB_58);


		if(personalSuccessTimes >= mediumSellRull.getSuccessTimes() || personalAccountSuccessPersonCount >= mediumSellRull.getSuccessPerson()){
			//将该个人号信息记录到个人号黑名单临时表中
			BlackPersonalAccountTemporary blackPersonalAccountTemporary = new BlackPersonalAccountTemporary();
			blackPersonalAccountTemporary.setPersonalAppId(personalAppId);
			blackPersonalAccountTemporary.setPersonalNickName(personalAccountName);
			blackPersonalAccountTemporary.setPersonalSourceType(personalAccountChannel);
			blackPersonalAccountTemporary.setCreateTime(date);
			if(personalSuccessTimes >= mediumSellRull.getSuccessTimes()){
				blackPersonalAccountTemporary.setJoinBlackType(2);
			}else{
				blackPersonalAccountTemporary.setJoinBlackType(1);
			}
			blackPersonalAccountTemporary.setRandomNums(String.join(",", personalAccountSuccessRandomNum));
			blackPersonalAccountTemporaryService.insertBlackPersonalAccountTemporary(blackPersonalAccountTemporary);

		}


	}

}
