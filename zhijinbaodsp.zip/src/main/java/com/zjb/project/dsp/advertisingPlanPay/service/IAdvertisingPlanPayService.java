package com.zjb.project.dsp.advertisingPlanPay.service;

import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;

import java.io.Serializable;
import java.util.List;

/**
 * 广告投放计划(支付) 服务层
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
public interface IAdvertisingPlanPayService extends IAdPlanService
{
	/**
     * 查询广告投放计划(支付)信息
     * 
     * @param id 广告投放计划(支付)ID
     * @return 广告投放计划(支付)信息
     */
	AdvertisingPlanPay selectAdvertisingPlanPayById(Serializable id);
	
	/**
     * 查询广告投放计划(支付)列表
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 广告投放计划(支付)集合
     */
	public List<AdvertisingPlanPay> selectAdvertisingPlanPayList(AdvertisingPlanPay advertisingPlanPay);
	
	/**
     * 新增广告投放计划(支付)
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
	public int insertAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay);
	
	/**
     * 修改广告投放计划(支付)
     * 
     * @param advertisingPlanPay 广告投放计划(支付)信息
     * @return 结果
     */
	public int updateAdvertisingPlanPay(AdvertisingPlanPay advertisingPlanPay);
		
	/**
     * 删除广告投放计划(支付)信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisingPlanPayByIds(String ids);

	/**
	 * 逻辑删除广告投放计划信息
	 *
	 * @param ids
	 * @return
	 */
	int logicDeleteAdvertisingPlanPayByIds(String ids);

	/**
	 * 根据公众号查询广告投放计划
	 *
	 * @param adAppId
	 * @return
	 */
	List<AdvertisingPlanPay> selectByAdAppId(String adAppId);

	
}
