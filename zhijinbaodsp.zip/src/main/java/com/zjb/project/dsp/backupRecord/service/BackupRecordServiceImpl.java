package com.zjb.project.dsp.backupRecord.service;

import cn.hutool.core.util.ZipUtil;
import com.alibaba.fastjson.JSONReader;
import com.alibaba.fastjson.JSONWriter;
import com.aliyun.oss.model.OSSObject;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.result.DeleteResult;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.manager.AsyncManager;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.backupRecord.domain.BackupRecord;
import com.zjb.project.dsp.backupRecord.mapper.BackupRecordMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.SystemUtils;
import org.bson.BsonDocument;
import org.bson.BsonString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Service;

import java.io.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimerTask;

import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;

/**
 * 数据备份记录 服务层实现
 *
 * @author songjy
 * @date 2020-04-17
 */
@Service
public class BackupRecordServiceImpl implements IBackupRecordService, InitializingBean {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private BackupRecordMapper backupRecordMapper;
    @Autowired
    private MongoTemplate mongoTemplate;
    @Autowired
    private ZjbConfig zjbConfig;

    @Override
    public void afterPropertiesSet() throws Exception {
        backupAdvertisingTargetInfo();
    }

    /**
     * 处理备份记录数小于24的记录
     */
    private void handleLess24() {

        String typeData = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        LocalDate maxDay = backupRecordMapper.selectMaxDay(typeData);

        /*按天分组且备份记录数小于24的记录*/
        List<BackupRecord> list = backupRecordMapper.selectGroupByDayLess24(typeData);

        if (list.isEmpty()) {
            return;
        }


        for (BackupRecord backupRecord : list) {

            if (backupRecord.getDayData().equals(maxDay)) {
                continue;
            }

            logger.info("{}日广告交易备份记录数小于24，修复处理中", backupRecord.getDayData());

            backupAdvertisingTargetInfoOSS(backupRecord.getDayData());

            logger.info("{}日广告交易备份记录数小于24，修复完毕", backupRecord.getDayData());
        }
    }

    /**
     * 清理备份完毕的数据：数据保留三个月
     */
    private void cleanAdvertisingTargetInfo() {

        /*删除65天以前的数据*/
        final LocalDate end = LocalDate.now().minusDays(65);
        final String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        final BackupRecord backupRecord = new BackupRecord();
        backupRecord.setTypeData(collectionName);

        LocalDate start = LocalDate.of(2019, 9, 6);

        for (; !start.isAfter(end); ) {

            logger.info("{}日广告交易数据开始校验", start);

            backupRecord.setDayData(start);
            List<BackupRecord> list = backupRecordMapper.selectBackupRecordList(backupRecord);

            BackupRecord record = !list.isEmpty() ? list.get(0) : null;

            /*数据备份后三天内自动删除*/
            if (null != record && null != record.getGmtStartBackup()
                    && DateUtils.diffDays(LocalDate.now(), record.getGmtStartBackup().toLocalDate()) > 3) {
                Query query = Query.query(Criteria.where("adRequestDate").is(start));
                DeleteResult deleteResult = mongoTemplate.remove(query, AdvertisingTargetInfo.class);
                logger.info("{}日删除广告交易记录条数：{}", start, deleteResult.getDeletedCount());
            }
            logger.info("{}日广告交易数据结束校验", start);
            start = start.plusDays(1L);
        }


    }

    /**
     * 备份广告交易数据
     */
    private void backupAdvertisingTargetInfo() {

        if (SystemUtils.IS_OS_WINDOWS || SystemUtils.IS_OS_MAC) {
            /*说明是本地开发测试环境，不处理*/
            return;
        }

        String typeData = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);

        AsyncManager.me().execute(new TimerTask() {
            @Override
            public void run() {

                /*处理备份记录数小于24的记录*/
                handleLess24();

                LocalDate start = backupRecordMapper.selectMaxDay(typeData);
                start = (null == start) ? LocalDate.of(2019, 9, 6) : start.minusDays(1L);

                for (; !start.isAfter(LocalDate.now().minusDays(1L)); ) {
                    long startBackup = System.currentTimeMillis();
                    logger.info("{}日广告交易数据开始备份", start);

                    boolean success = backupAdvertisingTargetInfoOSS(start);

                    if (!success) {
                        logger.error("{}日用户广告交易记录数据备份失败，任务中断", start);
                        return;
                    }

                    logger.info("{}日广告交易数据结束备份，耗时：{}", start, DateUtils.timeConsuming(System.currentTimeMillis() - startBackup));

                    start = start.plusDays(1L);
                }

                /*清理已备份数据*/
                cleanAdvertisingTargetInfo();

            }
        });
    }

    /**
     * 指定日期数据备份至OSS
     *
     * @param localDate
     * @return true：备份成功 false：备份失败
     */
    private boolean backupAdvertisingTargetInfoOSS(LocalDate localDate) {
        String typeData = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);

        logger.info("{}日广告交易数据查询中", localDate);

        /*拆分成24小时*/
        Integer[] hours = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23};

        for (Integer hour : hours) {

            BackupRecord backupRecordQuery = new BackupRecord();
            backupRecordQuery.setDayData(localDate);
            backupRecordQuery.setHour(hour);
            backupRecordQuery.setTypeData(typeData);
            List<BackupRecord> recordList = backupRecordMapper.selectBackupRecordList(backupRecordQuery);

            if (!recordList.isEmpty()) {
                logger.info("{}日{}时广告交易记录已备份", localDate, hour);
                continue;
            }

            BackupRecord newRecord = new BackupRecord();
            newRecord.setDayData(localDate);
            newRecord.setTypeData(typeData);
            newRecord.setGmtStartBackup(LocalDateTime.now());
            newRecord.setGmtEndBackup(newRecord.getGmtEndBackup());

            String lockKey = "backup_advertising_target_info_" + localDate + '_' + hour;
            String requestId = String.valueOf(System.currentTimeMillis());
            /*锁占有最大时间*/
            int millisecond = 1000 * EXRP_5_MINUTE;

            try {
                if (!JedisPoolCacheUtils.tryGetDistributedLock(lockKey, requestId, millisecond)) {
                    continue;
                }

                newRecord.setHour(hour);

                LocalDateTime start = LocalDateTime.of(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth(), hour, 0, 0);
                LocalDateTime end = LocalDateTime.of(localDate.getYear(), localDate.getMonthValue(), localDate.getDayOfMonth(), hour, 59, 59, 999999999);
                Criteria criteria = Criteria.where("adRequestDate").is(DateUtils.toDate(localDate))
                        .and("gmtAdRequestTime").gte(DateUtils.toDate(start)).lte(DateUtils.toDate(end));
                Query query = Query.query(criteria);
                List<AdvertisingTargetInfo> list = mongoTemplate.find(query, AdvertisingTargetInfo.class);
                if (list.isEmpty()) {
                    logger.info("【{}】至【{}】无广告交易数据", start, end);
                    continue;
                }
                logger.info("【{}】至【{}】广告交易数据条数：{}", start, end, list.size());
                newRecord.setCountData(list.size());

                String fileName = "/tmp/" + localDate + '-' + hour + "AdvertisingTargetInfo.json";
                File fileJson = new File(fileName);

                try (JSONWriter writer = new JSONWriter(new FileWriter(fileName))) {
                    writer.startArray();
                    for (AdvertisingTargetInfo record : list) {
                        writer.writeValue(record);
                    }
                    writer.endArray();
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                    return false;
                }

                logger.info("【{}】至【{}】广告交易数据写入JSON文件{}，共{}条", start, end, fileName, list.size());

                /* 压缩 */
                File fileZip = ZipUtil.zip(fileJson);
                String fileKey = zjbConfig.getAdvertisingTargetInfoUrl() + localDate + '/' + hour + "AdvertisingTargetInfo.zip";
                newRecord.setFileUrl(fileKey);

                /* 上传至OSS完毕 */
                try (InputStream inputStream = new FileInputStream(fileZip)) {
                    OssUtil.uploadFile(fileKey, inputStream);
                    logger.info("本地文件{}上传至OSS完毕：{}", fileZip.getAbsolutePath(), fileKey);
                    logger.info("{}】至【{}】备份广告交易记录总数：{}", start, end, list.size());
                } catch (IOException e) {
                    logger.error(e.getMessage(), e);
                    return false;
                }

                logger.info("本地文件{}删除{}", fileZip.getAbsolutePath(), fileZip.delete() ? "成功" : "失败");
                logger.info("本地文件{}删除{}", fileJson.getAbsolutePath(), fileJson.delete() ? "成功" : "失败");

                newRecord.setGmtEndBackup(LocalDateTime.now());
                backupRecordMapper.insertBackupRecord(newRecord);
            } finally {
                boolean release = JedisPoolCacheUtils.releaseDistributedLock(lockKey, requestId);
                logger.info("锁{}释放状态：{}", lockKey, release);
            }
        }

        return true;
    }

    /**
     * 查询数据备份记录信息
     *
     * @param id 数据备份记录ID
     * @return 数据备份记录信息
     */
    @Override
    public BackupRecord selectBackupRecordById(Long id) {
        return backupRecordMapper.selectBackupRecordById(id);
    }

    /**
     * 查询数据备份记录列表
     *
     * @param backupRecord 数据备份记录信息
     * @return 数据备份记录集合
     */
    @Override
    public List<BackupRecord> selectBackupRecordList(BackupRecord backupRecord) {
        return backupRecordMapper.selectBackupRecordList(backupRecord);
    }

    /**
     * 新增数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    @Override
    public int insertBackupRecord(BackupRecord backupRecord) {
        return backupRecordMapper.insertBackupRecord(backupRecord);
    }

    /**
     * 修改数据备份记录
     *
     * @param backupRecord 数据备份记录信息
     * @return 结果
     */
    @Override
    public int updateBackupRecord(BackupRecord backupRecord) {
        return backupRecordMapper.updateBackupRecord(backupRecord);
    }

    /**
     * 删除数据备份记录对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteBackupRecordByIds(String ids) {
        return backupRecordMapper.deleteBackupRecordByIds(Convert.toStrArray(ids));
    }

    @Override
    @Deprecated
    public Date minAdRequestDate() {

        List<BsonDocument> pipeline = new ArrayList<>();

        /*分组*/
        BsonDocument group = new BsonDocument("$group", new BsonDocument("_id", new BsonDocument())
                .append("min_date", new BsonDocument("$min", new BsonString("$adRequestDate")))
                //.append("max_date", new BsonDocument("$max", new BsonString("$adRequestDate")))
        );

        pipeline.add(group);

        String collectionName = mongoTemplate.getCollectionName(AdvertisingTargetInfo.class);
        AggregateIterable<BsonDocument> aggregateIterable = mongoTemplate.getCollection(collectionName).aggregate(pipeline, BsonDocument.class).batchSize(1000);
        try (MongoCursor<BsonDocument> mongoCursor = aggregateIterable.iterator()) {

            BsonDocument bsonDocument = mongoCursor.next();

            return new Date(bsonDocument.get("min_date").asDateTime().getValue());
        }

    }

    @Override
    public int importAdvertisingTargetInfo(BackupRecord backupRecord) {
        long start = System.currentTimeMillis();
        OSSObject ossObject = OssUtil.downloadFile(backupRecord.getFileUrl());

        LocalDate dayData = backupRecord.getDayData();
        int hour = backupRecord.getHour();
        String fileName = FilenameUtils.getName(backupRecord.getFileUrl());
        File zip = new File(FileUtils.getTempDirectory(), fileName);

        try (InputStream inputStream = ossObject.getObjectContent();
             BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
             OutputStream outputStream = new FileOutputStream(zip);
             BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream)) {
            byte[] buff = new byte[1024];
            for (int len; (len = bufferedInputStream.read(buff)) > 0; ) {
                bufferedOutputStream.write(buff, 0, len);
            }

        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            return 0;
        }

        logger.info("OSS文件{}下载至{}成功", backupRecord.getFileUrl(), zip.getAbsolutePath());

        File dir = ZipUtil.unzip(zip, FileUtils.getTempDirectory());
        File file = new File(dir, dayData + "-" + zip.getName().replaceFirst("zip", "json"));

        logger.info("{}文件解压至{}", zip.getAbsolutePath(), file.getAbsolutePath());

        int count = 0;

        try (JSONReader reader = new JSONReader(new FileReader(file))) {

            reader.startArray();
            for (; reader.hasNext(); ) {
                AdvertisingTargetInfo targetInfo = reader.readObject(AdvertisingTargetInfo.class);
                mongoTemplate.save(targetInfo);
                count++;
            }
            reader.endArray();

            logger.info("{}日{}时广告交易数据导入成功，共{}条，耗时：{}", dayData, hour, count, DateUtils.timeConsuming(System.currentTimeMillis() - start));

        } catch (FileNotFoundException e) {
            logger.error(backupRecord.getDayData() + "日广告交易数据导入失败" + e.getMessage(), e);
        }

        logger.warn("{}文件删除{}", file.getAbsolutePath(), file.delete() ? "成功" : "失败");
        logger.warn("{}文件删除{}", zip.getAbsolutePath(), zip.delete() ? "成功" : "失败");

        return count;
    }
}
