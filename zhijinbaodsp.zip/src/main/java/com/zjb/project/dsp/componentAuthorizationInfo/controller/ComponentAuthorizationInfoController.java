package com.zjb.project.dsp.componentAuthorizationInfo.controller;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_PLAN_STATUS_OK;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_USE_YES;
import static com.zjb.common.enums.ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN;
import static com.zjb.common.enums.ZjbDictionaryEnum.AUTH_STATUS_SUCCESS;
import static com.zjb.common.enums.ZjbDictionaryEnum.AUTH_STATUS_TODO;
import static com.zjb.common.enums.ZjbDictionaryEnum.MANUAL_ADD;
import static com.zjb.common.enums.ZjbDictionaryEnum.MANUAL_GROUND;
import static com.zjb.common.enums.ZjbDictionaryEnum.RECORD_STATUS_STARTED;
import static com.zjb.common.enums.ZjbDictionaryEnum.RECORD_STATUS_STOPPED;
import static com.zjb.common.enums.ZjbDictionaryEnum.YES;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_YEAR;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.zjb.common.constant.AdvertisingConstants;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.file.FileUploadUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdvertisingPlanService;
import com.zjb.project.dsp.advertisingPlanFans.domain.AdvertisingPlanFans;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.service.IAdvertisingPlanWxService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.autorizeCompany.domain.AutorizeCompany;
import com.zjb.project.dsp.autorizeCompany.service.IAutorizeCompanyService;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.domain.AutorizeCompanyThirdPlatform;
import com.zjb.project.dsp.autorizeCompanyThirdPlatform.service.IAutorizeCompanyThirdPlatformService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.CompanyThirdPlatformData;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.componentAuthorizationInfo.service.IComponentAuthorizationInfoService;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;
import com.zjb.project.dsp.componentgzhevent.service.IComponentGzhEventService;
import com.zjb.project.dsp.feign.service.IFeignAdminCoreService;
import com.zjb.project.dsp.gzhLabel.domain.GzhLabel;
import com.zjb.project.dsp.gzhLabel.service.IGzhLabelService;
import com.zjb.project.dsp.gzhPushAdInfo.domain.GzhPushAdInfo;
import com.zjb.project.dsp.gzhPushAdInfo.service.IGzhPushAdInfoService;
import com.zjb.project.dsp.gzhPushAdTj.domain.GzhPushAdTj;
import com.zjb.project.dsp.gzhPushAdTj.service.IGzhPushAdTjService;

import cn.hutool.http.HttpUtil;

/**
 * 公众号或小程序的授权
 * 信息操作处理
 *
 * @author zjb
 * @date 2019-07-09
 */
@Controller
@RequestMapping("/zjb/componentAuthorizationInfo")
public class ComponentAuthorizationInfoController extends BaseController {
    private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "zjb/componentAuthorizationInfo";

    @Autowired
    private IComponentAuthorizationInfoService componentAuthorizationInfoService;
    @Autowired
    private IGzhPushAdInfoService gzhPushAdInfoService;
    @Autowired
    private IGzhPushAdTjService gzhPushAdTjService;
    @Autowired
    private IAdvertisingPlanService advertisingPlanService;
    @Autowired
    private IAdvertisingPlanWxService advertisingPlanWxService;
    @Autowired
    private IGzhLabelService gzhLabelService;
    @Autowired
    private ZjbConfig zjbConfig;
    @Autowired
    private IComponentGzhEventService componentGzhEventService;
    @Autowired
    private IAutorizeCompanyService autorizeCompanyService;
    @Autowired
    private IAutorizeCompanyThirdPlatformService autorizeCompanyThirdPlatformService;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private IFeignAdminCoreService feignAdminCoreService;


    @RequiresPermissions("zjb:componentAuthorizationInfo:view")
    @GetMapping()
    public String componentAuthorizationInfo(ModelMap mmap) {
        AutorizeCompany autorizeCompany = new AutorizeCompany();
        List<AutorizeCompany> autorizeCompanyList = autorizeCompanyService.selectAutorizeCompanyList(autorizeCompany);
        mmap.put("autorizeCompanyList", autorizeCompanyList);
        return prefix + "/componentAuthorizationInfo";
    }

    /**
     * 查询公众号或小程序的授权
     * 列表
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(ComponentAuthorizationInfo componentAuthorizationInfo) {
        startPage();
        List<ComponentAuthorizationInfo> list = componentAuthorizationInfoService.selectComponentAuthorizationInfoList(componentAuthorizationInfo);
        return getDataTable(list);
    }

    /**
     * 跳转到授权上架页面
     *
     * @param mmap
     * @return
     */
    @GetMapping("/componentAuthorizationInfoAdd")
    public String componentAuthorizationInfoAdd(ModelMap mmap) {
        return prefix + "/componentAuthorizationInfoAdd";
    }

    /**
     * 新增公众号或小程序的授权
     */
    @GetMapping("/add/{thirdPlatformId}")
    public String add(@PathVariable("thirdPlatformId") Integer thirdPlatformId, ModelMap mmap) {

        //获取授权公司主体信息
        if (null != thirdPlatformId) {
            AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformById(thirdPlatformId);
            if (autorizeCompanyThirdPlatform != null) {
                mmap.put("companyName", autorizeCompanyThirdPlatform.getCompanyName());
                String param = JSON.toJSONString(autorizeCompanyThirdPlatform);
                String url = "https://admin.zhijinbao.net/wechat/getAuthUrlByCompany";

                String returnResults = HttpUtil.post(url, param);
                if (StringUtils.isNotEmpty(returnResults)) {
                    mmap.addAttribute("url", returnResults);
                }
            }
        }
        return prefix + "/add";
    }

    /**
     * 新增保存公众号或小程序的授权
     */
//    @RequiresPermissions("zjb:componentAuthorizationInfo:add")
    @Log(title = "公众号或小程序的授权", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(@RequestBody ComponentAuthorizationInfo componentAuthorizationInfo) {
        componentAuthorizationInfo.setComponentAuthorizationType(ZjbDictionaryEnum.AUTHORIZE_ADD.getValue());
        ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(componentAuthorizationInfo.getAppId());
        if (StringUtils.isNotEmpty(componentAuthorizationInfo.getCompanyAppId())) {
            //获取公司主体第三方平台信息
            AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformByAppId(componentAuthorizationInfo.getCompanyAppId());
            if (autorizeCompanyThirdPlatform != null) {
                componentAuthorizationInfo.setCompanyId(autorizeCompanyThirdPlatform.getCompanyId());
                componentAuthorizationInfo.setCompanyName(autorizeCompanyThirdPlatform.getCompanyName());
                componentAuthorizationInfo.setThirdPlatformAppId(autorizeCompanyThirdPlatform.getId());
                componentAuthorizationInfo.setThirdPlatformAppName(autorizeCompanyThirdPlatform.getAppName());
            }
        }
        if (componentAuthorizationInfo1 != null) {
            componentAuthorizationInfo.setGmtModified(new Date());
            componentAuthorizationInfo.setId(componentAuthorizationInfo1.getId());
            return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
        }
        return toAjax(componentAuthorizationInfoService.insertComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 修改公众号或小程序的授权
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        mmap.put("componentAuthorizationInfo", componentAuthorizationInfo);
        return prefix + "/edit";
    }

    /**
     * 修改保存公众号或小程序的授权
     */
    @Log(title = "公众号或小程序的授权", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(ComponentAuthorizationInfo componentAuthorizationInfo) {
        if (StringUtils.isEmpty(componentAuthorizationInfo.getMsgName())) {
            componentAuthorizationInfo.setMsgId(null);
        }

        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 核心系统修改保存公众号或小程序的授权
     */
    @Log(title = "核心系统修改公众号或小程序的授权信息", businessType = BusinessType.UPDATE)
    @PostMapping("/editOfAdmin")
    @ResponseBody
    public AjaxResult editSaveOfAdmin(@RequestBody ComponentAuthorizationInfo componentAuthorizationInfo) {
        if (StringUtils.isNotEmpty(componentAuthorizationInfo.getCompanyAppId())) {
            //获取公司主体第三方平台信息
            AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform = autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformByAppId(componentAuthorizationInfo.getCompanyAppId());
            if (autorizeCompanyThirdPlatform != null) {
                componentAuthorizationInfo.setCompanyId(autorizeCompanyThirdPlatform.getCompanyId());
                componentAuthorizationInfo.setCompanyName(autorizeCompanyThirdPlatform.getCompanyName());
                componentAuthorizationInfo.setThirdPlatformAppId(autorizeCompanyThirdPlatform.getId());
                componentAuthorizationInfo.setThirdPlatformAppName(autorizeCompanyThirdPlatform.getAppName());
            }
        }
        ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(componentAuthorizationInfo.getAppId());
        componentAuthorizationInfo.setId(componentAuthorizationInfo1.getId());
        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 删除公众号或小程序的授权
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:remove")
    @Log(title = "公众号或小程序的授权", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(componentAuthorizationInfoService.deleteComponentAuthorizationInfoByIds(ids));
    }

    /**
     * 修改扫码任务配置
     */
    @GetMapping("/configEdit/{id}")
    public String configEdit(@PathVariable("id") Integer id, ModelMap mmap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        mmap.put("componentAuthorizationInfo", componentAuthorizationInfo);
        return prefix + "/configEdit";
    }

    /**
     * 查看数据
     */
    @GetMapping("/selectData/{appid}")
    public String configEdit(@PathVariable("appid") String appId, ModelMap mmap) {
        //String admin_url = configService.selectConfigByKey(ZjbConfigEnum.ZJB_ADMIN_ZHIJINBAO_URI.getKey());
        //String s = HttpClient.get(admin_url + "/zjb/componentGzhEvent/selectComponentGzhEventCountByAppid/" + appId);
        List<ComponentGzhEvent> componentGzhEvents = componentGzhEventService.selectDayRealAmount(appId);
        mmap.put("componentGzhEvents", componentGzhEvents);
        mmap.put("appid", appId);
        return prefix + "/data";
    }


    @GetMapping("/getComponent")
    @ResponseBody
    public GzhPushAdInfo getComponent(String appid) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appid);
        if (StringUtils.isEmpty(componentAuthorizationInfo.getMsgId())) {
            return null;
        }
        GzhPushAdInfo gzhPushAdInfo = gzhPushAdInfoService.selectGzhPushAdInfoByAdId(componentAuthorizationInfo.getMsgId());
        if (ZjbDictionaryEnum.GZH_PUSH_AD_STATUS_STOP.getValue().equals(gzhPushAdInfo.getStatus())) {
            return null;
        }

        return gzhPushAdInfo;
    }

    @GetMapping("/getComponentAuthorizationInfo")
    @ResponseBody
    public ComponentAuthorizationInfo getComponentAuthorizationInfo(String appid) {
        return componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appid);
    }

    @GetMapping("/url")
    public String url(String uri, String qrcode, String openid, ModelMap mmap) {
        if (StringUtils.isNotEmpty(uri) && StringUtils.isNotEmpty(qrcode) && StringUtils.isNotEmpty(openid)) {
            GzhPushAdInfo gzhPushAdInfo1 = new GzhPushAdInfo();
            gzhPushAdInfo1.setAdInsideUri(uri);
            List<GzhPushAdInfo> gzhPushAdInfos = gzhPushAdInfoService.selectGzhPushAdInfoList(gzhPushAdInfo1);
            GzhPushAdTj gzhPushAdTj = new GzhPushAdTj();
            gzhPushAdTj.setMsgId(gzhPushAdInfos.get(0).getAdId());
            gzhPushAdTj.setInsideUri(gzhPushAdInfos.get(0).getAdInsideUri());
            gzhPushAdTj.setOutUrl(gzhPushAdInfos.get(0).getAdOutUrl());
            gzhPushAdTj.setOpenid(openid);
            gzhPushAdTj.setClickTime(new Date());
            gzhPushAdTj.setQrcode(qrcode);
            gzhPushAdTjService.insertGzhPushAdTj(gzhPushAdTj);
            mmap.put("url", gzhPushAdInfos.get(0).getAdOutUrl());
            return "redirect:" + gzhPushAdInfos.get(0).getAdOutUrl();
        }
        return null;
    }

    /**
     * 根据ID获取平台授权公众号信息
     */
    @GetMapping("/selectById/{id}")
    @ResponseBody
    public ComponentAuthorizationInfo selectById(@PathVariable("id") Integer id) {
        return componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
    }

    /**
     * 根据ID获取平台授权公众号信息
     */
    @PostMapping("/findByIds")
    @ResponseBody
    public List<ComponentAuthorizationInfo> findByIds(@RequestBody(required = false) Integer[] ids) {
        return componentAuthorizationInfoService.findByIds(ids);
    }

    /**
     * 查看数据
     */
    @PostMapping("/downUserInfo")
    @ResponseBody
    public AjaxResult downUserInfo(@RequestParam(value = "appid") String appId,
                                   @RequestParam(value = "date") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date createDate) {
        List<UserInfo> userInfos = componentGzhEventService.exportSubscribeUserInfo(appId, createDate);
        if (userInfos == null || userInfos.isEmpty()) {
            return AjaxResult.error("未查询到数据");
        }

        try {

            ExcelUtil<UserInfo> excelUtil = new ExcelUtil<>(UserInfo.class);
            AjaxResult ajaxResult = excelUtil.exportExcel(userInfos, "userInfo");
            String fileName = ajaxResult.get("msg").toString();
            String ext = FilenameUtils.getExtension(fileName);
            String md5 = DigestUtils.md5Hex(appId + createDate);
            String fileKey = zjbConfig.getTempFileUrl() + LocalDate.now() + '/' + md5 + '.' + ext;
            File file = new File(FileUtils.getTempDirectory(), fileName);

            try {
                OssUtil.uploadFile(fileKey, new FileInputStream(file));
            } catch (FileNotFoundException e) {
                logger.error(e.getMessage(), e);
            }

            String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
            logger.info("文件OSS路径：{}", fileUrl);

            ajaxResult.put("fileUrl", fileUrl);
            ajaxResult.put("fileName", fileName);
            return ajaxResult;
        } catch (Exception e) {
            return error("导出Excel失败，请联系网站管理员！");
        }

    }


    /**
     * 公众号投放配置
     *
     * @param id
     * @return
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:delivery")
    @GetMapping("/delivery/{id}")
    public String delivery(@PathVariable("id") Integer id, ModelMap mmap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        mmap.put("componentAuthorizationInfo", componentAuthorizationInfo);
        return prefix + "/delivery";
    }

    /**
     * 公众号投放配置
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:delivery")
    @Log(title = "公众号投放配置", businessType = BusinessType.UPDATE)
    @PostMapping("/delivery")
    @ResponseBody
    public AjaxResult delivery(ComponentAuthorizationInfo component, @RequestParam(value = "url", required = false) MultipartFile file) {

        ComponentAuthorizationInfo old = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(component.getId());

        if (null == old) {
            return error("公众号不存在");
        }

        component.setAppId(old.getAppId());

        if (null != component.getDayDeliveryLimit()
                && null != component.getTotalDeliveryLimit()
                && component.getDayDeliveryLimit() > component.getTotalDeliveryLimit()) {
            return error("日投放量不能大于总投放量");
        }

        if (old.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue())
                && null == component.getDayDeliveryLimit()) {
            /*日投放量不限*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
            restartAdvertisingUnitAliPay(old.getAppId());
            restartAdvertisingUnitWx(old.getAppId());
            restartAdvertisingUnitFans(old.getAppId());
        } else if (old.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue())
                && null == component.getTotalDeliveryLimit()) {
            /*总投放量不限*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
            restartAdvertisingUnitAliPay(old.getAppId());
            restartAdvertisingUnitWx(old.getAppId());
            restartAdvertisingUnitFans(old.getAppId());
        } else if (old.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue())
                && null != component.getDayDeliveryLimit() && component.getDayDeliveryLimit() > old.getDayFollowAmount()) {
            /*增加日预算*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
            restartAdvertisingUnitAliPay(old.getAppId());
            restartAdvertisingUnitWx(old.getAppId());
            restartAdvertisingUnitFans(old.getAppId());
        } else if (old.getDeliveryStatus().equals(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue())
                && null != component.getTotalDeliveryLimit() && component.getTotalDeliveryLimit() > old.getTotalFollowAmount()) {
            /*增加总投放量*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
            restartAdvertisingUnitAliPay(old.getAppId());
            restartAdvertisingUnitWx(old.getAppId());
            restartAdvertisingUnitFans(old.getAppId());
        } else if (null != component.getDayDeliveryLimit() && component.getDayDeliveryLimit() <= old.getDayFollowAmount()) {
            /*日投放量减少*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_DAY_LIMIT.getValue());
            stopAdvertisingPlan(component);
        } else if (null != component.getTotalDeliveryLimit() && component.getTotalDeliveryLimit() <= old.getTotalFollowAmount()) {
            /*总投放量减少*/
            component.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_TOTAL_LIMIT.getValue());
            stopAdvertisingPlan(component);
        }

        if (component.getPickPaperUrl() == null) {
            component.setPickPaperUrl(old.getPickPaperUrl());
        }
        if (component.getPickPaperType() == null) {
            component.setPickPaperType(old.getPickPaperType());
        }


        try {
            if (file != null && !file.isEmpty()) {
                //String avatar = FileUploadUtils.upload(null, file, FileUploadUtils.IMAGE_JPG_EXTENSION);
                String fileKey = zjbConfig.getProfile() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(file.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, file.getInputStream());
                String url = ZjbConstants.File_Domain + "/" + fileKey;

                ComponentAuthorizationInfo componentAuthorizationInfo = new ComponentAuthorizationInfo();
                componentAuthorizationInfo.setId(old.getId());
                componentAuthorizationInfo.setPickPaperUrl(url);
                componentAuthorizationInfo.setPickPaperType(2);
                componentAuthorizationInfoMapper.updateComponentAuthorizationInfoPickPaperUrl(componentAuthorizationInfo);
            }
        } catch (Exception e) {
            component.setPickPaperUrl("");
            componentAuthorizationInfoMapper.deleteComponentAuthorizationInfoPickPaperUrl(old.getId());
        }

        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(component));
    }

    /**
     * 自动停止广告投放计划
     *
     * @param component
     */
    private void stopAdvertisingPlan(ComponentAuthorizationInfo component) {
        /*事件发布*/
        Map<String, Object> map = new HashMap<>(4);
        map.put(AdvertisingConstants.KEY_APP_ID_STOP_AD_PLAN_EVENT, component);
        map.put(AdvertisingConstants.KEY_SYSTEM_ID, Constants.SYSTEM_ID);
        JedisPoolCacheUtils.publish(RedisSubscribe.CHANNEL_DSP_SYSTEM_COMMON, JSON.toJSONString(map));
    }

    /**
     * 广告池优化：当公众号启用后，对应广告单元自动切换为启用状态
     *
     * @param appId 公众号ID
     */
    private void restartAdvertisingUnitAliPay(String appId) {
        if (StringUtils.isBlank(appId)) {
            return;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appId);

        if (null == componentAuthorizationInfo) {
            return;
        }

        List<AdvertisingUnit> unitList = advertisingUnitService.selectUnitByWeChatOfficialAccount(componentAuthorizationInfo.getAppId());

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnit advertisingUnit : unitList) {
            if (advertisingUnit.getAdUseStatus().equals(AD_USE_YES.getValue())) {
                continue;
            }

            advertisingUnit.setAdUseStatus(AD_USE_YES.getValue());
            advertisingUnitService.updateAdvertisingUnit(advertisingUnit);

        }
    }

    /**
     * 广告池优化：当公众号启用后，对应广告单元自动切换为启用状态
     *
     * @param appId 公众号ID
     */
    private void restartAdvertisingUnitWx(String appId) {
        if (StringUtils.isBlank(appId)) {
            return;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appId);

        if (null == componentAuthorizationInfo) {
            return;
        }

        List<AdvertisingUnitWx> unitList = advertisingUnitWxService.selectUnitByWeChatOfficialAccount(componentAuthorizationInfo.getAppId());

        if (null == unitList || unitList.isEmpty()) {
            return;
        }

        for (AdvertisingUnitWx advertisingUnit : unitList) {
            if (advertisingUnit.getAdUseStatus().equals(AD_USE_YES.getValue())) {
                continue;
            }

            advertisingUnit.setAdUseStatus(AD_USE_YES.getValue());
            advertisingUnitWxService.updateAdvertisingUnitWx(advertisingUnit);

        }
    }

    /**
     * 广告池优化：当公众号启用后，对应广告单元自动切换为启用状态
     *
     * @param appId 公众号ID
     */
    private void restartAdvertisingUnitFans(String appId) {
        if (StringUtils.isBlank(appId)) {
            return;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appId);

        if (null == componentAuthorizationInfo) {
            return;
        }

        List<AdvertisingUnitFans> unitFansList = advertisingUnitFansService.selectUnitByWeChatOfficialAccount(componentAuthorizationInfo.getAppId());

        if (null == unitFansList || unitFansList.isEmpty()) {
            return;
        }

        for (AdvertisingUnitFans advertisingUnit : unitFansList) {
            if (advertisingUnit.getAdUseStatus().equals(AD_USE_YES.getValue())) {
                continue;
            }

            advertisingUnit.setAdUseStatus(AD_USE_YES.getValue());
            advertisingUnitFansService.updateAdvertisingUnitFans(advertisingUnit);

        }
    }

    /**
     * 涉及哪些已暂停广告投放计划
     *
     * @param id
     */
    @PostMapping("/pausedPlans")
    @ResponseBody
    public List<AdvertisingPlan> pausedPlans(@RequestParam(value = "id", required = false) Integer id) {

        if (null == id) {
            return Collections.emptyList();
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);

        if (null == componentAuthorizationInfo || StringUtils.isBlank(componentAuthorizationInfo.getAppId())) {
            return Collections.emptyList();
        }

        String appId = componentAuthorizationInfo.getAppId();
        List<AdvertisingPlan> list = advertisingPlanService.selectByAdAppId(appId);

        if (null != list && !list.isEmpty()) {
            list.removeIf(plan -> plan.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue()) || plan.getDeleted().equals(YES.getValue()));
        } else {
            list = new ArrayList<>();
        }

        List<AdvertisingPlanWx> listWx = advertisingPlanWxService.selectByAdAppId(appId);

        if (null != listWx && !listWx.isEmpty()) {

            for (AdvertisingPlanWx wx : listWx) {
                if (wx.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue()) || wx.getDeleted().equals(YES.getValue())) {
                    continue;
                }
                list.add(wx);
            }
        }

        List<AdvertisingPlanFans> planFans = advertisingPlanFansService.selectByAdAppId(appId);

        if (null != planFans && !planFans.isEmpty()) {

            for (AdvertisingPlanFans fans : planFans) {
                if (fans.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue()) || fans.getDeleted().equals(YES.getValue())) {
                    continue;
                }
                list.add(fans);
            }
        }

        return list;
    }

    /**
     * 公众号投放手动暂停
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:pause")
    @Log(title = "公众号投放手动暂停", businessType = BusinessType.UPDATE)
    @PostMapping("/pause")
    @ResponseBody
    public AjaxResult pause(Integer id) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);

        if (null == componentAuthorizationInfo) {
            return error("公众号不存在");
        }

        componentAuthorizationInfo.setDeliveryStatus(ZjbDictionaryEnum.AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STOP_MANUAL.getValue());
        componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);
        stopAdvertisingPlan(componentAuthorizationInfo);

        return success();
    }

    /**
     * 公众号投放手动恢复
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:resume")
    @Log(title = "公众号投放手动恢复", businessType = BusinessType.UPDATE)
    @PostMapping("/resume")
    @ResponseBody
    public AjaxResult resume(Integer id) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);

        if (null == componentAuthorizationInfo) {
            return error("公众号不存在");
        }

        componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
        componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);
        restartAdvertisingUnitAliPay(componentAuthorizationInfo.getAppId());
        restartAdvertisingUnitWx(componentAuthorizationInfo.getAppId());
        restartAdvertisingUnitFans(componentAuthorizationInfo.getAppId());

        return success();
    }

    /**
     * 未认证公众号openid记录打开
     */
    @Log(title = "未认证公众号openid记录打开 ", businessType = BusinessType.UPDATE)
    @PostMapping("/open")
    @ResponseBody
    public AjaxResult open(Integer id) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        componentAuthorizationInfo.setRecordStatus(RECORD_STATUS_STARTED.getValue());
        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 未认证公众号openid记录关闭
     */
    @Log(title = "未认证公众号openid记录关闭 ", businessType = BusinessType.UPDATE)
    @PostMapping("/close")
    @ResponseBody
    public AjaxResult close(Integer id) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        componentAuthorizationInfo.setRecordStatus(RECORD_STATUS_STOPPED.getValue());
        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 修改公众号标签
     */
    @GetMapping("/configLabel/{appid}")
    public String configLabel(@PathVariable("appid") String appid, ModelMap mmap) {
        String result = feignAdminCoreService.getAccessToken(appid);
        if (StringUtils.isNotBlank(result)) {
            String TAGS_URL = "https://api.weixin.qq.com/cgi-bin/tags/get?access_token=" + result;
            String targs = HttpUtil.get(TAGS_URL);
            if (StringUtils.isNotEmpty(targs)) {
                JSONObject jsonObject1 = JSON.parseObject(targs);
                JSONArray targs_list = JSON.parseArray(jsonObject1.getString("tags"));
                if (targs_list != null) {
                    for (Object o : targs_list) {
                        JSONObject jsonObject = JSONObject.parseObject(o.toString());
                        GzhLabel gzhLabel = new GzhLabel();
                        gzhLabel.setAppid(appid);
                        gzhLabel.setLabelId(jsonObject.getInteger("id"));
                        List<GzhLabel> gzhLabels = gzhLabelService.selectGzhLabelList(gzhLabel);
                        if (gzhLabels != null && gzhLabels.size() > 0) {
                            gzhLabel.setId(gzhLabels.get(0).getId());
                            gzhLabel.setLabelCount(jsonObject.getInteger("count"));
                            gzhLabel.setLabelName(jsonObject.getString("name"));
                            gzhLabel.setGmtModified(new Date());
                            gzhLabelService.updateGzhLabel(gzhLabel);
                        } else {
                            gzhLabel.setLabelCount(jsonObject.getInteger("count"));
                            gzhLabel.setLabelName(jsonObject.getString("name"));
                            gzhLabel.setGmtCreated(new Date());
                            gzhLabelService.insertGzhLabel(gzhLabel);
                        }

                    }
                }

            }
        }
        mmap.addAttribute("appid", appid);
        return "dsp/gzhLabel/gzhLabel";
    }

    /**
     * 修改保存公众号粉丝标签详情
     */
    @Log(title = "公众号粉丝标签详情", businessType = BusinessType.UPDATE)
    @PostMapping("/editStatus")
    @ResponseBody
    public AjaxResult editStatus(ComponentAuthorizationInfo componentAuthorizationInfo) {
        if (StringUtils.isNotEmpty(componentAuthorizationInfo.getAppId())) {
            ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(componentAuthorizationInfo.getAppId());
            componentAuthorizationInfo.setId(componentAuthorizationInfo1.getId());
        }

        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfoLabel(componentAuthorizationInfo));
    }

    @PostMapping("/weChatAccountInfo")
    @ResponseBody
    public List<ComponentAuthorizationInfo> findList(ComponentAuthorizationInfo info) {

        return componentAuthorizationInfoService.selectComponentAuthorizationInfoList(info);
    }

    /**
     * API对接上架公众号
     */
    @GetMapping("/manualAdd")
    public String manualAdd() {
        return prefix + "/manualAdd";
    }

    /**
     * API对接上架公众号新增保存
     *
     * @param componentAuthorizationInfo
     * @return
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:manualAdd")
    @Log(title = "公众号或API对接上架", businessType = BusinessType.INSERT)
    @PostMapping("/manualAdd")
    @ResponseBody
    public AjaxResult manualAddSave(ComponentAuthorizationInfo componentAuthorizationInfo) {
        Integer userId = getUserId().intValue();
        componentAuthorizationInfo.setInsertBaseParams(userId, userId);
        componentAuthorizationInfo.setComponentAuthorizationType(MANUAL_ADD.getValue());
        componentAuthorizationInfo.setAuthorizationStatus(AUTH_STATUS_SUCCESS.getValue());
        componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
        ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(componentAuthorizationInfo.getAppId());
        if (componentAuthorizationInfo1 != null) {
            componentAuthorizationInfo.setGmtModified(new Date());
            componentAuthorizationInfo.setId(componentAuthorizationInfo1.getId());
            return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
        }
        return toAjax(componentAuthorizationInfoService.insertComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 修改API对接上架公众号
     */
    @GetMapping("/manualEdit/{id}")
    public String manualEdit(@PathVariable("id") Integer id, ModelMap mmap) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);
        mmap.put("componentAuthorizationInfo", componentAuthorizationInfo);
        return prefix + "/manualEdit";
    }

    /**
     * 修改保存API对接上架公众号
     */
    @Log(title = "公众号或小程序的授权 ", businessType = BusinessType.UPDATE)
    @PostMapping("/manualEdit")
    @ResponseBody
    public AjaxResult manualEditSave(ComponentAuthorizationInfo componentAuthorizationInfo) {
        Integer userId = getUserId().intValue();
        componentAuthorizationInfo.setUpdateBaseParams(userId);
        componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
        return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
    }

    /**
     * 人工上架
     */
    @GetMapping("/manualGround")
    public String manualGround() {
        return prefix + "/manualGround";
    }

    /**
     * 人工上架公众号新增
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:manualGround")
    @Log(title = "人工上架公众号", businessType = BusinessType.INSERT)
    @PostMapping("/manualGround")
    @ResponseBody
    public AjaxResult manualGround(ComponentAuthorizationInfo componentAuthorizationInfo,
                                   @RequestParam("qrcodeUrlFile") MultipartFile qrcodeUrlFile) {
        try {
            if (!qrcodeUrlFile.isEmpty()) {
                String fileKey = zjbConfig.getGzhQrcodeUrl() +
                        DateUtils.getDate() + "/" +
                        OssUtil.encodingFilename(qrcodeUrlFile.getOriginalFilename(), FileUploadUtils.IMAGE_JPG_EXTENSION);
                OssUtil.uploadFile(fileKey, qrcodeUrlFile.getInputStream());
                componentAuthorizationInfo.setQrcodeUrl(ZjbConstants.File_Domain + "/" + fileKey);
            }
            componentAuthorizationInfo.setInsertBaseParams(getUserId().intValue(), getUserId().intValue());
            //人工上架
            componentAuthorizationInfo.setComponentAuthorizationType(MANUAL_GROUND.getValue());
            //未授权
            componentAuthorizationInfo.setAuthorizationStatus(AUTH_STATUS_TODO.getValue());
            //未认证
            //componentAuthorizationInfo.setVerifyTypeInfo(-1);
            //生效中
            componentAuthorizationInfo.setDeliveryStatus(AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_RUN.getValue());
            ComponentAuthorizationInfo componentAuthorizationInfo1 = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(componentAuthorizationInfo.getAppId());
            if (componentAuthorizationInfo1 != null) {
                componentAuthorizationInfo.setGmtModified(new Date());
                componentAuthorizationInfo.setId(componentAuthorizationInfo1.getId());
                return toAjax(componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo));
            }
            return toAjax(componentAuthorizationInfoService.insertComponentAuthorizationInfo(componentAuthorizationInfo));
        } catch (Exception e) {
            logger.warn("上传公众号二维码失败");
            return error();
        }
    }

    /**
     * 根据公众号APPID获取公司主体信息
     *
     * @param appid
     * @return
     */
    @GetMapping("/getAutorizeCompanyByAppId")
    @ResponseBody
    public AutorizeCompany getAutorizeCompanyByAppId(String appid) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appid);
        if (null == componentAuthorizationInfo || null == componentAuthorizationInfo.getCompanyId()) {
            return null;
        }

        AutorizeCompany autorizeCompany = autorizeCompanyService.selectAutorizeCompanyById(componentAuthorizationInfo.getCompanyId());

        return autorizeCompany;
    }

    /**
     * 根据公众号APPID获取公司主体第三方平台信息
     *
     * @param appid
     * @return
     */
    @GetMapping("/getAutorizeCompanyByThirdPlatformAppId")
    @ResponseBody
    public AutorizeCompanyThirdPlatform getAutorizeCompanyByThirdPlatformAppId(String appid) {
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoByAppId(appid);
        if (null == componentAuthorizationInfo || null == componentAuthorizationInfo.getThirdPlatformAppId()) {
            return null;
        }

        return autorizeCompanyThirdPlatformService.selectAutorizeCompanyThirdPlatformById(componentAuthorizationInfo.getThirdPlatformAppId());
    }

    /**
     * 获取授权公司主体列表信息
     *
     * @return
     */
    @GetMapping("/getAutorizeCompanyThirdPlatformList")
    @ResponseBody
    public AjaxResult getAutorizeCompanyThirdPlatformList() {
        List<CompanyThirdPlatformData> companyThirdPlatformDataList = new ArrayList<CompanyThirdPlatformData>();
        AutorizeCompany autorizeCompany = new AutorizeCompany();
        List<AutorizeCompany> autorizeCompanyList = autorizeCompanyService.selectAutorizeCompanyList(autorizeCompany);
        if (autorizeCompanyList != null && !(autorizeCompanyList.isEmpty())) {
            for (AutorizeCompany autorizeCompany1 : autorizeCompanyList) {
                if (null != autorizeCompany1 && null != autorizeCompany1.getId()) {
                    List<CompanyThirdPlatformData> thirdPlatformDataList = autorizeCompanyThirdPlatformService.getAutorizeCompanyThirdPlatformList(autorizeCompany1.getId());
                    if (thirdPlatformDataList != null && !(thirdPlatformDataList.isEmpty())) {
                        CompanyThirdPlatformData companyThirdPlatformData = new CompanyThirdPlatformData();
                        companyThirdPlatformData.setName(autorizeCompany1.getCompanyName());
                        companyThirdPlatformData.setValue(autorizeCompany1.getId());
                        companyThirdPlatformData.setChildren(thirdPlatformDataList);
                        companyThirdPlatformDataList.add(companyThirdPlatformData);
                    }
                }
            }
        }
        return success(companyThirdPlatformDataList);
    }

    @Log(title = "删除出纸二维码", businessType = BusinessType.DELETE)
    @PostMapping("/removeImg")
    @ResponseBody
    public AjaxResult removeImg(Integer id) {
        return toAjax(componentAuthorizationInfoService.deleteComponentAuthorizationInfoPickPaperUrl(id));
    }


    /**
     * 公众号总关注量矫正，即于核心数据库zjb.zjb_component_gzh_event数据保持一致
     */
    @RequiresPermissions("zjb:componentAuthorizationInfo:delivery")
    @Log(title = "公众号总关注量矫正", businessType = BusinessType.UPDATE)
    @PostMapping("/totalFollowAmount/correction")
    @ResponseBody
    public AjaxResult totalFollowAmountCorrection(Integer id) {

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoService.selectComponentAuthorizationInfoById(id);

        if (null == componentAuthorizationInfo) {
            return error("公众号不存在");
        }

        /*截至到昨日公众号关注数量*/
        int countSubscribeBeforeToday = componentAuthorizationInfoService.countSubscribeBeforeToday(componentAuthorizationInfo.getAppId());

        /*日关注量*/
        String keyDayFollowAmount = componentAuthorizationInfo.getAppId() + '_' + LocalDate.now();
        String valueDayFollowAmount = JedisPoolCacheUtils.get(keyDayFollowAmount, 0);
        int dayFollowAmount = StringUtils.isNumeric(valueDayFollowAmount) ? Integer.parseInt(valueDayFollowAmount) : 0;

        /*总关注量*/
        String keyTotalFollowAmount = componentAuthorizationInfo.getAppId() + "_total_follow_amount";
        int totalFollowAmount = dayFollowAmount + countSubscribeBeforeToday;
        JedisPoolCacheUtils.set(keyTotalFollowAmount, String.valueOf(totalFollowAmount), 0, EXRP_YEAR);
        componentAuthorizationInfo.setTotalFollowAmount(totalFollowAmount);

        componentAuthorizationInfoService.updateComponentAuthorizationInfo(componentAuthorizationInfo);

        return success();
    }
}
