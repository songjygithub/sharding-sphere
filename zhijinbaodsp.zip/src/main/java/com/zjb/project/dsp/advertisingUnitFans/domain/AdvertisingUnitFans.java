package com.zjb.project.dsp.advertisingUnitFans.domain;

import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;


/**
 * 粉丝通广告池表 zjb_advertising_unit_fans
 *
 * @author shenlong
 * @date 2019-11-22
 */
public class AdvertisingUnitFans extends AdvertisingUnit
{
	private static final long serialVersionUID = 1L;

	/**广告池id或名称*/
	private String adIdOrName;

	public String getAdIdOrName() {
		return adIdOrName;
	}

	public void setAdIdOrName(String adIdOrName) {
		this.adIdOrName = adIdOrName;
	}
}
