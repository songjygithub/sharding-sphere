package com.zjb.project.dsp.feign.service;

import com.zjb.project.common.componentAuthorizationInfo.domain.OpenApiAccountDTO;
import com.zjb.project.common.miniConfig.domain.WeChatSms;
import com.zjb.project.dsp.advertisingADExchange.domain.WechatParameter;
import com.zjb.project.dsp.feign.IBaseFeignService;
import com.zjb.qrcodego.domain.WeChatAccountTaskInfo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import static com.zjb.project.dsp.feign.IBaseFeignService.ZJB_ADMIN_CORE;

/**
 * @author songjy
 * @date 2020-05-20
 */
@FeignClient(value = ZJB_ADMIN_CORE, fallback = HystrixAdminCoreFallbackImpl.class)
public interface IFeignAdminCoreService extends IBaseFeignService {

    /**
     * 根据任务ID获取第三方平台广告信息
     */
    String ADMIN_CORE_URL_TASK_INFO = "/mini/task_info";

    /**
     * 根据任务ID获取第三方平台广告信息
     *
     * @param openId    用户微信|支付宝唯一标识
     * @param taskId    任务ID
     * @param qrCode    设备二维码
     * @param randomNum 用户扫码流水号
     * @param appId     公众号appId，如：wxeb1490cb1af26e65，可为空
     * @return 第三方平台广告信息
     */
    @RequestMapping(value = ADMIN_CORE_URL_TASK_INFO,
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE,
            produces = {MediaType.TEXT_PLAIN_VALUE})
    String taskInfo(@RequestParam(value = "openid") String openId,
                    @RequestParam(value = "taskId") String taskId,
                    @RequestParam(value = "qrcode") String qrCode,
                    @RequestParam(value = "randomNum") Long randomNum,
                    @RequestParam(value = "appId") String appId);

    /**
     * 根据参数获取公众号信息
     *
     * @param wechatParameter 请求参数
     * @return 公众号信息
     */
    @RequestMapping(value = "/mini/wechatInfo",
            method = RequestMethod.POST,
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    WeChatAccountTaskInfo weChatInfo(WechatParameter wechatParameter);

    /**
     * 判断openid是否关注4个公众号：微信小树叶功能模块已取消，该方法亦作废
     *
     * @param json
     * @return 判断openid是否关注4个公众号
     */
    @PostMapping(value = "/zjb/appidOpenidIndex/isSubscribe",
            consumes = MediaType.APPLICATION_JSON_UTF8_VALUE,
            produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @Deprecated
    String isSubscribe(String json);

    /**
     * 根据appId查询开放平台对接渠道账号申请信息
     *
     * @param appId 微信公众号
     * @return 开放平台对接渠道账号申请信息
     */
    @GetMapping("/zjb/openApiAccount/getOpenApiAccountInfo")
    OpenApiAccountDTO getOpenApiAccountInfoByAppId(@RequestParam("appid") String appId);

    /**
     * 根据微信公众号获取获取token
     * @param appId 微信公众号
     * @return token
     */
    @GetMapping("/wechat/getAccessToken/{appId}")
    String getAccessToken(@PathVariable("appId") String appId);

    /**
     * 公众号消息推送
     * @param weChatSms
     * @return 结果
     */
    @PostMapping("/mini/wechatsms/send")
    String weChatSmsSend(WeChatSms weChatSms);
}
