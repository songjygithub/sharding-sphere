package com.zjb.project.dsp.advertisingTargetInfo.domain;

import java.io.Serializable;

/**
 * @author songjy
 * @date 2019/10/15
 */
public class RpcResponse implements Serializable {
    private static final long serialVersionUID = 9044850235943057166L;

    private String requestId;

    private Boolean success;

    private String errorMessage;

    private String rrpcCode;

    private String payloadBase64Byte;

    private Long messageId;

    /**
     * 用户微信|支付宝唯一标识
     */
    private String openId;

    /**
     * 用户扫码流水号
     */
    private String randomNum;

    /**
     * 下发命令
     */
    private String command;

    /**
     * 小树叶极速取纸流水号
     */
    private Long leafSerialNum;

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getRrpcCode() {
        return rrpcCode;
    }

    public void setRrpcCode(String rrpcCode) {
        this.rrpcCode = rrpcCode;
    }

    public String getPayloadBase64Byte() {
        return payloadBase64Byte;
    }

    public void setPayloadBase64Byte(String payloadBase64Byte) {
        this.payloadBase64Byte = payloadBase64Byte;
    }

    public Long getMessageId() {
        return messageId;
    }

    public void setMessageId(Long messageId) {
        this.messageId = messageId;
    }

    public String getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(String randomNum) {
        this.randomNum = randomNum;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public Long getLeafSerialNum() {
        return leafSerialNum;
    }

    public void setLeafSerialNum(Long leafSerialNum) {
        this.leafSerialNum = leafSerialNum;
    }
}
