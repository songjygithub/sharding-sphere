package com.zjb.project.dsp.gzhPushAdTj.mapper;

import com.zjb.project.dsp.gzhPushAdTj.domain.GzhPushAdTj;
import java.util.List;	

/**
 * 消息广告点击统计 数据层
 * 
 * @author shenlong
 * @date 2019-08-26
 */
public interface GzhPushAdTjMapper 
{
	/**
     * 查询消息广告点击统计信息
     * 
     * @param id 消息广告点击统计ID
     * @return 消息广告点击统计信息
     */
	public GzhPushAdTj selectGzhPushAdTjById(Integer id);
	
	/**
     * 查询消息广告点击统计列表
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 消息广告点击统计集合
     */
	public List<GzhPushAdTj> selectGzhPushAdTjList(GzhPushAdTj gzhPushAdTj);
	
	/**
     * 新增消息广告点击统计
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 结果
     */
	public int insertGzhPushAdTj(GzhPushAdTj gzhPushAdTj);
	
	/**
     * 修改消息广告点击统计
     * 
     * @param gzhPushAdTj 消息广告点击统计信息
     * @return 结果
     */
	public int updateGzhPushAdTj(GzhPushAdTj gzhPushAdTj);
	
	/**
     * 删除消息广告点击统计
     * 
     * @param id 消息广告点击统计ID
     * @return 结果
     */
	public int deleteGzhPushAdTjById(Integer id);
	
	/**
     * 批量删除消息广告点击统计
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhPushAdTjByIds(String[] ids);
	
}