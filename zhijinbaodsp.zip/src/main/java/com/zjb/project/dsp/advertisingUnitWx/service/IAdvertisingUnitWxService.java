package com.zjb.project.dsp.advertisingUnitWx.service;

import java.util.List;

import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;

/**
 * 广告池-微信 服务层
 *
 * @author ZH
 * @date 2019-08-13
 */
public interface IAdvertisingUnitWxService {
    /**
     * 查询广告池信息
     *
     * @param id 广告池ID
     * @return 广告池信息
     */
    AdvertisingUnitWx selectAdvertisingUnitWxById(Integer id);

    /**
     * 查询广告池列表
     *
     * @param advertisingUnitWx 广告池信息
     * @return 广告池集合
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitWxList(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 新增广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    int insertAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 修改广告池
     *
     * @param advertisingUnitWx 广告池信息
     * @return 结果
     */
    int updateAdvertisingUnitWx(AdvertisingUnitWx advertisingUnitWx);

    /**
     * 删除广告池信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingUnitWxByIds(String ids);

    /**
     * 通过广告方案ID查询广告单元
     *
     * @param id
     * @return
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitListByCombinationId(Integer id);

    /**
     * @param taskId 表【zjb_scan_task】主键ID
     * @return
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitByTaskId(Integer taskId);

    /**
     * 通过广告投放计划ID查询广告单元
     *
     * @param planId
     * @return
     */
    List<AdvertisingUnitWx> selectAdvertisingUnitWxListByPlanId(Integer planId);

    /**
     * 公众号都走支配，无需关联任务查询
     *
     * @param weChatOfficialAccount 微信公众号
     * @return
     */
    List<AdvertisingUnitWx> selectUnitByWeChatOfficialAccount(String weChatOfficialAccount);

}
