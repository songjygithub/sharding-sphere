package com.zjb.project.dsp.forbidPutPersonalAccountConfig.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
																		import java.util.Date;
import java.util.List;

/**
 * 指定次数禁投个人号广告配置表 zjb_forbid_put_personal_account_config
 * 
 * @author jiangbingjie
 * @date 2020-04-22
 */
public class ForbidPutPersonalAccountConfig extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/** 配置主键 */
	private Integer configId;
	/** 设备id */
	private Integer deviceId;
	/** 设备名称 */
	private String deviceName;
	/** 设备SN */
	private String deviceSn;
	/** 代理商id */
	private Integer agencyId;
	/** 代理商名称 */
	private String agencyName;
	/** 安装场景分类编码(参考字典) */
	private String installSceneTypeCode;
	/** 安装场景编码(参考字典) */
	private String installSceneCode;
	/** 禁投个人号的取纸次数类型(参考字典) */
	private Integer forbidPutPersonalAccountType;
	/** 禁投个人号的取纸次数，多个之间用,分隔 */
	private String takePaperTimes;
	/** 指定次数禁投个人号广告配置状态(参考字典) */
	private Integer configStatus;
	/** 生效时间 */
	private Date effectiveTime;
	/** 失效时间 */
	private Date loseEfficacyTime;

	/**
	 * 代理商ID 非数据库映射字段
	 */
	private String agencyIds;

	/**
	 * 设备SN 非数据库映射字段
	 */
	@Excel(name = "mixId")
	private String mixId;

	/**
	 * 禁投公众号的取纸次数描述  非数据库映射字段
	 */
	private String takePaperTimesDesc;

	/**
	 * 当前用户取纸次数 非数据库映射字段
	 */
	private Integer takePaperTime;

	/**
	 * 当前时间  非数据库映射字段
	 */
	private String nowTime;

	/**
	 * 代理商id列表 非数据库映射字段
	 */
	private List<String> agencyIdList;

	public void setConfigId(Integer configId) 
	{
		this.configId = configId;
	}

	public Integer getConfigId() 
	{
		return configId;
	}
	public void setDeviceId(Integer deviceId) 
	{
		this.deviceId = deviceId;
	}

	public Integer getDeviceId() 
	{
		return deviceId;
	}
	public void setDeviceName(String deviceName) 
	{
		this.deviceName = deviceName;
	}

	public String getDeviceName() 
	{
		return deviceName;
	}
	public void setDeviceSn(String deviceSn) 
	{
		this.deviceSn = deviceSn;
	}

	public String getDeviceSn() 
	{
		return deviceSn;
	}
	public void setAgencyId(Integer agencyId) 
	{
		this.agencyId = agencyId;
	}

	public Integer getAgencyId() 
	{
		return agencyId;
	}
	public void setAgencyName(String agencyName) 
	{
		this.agencyName = agencyName;
	}

	public String getAgencyName() 
	{
		return agencyName;
	}
	public void setInstallSceneTypeCode(String installSceneTypeCode) 
	{
		this.installSceneTypeCode = installSceneTypeCode;
	}

	public String getInstallSceneTypeCode() 
	{
		return installSceneTypeCode;
	}
	public void setInstallSceneCode(String installSceneCode) 
	{
		this.installSceneCode = installSceneCode;
	}

	public String getInstallSceneCode() 
	{
		return installSceneCode;
	}
	public void setForbidPutPersonalAccountType(Integer forbidPutPersonalAccountType) 
	{
		this.forbidPutPersonalAccountType = forbidPutPersonalAccountType;
	}

	public Integer getForbidPutPersonalAccountType() 
	{
		return forbidPutPersonalAccountType;
	}
	public void setTakePaperTimes(String takePaperTimes) 
	{
		this.takePaperTimes = takePaperTimes;
	}

	public String getTakePaperTimes() 
	{
		return takePaperTimes;
	}
	public void setConfigStatus(Integer configStatus) 
	{
		this.configStatus = configStatus;
	}

	public Integer getConfigStatus() 
	{
		return configStatus;
	}
	public void setEffectiveTime(Date effectiveTime) 
	{
		this.effectiveTime = effectiveTime;
	}

	public Date getEffectiveTime() 
	{
		return effectiveTime;
	}
	public void setLoseEfficacyTime(Date loseEfficacyTime) 
	{
		this.loseEfficacyTime = loseEfficacyTime;
	}

	public Date getLoseEfficacyTime() 
	{
		return loseEfficacyTime;
	}

	public String getAgencyIds() {
		return agencyIds;
	}

	public void setAgencyIds(String agencyIds) {
		this.agencyIds = agencyIds;
	}

	public String getMixId() {
		return mixId;
	}

	public void setMixId(String mixId) {
		this.mixId = mixId;
	}

	public String getTakePaperTimesDesc() {
		return takePaperTimesDesc;
	}

	public void setTakePaperTimesDesc(String takePaperTimesDesc) {
		this.takePaperTimesDesc = takePaperTimesDesc;
	}

	public Integer getTakePaperTime() {
		return takePaperTime;
	}

	public void setTakePaperTime(Integer takePaperTime) {
		this.takePaperTime = takePaperTime;
	}

	public String getNowTime() {
		return nowTime;
	}

	public void setNowTime(String nowTime) {
		this.nowTime = nowTime;
	}

	public List<String> getAgencyIdList() {
		return agencyIdList;
	}

	public void setAgencyIdList(List<String> agencyIdList) {
		this.agencyIdList = agencyIdList;
	}

	public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("configId", getConfigId())
            .append("deviceId", getDeviceId())
            .append("deviceName", getDeviceName())
            .append("deviceSn", getDeviceSn())
            .append("agencyId", getAgencyId())
            .append("agencyName", getAgencyName())
            .append("installSceneTypeCode", getInstallSceneTypeCode())
            .append("installSceneCode", getInstallSceneCode())
            .append("forbidPutPersonalAccountType", getForbidPutPersonalAccountType())
            .append("takePaperTimes", getTakePaperTimes())
            .append("configStatus", getConfigStatus())
            .append("effectiveTime", getEffectiveTime())
            .append("loseEfficacyTime", getLoseEfficacyTime())
            .append("createrId", getCreaterId())
            .append("modifierId", getModifierId())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("deleted", getDeleted())
            .toString();
    }
}
