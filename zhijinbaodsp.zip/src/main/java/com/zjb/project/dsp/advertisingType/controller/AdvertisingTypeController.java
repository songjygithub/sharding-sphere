package com.zjb.project.dsp.advertisingType.controller;

import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.domain.BaseEntity;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingType.domain.AdvertisingType;
import com.zjb.project.dsp.advertisingType.service.IAdvertisingTypeService;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.system.user.domain.User;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

import static com.zjb.common.enums.ZjbDictionaryEnum.AD_USE_YES;
import static com.zjb.common.enums.ZjbDictionaryEnum.NO;

/**
 * 广告类型 信息操作处理
 *
 * @author songjy
 * @date 2020-03-24
 */
@Controller
@RequestMapping("/dsp/advertisingType")
public class AdvertisingTypeController extends BaseController {
    private String prefix = "dsp/advertisingType";

    @Autowired
    private IAdvertisingTypeService advertisingTypeService;
    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;
    @Autowired
    private IAdvertisingUnitService advertisingUnitService;

    @RequiresPermissions("dsp:advertisingType:view")
    @GetMapping()
    public String advertisingType() {
        return prefix + "/advertisingType";
    }

    /**
     * 查询广告类型列表
     */
    @RequiresPermissions("dsp:advertisingType:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingType advertisingType) {
        startPage();
        List<AdvertisingType> list = advertisingTypeService.selectAdvertisingTypeList(advertisingType);

        for (BaseEntity baseEntity : list) {
            User user = getUser(baseEntity.getCreaterId().longValue());
            baseEntity.setCreateBy(null == user ? "" : user.getUserName());
            user = getUser(baseEntity.getModifierId().longValue());
            baseEntity.setUpdateBy(null == user ? "" : user.getUserName());
        }

        return getDataTable(list);
    }

    /**
     * 查询广告类型列表：供核心系统初始化调用
     */
    @PostMapping("/all")
    @ResponseBody
    public List<AdvertisingType> listAdvertisingType(@RequestBody AdvertisingType advertisingType) {
        return advertisingTypeService.selectAdvertisingTypeList(advertisingType);
    }

    /**
     * 新增广告类型
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存广告类型
     */
    @RequiresPermissions("dsp:advertisingType:add")
    @Log(title = "广告类型", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingType advertisingType) {

        User user = getUser();
        advertisingType.setCreaterId(user.getUserId().intValue());
        advertisingType.setModifierId(user.getUserId().intValue());

        return toAjax(advertisingTypeService.insertAdvertisingType(advertisingType));
    }

    /**
     * 修改广告类型
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        AdvertisingType advertisingType = advertisingTypeService.selectAdvertisingTypeById(id);
        mmap.put("advertisingType", advertisingType);
        return prefix + "/edit";
    }

    /**
     * 已配置广告数量：详情
     */
    @RequiresPermissions("dsp:advertisingType:view")
    @GetMapping("/adConfigView/{id}")
    public String adConfigView(@PathVariable("id") Integer id, ModelMap modelMap) {

        AdvertisingType advertisingType = advertisingTypeService.selectAdvertisingTypeById(id);
        modelMap.put("advertisingType", advertisingType);

        AdvertisingUnitFans query = new AdvertisingUnitFans();
        query.setAdTypeId(id);

        List<AdvertisingUnit> unitList = advertisingUnitService.selectAdvertisingUnitList(query);
        List<AdvertisingUnitFans> unitFansList = advertisingUnitFansService.selectAdvertisingUnitFansList(query);
        unitList.addAll(unitFansList);

        modelMap.put("unitList", unitList);

        return prefix + "/adConfigView";
    }

    /**
     * 修改保存广告类型
     */
    @RequiresPermissions("dsp:advertisingType:edit")
    @Log(title = "广告类型", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingType advertisingType) {

        if (advertisingType.getId() >= 1 && advertisingType.getId() <= 2) {
            return error("不允许修改");
        }

        User user = getUser();
        advertisingType.setModifierId(user.getUserId().intValue());
        advertisingType.setGmtModified(new Date());

        return toAjax(advertisingTypeService.updateAdvertisingType(advertisingType));
    }

    /**
     * 删除广告类型
     */
    @RequiresPermissions("dsp:advertisingType:remove")
    @Log(title = "广告类型", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingTypeService.deleteAdvertisingTypeByIds(ids));
    }

}
