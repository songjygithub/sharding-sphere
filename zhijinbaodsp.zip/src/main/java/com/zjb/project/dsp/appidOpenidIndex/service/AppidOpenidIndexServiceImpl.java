package com.zjb.project.dsp.appidOpenidIndex.service;

import com.zjb.common.constant.Constants;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.dsp.appidOpenidIndex.domain.AppIdOpenIdIndex;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static org.apache.commons.lang3.time.DateFormatUtils.ISO_8601_EXTENDED_DATE_FORMAT;

/**
 * openid和appid关系 服务层实现
 *
 * @author songjy
 * @date 2019-11-01
 */
@Service
public class AppidOpenidIndexServiceImpl implements IAppidOpenidIndexService {
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 微信用户昵称提取规范，便于数据导出
     */
    private static final Pattern PATTERN_NICK_NAME = Pattern.compile("\\w*[\\u4e00-\\u9fa5]*\\d*");

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;

    @Override
    public AppIdOpenIdIndex selectById(Integer id) {

        if (null == id) {
            return null;
        }

        String sql = "SELECT * FROM zjb_appid_openid_index WHERE id = ?";
        try {

            return jdbcTemplate.queryForObject(sql, new Object[]{id}, new int[]{Types.INTEGER}, new RowMapper<AppIdOpenIdIndex>() {
                @Override
                public AppIdOpenIdIndex mapRow(ResultSet rs, int rowNum) throws SQLException {
                    AppIdOpenIdIndex record = new AppIdOpenIdIndex();
                    setValues(rs, record);
                    return record;
                }
            });

        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public int deleteById(Integer id) {

        AppIdOpenIdIndex record = selectById(id);

        if (null == record) {
            return 0;
        }

        String sql = "DELETE FROM zjb_appid_openid_index WHERE id = ?";
        Object[] args = {id};
        int[] argTypes = {Types.INTEGER};
        int r = jdbcTemplate.update(sql, args, argTypes);

        AuthorizationUserInfoDTO userInfo = new AuthorizationUserInfoDTO();
        userInfo.setOpenId(record.getOpenid());
        userInfo.setSubscribeGzh(",");

        authorizationUserInfoService.updateAuthorizationUserInfo(userInfo);

        return r;
    }

    @Override
    public List<AppIdOpenIdIndex> list(String zjbOpenId) {
        String sql = "SELECT * FROM `zjb_appid_openid_index` WHERE `zjb_openid` = ?";
        Object[] args = {zjbOpenId};
        int[] argTypes = {Types.VARCHAR};
        return jdbcTemplate.query(sql, args, argTypes, new RowMapper<AppIdOpenIdIndex>() {
            @Override
            public AppIdOpenIdIndex mapRow(ResultSet rs, int rowNum) throws SQLException {
                AppIdOpenIdIndex record = new AppIdOpenIdIndex();
                setValues(rs, record);
                return record;
            }
        });
    }

    /**
     * 设置值
     *
     * @param rs
     * @param record
     * @throws SQLException
     */
    private void setValues(ResultSet rs, AppIdOpenIdIndex record) throws SQLException {
        record.setId(rs.getInt("id"));
        record.setZjbOpenid(rs.getString("zjb_openid"));
        record.setOpenid(rs.getString("openid"));
        record.setAppid(rs.getString("appid"));
        record.setNickName(rs.getString("nick_name"));
        record.setSex(rs.getInt("sex"));
        record.setHeadImgUrl(rs.getString("head_img_url"));
        record.setCountry(rs.getString("country"));
        record.setProvince(rs.getString("province"));
        record.setCity(rs.getString("city"));
        record.setEvent(rs.getString("event"));
    }

    /**
     * 设置值
     *
     * @param rs
     * @param userInfo
     * @throws SQLException
     */
    private void setValues(ResultSet rs, UserInfo userInfo) throws SQLException {
        userInfo.setId(rs.getInt("id"));
        userInfo.setZjbOpenId(rs.getString("zjb_openid"));
        userInfo.setOpenid(rs.getString("openid"));
        userInfo.setNickName(rs.getString("nick_name"));
        userInfo.setSex(null == rs.getObject("sex") ? null : rs.getInt("sex"));
        userInfo.setHeadImgUrl(rs.getString("head_img_url"));
        userInfo.setCountry(rs.getString("country"));
        userInfo.setProvince(rs.getString("province"));
        userInfo.setCity(rs.getString("city"));
    }

    @Override
    public AppIdOpenIdIndex selectByOpenIdAndAppId(String openId, String appId) {

        if (StringUtils.isAnyBlank(openId, appId)) {
            return null;
        }

        String sql = "SELECT * FROM `zjb_appid_openid_index` WHERE `openid` = ? AND appid = ? LIMIT 1";
        Object[] args = {openId, appId};
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR};
        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<AppIdOpenIdIndex>() {
                @Override
                public AppIdOpenIdIndex mapRow(ResultSet rs, int rowNum) throws SQLException {
                    AppIdOpenIdIndex record = new AppIdOpenIdIndex();
                    setValues(rs, record);
                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public AppIdOpenIdIndex selectByZjbOpenIdAndAppId(String zjbOpenId, String appId) {
        String sql = "SELECT * FROM `zjb_appid_openid_index` WHERE `zjb_openid` = ? AND appid = ? LIMIT 1";
        int[] argTypes = {Types.VARCHAR, Types.VARCHAR};
        try {
            return jdbcTemplate.queryForObject(sql, new Object[]{zjbOpenId, appId}, argTypes, new RowMapper<AppIdOpenIdIndex>() {
                @Override
                public AppIdOpenIdIndex mapRow(ResultSet rs, int rowNum) throws SQLException {
                    AppIdOpenIdIndex record = new AppIdOpenIdIndex();
                    setValues(rs, record);
                    return record;
                }
            });
        } catch (EmptyResultDataAccessException e) {
            return null;
        }
    }

    @Override
    public int updateAppIdOpenIdIndexEvent(AppIdOpenIdIndex appIdOpenIdIndex) {
        String sql = "UPDATE `zjb_appid_openid_index` SET `event` = ?, `gmt_modified` = ? WHERE id = ?";
        Object[] args = {appIdOpenIdIndex.getEvent(), new Date(), appIdOpenIdIndex.getId()};
        int[] argTypes = {Types.VARCHAR, Types.TIMESTAMP, Types.INTEGER};
        int r = jdbcTemplate.update(sql, args, argTypes);

        if (!AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue().equals(appIdOpenIdIndex.getEvent())) {
            return r;
        }

        AuthorizationUserInfoDTO userInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(appIdOpenIdIndex.getZjbOpenid());

        if (null == userInfo || StringUtils.isBlank(userInfo.getSubscribeGzh())) {
            return r;
        }

        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(appIdOpenIdIndex.getAppid());

        if (null == componentAuthorizationInfo) {
            return r;
        }

        String[] array = StringUtils.split(userInfo.getSubscribeGzh(), ',');
        Set<String> set = new HashSet<>(Arrays.asList(array));
        boolean remove = set.remove(componentAuthorizationInfo.getId().toString());

        if (!remove) {
            return r;
        }

        userInfo.setSubscribeGzh(set.isEmpty() ? "," : String.join(",", set));
        authorizationUserInfoService.updateAuthorizationUserInfo(userInfo);

        return r;
    }

    @Override
    public List<UserInfo> selectByAppIdAndCreateDate(String appId, Date createDate) {
        String sql = "SELECT * FROM zjb_appid_openid_index WHERE `appid`= ? AND `gmt_created` BETWEEN ? AND ?";

        LocalDate start = DateUtils.toLocalDateTime(createDate).toLocalDate();
        LocalDateTime end = DateUtils.toLocalDateTime(createDate)
                .withHour(23)
                .withMinute(59)
                .withSecond(59);

        Object[] args = {appId, DateUtils.toDate(start), DateUtils.toDate(end)};
        int[] argTypes = {Types.VARCHAR, Types.TIMESTAMP, Types.TIMESTAMP};

        List<UserInfo> list = jdbcTemplate.query(sql, args, argTypes, new RowMapper<UserInfo>() {
            @Override
            public UserInfo mapRow(ResultSet rs, int rowNum) throws SQLException {
                UserInfo record = new UserInfo();
                setValues(rs, record);
                return record;
            }
        });

        if (null == list || list.isEmpty()) {
            return list;
        }

        for (UserInfo userInfo : list) {
            if (StringUtils.isNotBlank(userInfo.getNickName())) {
                continue;
            }

            AuthorizationUserInfoDTO user = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(userInfo.getZjbOpenId());

            if (null == user || StringUtils.isBlank(user.getUserNick())) {
                continue;
            }

            /*完善授权用户信息*/
            perfectUserInfo(userInfo, user);
        }

        return list.stream().filter(e -> StringUtils.isNotBlank(e.getOpenid())).collect(Collectors.toList());
    }

    /**
     * 完善授权用户信息
     *
     * @param userInfo
     * @param user
     */
    private void perfectUserInfo(UserInfo userInfo, AuthorizationUserInfoDTO user) {

        if (null == userInfo || null == userInfo.getId() || null == user) {
            return;
        }

        StringBuilder updateSql = new StringBuilder();
        List<Object> argList = new ArrayList<>();
        List<Integer> argTypeList = new ArrayList<>();

        if (StringUtils.isNotBlank(user.getUserNick())) {
            userInfo.setNickName(user.getUserNick());
            Matcher matcher = PATTERN_NICK_NAME.matcher(user.getUserNick());
            StringBuffer sb = new StringBuffer();
            for (; matcher.find(); ) {
                sb.append(StringUtils.defaultIfBlank(matcher.group(), ""));
            }
            updateSql.append("`nick_name` = ?,");
            argList.add(sb.toString());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isNotBlank(user.getCity())) {
            userInfo.setCity(user.getCity());
            updateSql.append("`city` = ?,");
            argList.add(user.getCity());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isNotBlank(user.getProvince())) {
            userInfo.setProvince(user.getProvince());
            updateSql.append("`province` = ?,");
            argList.add(user.getProvince());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isNotBlank(user.getCountry())) {
            userInfo.setCountry(user.getCountry());
            updateSql.append("`country` = ?,");
            argList.add(user.getCountry());
            argTypeList.add(Types.VARCHAR);
        }

        if (StringUtils.isNotBlank(user.getHeadimgurl())) {
            userInfo.setHeadImgUrl(user.getHeadimgurl());
            updateSql.append("`head_img_url` = ?,");
            argList.add(user.getHeadimgurl());
            argTypeList.add(Types.VARCHAR);
        }

        if (null != user.getSex()) {
            userInfo.setSex(user.getSex());
            updateSql.append("`sex` = ?,");
            argList.add(user.getSex());
            argTypeList.add(Types.INTEGER);
        }

        if (updateSql.length() == 0) {
            return;
        }

        /*删除最后一个逗号*/
        updateSql.deleteCharAt(updateSql.length() - 1);
        updateSql.insert(0, "UPDATE `zjb_appid_openid_index` SET ");
        updateSql.append(" WHERE id = ").append(userInfo.getId());
        Object[] array = new Object[argList.size()];
        for (int i = 0; i < argList.size(); i++) {
            array[i] = argList.get(i);
        }

        int[] arrayType = new int[argTypeList.size()];
        for (int i = 0; i < argTypeList.size(); i++) {
            arrayType[i] = argTypeList.get(i);
        }

        jdbcTemplate.update(updateSql.toString(), array, arrayType);
    }

    @Override
    public List<ComponentGzhEvent> selectByAppIdGroupByDate(String appId) {

        ComponentAuthorizationInfo authorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByAppId(appId);

        if (null == authorizationInfo || authorizationInfo.getComponentAuthorizationType().equals(MANUAL_ADD.getValue())) {
            /*人工添加公众号仍保留原有的统计方式*/
            return Collections.emptyList();
        }

        String sql = "SELECT `appid`, `create_date`, `event`, COUNT(*) AS `count` FROM `zjb_appid_openid_index` WHERE `appid` = ? AND `openid` IS NOT NULL GROUP BY `appid`, `create_date`,`event` ORDER BY `create_date` DESC";

        Object[] args = {appId};
        int[] argTypes = {Types.VARCHAR};

        List<ComponentGzhEvent> list = jdbcTemplate.query(sql, args, argTypes, new RowMapper<ComponentGzhEvent>() {
            @Override
            public ComponentGzhEvent mapRow(ResultSet rs, int rowNum) throws SQLException {
                ComponentGzhEvent record = new ComponentGzhEvent();
                record.setAppid(rs.getString("appid"));
                record.setDate(ISO_8601_EXTENDED_DATE_FORMAT.format(rs.getDate("create_date")));
                record.setCount(rs.getInt("count"));
                record.setEvent(rs.getString("event"));
                return record;
            }
        });

        if (null == list || list.isEmpty()) {
            return Collections.emptyList();
        }

        /*关注记录*/
        List<ComponentGzhEvent> listSubscribe = list.stream()
                .filter(e -> e.getEvent().equals(AD_WE_CHAT_ACCOUNT_SUBSCRIBE.getValue()))
                .collect(Collectors.toList());
        /*取关记录*/
        List<ComponentGzhEvent> listUnSubscribe = list.stream()
                .filter(e -> e.getEvent().equals(AD_WE_CHAT_ACCOUNT_UN_SUBSCRIBE.getValue()))
                .collect(Collectors.toList());

        for (ComponentGzhEvent gzhEvent : listSubscribe) {
            Optional<ComponentGzhEvent> optional = listUnSubscribe.stream()
                    .filter(e -> e.getDate().equals(gzhEvent.getDate()))
                    .findFirst();
            gzhEvent.setSubscribeCount(optional.isPresent() ? optional.get().getCount() + gzhEvent.getCount() : gzhEvent.getCount());
            gzhEvent.setUnSubscribeCount(optional.isPresent() ? optional.get().getCount() : 0);
        }

        return listSubscribe;
    }

}
