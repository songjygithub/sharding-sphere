package com.zjb.project.dsp.advertisingPlanFans.domain;

import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;


/**
 * 粉丝通广告投放计划表 zjb_advertising_plan_fans
 *
 * @author shenlong
 * @date 2019-11-22
 */
public class AdvertisingPlanFans extends AdvertisingPlan {
	private static final long serialVersionUID = 7627311290847069620L;
}
