package com.zjb.project.dsp.gzhGroup.controller;

import java.util.List;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import com.zjb.project.dsp.advertisingUnit.service.IAdvertisingUnitService;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.gzhGroup.domain.GzhGroup;
import com.zjb.project.dsp.gzhGroup.service.IGzhGroupService;
import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;
import com.zjb.project.dsp.scanTask.domain.ScanTask;
import com.zjb.project.dsp.scanTask.service.IScanTaskService;

/**
 * 公众号组 信息操作处理
 *
 * @author zjb
 * @date 2019-07-12
 */
@Controller
@RequestMapping("/zjb/gzhGroup")
public class GzhGroupController extends BaseController {
    private String prefix = "zjb/gzhGroup";

    @Autowired
    private IGzhGroupService gzhGroupService;
    @Autowired
    private IScanTaskService scanTaskService;
    @Autowired
    private IAdvertisingUnitService advertisingUnitService;

    @RequiresPermissions("zjb:gzhGroup:view")
    @GetMapping()
    public String gzhGroup() {
        return prefix + "/gzhGroup";
    }

    /**
     * 查询公众号组列表
     */
    @RequiresPermissions("zjb:gzhGroup:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(GzhGroup gzhGroup) {
        startPage();
        List<GzhGroup> list = gzhGroupService.selectGzhGroupList(gzhGroup);
        return getDataTable(list);
    }

    /**
     * 查询公众号组列表
     */
    @PostMapping("/listByGroup")
    @ResponseBody
    public TableDataInfo listByGroup(Integer gzhGroupId) {
        startPage();
        List<GzhxcxInfo> list = gzhGroupService.selectGzhByGroupId(gzhGroupId);
        return getDataTable(list);
    }

    /**
     * 新增公众号组
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存公众号组
     */
    @RequiresPermissions("zjb:gzhGroup:add")
    @Log(title = "公众号组", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(GzhGroup gzhGroup) {
        return toAjax(gzhGroupService.insertGzhGroup(gzhGroup));
    }

    /**
     * 修改公众号组
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") Integer id, ModelMap mmap) {
        GzhGroup gzhGroup = gzhGroupService.selectGzhGroupById(id);
        mmap.put("gzhGroup", gzhGroup);
        return prefix + "/edit";
    }

    /**
     * 查看并且修改公众号组
     */
    @GetMapping("/configure/{id}")
    public String configure(@PathVariable("id") Integer id, ModelMap mmap) {
        mmap.put("gzhGroupId", id);
        return prefix + "/configure";
    }

    /**
     * 修改保存公众号组
     */
    @RequiresPermissions("zjb:gzhGroup:edit")
    @Log(title = "公众号组", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(GzhGroup gzhGroup) {

        int r = gzhGroupService.updateGzhGroup(gzhGroup);

        restartAdvertisingPlan(gzhGroup);

        return toAjax(r);
    }

    /**
     * 涉及的投放广告计划重启
     *
     * @param gzhGroup
     */
    private void restartAdvertisingPlan(GzhGroup gzhGroup) {
        List<ScanTask> scanTasks = scanTaskService.selectByGzhGroupId(gzhGroup.getId());


        if (null != scanTasks) {

            for (ScanTask task : scanTasks) {
                List<AdvertisingUnit> unitList = advertisingUnitService.selectAdvertisingUnitByTaskId(task.getId());
                if (null != unitList && !unitList.isEmpty()) {
                    for (AdvertisingUnit advertisingUnit : unitList) {
                        restartAdvertisingPlan(advertisingUnit);
                    }
                }

                List<AdvertisingUnitWx> unitWxList = advertisingUnitWxService.selectAdvertisingUnitByTaskId(task.getId());

                if (null != unitWxList && !unitWxList.isEmpty()) {
                    for (AdvertisingUnitWx advertisingUnitWx : unitWxList) {
                        restartAdvertisingPlanWx(advertisingUnitWx);
                    }

                }
            }


        }
    }

    /**
     * 删除公众号组
     */
    @RequiresPermissions("zjb:gzhGroup:remove")
    @Log(title = "公众号组", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(gzhGroupService.deleteGzhGroupByIds(ids));
    }

    /**
     * 根据ID获取公众号配置
     */
    @GetMapping("/selectById/{id}")
    @ResponseBody
    public GzhGroup selectById(@PathVariable("id") Integer id) {
        return gzhGroupService.selectGzhGroupById(id);
    }
}
