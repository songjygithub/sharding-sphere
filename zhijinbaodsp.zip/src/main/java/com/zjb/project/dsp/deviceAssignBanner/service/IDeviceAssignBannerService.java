package com.zjb.project.dsp.deviceAssignBanner.service;

import com.zjb.project.dsp.deviceAssignBanner.domain.DeviceAssignBanner;
import java.util.List;

/**
 * 定向投放展示广告 服务层
 *
 * @author jiangbingjie
 * @date 2020-02-12
 */
public interface IDeviceAssignBannerService
{
	/**
	 * 查询定向投放展示广告信息
	 *
	 * @param id 定向投放展示广告ID
	 * @return 定向投放展示广告信息
	 */
	public DeviceAssignBanner selectDeviceAssignBannerById(Integer id);

	/**
	 * 查询定向投放展示广告列表
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 定向投放展示广告集合
	 */
	public List<DeviceAssignBanner> selectDeviceAssignBannerList(DeviceAssignBanner deviceAssignBanner);

	/**
	 * 新增定向投放展示广告
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 结果
	 */
	public int insertDeviceAssignBanner(DeviceAssignBanner deviceAssignBanner);

	/**
	 * 修改定向投放展示广告
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 结果
	 */
	public int updateDeviceAssignBanner(DeviceAssignBanner deviceAssignBanner);

	/**
	 * 删除定向投放展示广告信息
	 *
	 * @param ids 需要删除的数据ID
	 * @return 结果
	 */
	public int deleteDeviceAssignBannerByIds(String ids);

}
