package com.zjb.project.dsp.advertisingUnitFans.mapper;

import java.util.List;

import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import org.apache.ibatis.annotations.Param;

/**
 * 粉丝通广告池 数据层
 *
 * @author shenlong
 * @date 2019-11-22
 */
public interface AdvertisingUnitFansMapper {
    /**
     * 查询粉丝通广告池信息
     *
     * @param id 粉丝通广告池ID
     * @return 粉丝通广告池信息
     */
    AdvertisingUnitFans selectAdvertisingUnitFansById(Integer id);

    /**
     * 查询粉丝通广告池列表
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 粉丝通广告池集合
     */
    List<AdvertisingUnitFans> selectAdvertisingUnitFansList(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 新增粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    int insertAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 修改粉丝通广告池
     *
     * @param advertisingUnitFans 粉丝通广告池信息
     * @return 结果
     */
    int updateAdvertisingUnitFans(AdvertisingUnitFans advertisingUnitFans);

    /**
     * 删除粉丝通广告池
     *
     * @param id 粉丝通广告池ID
     * @return 结果
     */
    int deleteAdvertisingUnitFansById(Integer id);

    /**
     * 批量删除粉丝通广告池
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingUnitFansByIds(String[] ids);

    /**
     * 通过广告方案ID查询广告单元
     *
     * @param combinationId
     * @return
     */
    List<AdvertisingUnitFans> selectAdvertisingUnitListByCombinationId(Integer combinationId);

    /**
     * @param taskId 表【zjb_scan_task】主键ID
     * @return
     */
    List<AdvertisingUnitFans> selectAdvertisingUnitByTaskId(String taskId);

    /**
     * 通过广告单元ID查询所有记录
     *
     * @param unitId
     * @return
     */
    List<AdvertisingCombinationUnitFans> selectByUnitId(Integer unitId);

    /**
     * 根据广告池业务主键ID查询粉丝通广告池信息
     *
     * @param adId 粉丝通广告池业务主键ID
     * @return
     */
    public AdvertisingUnitFans selectAdvertisingUnitFansByAdId(String adId);

    /**
     * 根据微信个号编号查询广告单元
     *
     * @param weChatPersonalId 微信个号编号
     * @return 粉丝通广告池信息
     */
    List<AdvertisingUnitFans> findByWeChatPersonalId(String weChatPersonalId);

    /**
     * 根据QQ个号编号查询广告单元
     *
     * @param qqPersonalId
     * @return 粉丝通广告池信息
     */
    List<AdvertisingUnitFans> findByQQPersonalId(String qqPersonalId);

    /**
     * 获取公众号关注后推送消息
     * @param appId appid
     * @return gzh_subscribe_msg
     * */
    String getSubMsg(@Param("appId")String appId);
}