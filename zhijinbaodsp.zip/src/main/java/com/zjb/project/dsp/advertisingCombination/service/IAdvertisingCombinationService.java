package com.zjb.project.dsp.advertisingCombination.service;

import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombination;
import com.zjb.project.dsp.advertisingCombination.domain.AdvertisingCombinationUnit;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;

import java.util.List;

/**
 * 广告方案 服务层
 *
 * @author zjb
 * @date 2019-07-13
 */
public interface IAdvertisingCombinationService {

    /**
     * 修改操作
     */
    int OPERATION_TYPE_UPDATE = 1;

    /**
     * 查询广告方案信息
     *
     * @param id 广告方案ID
     * @return 广告方案信息
     */
    AdvertisingCombination selectAdvertisingCombinationById(Integer id);

    /**
     * 查询广告方案列表
     *
     * @param advertisingCombination 广告方案信息
     * @return 广告方案集合
     */
    List<AdvertisingCombination> selectAdvertisingCombinationList(AdvertisingCombination advertisingCombination);

    /**
     * 查询广告方案详情列表
     *
     * @param advertisingCombinationUnit 广告方案详情信息
     * @return 广告方案详情
     */
    List<AdvertisingCombinationUnit> selectAdvertisingCombinationUnitList(AdvertisingCombinationUnit advertisingCombinationUnit);

    /**
     * 新增广告方案
     *
     * @param advertisingCombination 广告方案信息
     * @return 结果
     */
    int insertAdvertisingCombination(AdvertisingCombination advertisingCombination);

    /**
     * 新增广告方案详情
     *
     * @param advertisingCombinationUnit
     * @return 结果
     */
    int insertAdvertisingCombinationUnit(AdvertisingCombinationUnit advertisingCombinationUnit);

    /**
     * 修改广告方案
     *
     * @param advertisingCombination 广告方案信息
     * @return 结果
     */
    int updateAdvertisingCombination(AdvertisingCombination advertisingCombination);

    /**
     * 删除广告方案信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    int deleteAdvertisingCombinationByIds(String ids);

    /**
     * 删除广告方案详情
     *
     * @param ids 需删除的数据id
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitByIds(String ids);

    /**
     * 删除广告方案详情
     *
     * @param combinationIds 广告方案id集
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitByCombinationId(String combinationIds);

    /**
     * 删除广告方案详情
     *
     * @param unitIds 广告池id集
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitByUnitId(String unitIds);

    /**
     * 更换广告方案详情
     *
     * @param advertisingCombinationUnit 广告方案
     * @return 结果
     */
    int modifyDetails(AdvertisingCombinationUnit advertisingCombinationUnit);

    /**
     * 扫码取纸按钮是否配置公众号
     *
     * @param id 方案ID
     * @return
     */
    List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer id);

    /**
     * 通过广告单元ID查询所有记录
     *
     * @param unitId
     * @return
     */
    List<AdvertisingCombinationUnit> selectByUnitId(Integer unitId);

}
