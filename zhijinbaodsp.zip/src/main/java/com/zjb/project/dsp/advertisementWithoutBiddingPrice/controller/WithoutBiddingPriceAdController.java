package com.zjb.project.dsp.advertisementWithoutBiddingPrice.controller;

import com.alibaba.fastjson.JSON;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.dsp.advertisementWithoutBiddingPrice.domain.WithoutBiddingPriceAdParam;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.service.IAdvertisingUnitFansService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 非竞价广告
 * @author jiangbingjie
 * @date 2020/4/2 10:56 上午
 */
@Controller
@RequestMapping("/withoutBiddingPriceAd")
public class WithoutBiddingPriceAdController {
    private static final Logger logger = LoggerFactory.getLogger(WithoutBiddingPriceAdController.class);
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;
    @Autowired
    private IAdvertisingUnitFansService advertisingUnitFansService;

    /**
     * 记录点击非竞价广告次数及人数
     * @param openid
     * @param adId
     * @return
     */
    @GetMapping("/withoutBiddingPriceAdRecord/{openid}/{adId}")
    @ResponseBody
    public Map withoutBiddingPriceAdRecord(@PathVariable("openid") String openid, @PathVariable("adId") String adId){
        HashMap<String,Object> map = new HashMap<>();
        logger.info("非竞价广告临时记录:openid=>{},adId=>{}", openid, adId);
        if(StringUtils.isEmpty(openid) || StringUtils.isEmpty(adId)){
            logger.warn("非竞价广告临时记录用户或者广告参数缺失:openid=>{},adId=>{}", openid, adId);
        }
        //根据adId获取广告单元池信息
        AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansService.selectAdvertisingUnitFansByAdId(adId);
        if(null == advertisingUnitFans || null == advertisingUnitFans.getId()){
            logger.warn("非竞价广告临时记录广告信息不存在:openid=>{},adId=>{}", openid, adId);
            map.put("code", 500);
            map.put("msg", "参数错误!");
            return map;
        }
        if(StringUtils.isNotEmpty(openid)){
            AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openid);
            if(authorizationUserInfo == null){
                logger.warn("非竞价广告临时记录用户信息不存在:openid=>{},adId=>{}", openid, adId);
                map.put("code", 500);
                map.put("msg", "参数错误!");
                return map;
            }
            //临时记录点击次数
            Map<String,Object> mapQueue = new HashMap<>(4);
            mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_CLICK_EVENT,advertisingUnitFans.getId()+"@"+openid);
            // 公众号展示数据发送给dsp
            JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));
            logger.info("非竞价广告临时记录成功:openid=>{},adId=>{}", openid, adId);
            map.put("code", 0);
            map.put("msg", "SUCCESS");
            return map;
        }
        map.put("code", 500);
        map.put("msg", "参数错误!");
        return map;
    }

    /**
     * 记录点击非竞价广告次数及人数
     * @param
     * @return
     */
    @PostMapping("/withoutBiddingPriceAdClickEvent")
    @ResponseBody
    public Map withoutBiddingPriceAdClickEvent(@RequestBody(required = false) WithoutBiddingPriceAdParam withoutBiddingPriceAdParam){
        HashMap<String,Object> map = new HashMap<>();
        String openid = withoutBiddingPriceAdParam.getOpenid();
        String adId = withoutBiddingPriceAdParam.getAdId();
        String randomNum = withoutBiddingPriceAdParam.getRandomNum();

        logger.info("非竞价广告临时记录:openid=>{},adId=>{},randomNum=>{}", openid,adId,randomNum);
        if(StringUtils.isEmpty(openid) || StringUtils.isEmpty(adId)){
            logger.warn("非竞价广告临时记录用户或者广告参数缺失:openid=>{},adId=>{}", openid, adId);
        }
        //根据adId获取广告单元池信息
        AdvertisingUnitFans advertisingUnitFans = advertisingUnitFansService.selectAdvertisingUnitFansByAdId(adId);
        if(null == advertisingUnitFans || null == advertisingUnitFans.getId()){
            logger.warn("非竞价广告临时记录广告信息不存在:openid=>{},adId=>{}", openid, adId);
            map.put("code", 500);
            map.put("msg", "参数错误!");
            return map;
        }
        if(StringUtils.isNotEmpty(openid)){
            AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(openid);
            if(authorizationUserInfo == null){
                logger.warn("非竞价广告临时记录用户信息不存在:openid=>{},adId=>{}", openid, adId);
                map.put("code", 500);
                map.put("msg", "参数错误!");
                return map;
            }
            //临时记录点击次数
            Map<String,Object> mapQueue = new HashMap<>(4);
            mapQueue.put(RedisSubscribe.KEY_WITHOUT_BIDDING_PRICE_AD_CLICK_EVENT,advertisingUnitFans.getId()+"@"+openid);
            // 公众号展示数据发送给dsp
            JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_DSP_COMMON, JSON.toJSONString(mapQueue));
            logger.info("非竞价广告临时记录成功:openid=>{},adId=>{}", openid, adId);
            map.put("code", 0);
            map.put("msg", "SUCCESS");
            return map;
        }
        map.put("code", 500);
        map.put("msg", "参数错误!");
        return map;
    }


}
