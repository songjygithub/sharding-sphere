package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author songjy
 * @Date 2019/11/29
 **/
public class StatisticsDeviceAdPlan implements Serializable {
    private static final long serialVersionUID = 3921842731707839293L;


    /**
     * 胜出广告计划ID
     */
    @Excel(name = "胜出广告计划ID")
    private String adWinPlanId;

    /**
     * 胜出广告计划名称
     */
    @Excel(name = "胜出广告计划名称")
    private String adWinPlanName;

    @Excel(name = "设备SN")
    private String deviceSn;

    private String deviceName;

    /**
     * 设备二维码
     */
    private String qrcode;

    /**
     * 设备所属代理商名称
     */
    @Excel(name = "设备所属代理商名称")
    private String agencyName;

    /**
     * 设备安装面向人群性别，参阅字典【zjb_face_sex】
     */
    private Integer faceSex;

    @Excel(name = "设备面向人群")
    private String sex;

    /**
     * 安装地址编码：六位数字代码
     */
    private String installAddressCode;

    /**
     * 安装地址
     */
    @Excel(name = "设备安装地址")
    private String installAddressName;

    /**
     * 设备安装场景名稱
     */
    @Excel(name = "设备安装场景类型")
    private String deviceSceneTypeName;

    /**
     * 设备安装场景，参阅字典【zjb_device_scene】
     */
    private String deviceScene;

    /**
     * 设备安装场景名稱
     */
    @Excel(name = "设备安装场景")
    private String deviceSceneName;

    /**
     * 广告计划胜出次数
     */
    @Excel(name = "广告计划出纸次数")
    private Float countAdWinPlanId;

    @Excel(name = "支付宝出纸次数")
    private Integer countOpenIdAliPay;

    @Excel(name = "微信出纸次数")
    private Integer countOpenIdWeChat;

    @Excel(name = "其他用户出纸次数")
    private Integer countOpenIdOther;

    /**
     * 设备所属代理商ID
     */
    private Integer agencyId;

    /**
     * 广告收益（元）
     */
    @Excel(name = "广告收益（元）")
    private BigDecimal income;

    /**
     * 代理商分成（元）
     */
    @Excel(name = "代理商分成（元）")
    private BigDecimal benefit;

    /**
     * 利润（元）
     */
    @Excel(name = "利润（元）")
    private BigDecimal profit;

    public String getAdWinPlanId() {
        return adWinPlanId;
    }

    public void setAdWinPlanId(String adWinPlanId) {
        this.adWinPlanId = adWinPlanId;
    }

    public String getAdWinPlanName() {
        return adWinPlanName;
    }

    public void setAdWinPlanName(String adWinPlanName) {
        this.adWinPlanName = adWinPlanName;
    }

    public Float getCountAdWinPlanId() {
        return countAdWinPlanId;
    }

    public void setCountAdWinPlanId(Float countAdWinPlanId) {
        this.countAdWinPlanId = countAdWinPlanId;
    }

    public String getDeviceSn() {
        return deviceSn;
    }

    public void setDeviceSn(String deviceSn) {
        this.deviceSn = deviceSn;
    }

    public Integer getAgencyId() {
        return agencyId;
    }

    public void setAgencyId(Integer agencyId) {
        this.agencyId = agencyId;
    }

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public Integer getFaceSex() {
        return faceSex;
    }

    public void setFaceSex(Integer faceSex) {
        this.faceSex = faceSex;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getInstallAddressCode() {
        return installAddressCode;
    }

    public void setInstallAddressCode(String installAddressCode) {
        this.installAddressCode = installAddressCode;
    }

    public String getInstallAddressName() {
        return installAddressName;
    }

    public void setInstallAddressName(String installAddressName) {
        this.installAddressName = installAddressName;
    }

    public String getDeviceSceneTypeName() {
        return deviceSceneTypeName;
    }

    public void setDeviceSceneTypeName(String deviceSceneTypeName) {
        this.deviceSceneTypeName = deviceSceneTypeName;
    }

    public String getDeviceScene() {
        return deviceScene;
    }

    public void setDeviceScene(String deviceScene) {
        this.deviceScene = deviceScene;
    }

    public String getDeviceSceneName() {
        return deviceSceneName;
    }

    public void setDeviceSceneName(String deviceSceneName) {
        this.deviceSceneName = deviceSceneName;
    }

    public String getQrcode() {
        return qrcode;
    }

    public void setQrcode(String qrcode) {
        this.qrcode = qrcode;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Integer getCountOpenIdAliPay() {
        return countOpenIdAliPay;
    }

    public void setCountOpenIdAliPay(Integer countOpenIdAliPay) {
        this.countOpenIdAliPay = countOpenIdAliPay;
    }

    public Integer getCountOpenIdWeChat() {
        return countOpenIdWeChat;
    }

    public void setCountOpenIdWeChat(Integer countOpenIdWeChat) {
        this.countOpenIdWeChat = countOpenIdWeChat;
    }

    public Integer getCountOpenIdOther() {
        return countOpenIdOther;
    }

    public void setCountOpenIdOther(Integer countOpenIdOther) {
        this.countOpenIdOther = countOpenIdOther;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getBenefit() {
        return benefit;
    }

    public void setBenefit(BigDecimal benefit) {
        this.benefit = benefit;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }
}
