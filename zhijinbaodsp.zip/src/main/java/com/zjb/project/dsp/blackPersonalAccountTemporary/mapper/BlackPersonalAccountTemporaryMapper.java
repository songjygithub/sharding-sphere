package com.zjb.project.dsp.blackPersonalAccountTemporary.mapper;

import com.zjb.project.dsp.blackPersonalAccountTemporary.domain.BlackPersonalAccountTemporary;
import java.util.List;	

/**
 * 个人号黑名单临时 数据层
 * 
 * @author jiangbingjie
 * @date 2020-05-08
 */
public interface BlackPersonalAccountTemporaryMapper 
{
	/**
     * 查询个人号黑名单临时信息
     * 
     * @param id 个人号黑名单临时ID
     * @return 个人号黑名单临时信息
     */
	public BlackPersonalAccountTemporary selectBlackPersonalAccountTemporaryById(Integer id);
	
	/**
     * 查询个人号黑名单临时列表
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 个人号黑名单临时集合
     */
	public List<BlackPersonalAccountTemporary> selectBlackPersonalAccountTemporaryList(BlackPersonalAccountTemporary blackPersonalAccountTemporary);
	
	/**
     * 新增个人号黑名单临时
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 结果
     */
	public int insertBlackPersonalAccountTemporary(BlackPersonalAccountTemporary blackPersonalAccountTemporary);
	
	/**
     * 修改个人号黑名单临时
     * 
     * @param blackPersonalAccountTemporary 个人号黑名单临时信息
     * @return 结果
     */
	public int updateBlackPersonalAccountTemporary(BlackPersonalAccountTemporary blackPersonalAccountTemporary);
	
	/**
     * 删除个人号黑名单临时
     * 
     * @param id 个人号黑名单临时ID
     * @return 结果
     */
	public int deleteBlackPersonalAccountTemporaryById(Integer id);
	
	/**
     * 批量删除个人号黑名单临时
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteBlackPersonalAccountTemporaryByIds(String[] ids);

	/**
	 * 清除个人号黑名单临时数据
	 * @return
	 */
	public int removeBlackPersonalAccountTemporary();
	
}