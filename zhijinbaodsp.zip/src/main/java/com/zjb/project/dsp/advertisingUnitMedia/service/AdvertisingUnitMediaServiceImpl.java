package com.zjb.project.dsp.advertisingUnitMedia.service;

import java.util.List;

import com.zjb.common.enums.ZjbDictionaryEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.advertisingUnitMedia.mapper.AdvertisingUnitMediaMapper;
import com.zjb.project.dsp.advertisingUnitMedia.domain.AdvertisingUnitMedia;
import com.zjb.project.dsp.advertisingUnitMedia.service.IAdvertisingUnitMediaService;
import com.zjb.common.support.Convert;

/**
 * 媒体矩阵广告池 服务层实现
 * 
 * @author 17854
 * @date 2020-03-19
 */
@Service
public class AdvertisingUnitMediaServiceImpl implements IAdvertisingUnitMediaService 
{
	@Autowired
	private AdvertisingUnitMediaMapper advertisingUnitMediaMapper;

	/**
     * 查询媒体矩阵广告池信息
     * 
     * @param id 媒体矩阵广告池ID
     * @return 媒体矩阵广告池信息
     */
    @Override
	public AdvertisingUnitMedia selectAdvertisingUnitMediaById(Integer id)
	{
	    return advertisingUnitMediaMapper.selectAdvertisingUnitMediaById(id);
	}
	
	/**
     * 查询媒体矩阵广告池列表
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 媒体矩阵广告池集合
     */
	@Override
	public List<AdvertisingUnitMedia> selectAdvertisingUnitMediaList(AdvertisingUnitMedia advertisingUnitMedia)
	{
	    return advertisingUnitMediaMapper.selectAdvertisingUnitMediaList(advertisingUnitMedia);
	}
	
    /**
     * 新增媒体矩阵广告池
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 结果
     */
	@Override
	public int insertAdvertisingUnitMedia(AdvertisingUnitMedia advertisingUnitMedia)
	{
		int r = advertisingUnitMediaMapper.insertAdvertisingUnitMedia(advertisingUnitMedia);
		if (r > 0) {
			advertisingUnitMedia.setAdvertisingId(ZjbDictionaryEnum.AD_FAN_MEDIA_PREFIX.getValue().toString() + advertisingUnitMedia.getId());
			r += advertisingUnitMediaMapper.updateAdvertisingUnitMedia(advertisingUnitMedia);
		}
		return r;
	}
	
	/**
     * 修改媒体矩阵广告池
     * 
     * @param advertisingUnitMedia 媒体矩阵广告池信息
     * @return 结果
     */
	@Override
	public int updateAdvertisingUnitMedia(AdvertisingUnitMedia advertisingUnitMedia)
	{
	    return advertisingUnitMediaMapper.updateAdvertisingUnitMedia(advertisingUnitMedia);
	}

	/**
     * 删除媒体矩阵广告池对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteAdvertisingUnitMediaByIds(String ids)
	{
		return advertisingUnitMediaMapper.deleteAdvertisingUnitMediaByIds(Convert.toStrArray(ids));
	}
	
}
