package com.zjb.project.dsp.blackPersonalAccount.controller;

import java.util.List;

import com.zjb.project.dsp.manualAppidOpenidIndex.domain.ManualAppidOpenidIndex;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.blackPersonalAccount.domain.BlackPersonalAccount;
import com.zjb.project.dsp.blackPersonalAccount.service.IBlackPersonalAccountService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 个人号黑名单 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
@Controller
@RequestMapping("/dsp/blackPersonalAccount")
public class BlackPersonalAccountController extends BaseController
{
    private String prefix = "dsp/blackPersonalAccount";
	
	@Autowired
	private IBlackPersonalAccountService blackPersonalAccountService;
	
	@RequiresPermissions("dsp:blackPersonalAccount:view")
	@GetMapping()
	public String blackPersonalAccount()
	{
	    return prefix + "/blackPersonalAccount";
	}
	
	/**
	 * 查询个人号黑名单列表
	 */
	@RequiresPermissions("dsp:blackPersonalAccount:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(BlackPersonalAccount blackPersonalAccount)
	{
		startPage();
		blackPersonalAccount.setDeleted(0);
        List<BlackPersonalAccount> list = blackPersonalAccountService.selectBlackPersonalAccountList(blackPersonalAccount);
		return getDataTable(list);
	}
	
	/**
	 * 新增个人号黑名单
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存个人号黑名单
	 */
	@RequiresPermissions("dsp:blackPersonalAccount:add")
	@Log(title = "个人号黑名单", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(BlackPersonalAccount blackPersonalAccount)
	{		
		return toAjax(blackPersonalAccountService.insertBlackPersonalAccount(blackPersonalAccount));
	}

	/**
	 * 修改个人号黑名单
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		BlackPersonalAccount blackPersonalAccount = blackPersonalAccountService.selectBlackPersonalAccountById(id);
		mmap.put("blackPersonalAccount", blackPersonalAccount);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存个人号黑名单
	 */
	@RequiresPermissions("dsp:blackPersonalAccount:edit")
	@Log(title = "个人号黑名单", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(BlackPersonalAccount blackPersonalAccount)
	{		
		return toAjax(blackPersonalAccountService.updateBlackPersonalAccount(blackPersonalAccount));
	}
	
	/**
	 * 删除个人号黑名单
	 */
	@RequiresPermissions("dsp:blackPersonalAccount:remove")
	@Log(title = "个人号黑名单", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(blackPersonalAccountService.deleteBlackPersonalAccountByIds(ids));
	}

	/**
	 * 获取个人号黑名单数量
	 * @param blackPersonalAccount
	 * @return
	 */
	@PostMapping( "/getBlackPersonalAccountCount")
	@ResponseBody
	public Integer getBlackPersonalAccountCount(@RequestBody BlackPersonalAccount blackPersonalAccount){
		blackPersonalAccount.setDeleted(0);
		return blackPersonalAccountService.getBlackPersonalAccountCount(blackPersonalAccount);
	}
	
}
