package com.zjb.project.dsp.blackThirdPlatformGzh.service;

import com.zjb.project.dsp.advertisingADExchange.domain.ThirdPlatformGzh;
import com.zjb.project.dsp.blackThirdPlatformGzh.domain.BlackThirdPlatformGzh;
import java.util.List;

/**
 * 第三方平台公众号黑名单 服务层
 * 
 * @author jiangbingjie
 * @date 2020-04-17
 */
public interface IBlackThirdPlatformGzhService 
{
	/**
     * 查询第三方平台公众号黑名单信息
     * 
     * @param id 第三方平台公众号黑名单ID
     * @return 第三方平台公众号黑名单信息
     */
	public BlackThirdPlatformGzh selectBlackThirdPlatformGzhById(Integer id);
	
	/**
     * 查询第三方平台公众号黑名单列表
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 第三方平台公众号黑名单集合
     */
	public List<BlackThirdPlatformGzh> selectBlackThirdPlatformGzhList(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
	/**
     * 新增第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	public int insertBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
	/**
     * 修改第三方平台公众号黑名单
     * 
     * @param blackThirdPlatformGzh 第三方平台公众号黑名单信息
     * @return 结果
     */
	public int updateBlackThirdPlatformGzh(BlackThirdPlatformGzh blackThirdPlatformGzh);
		
	/**
     * 删除第三方平台公众号黑名单信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteBlackThirdPlatformGzhByIds(String ids);

	/**
	 * 广告方案第三方公众号胜出后将appid和openid记入缓存（第三方公众号黑名单）
	 * @param thirdPlatformGzh
	 */
	public void cacheThirdPlatformGzhInfo(ThirdPlatformGzh thirdPlatformGzh);

	/**
	 * 获取第三方平台公众号黑名单数量
	 * @param blackThirdPlatformGzh
	 * @return
	 */
	public int getBlackThirdPlatformGzhCount(BlackThirdPlatformGzh blackThirdPlatformGzh);
	
}
