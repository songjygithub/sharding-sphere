package com.zjb.project.dsp.advertisingCombinationFans.service;

import com.zjb.project.dsp.advertisingCombinationFans.domain.AdvertisingCombinationFans;
import com.zjb.project.dsp.advertisingCombinationUnitFans.domain.AdvertisingCombinationUnitFans;
import com.zjb.project.dsp.advertisingUnitFans.domain.AdvertisingUnitFans;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.qqPersonal.domain.QqPersonal;
import com.zjb.project.dsp.weChatPersonal.domain.WeChatPersonal;

import java.util.List;

/**
 * 粉丝通广告方案 服务层
 *
 * @author shenlong
 * @date 2019-11-22
 */
public interface IAdvertisingCombinationFansService {
    /**
     * 查询粉丝通广告方案信息
     *
     * @param id 粉丝通广告方案ID
     * @return 粉丝通广告方案信息
     */
    public AdvertisingCombinationFans selectAdvertisingCombinationFansById(Integer id);

    /**
     * 查询粉丝通广告方案列表
     *
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 粉丝通广告方案集合
     */
    public List<AdvertisingCombinationFans> selectAdvertisingCombinationFansList(AdvertisingCombinationFans advertisingCombinationFans);

    /**
     * 查询粉丝通广告方案列表
     *
     * @param advertisingCombinationUnitFans 粉丝通广告方案信息
     * @return 粉丝通广告方案集合
     */
    public List<AdvertisingCombinationUnitFans> selectAdvertisingCombinationUnitFansList(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);

    /**
     * 新增粉丝通广告方案
     *
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
    public int insertAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans);

    /**
     * 修改粉丝通广告方案
     *
     * @param advertisingCombinationFans 粉丝通广告方案信息
     * @return 结果
     */
    public int updateAdvertisingCombinationFans(AdvertisingCombinationFans advertisingCombinationFans);

    /**
     * 删除粉丝通广告方案信息
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    public int deleteAdvertisingCombinationFansByIds(String ids);

    /**
     * 删除广告方案中的广告
     *
     * @param ids 广告池id集
     * @return 结果
     */
    int deleteAdvertisingCombinationUnitFansByUnitId(String ids);

    int modifyDetails(AdvertisingCombinationUnitFans advertisingCombinationUnitFans);

    /**
     * 扫码取纸按钮是否配置公众号
     *
     * @param id
     * @return
     */
    List<ComponentAuthorizationInfo> isWeChatOfficialAccountOnSpacePaperOutput(Integer id);

    /**
     * 扫码取纸按钮是否配置微信个人号
     *
     * @param id
     * @return
     */
    List<WeChatPersonal> isWeChatPersonalAccountOnSpacePaperOutput(Integer id);

    /**
     * 扫码取纸按钮是否配置QQ个人号
     *
     * @param id
     * @return QQ个人号信息
     */
    List<QqPersonal> isQQPersonalAccountOnSpacePaperOutput(Integer id);

    /**
     * 通过广告单元ID查询所有记录
     *
     * @param unitId
     * @return
     */
    List<AdvertisingCombinationUnitFans> selectByUnitId(Integer unitId);
}
