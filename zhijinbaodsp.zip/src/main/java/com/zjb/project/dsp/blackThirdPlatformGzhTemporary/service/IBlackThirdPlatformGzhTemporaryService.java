package com.zjb.project.dsp.blackThirdPlatformGzhTemporary.service;

import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.domain.BlackThirdPlatformGzhTemporary;
import java.util.List;

/**
 * 公众号黑名单临时 服务层
 * 
 * @author jiangbingjie
 * @date 2020-05-07
 */
public interface IBlackThirdPlatformGzhTemporaryService 
{
	/**
     * 查询公众号黑名单临时信息
     * 
     * @param id 公众号黑名单临时ID
     * @return 公众号黑名单临时信息
     */
	public BlackThirdPlatformGzhTemporary selectBlackThirdPlatformGzhTemporaryById(Integer id);
	
	/**
     * 查询公众号黑名单临时列表
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 公众号黑名单临时集合
     */
	public List<BlackThirdPlatformGzhTemporary> selectBlackThirdPlatformGzhTemporaryList(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary);
	
	/**
     * 新增公众号黑名单临时
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 结果
     */
	public int insertBlackThirdPlatformGzhTemporary(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary);
	
	/**
     * 修改公众号黑名单临时
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 结果
     */
	public int updateBlackThirdPlatformGzhTemporary(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary);
		
	/**
     * 删除公众号黑名单临时信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteBlackThirdPlatformGzhTemporaryByIds(String ids);

	/**
	 * 清除公众号黑名单临时数据
	 */
	public int removeBlackThirdPlatformGzhTemporary();
	
}
