package com.zjb.project.dsp.feign;

/**
 * @author songjy
 * @date 2020-05-20
 */
public interface IBaseFeignService {
    /**
     * 纸巾宝核心系统虚拟域名（虚拟IP）
     */
    String ZJB_ADMIN_CORE = "zjb-admin-core";
}
