package com.zjb.project.dsp.blackThirdPlatformGzhTemporary.service;

import java.util.List;

import com.vdurmont.emoji.EmojiParser;
import com.zjb.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.mapper.BlackThirdPlatformGzhTemporaryMapper;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.domain.BlackThirdPlatformGzhTemporary;
import com.zjb.project.dsp.blackThirdPlatformGzhTemporary.service.IBlackThirdPlatformGzhTemporaryService;
import com.zjb.common.support.Convert;

/**
 * 公众号黑名单临时 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-05-07
 */
@Service
public class BlackThirdPlatformGzhTemporaryServiceImpl implements IBlackThirdPlatformGzhTemporaryService 
{
	@Autowired
	private BlackThirdPlatformGzhTemporaryMapper blackThirdPlatformGzhTemporaryMapper;

	/**
     * 查询公众号黑名单临时信息
     * 
     * @param id 公众号黑名单临时ID
     * @return 公众号黑名单临时信息
     */
    @Override
	public BlackThirdPlatformGzhTemporary selectBlackThirdPlatformGzhTemporaryById(Integer id)
	{
	    return blackThirdPlatformGzhTemporaryMapper.selectBlackThirdPlatformGzhTemporaryById(id);
	}
	
	/**
     * 查询公众号黑名单临时列表
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 公众号黑名单临时集合
     */
	@Override
	public List<BlackThirdPlatformGzhTemporary> selectBlackThirdPlatformGzhTemporaryList(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{
	    return blackThirdPlatformGzhTemporaryMapper.selectBlackThirdPlatformGzhTemporaryList(blackThirdPlatformGzhTemporary);
	}
	
    /**
     * 新增公众号黑名单临时
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 结果
     */
	@Override
	public int insertBlackThirdPlatformGzhTemporary(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{
		//公众号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackThirdPlatformGzhTemporary.getThirdPlatformAppName())){
			String thirdPlatformAppName = EmojiParser.parseToAliases(blackThirdPlatformGzhTemporary.getThirdPlatformAppName());
			blackThirdPlatformGzhTemporary.setThirdPlatformAppName(thirdPlatformAppName);
		}
	    return blackThirdPlatformGzhTemporaryMapper.insertBlackThirdPlatformGzhTemporary(blackThirdPlatformGzhTemporary);
	}
	
	/**
     * 修改公众号黑名单临时
     * 
     * @param blackThirdPlatformGzhTemporary 公众号黑名单临时信息
     * @return 结果
     */
	@Override
	public int updateBlackThirdPlatformGzhTemporary(BlackThirdPlatformGzhTemporary blackThirdPlatformGzhTemporary)
	{
		//公众号名称Emoji格式化
		if(StringUtils.isNotEmpty(blackThirdPlatformGzhTemporary.getThirdPlatformAppName())){
			String thirdPlatformAppName = EmojiParser.parseToAliases(blackThirdPlatformGzhTemporary.getThirdPlatformAppName());
			blackThirdPlatformGzhTemporary.setThirdPlatformAppName(thirdPlatformAppName);
		}
	    return blackThirdPlatformGzhTemporaryMapper.updateBlackThirdPlatformGzhTemporary(blackThirdPlatformGzhTemporary);
	}

	/**
     * 删除公众号黑名单临时对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteBlackThirdPlatformGzhTemporaryByIds(String ids)
	{
		return blackThirdPlatformGzhTemporaryMapper.deleteBlackThirdPlatformGzhTemporaryByIds(Convert.toStrArray(ids));
	}

	/**
	 * 清除公众号黑名单临时数据
	 */
	@Override
	public int removeBlackThirdPlatformGzhTemporary() {
		return blackThirdPlatformGzhTemporaryMapper.removeBlackThirdPlatformGzhTemporary();
	}

}
