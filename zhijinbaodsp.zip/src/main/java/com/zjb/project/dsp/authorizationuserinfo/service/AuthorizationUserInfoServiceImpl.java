package com.zjb.project.dsp.authorizationuserinfo.service;

import com.alibaba.fastjson.JSON;
import com.mongodb.client.result.UpdateResult;
import com.zjb.common.constant.Constants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.time.LocalDate;
import java.util.Date;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_AUTHORIZATION_USER_INFO_BY_OPENID;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_14;

/**
 * @author songjy
 * @Date 2019/11/18
 **/
@Service
public class AuthorizationUserInfoServiceImpl implements IAuthorizationUserInfoService {

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 授权用户信息字段
     */
    private String[] columns = {"id", "openid", "user_nick", "sex", "province", "city", "country", "headimgurl",
            "source_type", "gmt_created", "gmt_modified", "gender", "take_paper_day_limit", "risk_score"};

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    @Qualifier(value = Constants.DB_ZJB_ID)
    private JdbcTemplate jdbcTemplate;

    @Override
    public AuthorizationUserInfoDTO selectAuthorizationUserInfoByOpenId(String openId) {
        AuthorizationUserInfoDTO userInfo = JedisPoolCacheUtils.getV(ZJB_AUTHORIZATION_USER_INFO_BY_OPENID + '_' + openId, ZJB_DB_14, AuthorizationUserInfoDTO.class);

        if (null != userInfo) {
            return userInfo;
        }

        /*从mongodb中读取用户信息*/
        try {
            Query query = new Query(Criteria.where("openId").is(openId));
            return mongoTemplate.findOne(query, AuthorizationUserInfoDTO.class);
        } catch (DataAccessResourceFailureException e) {
            logger.error("从MongoDB中获取授权用户{}信息失败：{}", openId, e.getMessage());
            return selectByOpenId(openId);
        }
    }

    /**
     * 从MySQL中查询授权用户信息
     *
     * @param openId
     * @return
     */
    private AuthorizationUserInfoDTO selectByOpenId(String openId) {

        String sql = String.format("SELECT %s FROM `zjb_authorization_user_info` WHERE `openid` = ?", String.join(",", columns));
        Object[] args = {openId};
        int[] argTypes = {Types.VARCHAR};

        try {
            return jdbcTemplate.queryForObject(sql, args, argTypes, new RowMapper<AuthorizationUserInfoDTO>() {
                @Override
                public AuthorizationUserInfoDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
                    AuthorizationUserInfoDTO record = new AuthorizationUserInfoDTO();

                    record.setOpenId(rs.getString("openid"));
                    record.setUserNick(rs.getString("user_nick"));
                    record.setSex(rs.getInt("sex"));
                    record.setProvince(rs.getString("province"));
                    record.setCity(rs.getString("city"));
                    record.setCountry(rs.getString("country"));
                    record.setHeadimgurl(rs.getString("headimgurl"));
                    record.setSourceType(rs.getString("source_type"));

                    Date gmtCreated = rs.getTimestamp("gmt_created");
                    record.setCreated(null == gmtCreated ? null : DateUtils.DATETIME_FORMAT.format(gmtCreated));

                    Date gmtModified = rs.getTimestamp("gmt_modified");
                    record.setUpdated(null == gmtModified ? null : DateUtils.DATETIME_FORMAT.format(gmtModified));

                    record.setGender(rs.getString("gender"));
                    record.setTakePaperDayLimit(rs.getLong("take_paper_day_limit"));
                    record.setRiskScore(rs.getDouble("risk_score"));

                    return record;
                }
            });
        } catch (EmptyResultDataAccessException ex) {
            return null;
        }
    }

    @Override
    public int updateAuthorizationUserInfo(AuthorizationUserInfoDTO userInfo) {

        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            return 0;
        }
        // 删除缓存
        JedisPoolCacheUtils.setRExpire(ZJB_AUTHORIZATION_USER_INFO_BY_OPENID + "_" + userInfo.getOpenId(), "", 0, ZJB_DB_14);

        logger.debug("准备更新的用户信息是：{}", userInfo.toString());

        Update update = new Update();

        if (StringUtils.isNotBlank(userInfo.getSubscribeGzh())) {
            /*关注公众号列表*/
            update.set("subscribeGzh", StringUtils.defaultIfBlank(userInfo.getSubscribeGzh(), ","));
        }
        if (StringUtils.isNotBlank(userInfo.getAutoOutPaper())) {
            update.set("autoOutPaper", userInfo.getAutoOutPaper());
        }

        if (update.getUpdateObject().isEmpty()) {
            return 0;
        }

        try {
            Query query = Query.query(Criteria.where("openId").is(userInfo.getOpenId()));
            UpdateResult result = mongoTemplate.updateFirst(query, update, AuthorizationUserInfoDTO.class);
            return (int) result.getModifiedCount();
        } catch (DataAccessResourceFailureException e) {
            logger.error("处理授权用户信息【{}】异常：{}", JSON.toJSONString(userInfo), e.getMessage());
            return 0;
        }
    }

    /**
     * 用户当天已取纸次数
     *
     * @param openId
     * @param today  用户取纸日期(yyyy-MM-dd) 可为NUll，默认当日
     * @return 用户当天已取纸次数
     */
    public static int todayTakePaperCount(String openId, LocalDate today) {
        String key = ZjbConstantsRedis.REDIS_MINI_OPENID_DAY_QRCOUNT + (null == today ? LocalDate.now() : today) + openId;
        String userDayTakePaperCountStr = JedisPoolCacheUtils.getVStr(key, ZjbConstantsRedis.ZJB_DB_1);
        return StringUtils.isNumeric(userDayTakePaperCountStr) ? Integer.parseInt(userDayTakePaperCountStr) : 0;
    }

}
