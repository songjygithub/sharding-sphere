package com.zjb.project.dsp.advertisementPlanDevice.mapper;

import com.zjb.project.dsp.advertisementPlanDevice.domain.AdvertisementPlanDevice;
import java.util.List;	

/**
 * 非竞价广告投放设备定向 数据层
 * 
 * @author Nigel Yang
 * @date 2020-05-09
 */
public interface AdvertisementPlanDeviceMapper 
{
	/**
     * 查询非竞价广告投放设备定向信息
     * 
     * @param id 非竞价广告投放设备定向ID
     * @return 非竞价广告投放设备定向信息
     */
	public AdvertisementPlanDevice selectAdvertisementPlanDeviceById(Integer id);
	
	/**
     * 查询非竞价广告投放设备定向列表
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 非竞价广告投放设备定向集合
     */
	public List<AdvertisementPlanDevice> selectAdvertisementPlanDeviceList(AdvertisementPlanDevice advertisementPlanDevice);
	
	/**
     * 新增非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	public int insertAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice);
	
	/**
     * 修改非竞价广告投放设备定向
     * 
     * @param advertisementPlanDevice 非竞价广告投放设备定向信息
     * @return 结果
     */
	public int updateAdvertisementPlanDevice(AdvertisementPlanDevice advertisementPlanDevice);
	
	/**
     * 删除非竞价广告投放设备定向
     * 
     * @param id 非竞价广告投放设备定向ID
     * @return 结果
     */
	public int deleteAdvertisementPlanDeviceById(Integer id);
	
	/**
     * 批量删除非竞价广告投放设备定向
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAdvertisementPlanDeviceByIds(String[] ids);

	/**
	 *
	 * @param ids
	 */
	public void deleteAdvertisementPlanDeviceByAdvertisementPlanIds(String[] ids);
}