package com.zjb.project.dsp.advertisingUserInfo.controller;

import cn.hutool.extra.emoji.EmojiUtil;
import com.alibaba.fastjson.JSON;
import com.zjb.common.enums.ZjbConfigEnum;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.mgservice.IMgBaseService;
import com.zjb.framework.web.page.PageDomain;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.page.TableSupport;
import com.zjb.project.common.authorizationUserInfo.domain.AuthorizationUserInfoDTO;
import com.zjb.project.dsp.advertisingTargetInfo.domain.AdvertisingTargetInfo;
import com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService;
import com.zjb.project.dsp.advertisingUserInfo.domain.AdvertisingUserInfo;
import com.zjb.project.dsp.advertisingUserInfo.domain.PersonalAchievement;
import com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService;
import com.zjb.project.dsp.authorizationuserinfo.service.IAuthorizationUserInfoService;
import com.zjb.project.dsp.leafTask.domain.LeafTask;
import com.zjb.project.dsp.leafTask.service.ILeafTaskService;
import com.zjb.project.dsp.userEnvironmentalProtection.domain.EnvironmentalProtection;
import com.zjb.project.dsp.userEnvironmentalProtection.service.IUserEnvironmentalProtectionService;
import com.zjb.project.system.config.service.IConfigService;
import org.apache.commons.io.IOUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static com.zjb.common.constant.ZjbConstantsRedis.USER_CONSUMED_LEAF_SERIAL_NUM;
import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.LEAF_CONSUME_WAY_PL;
import static com.zjb.common.enums.ZjbDictionaryEnum.TAKE_PAPER_LEAF;
import static com.zjb.common.enums.ZjbDictionaryTypeEnum.LEAF_SPEED_PICKING_CONSUME_WAY;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_5_MINUTE;
import static com.zjb.project.dsp.advertisingTargetInfo.service.IAdvertisingTargetInfoService.PRIMARY_KEY_ID;
import static com.zjb.project.dsp.advertisingUserInfo.service.IAdvertisingUserInfoService.PRIMARY_KEY_OPEN_ID;

/**
 * @author songjy
 * @date 2019/08/08
 */
@Controller
@RequestMapping(value = {"/zjb/advertisingUserInfo", "/dsp/advertisingUserInfo"})
public class AdvertisingUserInfoController extends BaseController {
    private String prefix = "dsp/advertisingUserInfo";

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private IAdvertisingUserInfoService advertisingUserInfoService;
    @Autowired
    private IUserEnvironmentalProtectionService userEnvironmentalProtectionService;
    @Autowired
    private IConfigService configService;
    @Autowired
    private ILeafTaskService leafTaskService;
    @Autowired
    private IAdvertisingTargetInfoService advertisingTargetInfoService;
    @Autowired
    private IAuthorizationUserInfoService authorizationUserInfoService;

    @RequiresPermissions("dsp:advertisingUserInfo:view")
    @GetMapping()
    public String advertisingUserInfo() {
        return prefix + "/advertisingUserInfo";
    }

    /**
     * 查询扫码用户列表
     */
    @RequiresPermissions("dsp:advertisingUserInfo:list")
    @PostMapping("/list")
    @ResponseBody
    public TableDataInfo list(AdvertisingUserInfo advertisingUserInfo) {
        PageDomain pageDomain = TableSupport.buildPageRequest();
        Integer pageNum = pageDomain.getPageNum();
        Integer pageSize = pageDomain.getPageSize();

        Pageable pageable = PageRequest.of(pageNum - 1, pageSize);
        IMgBaseService.PAGEABLE_THREAD_LOCAL.set(pageable);

        List<AdvertisingUserInfo> list = advertisingUserInfoService.selectAdvertisingUserInfoList(advertisingUserInfo);

        IMgBaseService.PAGEABLE_THREAD_LOCAL.remove();
        TableDataInfo dataInfo = IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.get();

        if (null != dataInfo) {
            IMgBaseService.TABLE_DATA_INFO_THREAD_LOCAL.remove();
            return dataInfo;
        }

        return getDataTable(list);
    }

    /**
     * 新增扫码用户
     */
    @GetMapping("/add")
    public String add() {
        return prefix + "/add";
    }

    /**
     * 新增保存扫码用户
     */
    @RequiresPermissions("dsp:advertisingUserInfo:add")
    @Log(title = "扫码用户", businessType = BusinessType.INSERT)
    @PostMapping("/add")
    @ResponseBody
    public AjaxResult addSave(AdvertisingUserInfo advertisingUserInfo) {
        advertisingUserInfoService.save(advertisingUserInfo);
        return toAjax(1);
    }

    /**
     * 修改扫码用户
     */
    @GetMapping("/edit/{id}")
    public String edit(@PathVariable("id") String id, ModelMap mmap) {
        AdvertisingUserInfo advertisingUserInfo = advertisingUserInfoService.findById(id);
        mmap.put("advertisingUserInfo", advertisingUserInfo);
        return prefix + "/edit";
    }

    /**
     * 修改保存扫码用户
     */
    @RequiresPermissions("dsp:advertisingUserInfo:edit")
    @Log(title = "扫码用户", businessType = BusinessType.UPDATE)
    @PostMapping("/edit")
    @ResponseBody
    public AjaxResult editSave(AdvertisingUserInfo advertisingUserInfo) {
        advertisingUserInfoService.updateByKey(advertisingUserInfo, PRIMARY_KEY_OPEN_ID);
        return toAjax(1);
    }

    /**
     * 删除扫码用户
     */
    @RequiresPermissions("dsp:advertisingUserInfo:remove")
    @Log(title = "扫码用户", businessType = BusinessType.DELETE)
    @PostMapping("/remove")
    @ResponseBody
    public AjaxResult remove(String ids) {
        return toAjax(advertisingUserInfoService.deleteAdvertisingUserInfoByIds(ids));
    }


    /**
     * 1、用户总取纸次数递增
     * 2、记录用户当天取纸次数
     *
     * @param advertisingUserInfo
     * @return
     */
    @PostMapping("/totalPaperNumIncrement")
    @ResponseBody
    @Deprecated
    public AjaxResult totalPaperNumIncrement(@RequestBody(required = false) AdvertisingUserInfo advertisingUserInfo) {

        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return error("用户openId为空");
        }

        advertisingUserInfoService.totalPaperNumIncrement(advertisingUserInfo);

        return success();
    }

    /**
     * 更新当天广告投放至用户记录
     *
     * @param advertisingUserInfo
     * @return
     */
    @PostMapping("/updateAdvertisingDayRecord")
    @ResponseBody
    @Deprecated
    public AjaxResult updateAdvertisingDayRecord(@RequestBody(required = false) AdvertisingUserInfo advertisingUserInfo) {

        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return error("用户openId为空");
        }

        if (StringUtils.isBlank(advertisingUserInfo.getLastPlanId())) {
            return error("广告计划ID为空");
        }

        //advertisingUserInfoService.updateAdvertisingDayRecord(advertisingUserInfo);

        return success();
    }

    /**
     * 根据openid查询出个人中心页面需要的字段
     *
     * @param advertisingUserInfo
     * @return
     */
    @PostMapping("/getPersonalCenterInfo")
    @ResponseBody
    public AjaxResult getPersonalCenterInfo(@RequestBody(required = false) AdvertisingUserInfo advertisingUserInfo) {
        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return error("用户openId为空");
        }
        // 根据openid查出用户信息
        advertisingUserInfo = advertisingUserInfoService.getUserInfo(advertisingUserInfo.getOpenId());
        if (null == advertisingUserInfo) {
            return error("用户信息不存在");
        }
        return success(advertisingUserInfo);
    }

    /**
     * 根据openid查询出个人成就详情
     *
     * @param advertisingUserInfo
     * @return
     */
    @PostMapping("/getPersonalAchievement")
    @ResponseBody
    public AjaxResult getPersonalAchievement(@RequestBody(required = false) AdvertisingUserInfo advertisingUserInfo) {
        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return error("用户openId为空");
        }
        // 根据openid查出用户成就信息
        List<PersonalAchievement> personalAchievements = advertisingUserInfoService.getPersonalAchievement(advertisingUserInfo.getOpenId());
        if (null == personalAchievements) {
            return error("该用户无成就信息");
        }
        Map<String, Object> map = new HashMap<>();
        advertisingUserInfo = advertisingUserInfoService.getUserInfo(advertisingUserInfo.getOpenId());
        map.put("personalAchievements", personalAchievements);
        map.put("advertisingUserInfo", advertisingUserInfo);
        return success(map);
    }

    /**
     * 根据openid查询出个人环保等级记录
     *
     * @param advertisingUserInfo
     * @return
     */
    @PostMapping("/getUserEnvironmentalProtection")
    @ResponseBody
    public AjaxResult getUserEnvironmentalProtection(@RequestBody(required = false) AdvertisingUserInfo advertisingUserInfo) {
        if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
            return error("用户openId为空");
        }
        AdvertisingUserInfo userInfo = advertisingUserInfoService.findByOpenId(advertisingUserInfo.getOpenId());
        if (userInfo == null) {
            return error("用户不存在");
        }
        // 根据openid查出用户环保等级信息
        List<EnvironmentalProtection> environmentalProtections = userEnvironmentalProtectionService.getUserEnvironmentalProtection(userInfo);

        AjaxResult ajaxResult = success(environmentalProtections);
        if (null != environmentalProtections && environmentalProtections.size() > 1) {
            // 将用户最新的环保等级拆出来，方便前端展示
            ajaxResult.put("environmentalProtection", environmentalProtections.get(environmentalProtections.size() - 2));
        }

        advertisingUserInfoService.completeUserInfo(userInfo);

        /*用户个人信息*/
        ajaxResult.put("userInfo", userInfo);
        ajaxResult.put("beatPercentage", userEnvironmentalProtectionService.getBeatPercentage(advertisingUserInfo));

        return ajaxResult;
    }

    /**
     * 生成绑定支付宝二维码
     *
     * @param response
     * @param openId
     * @throws IOException
     */
    @GetMapping("/generateBindQrcode")
    @ResponseBody
    public void generateBindQrcode(HttpServletResponse response, String openId) throws IOException {
        if (StringUtils.isBlank(openId)) {
            // 无用户Id直接返回
            return;
        }
        byte[] data = advertisingUserInfoService.generatorBindQrCode(openId);
        response.reset();
        response.setHeader("Content-Disposition", "inline; filename=\"" + openId + ".png\"");
        response.addHeader("Content-Length", "" + data.length);
        response.setContentType("image/png; charset=UTF-8");

        IOUtils.write(data, response.getOutputStream());
    }

    /**
     * 个人中心--查询
     *
     * @param json
     * @return
     */
    @PostMapping("/find")
    @ResponseBody
    public AjaxResult queryUserInfo(@RequestBody(required = false) String json) {

        if (StringUtils.isBlank(json)) {
            return error("openId参数缺失");
        }

        if (json.charAt(0) != '{') {
            logger.error("数据非JSON格式：{}", json);
            return error("非JSON格式数据");
        }

        long start = System.currentTimeMillis();
        try {
            AdvertisingUserInfo advertisingUserInfo = JSON.parseObject(json, AdvertisingUserInfo.class);

            if (null == advertisingUserInfo || StringUtils.isBlank(advertisingUserInfo.getOpenId())) {
                return error("openId参数缺失");
            }

            AdvertisingUserInfo userInfo = advertisingUserInfoService.findByOpenId(advertisingUserInfo.getOpenId());

            if (null == userInfo) {
                AjaxResult ajaxResult = error("用户不存在");
                ajaxResult.put("code", 404);
                return ajaxResult;
            }

            AuthorizationUserInfoDTO authorizationUserInfo = authorizationUserInfoService.selectAuthorizationUserInfoByOpenId(advertisingUserInfo.getOpenId());

            if (null == authorizationUserInfo) {
                AjaxResult ajaxResult = error("用户不存在");
                ajaxResult.put("code", 404);
                return ajaxResult;
            }
            // 是否自动出纸
            if (StringUtils.isBlank(authorizationUserInfo.getAutoOutPaper())) {
                userInfo.setAutoOutPaper("0");
            } else {
                userInfo.setAutoOutPaper(authorizationUserInfo.getAutoOutPaper());
            }
            if (StringUtils.isNotBlank(authorizationUserInfo.getUserNick())) {
                userInfo.setUserNick(authorizationUserInfo.getUserNick());
                advertisingUserInfoService.updateByKey(userInfo, PRIMARY_KEY_OPEN_ID);
            }

            userInfo.setPopup(advertisingUserInfo.getPopup());

            // 查询积分等级
            EnvironmentalProtection ep = userEnvironmentalProtectionService.getEnvironmentalProtection(userInfo);
            if (null != ep && null != ep.getLevel()) {
                userInfo.setEnvironmentalProtectionLevel(ep.getLevel());
            }

            /*补全用户信息*/
            advertisingUserInfoService.completeUserInfo(userInfo);

            //还原emoji表情
            if (StringUtils.isNotBlank(userInfo.getUserNick())) {
                userInfo.setUserNick(EmojiUtil.toUnicode(authorizationUserInfo.getUserNick()));
            }

            String payTakePaperDisplay = configService.selectConfigByKey(ZjbConfigEnum.ZJB_PAY_TAKE_PAPER_DISPLAY.getKey());
            userInfo.setPayTakePaperDisplay(StringUtils.isNumeric(payTakePaperDisplay) ? Integer.parseInt(payTakePaperDisplay) : ZjbDictionaryEnum.NO.getValue());

            AjaxResult ajaxResult = success(userInfo);

            /*返回4个小树叶任务*/
            LeafTask leafTask = new LeafTask();
            leafTask.setOpenId(userInfo.getOpenId());
            leafTask.setShelfStatus(ZjbDictionaryEnum.LEAF_TASK_SHELF_ONLINE.getValue());
            leafTask.setOperationType(ILeafTaskService.OPERATION_TYPE_6);
            leafTask.setLimit(4);
            List<LeafTask> leafTasks = leafTaskService.queryLeafTaskList(leafTask);
            ajaxResult.put("leafTasks", leafTasks);

            /*可领取小树叶数量*/
            leafTask.setLimit(Integer.MAX_VALUE);
            leafTasks = leafTaskService.queryLeafTaskList(leafTask);
            userInfo.setAmountAvailableCanLeaf(0);
            for (LeafTask task : leafTasks) {
                userInfo.setAmountAvailableCanLeaf(task.getLeafAmount() + userInfo.getAmountAvailableCanLeaf());
            }

            return ajaxResult;
        } catch (Exception e) {
            logger.error(json);
            logger.error(e.getMessage(), e);
            return error(e.getMessage());
        } finally {
            long diff = System.currentTimeMillis() - start;

            if (diff > 60 * 1000) {
                logger.error("个人中心--查询总耗时（毫秒）：{}", diff);
            } else {
                logger.info("个人中心--查询总耗时（毫秒）：{}", diff);
            }
        }
    }

    /**
     * 修改是否自动出纸
     *
     * @param authorizationUserInfo
     * @return
     */
    @PostMapping("/modifyAutoOutPaper")
    @ResponseBody
    public AjaxResult modifyUserInfo(@RequestBody(required = false) AuthorizationUserInfoDTO authorizationUserInfo) {

        if (null == authorizationUserInfo || StringUtils.isBlank(authorizationUserInfo.getOpenId())) {
            logger.error("openId参数缺失");
            return error("openId参数缺失");
        }
        if (StringUtils.isBlank(authorizationUserInfo.getAutoOutPaper())) {
            return error("auto参数缺失");
        }
        return success(authorizationUserInfoService.updateAuthorizationUserInfo(authorizationUserInfo));
    }

    /**
     * 个人中心--修改
     *
     * @param userInfo
     * @return
     */
    @PostMapping("/modify")
    @ResponseBody
    public AjaxResult modifyUserInfo(@RequestBody(required = false) AdvertisingUserInfo userInfo) {

        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            logger.error("openId参数缺失");
            return error("openId参数缺失");
        }

        AdvertisingUserInfo userInfoOld = advertisingUserInfoService.findByOpenId(userInfo.getOpenId());

        if (null == userInfoOld) {
            return error("用户不存在");
        }

        advertisingUserInfoService.updateByKey(userInfo, PRIMARY_KEY_OPEN_ID);

        return success(advertisingUserInfoService.findByOpenId(userInfo.getOpenId()));
    }

    /**
     * 用户极速取纸
     *
     * @param userInfo
     * @return
     */
    @PostMapping("/speed/picking")
    @ResponseBody
    public AjaxResult speedPicking(@RequestBody(required = false) AdvertisingUserInfo userInfo) {

        /**
         * 可用小树叶数量
         */
        int leafCount = 0;

        if (null == userInfo || StringUtils.isBlank(userInfo.getOpenId())) {
            AjaxResult ajaxResult = error("openId参数缺失");
            ajaxResult.put("leafCount", leafCount);
            return ajaxResult;
        }

        if (!StringUtils.isNumeric(userInfo.getRandomNum())) {
            AjaxResult ajaxResult = error("缺失用户扫码流水号||非数字");
            ajaxResult.put("leafCount", leafCount);
            return ajaxResult;
        }

        try {
            AdvertisingUserInfo advertisingUserInfo = advertisingUserInfoService.findByOpenId(userInfo.getOpenId());

            if (null == advertisingUserInfo) {
                AjaxResult ajaxResult = error("用户不存在");
                ajaxResult.put("leafCount", leafCount);
                return ajaxResult;
            }

            Integer amountObtainedLeaf = advertisingUserInfo.getAmountObtainedLeaf();

            if (null == amountObtainedLeaf) {
                AjaxResult ajaxResult = error("用户未获得小树叶");
                ajaxResult.put("leafCount", leafCount);
                return ajaxResult;
            }

            /*一次极速消费20个小树叶*/
            int consumedLeaf = 20;

            Integer amountConsumedLeaf = (null == advertisingUserInfo.getAmountConsumedLeaf() ? 0 : advertisingUserInfo.getAmountConsumedLeaf());
            leafCount = (amountObtainedLeaf - amountConsumedLeaf);

            if (leafCount < consumedLeaf) {
                AjaxResult ajaxResult = error("用户可用小树叶不足" + consumedLeaf);
                ajaxResult.put("leafCount", leafCount);
                return ajaxResult;
            }

            userInfo.setAmountConsumedLeaf(consumedLeaf);
            userInfo.setSpeedPick(ZjbDictionaryEnum.YES.getValue().toString());
            userInfo.setLeafSerialNum(System.currentTimeMillis());
            userInfo.setLeafCount(leafCount);


            AjaxResult ajaxResult = success();
            ajaxResult.put("leafCount", leafCount);

            AdvertisingTargetInfo targetInfo = advertisingTargetInfoService.find(Long.parseLong(userInfo.getRandomNum()));

            /*极速取纸扣减小树叶*/
            String val = configService.selectConfigByKey(LEAF_SPEED_PICKING_CONSUME_WAY.getType());
            if (LEAF_CONSUME_WAY_PL.getValue().equals(val)) {
                advertisingUserInfo.setAmountConsumedLeaf(amountConsumedLeaf + consumedLeaf);
                advertisingUserInfoService.updateByKey(advertisingUserInfo, PRIMARY_KEY_OPEN_ID);

                advertisingUserInfoService.speedPicking(userInfo);
                logger.info("扫码流水号【{}】用户【{}】小树叶取纸流水号【{}】", userInfo.getRandomNum(), userInfo.getOpenId(), userInfo.getLeafSerialNum());

                targetInfo.setLeafSerialNums(null == targetInfo.getLeafSerialNums() ? new HashSet<>(4) : targetInfo.getLeafSerialNums());
                targetInfo.setTakePaperSource(TAKE_PAPER_LEAF.getValue());
                targetInfo.getLeafSerialNums().add(userInfo.getLeafSerialNum());
                advertisingTargetInfoService.updateByKey(targetInfo, PRIMARY_KEY_ID);

                JedisPoolCacheUtils.sadd(USER_CONSUMED_LEAF_SERIAL_NUM, ZJB_DB_50, 3 * EXRP_5_MINUTE, userInfo.getLeafSerialNum().toString());
                ajaxResult.put("leafSerialNum", userInfo.getLeafSerialNum());

            }

            return ajaxResult;
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            logger.error("极速取纸异常：{}", JSON.toJSONString(userInfo, true));
            return error(e.getMessage());
        }
    }
}