package com.zjb.project.dsp.grhPushRecord.controller;

import java.util.List;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.project.dsp.grhPushRecord.domain.GrhPushRecord;
import com.zjb.project.dsp.grhPushRecord.service.IGrhPushRecordService;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.framework.web.domain.AjaxResult;

/**
 * 个人号推送记录 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
@Controller
@RequestMapping("/dsp/grhPushRecord")
public class GrhPushRecordController extends BaseController
{
    private String prefix = "dsp/grhPushRecord";
	
	@Autowired
	private IGrhPushRecordService grhPushRecordService;
	
	@RequiresPermissions("dsp:grhPushRecord:view")
	@GetMapping()
	public String grhPushRecord()
	{
	    return prefix + "/grhPushRecord";
	}
	
	/**
	 * 查询个人号推送记录列表
	 */
	@RequiresPermissions("dsp:grhPushRecord:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(GrhPushRecord grhPushRecord)
	{
		startPage();
        List<GrhPushRecord> list = grhPushRecordService.selectGrhPushRecordList(grhPushRecord);
		return getDataTable(list);
	}
	
	/**
	 * 新增个人号推送记录
	 */
	@GetMapping("/add")
	public String add()
	{
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存个人号推送记录
	 */
	@RequiresPermissions("dsp:grhPushRecord:add")
	@Log(title = "个人号推送记录", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(GrhPushRecord grhPushRecord)
	{		
		return toAjax(grhPushRecordService.insertGrhPushRecord(grhPushRecord));
	}

	/**
	 * 修改个人号推送记录
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		GrhPushRecord grhPushRecord = grhPushRecordService.selectGrhPushRecordById(id);
		mmap.put("grhPushRecord", grhPushRecord);
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存个人号推送记录
	 */
	@RequiresPermissions("dsp:grhPushRecord:edit")
	@Log(title = "个人号推送记录", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(GrhPushRecord grhPushRecord)
	{		
		return toAjax(grhPushRecordService.updateGrhPushRecord(grhPushRecord));
	}
	
	/**
	 * 删除个人号推送记录
	 */
	@RequiresPermissions("dsp:grhPushRecord:remove")
	@Log(title = "个人号推送记录", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(grhPushRecordService.deleteGrhPushRecordByIds(ids));
	}
	
}
