package com.zjb.project.dsp.advertisingPlanWx.domain;

import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;

/**
 * 广告投放计划表 zjb_advertising_plan_wx
 *
 * @author songjy
 * @date 2019-08-19
 */
public class AdvertisingPlanWx extends AdvertisingPlan {
	private static final long serialVersionUID = 2353329730239009143L;

}