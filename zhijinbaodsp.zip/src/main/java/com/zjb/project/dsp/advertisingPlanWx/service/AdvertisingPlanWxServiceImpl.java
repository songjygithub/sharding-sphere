package com.zjb.project.dsp.advertisingPlanWx.service;

import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationUnitWx;
import com.zjb.project.dsp.advertisingCombinationWx.domain.AdvertisingCombinationWx;
import com.zjb.project.dsp.advertisingCombinationWx.mapper.AdvertisingCombinationWxMapper;
import com.zjb.project.dsp.advertisingPlan.service.AdPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlan.service.AdvertisingPlanServiceImpl;
import com.zjb.project.dsp.advertisingPlanWx.domain.AdvertisingPlanWx;
import com.zjb.project.dsp.advertisingPlanWx.mapper.AdvertisingPlanWxMapper;
import com.zjb.project.dsp.advertisingUnitWx.domain.AdvertisingUnitWx;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.ComponentAuthorizationInfo;
import com.zjb.project.dsp.componentAuthorizationInfo.mapper.ComponentAuthorizationInfoMapper;
import com.zjb.project.dsp.deviceInstallScene.domain.DeviceInstallScene;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.*;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_SECOND;

/**
 * 广告投放计划 服务层实现
 *
 * @author songjy
 * @date 2019-08-19
 */
@Service
public class AdvertisingPlanWxServiceImpl extends AdPlanServiceImpl implements IAdvertisingPlanWxService {
    @Autowired
    private AdvertisingPlanWxMapper advertisingPlanWxMapper;
    @Autowired
    private AdvertisingCombinationWxMapper advertisingCombinationWxMapper;
    @Autowired
    private ComponentAuthorizationInfoMapper componentAuthorizationInfoMapper;
    @Autowired
    private IDeviceInstallSceneService deviceInstallSceneService;

    /**
     * 查询广告投放计划信息
     *
     * @param id 广告投放计划ID
     * @return 广告投放计划信息
     */
    @Override
    public AdvertisingPlanWx selectAdvertisingPlanWxById(Serializable id) {

        if (null == id) {
            return null;
        }

        if (id.getClass() == Integer.class || id.getClass() == int.class) {
            return advertisingPlanWxMapper.selectAdvertisingPlanWxById((Integer) id);
        }

        if (id.getClass() == String.class && id.toString().startsWith(AD_UNIT_TYPE_WX.getValue())) {
            return advertisingPlanWxMapper.selectAdvertisingPlanWxByPlanId((String) id);
        }

        return null;
    }

    /**
     * 查询广告投放计划列表
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 广告投放计划集合
     */
    @Override
    public List<AdvertisingPlanWx> selectAdvertisingPlanWxList(AdvertisingPlanWx advertisingPlanWx) {
        return advertisingPlanWxMapper.selectAdvertisingPlanWxList(advertisingPlanWx);
    }

    /**
     * 新增广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    @Override
    public int insertAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx) {

        advertisingPlanWx.setGmtCreated(new Date());
        advertisingPlanWx.setGmtModified(advertisingPlanWx.getGmtCreated());
        advertisingPlanWx.setModifierId(advertisingPlanWx.getCreaterId());
        if(StringUtils.isNotEmpty(advertisingPlanWx.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlanWx);
        }

        int r = advertisingPlanWxMapper.insertAdvertisingPlanWx(advertisingPlanWx);

        if (r <= 0) {
            return r;
        }

        handleComponentAuthorizationType(advertisingPlanWx);

        /*业务标识自增主键，且必须是05开头，即05 + id*/
        advertisingPlanWx.setPlanId(AD_UNIT_TYPE_WX.getValue().toString() + advertisingPlanWx.getId());
        advertisingPlanWxMapper.updateAdvertisingPlanWx(advertisingPlanWx);

        /*保存广告投放定向信息*/
        r += insertTargetingInfo(advertisingPlanWx);

        AdvertisingPlanServiceImpl.synchronizeRedis(advertisingPlanWxMapper.selectAdvertisingPlanWxById(advertisingPlanWx.getId()));

        return r;
    }

    /**
     * 修改广告投放计划
     *
     * @param advertisingPlanWx 广告投放计划信息
     * @return 结果
     */
    @Override
    public int updateAdvertisingPlanWx(AdvertisingPlanWx advertisingPlanWx) {
        AdvertisingPlanWx advertisingPlanOld = advertisingPlanWxMapper.selectAdvertisingPlanWxById(advertisingPlanWx.getId());

        if (null == advertisingPlanOld) {
            return 0;
        }
        if(StringUtils.isNotEmpty(advertisingPlanWx.getInstallSceneIds())){
            handleDeviceInstallScene(advertisingPlanWx);
        }

        setAdvertisingStatus(advertisingPlanWx, advertisingPlanOld);

        handleComponentAuthorizationType(advertisingPlanWx);

        int r = advertisingPlanWxMapper.updateAdvertisingPlanWx(advertisingPlanWx);

        if (r <= 0) {
            return r;
        }

        synchronizeAdvertisingStatus(advertisingPlanWx);

        if (null != advertisingPlanWx && null != advertisingPlanWx.getAdvertisingStatus()
                && !advertisingPlanWx.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())) {
            /*该广告投放暂停*/
            clearLocalCacheRegex(advertisingPlanOld.getPlanId());
        }

        if (null != advertisingPlanWx && null != advertisingPlanWx.getAdvertisingStatus()
                && advertisingPlanWx.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_OK.getValue())
                && !advertisingPlanOld.getAdvertisingStatus().equals(AD_PLAN_STATUS_PAUSE_MANUAL.getValue())) {
            /*该广告投放恢复*/
            reloadPattern(advertisingPlanOld.getPlanId());
        }

        /*修改广告投放定向信息*/
        r += updateTargetingInfo(advertisingPlanWx);

        AdvertisingPlanWx advertisingPlanNew = advertisingPlanWxMapper.selectAdvertisingPlanWxById(advertisingPlanWx.getId());
        AdvertisingPlanServiceImpl.synchronizeRedis(advertisingPlanNew);
        /*Redis中数据保存到数据库中*/
        advertisingPlanWxMapper.updateAdvertisingPlanWx(advertisingPlanNew);

        return r;
    }

    /**
     * 删除广告投放计划对象
     *
     * @param ids 需要删除的数据ID
     * @return 结果
     */
    @Override
    public int deleteAdvertisingPlanWxByIds(String ids) {
        return advertisingPlanWxMapper.deleteAdvertisingPlanWxByIds(Convert.toStrArray(ids));
    }

    @Override
    public int logicDeleteAdvertisingPlanWxByIds(String ids) {
        String[] array = Convert.toStrArray(ids);
        int r = advertisingPlanWxMapper.logicDeleteAdvertisingPlanWxByIds(Convert.toStrArray(ids));

        /*清空缓存对应数据*/
        for (String id : array) {
            id = id.startsWith(AD_UNIT_TYPE_WX.getValue()) ? id : (AD_UNIT_TYPE_WX.getValue() + id);
            String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + id;
            clearLocalCacheRegex(id);
            JedisPoolCacheUtils.setVExpire(key, "", EXRP_SECOND, ZJB_DB_50);
        }

        return r;
    }

    @Override
    public List<AdvertisingPlanWx> selectByAdAppId(String adAppId) {
        return advertisingPlanWxMapper.selectByAdAppId(adAppId);
    }

    @Override
    public List<AdvertisingPlanWx> selectByUnitId(Integer unitId) {
        if (null == unitId) {
            return Collections.emptyList();
        }

        List<AdvertisingCombinationUnitWx> combinationUnits = advertisingCombinationWxMapper.selectByUnitId(unitId);

        if (null == combinationUnits || combinationUnits.isEmpty()) {
            return Collections.emptyList();
        }

        List<AdvertisingPlanWx> list = new ArrayList<>();

        for (AdvertisingCombinationUnitWx combinationUnit : combinationUnits) {
            AdvertisingPlanWx advertisingPlan = new AdvertisingPlanWx();
            advertisingPlan.setCombinationId(combinationUnit.getCombinationId());
            advertisingPlan.setDeleted(ZjbDictionaryEnum.NO.getValue());
            List<AdvertisingPlanWx> planList = advertisingPlanWxMapper.selectAdvertisingPlanWxList(advertisingPlan);
            if (null != planList && !planList.isEmpty()) {
                list.addAll(planList);
            }
        }

        return list;
    }

    private void handleComponentAuthorizationType(AdvertisingPlanWx advertisingPlanWx){
        if(advertisingPlanWx == null || null == advertisingPlanWx.getCombinationId()){
            return;
        }
        AdvertisingCombinationWx advertisingCombinationWx = advertisingCombinationWxMapper.selectAdvertisingCombinationWxById(advertisingPlanWx.getCombinationId());
        if(advertisingCombinationWx == null || null == advertisingCombinationWx.getId()){
            return;
        }
        AdvertisingCombinationUnitWx unit = new AdvertisingCombinationUnitWx();
        unit.setCombinationId(advertisingCombinationWx.getId());

        List<AdvertisingCombinationUnitWx> advertisingCombinationUnitWxList = advertisingCombinationWxMapper.selectAdvertisingCombinationUnitWxList(unit);
        if(advertisingCombinationUnitWxList == null || advertisingCombinationUnitWxList.size() <=0){
            return;
        }
        advertisingCombinationUnitWxList = advertisingCombinationUnitWxList.stream().filter(e->e.getAdSpaceIdentifier().equals(AD_SPACE_PAPER_OUTPUT.getValue())).collect(Collectors.toList());

        if(advertisingCombinationUnitWxList == null || advertisingCombinationUnitWxList.size() <=0 || advertisingCombinationUnitWxList.size()>1){
            return;
        }
        AdvertisingUnitWx advertisingUnitWx = advertisingUnitWxMapper.selectAdvertisingUnitWxById(advertisingCombinationUnitWxList.get(0).getAdUnitId());
        if(advertisingUnitWx == null || null == advertisingUnitWx.getAdUseStatus() || !AD_USE_YES.getValue().equals(advertisingUnitWx.getAdUseStatus()) || StringUtils.isEmpty(advertisingUnitWx.getWeChatAccount())){
            return;
        }
        ComponentAuthorizationInfo componentAuthorizationInfo = componentAuthorizationInfoMapper.selectComponentAuthorizationInfoByComponentId(advertisingUnitWx.getWeChatAccount());
        if(componentAuthorizationInfo == null){
            return;
        }
        advertisingPlanWx.setComponentAuthorizationType(componentAuthorizationInfo.getComponentAuthorizationType());
    }

    private void handleDeviceInstallScene(AdvertisingPlanWx advertisingPlanWx){
        if(StringUtils.isEmpty(advertisingPlanWx.getInstallSceneIds())){
            return;
        }
        Set<String> set = new HashSet<>();
        String[] sceneIds = advertisingPlanWx.getInstallSceneIds().split(",");
        if(sceneIds == null || sceneIds.length<=0){
            return;
        }
        for(String sceneId : sceneIds){
            DeviceInstallScene deviceInstallScene = deviceInstallSceneService.getDeviceInstallSceneById(sceneId);
            if(deviceInstallScene != null && StringUtils.isNotEmpty(deviceInstallScene.getSceneCode())){
                set.add(deviceInstallScene.getSceneCode());
            }
        }
        if(set.size() == 0){
            return;
        }
        advertisingPlanWx.setDeviceScene(String.join(",", set));

    }
}
