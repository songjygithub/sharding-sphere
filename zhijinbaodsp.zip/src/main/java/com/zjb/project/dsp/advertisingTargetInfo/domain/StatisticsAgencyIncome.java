package com.zjb.project.dsp.advertisingTargetInfo.domain;

import com.zjb.framework.aspectj.lang.annotation.Excel;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author songjy
 * @date 2020-02-06
 */
public class StatisticsAgencyIncome implements Serializable {
    private static final long serialVersionUID = 2657253353673383807L;

    /**
     * 代理商名称
     */
    @Excel(name = "代理商名称")
    private String agencyName;

    /**
     * 广告收益（元）
     */
    @Excel(name = "广告收益（元）")
    private BigDecimal income;

    /**
     * 代理商分成（元）
     */
    @Excel(name = "代理商分成（元）")
    private BigDecimal benefit;

    /**
     * 利润（元）
     */
    @Excel(name = "利润（元）")
    private BigDecimal profit;

    public String getAgencyName() {
        return agencyName;
    }

    public void setAgencyName(String agencyName) {
        this.agencyName = agencyName;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getBenefit() {
        return benefit;
    }

    public void setBenefit(BigDecimal benefit) {
        this.benefit = benefit;
    }

    public BigDecimal getProfit() {
        return profit;
    }

    public void setProfit(BigDecimal profit) {
        this.profit = profit;
    }
}
