package com.zjb.project.dsp.advertisingPlanPay.controller;

import static com.zjb.common.constant.ZjbConstantsRedis.ZJB_DB_50;
import static com.zjb.common.enums.ZjbDictionaryEnum.NO;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.common.utils.OssUtil;
import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.poi.ExcelUtil;
import com.zjb.framework.aspectj.lang.annotation.Log;
import com.zjb.framework.aspectj.lang.enums.BusinessType;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.ZjbConfig;
import com.zjb.framework.web.controller.BaseController;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.framework.web.page.TableDataInfo;
import com.zjb.project.dsp.advertisingCombinationPay.domain.AdvertisingCombinationPay;
import com.zjb.project.dsp.advertisingCombinationPay.service.IAdvertisingCombinationPayService;
import com.zjb.project.dsp.advertisingPlan.controller.AdvertisingPlanController;
import com.zjb.project.dsp.advertisingPlan.domain.AdvertisingPlan;
import com.zjb.project.dsp.advertisingPlan.service.IAdPlanService;
import com.zjb.project.dsp.advertisingPlanDevice.domain.AdvertisingPlanDevice;
import com.zjb.project.dsp.advertisingPlanDevice.service.IAdvertisingPlanDeviceService;
import com.zjb.project.dsp.advertisingPlanPay.domain.AdvertisingPlanPay;
import com.zjb.project.dsp.advertisingPlanPay.service.IAdvertisingPlanPayService;
import com.zjb.project.dsp.agency.domain.Agency;
import com.zjb.project.dsp.agency.service.IAgencyService;
import com.zjb.project.dsp.device.service.IDeviceService;
import com.zjb.project.dsp.deviceInstallScene.service.IDeviceInstallSceneService;
import com.zjb.project.system.user.domain.User;

/**
 * 广告投放计划(支付) 信息操作处理
 * 
 * @author jiangbingjie
 * @date 2019-11-06
 */
@Controller
@RequestMapping("/dsp/advertisingPlanPay")
public class AdvertisingPlanPayController extends BaseController
{
	private Logger logger = LoggerFactory.getLogger(this.getClass());
    private String prefix = "dsp/advertisingPlanPay";
	
	@Autowired
	private IAdvertisingPlanPayService advertisingPlanPayService;
	@Autowired
	private IAdvertisingCombinationPayService advertisingCombinationPayService;
	@Autowired
	private IAgencyService agencyService;
	@Autowired
	private IDeviceService deviceService;
	@Autowired
	private ZjbConfig zjbConfig;
	@Autowired
	private IAdvertisingPlanDeviceService advertisingPlanDeviceService;
	@Autowired
	private IDeviceInstallSceneService deviceInstallSceneService;
	
	@RequiresPermissions("dsp:advertisingPlanPay:view")
	@GetMapping()
	public String advertisingPlanPay(ModelMap mmap)
	{
		AdvertisingCombinationPay advertisingCombinationPay = new AdvertisingCombinationPay();
		List<AdvertisingCombinationPay> advertisingCombinations = advertisingCombinationPayService.selectAdvertisingCombinationPayList(advertisingCombinationPay);
		mmap.put("advertisingCombinations", advertisingCombinations);
	    return prefix + "/advertisingPlanPay";
	}
	
	/**
	 * 查询广告投放计划(支付)列表
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:list")
	@PostMapping("/list")
	@ResponseBody
	public TableDataInfo list(AdvertisingPlanPay advertisingPlan)
	{
		String searchVal = advertisingPlan.getSearchValue();
		if (StringUtils.isNumeric(searchVal)) {
			advertisingPlan.setId(Integer.parseInt(searchVal));
		}

		startPage();
		List<AdvertisingPlanPay> list = advertisingPlanPayService.selectAdvertisingPlanPayList(advertisingPlan);

		DecimalFormat decimalFormat = new DecimalFormat("0%");
		for (AdvertisingPlanPay e : list) {

			String key = ZjbConstantsRedis.AD_PLAN_ID_PREFIX + '_' + e.getPlanId();
			AdvertisingPlanPay planFromRedis = JedisPoolCacheUtils.getV(key, ZJB_DB_50, AdvertisingPlanPay.class);
			if (null != planFromRedis) {
				/*今日花费*/
				e.setTodaySpend(planFromRedis.getTodaySpend());
				/*今日胜出次数*/
				e.setTodayWinNum(planFromRedis.getTodayWinNum());
				/*总胜出次数*/
				e.setTotalWinNum(planFromRedis.getTotalWinNum());
				/*总花费*/
				e.setTotalSpend(planFromRedis.getTotalSpend());
				/*竞价胜出次数*/
				e.setBidWinNum(planFromRedis.getBidWinNum());
				/*参与竞价次数*/
				e.setParticipateBidNum(planFromRedis.getParticipateBidNum());
			}

			boolean zero = (null == e.getBidWinNum() || 0 == e.getBidWinNum() || null == e.getParticipateBidNum()
					|| 0 == e.getParticipateBidNum());
			e.setWinRate(zero ? "--" : decimalFormat.format(1F * e.getBidWinNum() / e.getParticipateBidNum()));

			User user = getUser(e.getCreaterId());
			e.setCreateBy(null == user ? null : user.getUserName());

			user = getUser(e.getModifierId());
			e.setUpdateBy(null == user ? null : user.getUserName());

			AdvertisingCombinationPay advertisingCombination = advertisingCombinationPayService.selectAdvertisingCombinationPayById(e.getCombinationId());
			e.setCombinationName(null == advertisingCombination ? null : advertisingCombination.getName());

		}

		return getDataTable(list);
	}
	
	/**
	 * 新增广告投放计划(支付)
	 */
	@GetMapping("/add")
	public String add(ModelMap map)
	{
		List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

		/** 过滤掉子代理商 */
		for (Iterator<Agency> iterator = agencyList.iterator(); iterator.hasNext(); ) {
			if (null != iterator.next().getParentAgencyId()) {
				iterator.remove();
			}
		}

		AdvertisingCombinationPay advertisingCombinationPay = new AdvertisingCombinationPay();
		List<AdvertisingCombinationPay> advertisingCombinations = advertisingCombinationPayService.selectAdvertisingCombinationPayList(advertisingCombinationPay);

		map.put("agencyList", agencyList);
		map.put("advertisingCombinations", advertisingCombinations);
		map.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
	    return prefix + "/add";
	}
	
	/**
	 * 新增保存广告投放计划(支付)
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:add")
	@Log(title = "广告投放计划(支付)", businessType = BusinessType.INSERT)
	@PostMapping("/add")
	@ResponseBody
	public AjaxResult addSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanPay advertisingPlan)
	{
		AjaxResult ajaxResult = AdvertisingPlanController.check(advertisingPlan);
		if (null != ajaxResult) {
			return ajaxResult;
		}
		AdvertisingPlanController.handleFile(file, advertisingPlan, deviceService);
		User user = getUser();
		advertisingPlan.setCreaterId(user.getUserId().intValue());

		return toAjax(advertisingPlanPayService.insertAdvertisingPlanPay(advertisingPlan));
	}

	/**
	 * 修改广告投放计划(支付)
	 */
	@GetMapping("/edit/{id}")
	public String edit(@PathVariable("id") Integer id, ModelMap mmap)
	{
		AdvertisingPlanPay advertisingPlanPay = advertisingPlanPayService.selectAdvertisingPlanPayById(id);
		mmap.put("advertisingPlanPay", advertisingPlanPay);
		List<Agency> agencyList = agencyService.selectAgencyList(new Agency());

		/** 过滤掉子代理商 */
		for (Iterator<Agency> iterator = agencyList.iterator(); iterator.hasNext(); ) {
			if (null != iterator.next().getParentAgencyId()) {
				iterator.remove();
			}
		}

		AdvertisingPlanPay advertisingPlan = advertisingPlanPayService.selectAdvertisingPlanPayById(id);
		AdvertisingCombinationPay advertisingCombinationPay = new AdvertisingCombinationPay();
		List<AdvertisingCombinationPay> advertisingCombinations = advertisingCombinationPayService.selectAdvertisingCombinationPayList(advertisingCombinationPay);
		if(StringUtils.isNotEmpty(advertisingPlan.getDeviceScene())){
			String deviceSceneIds = deviceInstallSceneService.getSceneIdsByCode(advertisingPlan.getDeviceScene());
			mmap.put("deviceSceneIds",deviceSceneIds);
		}

		mmap.put("deviceSceneSelected", StringUtils.split(advertisingPlan.getDeviceScene(), ','));
		mmap.put("agencyIdSelected", null == advertisingPlan.getAgencyIdArray() ? null : Convert.toIntArray(advertisingPlan.getAgencyIdArray()));
		mmap.put("agencyList", agencyList);
		mmap.put("advertisingCombinations", advertisingCombinations);
		mmap.put("advertisingPlan", advertisingPlan);
		mmap.put("paperTodayNumArray", new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
		mmap.put("paperTodayNumSelected", StringUtils.isBlank(advertisingPlan.getPaperTodayNum()) ? null : Convert.toIntArray(advertisingPlan.getPaperTodayNum()));
	    return prefix + "/edit";
	}
	
	/**
	 * 修改保存广告投放计划(支付)
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:edit")
	@Log(title = "广告投放计划(支付)", businessType = BusinessType.UPDATE)
	@PostMapping("/edit")
	@ResponseBody
	public AjaxResult editSave(@RequestParam(value = "fileExcel", required = false) MultipartFile file, AdvertisingPlanPay advertisingPlan)
	{
		AdvertisingPlanPay advertisingPlanOld = advertisingPlanPayService.selectAdvertisingPlanPayById(advertisingPlan.getId());

		if (null == advertisingPlanOld) {
			return error("记录不存在");
		}

		AjaxResult ajaxResult = AdvertisingPlanController.check(advertisingPlan);

		if (null != ajaxResult) {
			return ajaxResult;
		}

		AdvertisingPlanController.handleFile(file, advertisingPlan, deviceService);

		User user = getUser();
		advertisingPlan.setModifierId(null == user ? null : user.getUserId().intValue());

		if (null != advertisingPlan.getOperatorType() && advertisingPlan.getOperatorType().equals(IAdPlanService.OPERATION_TYPE_UPDATE)) {
			advertisingPlan.setCategoryFinance(null == advertisingPlan.getCategoryFinance() ? NO.getValue() : advertisingPlan.getCategoryFinance());
			advertisingPlan.setWeChatAccount(null == advertisingPlan.getWeChatAccount() ? NO.getValue() : advertisingPlan.getWeChatAccount());
		}

		return toAjax(advertisingPlanPayService.updateAdvertisingPlanPay(advertisingPlan));
	}
	
	/**
	 * 删除广告投放计划(支付)
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:remove")
	@Log(title = "广告投放计划(支付)", businessType = BusinessType.DELETE)
	@PostMapping( "/remove")
	@ResponseBody
	public AjaxResult remove(String ids)
	{		
		return toAjax(advertisingPlanPayService.logicDeleteAdvertisingPlanPayByIds(ids));
	}

	@Log(title = "广告投放计划", businessType = BusinessType.EXPORT)
	@PostMapping("/export/sn")
	@ResponseBody
	public AjaxResult exportDeviceSn(AdvertisingPlanPay advertisingPlan) {

		List<AdvertisingPlan> list = new ArrayList<>();
		ExcelUtil<AdvertisingPlan> util = new ExcelUtil<>(AdvertisingPlan.class);
		/*sheetName必须是：addevice，否则无法直接上传导入分成配置*/
		String sheetName = "addevice";

		AdvertisingPlanDevice advertisingPlanDevice = advertisingPlanDeviceService.selectAdvertisingPlanDeviceByPlanId(advertisingPlan.getPlanId());

		if (null == advertisingPlanDevice) {
			return util.exportExcel(list, sheetName);
		}

		String[] array = StringUtils.split(advertisingPlanDevice.getDeviceSn(), ',');

		if (null == array || array.length == 0) {
			return util.exportExcel(list, sheetName);
		}

		for (String sn : array) {
			AdvertisingPlan record = new AdvertisingPlan();
			record.setMixId(sn);
			list.add(record);
		}

		return util.exportExcel(list, sheetName);
	}

	/**
	 * 文件上传
	 */
	@PostMapping("/uploadFile")
	@ResponseBody
	public AjaxResult uploadImg(@RequestParam("file") MultipartFile file) {

		if (file.isEmpty()) {
			return error("文件为空");
		}

		String fileName = FilenameUtils.getName(file.getOriginalFilename());
		String ext = FilenameUtils.getExtension(fileName);
		String md5 = DigestUtils.md5Hex(fileName);
		String fileKey = zjbConfig.getAdPlanDeviceFileUrl() + LocalDate.now()
				+ '/' + md5 + '.' + ext;

		try {
			OssUtil.uploadFile(fileKey, file.getInputStream());
			String fileUrl = ZjbConstants.File_Domain + '/' + fileKey;
			logger.warn("文件OSS路径：{}", fileUrl);
			AjaxResult ajaxResult = success();
			ajaxResult.put("fileUrl", fileUrl);
			ajaxResult.put("fileName", fileName);
			return ajaxResult;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return error(e.getMessage());
		}
	}


	/**
	 * 边界广告投放计划权重
	 */
	@GetMapping("/weight/{id}")
	public String weight(@PathVariable("id") Integer id, ModelMap mmap) {
		AdvertisingPlanPay advertisingPlan = advertisingPlanPayService.selectAdvertisingPlanPayById(id);
		mmap.put("advertisingPlan", advertisingPlan);
		mmap.put("planWeightArray", new int[]{1, 2, 3, 4, 5});
		return prefix + "/weight";
	}

	/**
	 * 边界广告投放计划权重
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:weight")
	@Log(title = "广告投放计划权重设置", businessType = BusinessType.UPDATE)
	@PostMapping("/weight")
	@ResponseBody
	public AjaxResult weight(AdvertisingPlanPay advertisingPlan, ModelMap mmap) {

		User user = getUser();
		advertisingPlan.setModifierId(user.getUserId().intValue());
		advertisingPlanPayService.updateAdvertisingPlanPay(advertisingPlan);

		return success();
	}

	/**
	 * 广告投放计划手动暂停
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:pause")
	@Log(title = "广告投放计划手动暂停", businessType = BusinessType.UPDATE)
	@PostMapping("/pause")
	@ResponseBody
	public AjaxResult pause(String ids) {

		for (String id : StringUtils.split(ids)) {
			AdvertisingPlanPay advertisingPlan = advertisingPlanPayService.selectAdvertisingPlanPayById(Integer.parseInt(id));
			advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_PAUSE_MANUAL.getValue());
			advertisingPlanPayService.updateAdvertisingPlanPay(advertisingPlan);
		}

		return success();
	}

	/**
	 * 广告投放计划手动恢复
	 */
	@RequiresPermissions("dsp:advertisingPlanPay:resume")
	@Log(title = "广告投放计划手动恢复", businessType = BusinessType.UPDATE)
	@PostMapping("/resume")
	@ResponseBody
	public AjaxResult resume(String ids) {

		for (String id : StringUtils.split(ids)) {
			AdvertisingPlanPay advertisingPlan = advertisingPlanPayService.selectAdvertisingPlanPayById(Integer.parseInt(id));

			if (null == advertisingPlan) {
				return error("广告计划不存在");
			}
			advertisingPlan.setAdvertisingStatus(ZjbDictionaryEnum.AD_PLAN_STATUS_OK.getValue());
			advertisingPlanPayService.updateAdvertisingPlanPay(advertisingPlan);
			advertisingPlanPayService.reloadPattern(advertisingPlan.getPlanId());
		}

		return success();
	}
	
}
