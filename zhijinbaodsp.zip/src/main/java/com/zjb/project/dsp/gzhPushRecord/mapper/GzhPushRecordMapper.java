package com.zjb.project.dsp.gzhPushRecord.mapper;

import com.zjb.project.dsp.gzhPushRecord.domain.GzhPushRecord;
import java.util.List;	

/**
 * 公众号推送记录 数据层
 * 
 * @author shenlong
 * @date 2020-01-15
 */
public interface GzhPushRecordMapper 
{
	/**
     * 查询公众号推送记录信息
     * 
     * @param id 公众号推送记录ID
     * @return 公众号推送记录信息
     */
	public GzhPushRecord selectGzhPushRecordById(Integer id);
	
	/**
     * 查询公众号推送记录列表
     * 
     * @param gzhPushRecord 公众号推送记录信息
     * @return 公众号推送记录集合
     */
	public List<GzhPushRecord> selectGzhPushRecordList(GzhPushRecord gzhPushRecord);
	
	/**
     * 新增公众号推送记录
     * 
     * @param gzhPushRecord 公众号推送记录信息
     * @return 结果
     */
	public int insertGzhPushRecord(GzhPushRecord gzhPushRecord);
	
	/**
     * 修改公众号推送记录
     * 
     * @param gzhPushRecord 公众号推送记录信息
     * @return 结果
     */
	public int updateGzhPushRecord(GzhPushRecord gzhPushRecord);
	
	/**
     * 删除公众号推送记录
     * 
     * @param id 公众号推送记录ID
     * @return 结果
     */
	public int deleteGzhPushRecordById(Integer id);
	
	/**
     * 批量删除公众号推送记录
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteGzhPushRecordByIds(String[] ids);

	/**
     * 批量删除5天前公众号推送记录
     *
     * @return 结果
     */
	public int deleteGzhPushRecord(String gzhPushTimes);
	
}