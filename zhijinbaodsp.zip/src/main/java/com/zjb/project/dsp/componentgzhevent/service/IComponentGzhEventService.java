package com.zjb.project.dsp.componentgzhevent.service;

import com.zjb.project.dsp.componentAuthorizationInfo.domain.UserInfo;
import com.zjb.project.dsp.componentgzhevent.domain.ComponentGzhEvent;

import java.util.Date;
import java.util.List;

/**
 * @author songjy
 * @date 2019/10/28
 */
public interface IComponentGzhEventService {

    /**
     * 根据主键查询
     *
     * @param id
     * @return
     */
    ComponentGzhEvent findById(Integer id);

    /**
     * 查询指定日期公众号事件
     *
     * @param gmtDate yyyy-MM-dd
     * @param appId   公众号
     * @param event   事件类型
     * @return
     */
    List<ComponentGzhEvent> findByAppIdAndEvent(Date gmtDate, String appId, String event);

    /**
     * 查询用户对公众号得最后一次事件记录
     *
     * @param appId
     * @param openId 可以是纸巾宝openId也可以是关注公众号后的openId
     * @param event
     * @return
     */
    ComponentGzhEvent findLastByAppIdAndOpenIdAndEvent(String appId, String openId, String event);

    /**
     * 补充缺失的纸巾宝openId
     *
     * @param componentGzhEvent
     * @return
     */
    int updatePerfectZjbOpenId(ComponentGzhEvent componentGzhEvent);

    /**
     * 补充缺失的设备信息
     *
     * @param componentGzhEvent
     * @return
     */
    int updatePerfectDeviceInfo(ComponentGzhEvent componentGzhEvent);

    /**
     * 查询公众号日关注数量、当日关注且当日取关数量、日取关数量
     *
     * @param weChatAccount 微信公众号
     * @return
     */
    List<ComponentGzhEvent> selectDayRealAmount(String weChatAccount);

    /**
     * 导出指定日期关注公众号的用户信息
     *
     * @param weChatAccount
     * @param date
     * @return
     */
    List<UserInfo> exportSubscribeUserInfo(String weChatAccount, Date date);
}
