package com.zjb.project.dsp.advertisingUnitWx.domain;

import com.zjb.project.dsp.advertisingUnit.domain.AdvertisingUnit;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;

import java.util.Date;

/**
 * 广告池-微信表 zjb_advertising_unit_wx
 *
 * @author ZH
 * @date 2019-08-13
 */
public class AdvertisingUnitWx extends AdvertisingUnit {
    private static final long serialVersionUID = -2091660687312823644L;
}
