package com.zjb.project.dsp.gzhxcxInfo.service;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.support.Convert;
import com.zjb.project.dsp.gzhxcxInfo.domain.GzhxcxInfo;
import com.zjb.project.dsp.gzhxcxInfo.mapper.GzhxcxInfoMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 * 公众号小程序 服务层实现
 * 
 * @author zjb
 * @date 2018-09-14
 */
@Service
public class GzhxcxInfoServiceImpl implements IGzhxcxInfoService , InitializingBean
{
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private GzhxcxInfoMapper gzhxcxInfoMapper;
	@Autowired
	@Qualifier(value = com.zjb.common.constant.Constants.DB_ZJB_ID)
	private JdbcTemplate jdbcTemplate;

	@Override
	public void afterPropertiesSet() throws Exception {
		importTask();
	}

	/**
	 * 导入核心系统任务数据
	 */
	private void importTask() {
		String sql = "SELECT * FROM `zjb_gzhxcx_info` WHERE deleted = 0 AND id  IN (%s)";

		sql = String.format(sql , "2");

		logger.info("查询任务SQL:{}" , sql);

		List<GzhxcxInfo> list = jdbcTemplate.query(sql , new RowMapper<GzhxcxInfo>() {
			Date now = new Date();

			@Override
			public GzhxcxInfo mapRow(ResultSet rs , int rowNum) throws SQLException {
				GzhxcxInfo gzhxcxInfo = new GzhxcxInfo();
				gzhxcxInfo.setId(rs.getInt("id"));
				gzhxcxInfo.setGzhId(ZjbDictionaryEnum.AD_FAN_COMBINATION_UNIT_PREFIX.getValue().toString() + gzhxcxInfo.getId());
				gzhxcxInfo.setAppid(rs.getString("appid"));
				gzhxcxInfo.setAppsecret(rs.getString("appsecret"));
				gzhxcxInfo.setName(rs.getString("name"));
				gzhxcxInfo.setType(rs.getInt("type"));
				gzhxcxInfo.setSubscribeMsg(rs.getString("subscribe_msg"));
				gzhxcxInfo.setGmtCreated(now);
				gzhxcxInfo.setGmtModified(now);
				gzhxcxInfo.setCreaterId(1703);
				gzhxcxInfo.setModifierId(1703);
				gzhxcxInfo.setDeleted(0);
				return gzhxcxInfo;

			}
		});

		if (null == list || list.isEmpty()) {
			return;
		}

		int r = 0;
		for (GzhxcxInfo gzhxcxInfo : list) {
			r += gzhxcxInfoMapper.insertGzhxcxInfo(gzhxcxInfo);
		}

		logger.warn("本次导入数据条数：{}" , r);
	}
	/**
     * 查询公众号小程序信息
     * 
     * @param id 公众号小程序ID
     * @return 公众号小程序信息
     */
    @Override
	public GzhxcxInfo selectGzhxcxInfoById(Integer id)
	{
	    return gzhxcxInfoMapper.selectGzhxcxInfoById(id);
	}
	
	/**
     * 查询公众号小程序列表
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 公众号小程序集合
     */
	@Override
	public List<GzhxcxInfo> selectGzhxcxInfoList(GzhxcxInfo gzhxcxInfo)
	{
	    return gzhxcxInfoMapper.selectGzhxcxInfoList(gzhxcxInfo);
	}
	
    /**
     * 新增公众号小程序
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 结果
     */
	@Override
	public int insertGzhxcxInfo(GzhxcxInfo gzhxcxInfo)
	{

		gzhxcxInfo.setGmtCreated(new Date());
		gzhxcxInfo.setGmtModified(gzhxcxInfo.getGmtCreated());
		int r = gzhxcxInfoMapper.insertGzhxcxInfo(gzhxcxInfo);

		if (r > 0) {
			gzhxcxInfo.setGzhId(ZjbDictionaryEnum.AD_FAN_COMBINATION_UNIT_PREFIX.getValue().toString() + gzhxcxInfo.getId());
			r += gzhxcxInfoMapper.updateGzhxcxInfo(gzhxcxInfo);
		}
		return r;
	}
	
	/**
     * 修改公众号小程序
     * 
     * @param gzhxcxInfo 公众号小程序信息
     * @return 结果
     */
	@Override
	public int updateGzhxcxInfo(GzhxcxInfo gzhxcxInfo)
	{
	    return gzhxcxInfoMapper.updateGzhxcxInfo(gzhxcxInfo);
	}

	/**
     * 删除公众号小程序对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGzhxcxInfoByIds(String ids)
	{
		return gzhxcxInfoMapper.deleteGzhxcxInfoByIds(Convert.toStrArray(ids));
	}
	
}
