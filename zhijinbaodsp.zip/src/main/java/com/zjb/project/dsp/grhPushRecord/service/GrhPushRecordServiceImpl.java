package com.zjb.project.dsp.grhPushRecord.service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.alibaba.fastjson.JSON;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.common.utils.DateUtils;
import com.zjb.common.utils.StringUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.framework.config.RedisSubscribe;
import com.zjb.project.dsp.gzhPushRecord.domain.GzhPushRecord;
import com.zjb.project.system.config.service.IConfigService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.grhPushRecord.mapper.GrhPushRecordMapper;
import com.zjb.project.dsp.grhPushRecord.domain.GrhPushRecord;
import com.zjb.project.dsp.grhPushRecord.service.IGrhPushRecordService;
import com.zjb.common.support.Convert;

/**
 * 个人号推送记录 服务层实现
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
@Service
public class GrhPushRecordServiceImpl implements IGrhPushRecordService
{
	private static final Logger log = LoggerFactory.getLogger(GrhPushRecordServiceImpl.class);

	@Autowired
	private GrhPushRecordMapper grhPushRecordMapper;
	@Autowired
	private IConfigService configService;

	/**
     * 查询个人号推送记录信息
     * 
     * @param id 个人号推送记录ID
     * @return 个人号推送记录信息
     */
    @Override
	public GrhPushRecord selectGrhPushRecordById(Integer id)
	{
	    return grhPushRecordMapper.selectGrhPushRecordById(id);
	}
	
	/**
     * 查询个人号推送记录列表
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 个人号推送记录集合
     */
	@Override
	public List<GrhPushRecord> selectGrhPushRecordList(GrhPushRecord grhPushRecord)
	{
	    return grhPushRecordMapper.selectGrhPushRecordList(grhPushRecord);
	}
	
    /**
     * 新增个人号推送记录
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 结果
     */
	@Override
	public int insertGrhPushRecord(GrhPushRecord grhPushRecord)
	{
	    return grhPushRecordMapper.insertGrhPushRecord(grhPushRecord);
	}
	
	/**
     * 修改个人号推送记录
     * 
     * @param grhPushRecord 个人号推送记录信息
     * @return 结果
     */
	@Override
	public int updateGrhPushRecord(GrhPushRecord grhPushRecord)
	{
	    return grhPushRecordMapper.updateGrhPushRecord(grhPushRecord);
	}

	/**
     * 删除个人号推送记录对象
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	@Override
	public int deleteGrhPushRecordByIds(String ids)
	{
		return grhPushRecordMapper.deleteGrhPushRecordByIds(Convert.toStrArray(ids));
	}

	/**
	 * 新增或编辑个人号展示记录
	 * @param grhPushRecord
	 * @return
	 */
	@Override
	public int insertOrUpdate(GrhPushRecord grhPushRecord) {
		if(null == grhPushRecord){
			log.warn("插入数据为null!");
			return 0 ;
		}
		if(StringUtils.isBlank(grhPushRecord.getPersonalAppId()) || StringUtils.isBlank(grhPushRecord.getOpenId())){
			log.warn("参数不能为空!");
			return 0 ;
		}
		List<GrhPushRecord> grhPushRecords = selectGrhPushRecordList(grhPushRecord);
		String grhPushTimes = configService.selectConfigByKey("zjb_grh_push_times");
		if(StringUtils.isEmpty(grhPushTimes)){
			grhPushTimes = "2";
		}
		int viewCount = 0;
		if(CollectionUtils.isEmpty(grhPushRecords)){
			viewCount = 1;
		}else{
			GrhPushRecord grhPushRecord1 = grhPushRecords.get(0);
			if(null != grhPushRecord1 && null != grhPushRecord1.getViewCount()){
				viewCount = grhPushRecord1.getViewCount()+1;
			}else{
				viewCount = 1;
			}
		}
		if(CollectionUtils.isEmpty(grhPushRecords)){
			grhPushRecord.setViewCount(viewCount);
			grhPushRecord.setCreateTime(DateUtils.dateTime("yyyy-MM-dd",DateUtils.getDate()));
			grhPushRecord.setGmtCreated(new Date());
			grhPushRecord.setGmtModified(new Date());
			grhPushRecordMapper.insertGrhPushRecord(grhPushRecord);
		}else{
			GrhPushRecord grhPushRecord1 = grhPushRecords.get(0);
			grhPushRecord1.setViewCount(viewCount);
			grhPushRecord1.setGmtModified(new Date());
			grhPushRecordMapper.updateGrhPushRecord(grhPushRecord1);
		}
		int grhPushTime = Integer.parseInt(grhPushTimes);
		if(grhPushTime == viewCount){
			// 将该记录发送到核心系统个人号 index表中
			Map<String, Object> mapQueue = new HashMap<>(4);
			mapQueue.put(RedisSubscribe.KEY_GRH_RECORD_EVENT, grhPushRecord.getPersonalAppId() + "@" + grhPushRecord.getOpenId());
			JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_ADMIN_GZH, JSON.toJSONString(mapQueue));
		}
		if(grhPushTime < viewCount){
			// 将该记录发送到核心系统个人号 index表中
			Map<String, Object> mapQueue = new HashMap<>(4);
			mapQueue.put(RedisSubscribe.KEY_GRH_RECORD_EVENT, grhPushRecord.getPersonalAppId() + "@" + grhPushRecord.getOpenId());
			JedisPoolCacheUtils.lpush(RedisSubscribe.MESSAGE_QUEUE_ADMIN_GZH, JSON.toJSONString(mapQueue));
			log.warn("个人号推送次数记录表数据异常,展示次数大于配置次数且没有过滤!personalAppId:[{}],openid:[{}]",grhPushRecord.getPersonalAppId(),grhPushRecord.getOpenId());
			return  0 ;
		}

		return 0;
	}

	/**
	 * 清除个人号展示记录
	 * @return
	 */
	@Override
	public int removeGrhShowRecord(String grhPushTimes) {
		return grhPushRecordMapper.removeGrhShowRecord(grhPushTimes);
	}

}
