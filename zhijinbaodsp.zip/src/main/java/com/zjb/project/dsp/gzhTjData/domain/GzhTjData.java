package com.zjb.project.dsp.gzhTjData.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.zjb.framework.web.domain.BaseEntity;
							import java.math.BigDecimal;
		import java.util.Date;

/**
 * 公众号关注数据表 zjb_gzh_tj_data
 * 
 * @author shenlong
 * @date 2020-01-04
 */
public class GzhTjData extends BaseEntity
{
	private static final long serialVersionUID = 1L;
	
	/**  */
	private Integer id;
	/** appid */
	private String appid;
	/** 公众号名称 */
	private String nickName;
	/** 关注数 */
	private Integer subscribeCount;
	/** 当日关注并取关数 */
	private Integer sameDayUnsubscribeCount;
	/** 取关数 */
	private Integer unsubscribeCount;
	/** 取关率 */
	private BigDecimal unsubscribeRate;
	/** 当日关注并取关率 */
	private BigDecimal sameDayUnsubscribeRate;
	/** pv */
	private Integer qrcodePv;
	/** 新uv */
	private Integer qrcodeNewUv;
	/** 老uv */
	private Integer qrcodeOldUv;
	/** 记录日期 */
	private Date tjDate;
	/** 公众号来源 */
	private Integer gzhFromType;

	// 非数据库字段
	private String selectDate;
	private String startDate;
	private String endDate;
	private String[] appIds;

	public String[] getAppIds() {
		return appIds;
	}

	public void setAppIds(String[] appIds) {
		this.appIds = appIds;
	}

	public String getSelectDate() {
		return selectDate;
	}

	public void setSelectDate(String selectDate) {
		this.selectDate = selectDate;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public Integer getId() 
	{
		return id;
	}
	public void setAppid(String appid) 
	{
		this.appid = appid;
	}

	public String getAppid() 
	{
		return appid;
	}
	public void setNickName(String nickName) 
	{
		this.nickName = nickName;
	}

	public String getNickName() 
	{
		return nickName;
	}
	public void setSubscribeCount(Integer subscribeCount) 
	{
		this.subscribeCount = subscribeCount;
	}

	public Integer getSubscribeCount() 
	{
		return subscribeCount;
	}
	public void setSameDayUnsubscribeCount(Integer sameDayUnsubscribeCount) 
	{
		this.sameDayUnsubscribeCount = sameDayUnsubscribeCount;
	}

	public Integer getSameDayUnsubscribeCount() 
	{
		return sameDayUnsubscribeCount;
	}
	public void setUnsubscribeCount(Integer unsubscribeCount) 
	{
		this.unsubscribeCount = unsubscribeCount;
	}

	public Integer getUnsubscribeCount() 
	{
		return unsubscribeCount;
	}
	public void setUnsubscribeRate(BigDecimal unsubscribeRate) 
	{
		this.unsubscribeRate = unsubscribeRate;
	}

	public BigDecimal getUnsubscribeRate() 
	{
		return unsubscribeRate;
	}
	public void setSameDayUnsubscribeRate(BigDecimal sameDayUnsubscribeRate) 
	{
		this.sameDayUnsubscribeRate = sameDayUnsubscribeRate;
	}

	public BigDecimal getSameDayUnsubscribeRate() 
	{
		return sameDayUnsubscribeRate;
	}
	public void setQrcodePv(Integer qrcodePv) 
	{
		this.qrcodePv = qrcodePv;
	}

	public Integer getQrcodePv() 
	{
		return qrcodePv;
	}
	public void setQrcodeNewUv(Integer qrcodeNewUv) 
	{
		this.qrcodeNewUv = qrcodeNewUv;
	}

	public Integer getQrcodeNewUv() 
	{
		return qrcodeNewUv;
	}
	public void setQrcodeOldUv(Integer qrcodeOldUv) 
	{
		this.qrcodeOldUv = qrcodeOldUv;
	}

	public Integer getQrcodeOldUv() 
	{
		return qrcodeOldUv;
	}
	public void setTjDate(Date tjDate) 
	{
		this.tjDate = tjDate;
	}

	public Date getTjDate() 
	{
		return tjDate;
	}

	public void setGzhFromType(Integer gzhFromType) 
	{
		this.gzhFromType = gzhFromType;
	}

	public Integer getGzhFromType() 
	{
		return gzhFromType;
	}

    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("appid", getAppid())
            .append("nickName", getNickName())
            .append("subscribeCount", getSubscribeCount())
            .append("sameDayUnsubscribeCount", getSameDayUnsubscribeCount())
            .append("unsubscribeCount", getUnsubscribeCount())
            .append("unsubscribeRate", getUnsubscribeRate())
            .append("sameDayUnsubscribeRate", getSameDayUnsubscribeRate())
            .append("qrcodePv", getQrcodePv())
            .append("qrcodeNewUv", getQrcodeNewUv())
            .append("qrcodeOldUv", getQrcodeOldUv())
            .append("tjDate", getTjDate())
            .append("gmtCreated", getGmtCreated())
            .append("gmtModified", getGmtModified())
            .append("gzhFromType", getGzhFromType())
            .toString();
    }
}
