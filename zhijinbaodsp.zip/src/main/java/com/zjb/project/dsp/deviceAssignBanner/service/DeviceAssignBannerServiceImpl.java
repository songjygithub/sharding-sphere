package com.zjb.project.dsp.deviceAssignBanner.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.zjb.project.dsp.deviceAssignBanner.mapper.DeviceAssignBannerMapper;
import com.zjb.project.dsp.deviceAssignBanner.domain.DeviceAssignBanner;
import com.zjb.project.dsp.deviceAssignBanner.service.IDeviceAssignBannerService;
import com.zjb.common.support.Convert;

/**
 * 定向投放展示广告 服务层实现
 *
 * @author jiangbingjie
 * @date 2020-02-12
 */
@Service
public class DeviceAssignBannerServiceImpl implements IDeviceAssignBannerService
{
	@Autowired
	private DeviceAssignBannerMapper deviceAssignBannerMapper;

	/**
	 * 查询定向投放展示广告信息
	 *
	 * @param id 定向投放展示广告ID
	 * @return 定向投放展示广告信息
	 */
	@Override
	public DeviceAssignBanner selectDeviceAssignBannerById(Integer id)
	{
		return deviceAssignBannerMapper.selectDeviceAssignBannerById(id);
	}

	/**
	 * 查询定向投放展示广告列表
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 定向投放展示广告集合
	 */
	@Override
	public List<DeviceAssignBanner> selectDeviceAssignBannerList(DeviceAssignBanner deviceAssignBanner)
	{
		return deviceAssignBannerMapper.selectDeviceAssignBannerList(deviceAssignBanner);
	}

	/**
	 * 新增定向投放展示广告
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 结果
	 */
	@Override
	public int insertDeviceAssignBanner(DeviceAssignBanner deviceAssignBanner)
	{
		return deviceAssignBannerMapper.insertDeviceAssignBanner(deviceAssignBanner);
	}

	/**
	 * 修改定向投放展示广告
	 *
	 * @param deviceAssignBanner 定向投放展示广告信息
	 * @return 结果
	 */
	@Override
	public int updateDeviceAssignBanner(DeviceAssignBanner deviceAssignBanner)
	{
		return deviceAssignBannerMapper.updateDeviceAssignBanner(deviceAssignBanner);
	}

	/**
	 * 删除定向投放展示广告对象
	 *
	 * @param ids 需要删除的数据ID
	 * @return 结果
	 */
	@Override
	public int deleteDeviceAssignBannerByIds(String ids)
	{
		return deviceAssignBannerMapper.deleteDeviceAssignBannerByIds(Convert.toStrArray(ids));
	}

}
