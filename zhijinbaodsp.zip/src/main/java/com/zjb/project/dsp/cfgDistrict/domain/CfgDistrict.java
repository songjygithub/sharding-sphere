package com.zjb.project.dsp.cfgDistrict.domain;


import com.zjb.framework.web.domain.BaseEntity;

/**
 * 省市区表 zjb_cfg_district
 *
 * @author zjb
 * @date 2018-08-15
 */
public class CfgDistrict extends BaseEntity {
    private static final long serialVersionUID = 1L;

    /**
     *
     */
    private Integer id;
    /**
     * 名称
     */
    private String name;
    /**
     * 父节点
     */
    private Integer parentId;
    /**
     * 排序
     */
    private Integer sortid;
    /**
     * 节点等级
     */
    private Integer districtLevel;

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setParentId(Integer parentId) {
        this.parentId = parentId;
    }

    public Integer getParentId() {
        return parentId;
    }

    public void setSortid(Integer sortid) {
        this.sortid = sortid;
    }

    public Integer getSortid() {
        return sortid;
    }

    public void setDistrictLevel(Integer districtLevel) {
        this.districtLevel = districtLevel;
    }

    public Integer getDistrictLevel() {
        return districtLevel;
    }
}
