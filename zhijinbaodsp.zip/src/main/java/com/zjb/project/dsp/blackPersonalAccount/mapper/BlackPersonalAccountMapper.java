package com.zjb.project.dsp.blackPersonalAccount.mapper;

import com.zjb.project.dsp.blackPersonalAccount.domain.BlackPersonalAccount;
import java.util.List;	

/**
 * 个人号黑名单 数据层
 * 
 * @author jiangbingjie
 * @date 2020-03-19
 */
public interface BlackPersonalAccountMapper 
{
	/**
     * 查询个人号黑名单信息
     * 
     * @param id 个人号黑名单ID
     * @return 个人号黑名单信息
     */
	public BlackPersonalAccount selectBlackPersonalAccountById(Integer id);
	
	/**
     * 查询个人号黑名单列表
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 个人号黑名单集合
     */
	public List<BlackPersonalAccount> selectBlackPersonalAccountList(BlackPersonalAccount blackPersonalAccount);
	
	/**
     * 新增个人号黑名单
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 结果
     */
	public int insertBlackPersonalAccount(BlackPersonalAccount blackPersonalAccount);
	
	/**
     * 修改个人号黑名单
     * 
     * @param blackPersonalAccount 个人号黑名单信息
     * @return 结果
     */
	public int updateBlackPersonalAccount(BlackPersonalAccount blackPersonalAccount);
	
	/**
     * 删除个人号黑名单
     * 
     * @param id 个人号黑名单ID
     * @return 结果
     */
	public int deleteBlackPersonalAccountById(Integer id);
	
	/**
     * 批量删除个人号黑名单
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteBlackPersonalAccountByIds(String[] ids);

	/**
	 * 逻辑删除个人号黑名单
	 * @param ids
	 * @return
	 */
	public int logicDeleteBlackPersonalAccountByIds(String[] ids);

	
}