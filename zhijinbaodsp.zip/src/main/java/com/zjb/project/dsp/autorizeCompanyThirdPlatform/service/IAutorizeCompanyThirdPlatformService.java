package com.zjb.project.dsp.autorizeCompanyThirdPlatform.service;

import com.zjb.project.dsp.autorizeCompanyThirdPlatform.domain.AutorizeCompanyThirdPlatform;
import com.zjb.project.dsp.componentAuthorizationInfo.domain.CompanyThirdPlatformData;

import java.util.List;

/**
 * 授权公司第三方平台 服务层
 * 
 * @author jiangbingjie
 * @date 2020-03-05
 */
public interface IAutorizeCompanyThirdPlatformService 
{
	/**
     * 查询授权公司第三方平台信息
     * 
     * @param id 授权公司第三方平台ID
     * @return 授权公司第三方平台信息
     */
	public AutorizeCompanyThirdPlatform selectAutorizeCompanyThirdPlatformById(Integer id);
	
	/**
     * 查询授权公司第三方平台列表
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 授权公司第三方平台集合
     */
	public List<AutorizeCompanyThirdPlatform> selectAutorizeCompanyThirdPlatformList(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform);
	
	/**
     * 新增授权公司第三方平台
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 结果
     */
	public int insertAutorizeCompanyThirdPlatform(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform);
	
	/**
     * 修改授权公司第三方平台
     * 
     * @param autorizeCompanyThirdPlatform 授权公司第三方平台信息
     * @return 结果
     */
	public int updateAutorizeCompanyThirdPlatform(AutorizeCompanyThirdPlatform autorizeCompanyThirdPlatform);
		
	/**
     * 删除授权公司第三方平台信息
     * 
     * @param ids 需要删除的数据ID
     * @return 结果
     */
	public int deleteAutorizeCompanyThirdPlatformByIds(String ids);

	/**
	 * 获取公司主体下有效的第三方平台信息
	 * @param companyId
	 * @return
	 */
	public List<CompanyThirdPlatformData> getAutorizeCompanyThirdPlatformList(Integer companyId);

	/**
	 * 获取公司主体第三方平台信息
	 * @param appId
	 * @return
	 */
	public AutorizeCompanyThirdPlatform selectAutorizeCompanyThirdPlatformByAppId(String appId);
	
}
