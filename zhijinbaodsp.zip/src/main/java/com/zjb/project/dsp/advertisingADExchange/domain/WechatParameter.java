package com.zjb.project.dsp.advertisingADExchange.domain;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author shenlong
 * @date 2019/11/20
 */
public class WechatParameter implements Serializable {

    private static final long serialVersionUID = -4137422258060989907L;

    /**
     * 公众号appid
     */
    private String weChatAccount;
    /**
     * 设备唯一标识
     */
    private String qrCode;
    /**
     * 用户唯一标识
     */
    private String openId;
    /**
     * 用户扫码流水号
     */
    private Long randomNum;

    /**
     * 发起请求时间
     */
    private LocalDateTime gmtRequest;

    public Long getRandomNum() {
        return randomNum;
    }

    public void setRandomNum(Long randomNum) {
        this.randomNum = randomNum;
    }

    public String getWeChatAccount() {
        return weChatAccount;
    }

    public void setWeChatAccount(String weChatAccount) {
        this.weChatAccount = weChatAccount;
    }

    public String getQrCode() {
        return qrCode;
    }

    public void setQrCode(String qrCode) {
        this.qrCode = qrCode;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public LocalDateTime getGmtRequest() {
        return gmtRequest;
    }

    public void setGmtRequest(LocalDateTime gmtRequest) {
        this.gmtRequest = gmtRequest;
    }
}