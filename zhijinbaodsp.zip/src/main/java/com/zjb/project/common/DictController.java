package com.zjb.project.common;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zjb.common.utils.CollectionUtils;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.project.dsp.cfgDistrict.domain.CfgDistrict;
import com.zjb.project.dsp.cfgDistrict.service.ICfgDistrictService;
import com.zjb.project.util.DictUtils;

/**
 * 通用请求处理
 * 
 * @author zjb
 */
@RestController
@RequestMapping("/zjbdsp")
public class DictController {
	@Autowired
	private ICfgDistrictService iCfgDistrictService;

	/**
	 * 字典select
	 * 
	 * @param dictType
	 * @return
	 */
	@GetMapping("/dict/{dictType}")
	public AjaxResult dict(@PathVariable("dictType") String dictType) {
		AjaxResult ajaxResult = AjaxResult.success();
		ajaxResult.put("results", DictUtils.getDictForSelect(dictType));
		return ajaxResult;
	}

	/**
	 * 省市区select
	 * 
	 * @param parentId
	 * @return
	 */
	@GetMapping("/district/{parentId}")
	public AjaxResult district(@PathVariable("parentId") Integer parentId) {
		AjaxResult ajaxResult = null;
		if (parentId != null) {
			CfgDistrict cfgDistrict = new CfgDistrict();
			cfgDistrict.setParentId(parentId);
			List<CfgDistrict> list = iCfgDistrictService.selectCfgDistrictList(cfgDistrict);
			ajaxResult = AjaxResult.success();
			ajaxResult.put("results", converDistrict(list));
			return ajaxResult;
		}
		return AjaxResult.error("ParentId 不能为空");
	}

	private List<Map<String, String>> converDistrict(List<CfgDistrict> list) {
		List<Map<String, String>> result = null;
		if (CollectionUtils.isNotEmpty(list)) {
			result = Lists.newArrayList();
			for (CfgDistrict cfgDistrict : list) {
				Map map = Maps.newHashMap();
				map.put(DictUtils.DICT_TEXT, cfgDistrict.getName());
				map.put(DictUtils.DICT_ID, cfgDistrict.getId());
				result.add(map);
			}
		}
		return result;
	}

}
