package com.zjb.common.enums;

import java.util.Arrays;
import java.util.HashSet;

/**
 * @author songjy
 * @date 2019/07/03
 */
public enum ZjbConfigEnum {

    /**
     * 设备最大扫码次数配置项
     */
    DEVICE_OUTPAPER_MAX_COUNT("zjb.device.outpapercount", 5),

    /**
     * 是否显示故障上报按钮
     */
    ABNORMAL_TYPE("zjb_abnormal_type", "false"),
    /**
     * 域名【66k22.top】
     */
    DOMAIN_ADDRESS_66K22_TOP("zjb_domain_address_66k22_top", "66k22.top"),

    /**
     * 授权域名
     */
    DOMAIN_ADDRESS_AUTH_THROUGH_TOP("zjb_domain_auth_through", "hello699.top"),

    /**
     * 广告域名（其它）
     */
    DOMAIN_ADDRESS_OTHER("zjb_domain_address_other", "zhidage.top"),
    /**
     * 域名【66k22.top】对应的任务ID
     */
    S66K22_TOP_TASK_ID("zjb_s66k22_top_task_id", new HashSet<>(Arrays.asList(new String[]{"29", "1029", "30", "1030", "31", "1031", "32", "1032"}))),
    /**
     * 域名【zjb3.top】对应的任务ID
     */
    ZJB3_TOP_TASK_ID("zjb_zjb3_top_task_id", new HashSet<>(Arrays.asList(new String[]{"14", "1014", "17", "1017", "18", "1018", "19", "1019"}))),
    /**
     * 每个IP地址每日获取短信次数
     */
    ZJB_IP_TIMES("zjb_ip_times", null),

    /**
     * 付费取纸入口是否显示，0：否 1：是
     */
    ZJB_PAY_TAKE_PAPER_DISPLAY("zjb_pay_take_paper_display", 1),

    /**
     * 允许跨域的域名
     */
    ZJB_CORS_ALLOWED_ORIGINS("zjb_cors_allowed_origins", null),

    /**
     * 指定设备(qrcode)小树叶广告落地页跳转路径
     */
    ZJB_DEVICE_XSY_URL_QRCODE("zjb_device_xsy_url_qrcode", "*"),

    /**
     * 微信小程序任务ID
     */
    ZJB_WEI_XIN_APP_TASK_UNIT_ID("zjb_wei_xin_app_task_unit_id", new HashSet<>()),

    /**
     * 初始化密码 123456
     */
    ZJB_SYS_USER_INITPASSWORD("sys.user.initPassword", "123456"),

    /**
     * 广点通心跳服务器
     */
    ZJB_GDT_SERVER_DOMAIN("zjb_gdt_server_domain", null),

    /**
     * 小树叶首页链接地址
     */
    ZJB_DSP_LEAF_INDEX_URL("zjb_dsp_leaf_index_url", null),

    /**
     * 小树叶专用域名
     */
    ZJB_LEAF_PRIVATE_DOMAIN("zjb_leaf_private_domain", null),

    /**
     * 粉丝通专用域名
     */
    ZJB_FANS_PRIVATE_DOMAIN("zjb_fans_private_domain", null),

    /**
     * 第三方平台广告拉取超时限制（毫秒）
     */
    ZJB_HTTP_THIRD_SOCKET_TIMEOUT("zjb_http_third_socket_timeout", 3000),

    /**
     * 是否支持直跳原始关注公众号页面链接 0：否 1：是
     */
    ZJB_OPEN_LEAPING_LINK("zjb_open_leaping_link", 0),

    /**
     * 直跳原始关注公众号页面白名单设备
     */
    ZJB_OPEN_LEAPING_LINK_DEVICE("zjb_open_leaping_link_device", null),

    /**
     * 第三方平台secret  (默认为"纸巾宝"第三方平台)
     */
    ZJB_COMPONENT_SECRET("zjb_component_secret", "19afd0f53e3eadca1a47f827becc4977"),

    /**
     * 第三方平台APPID  (默认为"纸巾宝"第三方平台)
     */
    ZJB_COMPONENT_APPID("zjb_component_appid", "wx70372a6f90bbae02"),

    /**
     * 核心系统访问域名
     */
    ZJB_ADMIN_HOST("zjb_admin_host", "https://admin.zhijinbao.net"),

    /**
     * 粉丝通支付宝端下展示卡片
     */
    ZJB_FANS_CARD_ALIPAY("zjb_fans_card_alipay", null),

    /**
     * 粉丝通微信端下展示卡片
     */
    ZJB_FANS_CARD_WECHAT("zjb_fans_card_wechat", null),

    /**
     * 纸巾宝App下载引导页链接
     */
    ZJB_DSP_APP_DOWN_URL("zjb_dsp_app_down_url", null),

    /**
     * 不允许用支付宝取纸的广告计划ID集合
     */
    ZJB_NOT_ALI_PAY_ALLOWED_TAKE_PAPER_PLAN_ID("zjb_not_ali_pay_allowed_take_paper_plan_id", null),


    /**
     * 保底广告计划ID集合
     */
    ZJB_GUARANTEE_AD_PLAN_ID("zjb_guarantee_ad_plan_id", null),
    ;

    /**
     * 配置项KEY
     */
    private final String key;
    /**
     * 配置默认值
     */
    private final Object value;

    private ZjbConfigEnum(String key, Object value) {
        this.key = key;
        this.value = value;
    }

    public String getKey() {
        return key;
    }

    @SuppressWarnings("unchecked")
    public <T> T getValue() {
        return (T) value;
    }
}
