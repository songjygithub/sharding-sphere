package com.zjb.common.enums;

/**
 * 程序运行环境枚举值
 *
 * @author songjy
 * @date 2019/07/09
 */
public enum ZjbEnvEnum {
    ONLINE("线上环境"),
    TEST_ONLINE("预发布环境");

    /**
     * 环境名称
     */
    private final String name;

    private ZjbEnvEnum(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
