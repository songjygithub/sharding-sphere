package com.zjb.common.enums;

/**
 * 字典分类编码
 *
 * @author songjy
 * @date 2019/07/01
 */
public enum ZjbDictionaryTypeEnum {

    BROWSER_TYPE("zjb_browser_type" , "浏览器类型"),
    SMS_SEND_TYPE("zjb_sms_send_type" , "短信发送类型"),
    SMS_SEND_STATUS("zjb_sms_send_status" , "短信发送状态"),
    ROLE_TYPE("zjb_role_type" , "角色类型"),
    PROGRAM_TYPE("zjb_program_type" , "广告方案类型"),
    SEX("zjb_sex" , "安装地人群属性"),
    YES_NO("zjb_yes_no" , "是否"),
    DEVICE_SCENE("zjb_device_scene" , "设备安装场合"),
    AD_PLAN_CATEGORY("zjb_ad_plan_category" , "广告计划所属行业"),
    AD_PLAN_STATUS("zjb_ad_plan_status" , "广告计划投放状态"),
    AD_FACE_SEX("zjb_face_sex" , "广告计划投放面向人群性别"),
    AD_LONG_TERM_EFFECTIVE("zjb_long_term_effective" , "广告计划是否长期有效"),
    AD_PLATFORM_TYPE("zjb_platform_type" , "广告平台类型"),
    AD_SCAN_TOOL("zjb_scan_tool" , "广告投放扫码环境"),
    AD_AUTH_USER_SOURCE_TYPE("zjb_auth_user_source_type" , "授权用户来源类型"),
    AD_NETWORK_TYPE("zjb_network_type" , "广告投放网络类型"),
    AD_OPERATOR_TYPE("zjb_operator_type" , "广告投放运营商"),
    AD_RADIO_DEVICE_SN("zjb_radio_device_sn" , "广告投放设备SN定向"),
    AD_RADIO_DEVICE_SCENE("zjb_radio_device_scene" , "广告投放设备场景定向"),
    AD_RADIO_DEVICE_AGENCY("zjb_radio_device_agency" , "广告投放代理商定向"),
    AD_RADIO_WE_CHAT_OFFICIAL_ACCOUNT("zjb_radio_we_chat_official_account" , "公众号定向"),
    AD_SPACE_IDENTIFIER("zjb_ad_space_identifier" , "广告位"),
    AD_REDIRECT_URL_TYPE("zjb_redirect_url_type" , "跳转类型"),
    AD_USE_STATUS("zjb_ad_use_status" , "广告使用状态"),
    AD_CLASSIFY_PREFIX("zjb_ad_classify_prefix" , "广告编号规则前缀标识"),
    AD_SINGLE_USER_FREQUENCY("zjb_ad_single_user_frequency" , "策略-单用户广告计划投放频次"),
    AD_TEMPLATE_TYPE("zjb_ad_template_type" , "广告模板类型"),
    AD_UNIT_TYPE("zjb_ad_unit_type" , "广告产品类型"),
    AD_TYPE_INCOME_EXPENDITURE_LEAF("zjb_ad_type_income_expenditure_leaf" , "小树叶收支类型"),
    GZH_PUSH_AD_STATUS("zjb_gzh_push_ad_status" , "公众号推送广告状态"),
    LEAF_TASK_SHELF_STATUS("zjb_leaf_task_shelf_status" , "小树叶任务上架状态"),
    LEAF_TASK_TYPE("zjb_leaf_task_type" , "小树叶任务类型"),
    LEAF_TASK_VERIFY_STATUS("zjb_leaf_task_verify_status" , "小树叶发放审核状态"),
    LEAF_STATUS_INCOME_EXPENDITURE("zjb_leaf_status_income_expenditure" , "小树叶收支明细状态"),
    LEAF_TYPE_INCOME_EXPENDITURE("zjb_leaf_type_income_expenditure" , "小树叶收支收支类型"),
    LEAF_ISSUE_TYPE("zjb_leaf_issue_type" , "小树叶发放方式"),
    LEAF_ISSUE_STATUS("zjb_leaf_issue_status" , "小树叶发放状态"),
    USER_HOME_PAGE_PUSH_TYPE("user_home_page_popup_type" , "用户体系首页弹窗信息类型"),
    LEAF_JUMP_TYPE("zjb_leaf_jump_type" , "首页配置任务跳转类型"),
    LEAF_CONFIG_POSITION("zjb_leaf_config_position" , "首页配置位置"),
    USER_HOME_PAGE_POPUP_TYPE("user_home_page_popup_type" , "用户体系首页弹窗信息类型"),
    ZJB_PR_OUT_PAPER_STATUS("zjb_pr_out_paper_status" , "$ZJBPR出纸状态"),
    LEAF_TASK_QUERY_TYPE("zjb_leaf_task_query_type" , "小树叶任务查询类型"),
    LEAF_SPEED_PICKING_CONSUME_WAY("zjb_speed_picking_leaf_consume_way" , "小树叶极速取纸扣减方式"),
    TAKE_PAPER_SOURCE("take_paper_source" , "取纸来源"),
    MQ_STATUS("zjb_mq_status" , "消息队列状态"),
    AD_WE_CHAT_ACCOUNT_EVENT("zjb_ad_we_chat_official_account_event" , "微信公众号事件"),
    AD_WE_CHAT_OFFICIAL_ACCOUNT_DELIVERY_STATUS("zjb_we_chat_official_account_delivery_status" , "微信公众号投放状态"),
    WE_CHAT_PERSONAL_DELIVERY_STATUS("zjb_we_chat_personal_delivery_status" , "微信个人号投放状态"),
    QQ_PERSONAL_DELIVERY_STATUS("zjb_qq_personal_delivery_status" , "QQ个人号投放状态"),
    RULL_STATUS("zjb_rull_status","售卖规则使用状态"),
    COMPONENT_AUTHORIZATION_TYPE("zjb_component_authorization_type","公众号授权类型"),
    WECHAT_ACCOUNT_AUTH_STATUS("zjb_auth_status","授权状态"),
    WECHAT_ACCOUNT_VERIFY_STATUS("zjb_verify_status","认证状态"),
    AD_FROM_TYPE("zjb_from_type","返回广告类型"),
	FANS_CARD_TYPE("zjb_fans_card","粉丝通首页展示卡片"),
    RECORD_STATUS("zjb_record_status","未认证公众号记录openid"),
    SPECIAL_TYPE("zjb_device_special_type","特殊设备类型"),
    FORBID_PUT_OFFICIAL_ACCOUNT_TYPE("zjb_forbid_put_official_account_type","禁投公众号的取纸次数类型"),
    FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_STATUS("zjb_forbid_put_official_account_config_status","指定次数禁投公众号广告配置状态"),
    FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_STATUS("zjb_forbid_put_personal_account_config_status","指定次数禁投个人号广告配置状态"),
    FORBID_PUT_PERSONAL_ACCOUNT_TYPE("zjb_forbid_put_personal_account_type","禁投个人号的取纸次数类型"),

    DEVICE_INSTALL_SCENE_TYPE("zjb_device_install_scene_type" , "设备安装场景类型"),
    DEVICE_INSTALL_SCENE("zjb_device_install_scene" , "设备安装场景"),
    DEVICE_SPECIAL_STATUS("zjb_device_special_status","屏蔽付费设备状态"),

    PERSONAL_SOURCE_TYPE("zjb_personal_source_type","个人号来源渠道"),
    PERSONAL_TYPE("zjb_personal_type","个人号类型"),

    ADVERTISEMENT_STATUS("zjb_advertisement_status","非竞价广告状态"),

    WITHOUT_BIDDING_ADVERTISEMENT_EVENT_TYPE("zjb_without_bidding_advertisement_event_type","非竞价广告关注方式"),

    THIRD_PLATFORM_CHANNEL("zjb_third_platform_channel","第三方平台标识"),

    SYS_FILE_TYPE("sys_file_type","导出文件分类"),

    EXPORT_SYS_FILE_STATUS("export_sys_file_status","导出文件状态"),
    ZJB_DEVICE_SPECIAL_OUT_PAPER_TYPE("zjb_device_special_out_paper_type","指定设备取纸方式"),
    ;

    private ZjbDictionaryTypeEnum(String type , String name) {
        this.type = type;
        this.name = name;
    }

    /**
     * 字典分类编码
     */
    private final String type;
    /**
     * 字典分类名称
     */
    private final String name;

    public String getType() {
        return type;
    }

    public String getName() {
        return name;
    }
}
