package com.zjb.common.constant;

import com.zjb.common.enums.ZjbEnvEnum;
import org.apache.commons.lang3.SystemUtils;

/**
 * 各环境变量值
 *
 * @author songjy
 * @date 2019/07/09
 */
public interface ZjbEnvConstants {

    /**
     * 根据操作系统类型判定程序当前运行环境
     */
    ZjbEnvEnum ENV = (SystemUtils.IS_OS_WINDOWS || SystemUtils.IS_OS_MAC) ? ZjbEnvEnum.TEST_ONLINE : ZjbEnvEnum.ONLINE;

    /**
     * 程序当前运行环境
     */
    String ZJB_CURRENT_EVN = (ZjbEnvEnum.ONLINE == ENV) ? "ONLINE" : "TEST";
    /**
     * 文件服务器
     */
    String FILE_DOMAIN = (ZjbEnvEnum.ONLINE == ENV) ? "http://imgdsp.zhijinbao.net" : "https://sczjbdsptest.oss-cn-shanghai.aliyuncs.com";

    /**
     * OSS对象文件分类根目录
     */
    String BUCKET_NAME = (ZjbEnvEnum.ONLINE == ENV) ? "sczjbdsp" : "sczjbdsptest";

    /**
     * redis所在机器地址
     */
    String REDIS_HOST = (ZjbEnvEnum.ONLINE == ENV) ? "r-uf657b40717bc4c4.redis.rds.aliyuncs.com" : "127.0.0.1";
    /**
     * redis连接密码
     */
    String REDIS_PASSWORD = (ZjbEnvEnum.ONLINE == ENV) ? "Xcxzjb@456a" : "sczj";

}
