package com.zjb.common.constant;

/**
 * Zjb通用常量
 * 
 * @author zjb
 */
public interface ZjbConstants
{
    public static final String ZJB_CURRENT_EVN = ZjbEnvConstants.ZJB_CURRENT_EVN;
    public static final String File_Domain = ZjbEnvConstants.FILE_DOMAIN;

    public static final String ZJB_CURRENT_SMS = "DY";//当前使用的短信渠道。DY:阿里短信

    public static final String ZJB_SMS_FORCE_SEND = "1";//强制发送短信


    public static final String ZJB_EXCEPTION_INFO = "zjb_exception_info";

}
