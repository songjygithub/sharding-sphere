package com.zjb.common.constant;

/**
 * @author ：guoj
 * @date ：Created in 2019/9/17 16:12
 * @description： 用户运营体系开通vip需要关注的公众号相关类，成就信息相关图片
 */

public class ZjbVipConstants {

    public static String LEAF_NAME = "纸巾宝小树叶";
    public static String LEAF_APPID = "wx25e1c629a4ca7128";
    public static String LEAF_ICON = "https://img.zhijinbao.net/h5/static/img/leaf.png";

    public static String VIP_CENTER_NAME = "纸巾宝会员中心";
    public static String VIP_CENTER_APPID = "wx24ee4af9278febc4";
    public static String VIP_CENTER_ICON = "https://img.zhijinbao.net/h5/static/img/vip_center.png";
    public static String VIP_CENTER_QRODEADDRESS = "http://img.zhijinbao.net/home/zjbadmin/gzhQrode/2019-07-30/9897320190730.png";

    public static String WELFARE_CENTER_NAME = "纸巾宝福利中心";
    public static String WELFARE_CENTER_APPID = "wx000d6c181df60a11";
    public static String WELFARE_CENTER_ICON = "https://img.zhijinbao.net/h5/static/img/welfare_center.png";

    public static String READ_CENTER_NAME = "纸巾宝阅读中心";
    public static String READ_CENTER_APPID = "wx4b4050d9a39c8333";
    public static String READ_CENTER_ICON = "https://img.zhijinbao.net/h5/static/img/read_center.png";
    public static String READ_CENTER_QRODEADDRESS = "http://img.zhijinbao.net/home/zjbadmin/gzhQrode/2019-09-27/8520320190927.png";

    public static String NEWS_PLUS_NAME = "八卦PLUS";
    public static String NEWS_PLUS_APPID = "wx155bf6960e058267";
    public static String NEWS_PLUS_ICON = "http://wx.qlogo.cn/mmopen/SM73swrVqKXezloLSibu4ibZ4JYTj0UTIM7OphibB6geE92UfwYqmbnWMmdoGHzicrx5x427yZNa0l1gJ5z1PicibQo2J7hIOROYnN/64";
    public static String NEWS_PLUS_QRODEADDRESS = "http://img.zhijinbao.net/home/zjbadmin/gzhQrode/2019-07-26/1394320190726.png";

    // 成就信息图片地址
    // 白银
    public static String SILVERURL = "https://img.zhijinbao.net/h5/static/img/glory1.png";
    public static String SILVERREALGLORY = "https://img.zhijinbao.net/h5/static/img/realglory1.png";
    // 黄金
    public static String GOLDURL = "https://img.zhijinbao.net/h5/static/img/glory2.png";
    public static String GOLDREALGLORY = "https://img.zhijinbao.net/h5/static/img/realglory2.png";
    // 铂金
    public static String PLATINUMURL = "https://img.zhijinbao.net/h5/static/img/glory3.png";
    public static String PLATINUMREALGLORY = "https://img.zhijinbao.net/h5/static/img/realglory3.png";
    // 钻石
    public static String DIAMONDSURL = "https://img.zhijinbao.net/h5/static/img/glory4.png";
    public static String DIAMONDSREALGLORY = "https://img.zhijinbao.net/h5/static/img/realglory4.png";
}
