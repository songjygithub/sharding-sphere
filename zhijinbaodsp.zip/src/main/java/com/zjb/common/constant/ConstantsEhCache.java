package com.zjb.common.constant;

/**
 * @author songjy
 * @date 2020-04-26
 */
public final class ConstantsEhCache {
    /**
     * 缓存名称：微信公众号
     */
    public static final String CACHE_WE_CHAT_OFFICIAL_ACCOUNT = "WeChatOfficialAccount";

    /**
     * 设备安装信息
     */
    public static final String CACHE_DEVICE_INSTALL_INFO = "DeviceInstallInfo";
}
