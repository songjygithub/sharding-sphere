package com.zjb.common.constant;

/**
 * @author songjy
 * @date 2019/07/03
 */
public interface ZjbConstantsRedis {

    /**
     * ========redis db key 标识符 共256个========
     */
    int ZJB_DB_1 = 1;
    int ZJB_DB_4 = 4;
    int ZJB_DB_6 = 6;
    /**第三方调取次数相关*/
    int ZJB_DB_19 = 19;
    int ZJB_DB_14 = 14;
    int ZJB_DB_50 = 50;
    int ZJB_DB_51 = 51;
    int ZJB_DB_52 = 52;
    int ZJB_DB_53 = 53;
    int ZJB_DB_54 = 54;
    int ZJB_DB_55 = 55;
    int ZJB_DB_56 = 56;
    // 公众号相关库
    int ZJB_DB_57 = 57;
    //个人号相关
    int ZJB_DB_58 = 58;
    //非竞价广告相关
    int ZJB_DB_59 = 59;


    /**
     * 用户信息
     */
    String REDIS_USER_INFO = "zjb_user_info";

    /**
     * 记录用户授权数据
     */
    String ZJB_AUTHORIZATION_USER_INFO_BY_OPENID = "zjb_authorization_user_info_by_openid";
    String GZH_COMPONENT_VERIFY_TICKET = "zjb_component_verify_ticket";
    String GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_TOKEN = "zjb_third_component_authorizer_authorization_token";
    String GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_REFRESH = "zjb_third_component_authorizer_authorization_refresh";
    String GZH_THIRD_COMPONENT_AUTHORIZER_ACCESS_TOKEN = "zjb_third_component_authorizer_access_token";

    /**
     * 参数配置
     */
    String REDIS_CONFIG_INFO_ID = "zjb_redis_config_info_id";
    String REDIS_CONFIG_INFO_KEY = "zjb_redis_config_info_key";

    /**
     * ========字典数据缓存前缀========
     */
    String REDIS_DICT_DATA_TYPE_VALUE = "zjb_redis_dict_data_type_value";
    String REDIS_DICT_DATA_ID = "zjb_redis_dict_data_id";
    String REDIS_DICT_DATA_TYPE_STATUS = "zjb_redis_dict_data_type_status";

    /**
     * 登录验证码
     */
    String SMS_LOGIN = "zjb_sms_login";

    /**
     * 小程序用户对应的每日扫码次数
     */
    String REDIS_MINI_OPENID_DAY_QRCOUNT = "zjb_mini_opend_day_qrcount";

    /**
     * 广告计划ID
     */
    String AD_PLAN_ID_PREFIX = "zjb_ad_plan_id";

    /**
     * ========设备信息缓存========
     */
    String REDIS_DEVICE_INFO_ID = "zjb_redis_device_info_id";
    String REDIS_DEVICE_INFO_NAME = "zjb_redis_device_info_name";
    String REDIS_DEVICE_INFO_SN = "zjb_redis_device_info_sn";
    String REDIS_DEVICE_INFO_QRCODE = "zjb_redis_device_info_qrcode";
    String REDIS_DEVICE_INFO_QRCODEB = "zjb_redis_device_info_qrcodeb";

    /**
     * ========公众号相关key=======
     */
    String GZH_TOKEN = "zjb_gzh_token";

    /**
     * 广告统计信息订阅channel发布数量
     */
    String CHANNEL_STATISTICS_AD_INFO_COUNT_PUBLISH = "zjb_channel_statistics_ad_info_count_publish";
    /** ========用户运营体系相关key=======
     */
    /**
     * 短信验证码次数Key
     */
    String REDIS_MINI_TELPHONE_TIMES = "zjb_redis_mini_telphone_times";
    /**
     * 短信验证码Key
     */
    String REDIS_MINI_TELPHONE_CAPTCHA = "zjb_redis_mini_telphone_captcha";

    /**
     * 常规取纸用户扫码流水号集合，6分钟内清理一次集合
     */
    String GENERAL_OUT_PAPER_RANDOM_NUM = "general_out_paper_random_num";

    /**
     * 粉丝通极速取纸延后通知
     */
    String FANS_WE_CHAT_ACCOUNT_NOTICE_INFO_DELAY = "fans_we_chat_account_notice_info_delay";

    /**
     * 用户小树叶极速取纸流水号集合，6分钟内清理一次集合
     */
    String USER_CONSUMED_LEAF_SERIAL_NUM = "zjb_user_consumed_leaf_serial_num";

    /**
     * 保底广告计划ID
     */
    String DSP_GUARANTEE_AD_PLAN_ID = "dsp_guarantee_ad_plan_id";

    /**
     * 保底广告计划对应的方案
     */
    String DSP_GUARANTEE_PLAN_COMBINATION_ID = "dsp_guarantee_plan_combination_id";


    /** ========告警相关key=======
     */
    /**
     * 定时任务告警Key
     */
    String REDIS_MONITOR_ERROR = "zjb_redis_monitor_error";
    /**
     * 核心系统告警Key
     */
    String REDIS_ADMIN_ERROR = "zjb_redis_admin_error";

    /**
     * $ZJBPR每天的数量
     */
    String ZJB_PR_EVERY_DAY_AMOUNT = "zjb_pr_every_day_amount";

    /**
     * 公众号事件处理进度最小ID
     */
    String ZJB_HANDLE_EVENT_MIN_ID = "handle_event_min_id";

    /**
     * 纸巾宝平台提供给第三方公众号扫码取纸的唯一标识
     */
    String RDEIS_THIRD_PARTY_OUT_PAPER_IDENTIFY = "third_party_out_paper_identify";

    /**
     * 广告计划支付宝用户胜出数量
     */
    String AD_PLAN_WIN_ALI_PAY_AMOUNT = "ad_plan_win_ali_pay_amount";

    /**
     * 广告计划微信用户胜出数量
     */
    String AD_PLAN_WIN_WE_CHAT_AMOUNT = "ad_plan_win_we_chat_amount";

    /**
     * 广告计划其它用户胜出数量
     */
    String AD_PLAN_WIN_OTHER_AMOUNT = "ad_plan_win_other_amount";

    /**
     * 公众号推送链接有效信息
     */
    String GZH_PUSH_URL = "gzh_push_url";

    /**
     * 胜出广告方案缓存，默认5分钟
     */
    String ZJB_AD_COMBINATION_INFO = "zjb_ad_combination_info";

    /**
     * 缓存公众号胜出的出纸方案，默认10分钟
     */
    String ZJB_GZH_TAKE_THE_PAPER_PROCESS = "zjb_gzh_take_the_paper_process";

    /**
     * 公众号二维码pv
     */
    String ZJB_GZH_QRCODE_PV = "zjb_gzh_qrcode_pv";

    /**
     * 公众号二维码新uv
     */
    String ZJB_GZH_QRCODE_NEW_UV = "zjb_gzh_qrcode_new_uv";

    /**
     * 公众号二维码老uv
     */
    String ZJB_GZH_QRCODE_OLD_UV = "zjb_gzh_qrcode_old_uv";

    /**
     *  未认证公众号公众号每日加粉统计
     */
    String UNVERIFIED_GZH_DATA = "unverified_gzh_data";
	    //公司主体下第三方平台密钥
    String GZH_AUTORIZE_COMPANY_THIRD_PLATOFRM_SECRET = "zjb_autorize_company_third_platform_secret";

    /**
     *  未认证公众号图文消息落地广告
     */
    String ZJB_AD_URL = "zjb_ad_url";

    /**屏蔽付费取纸设备信息*/
    String REDIS_DEVICE_SPECIAL_INFO = "zjb_redis_device_special_info";

    /**
     * 个人号昵称
     */
    String PERSONAL_ACCOUNT_NAME = "zjb_personal_account_name";

    /**
     * 个人号来源渠道
     */
    String PERSONAL_ACCOUNT_CHANNEL = "zjb_personal_account_channel";

    /**
     * 个人号胜出次数
     */
    String PERSONAL_ACCOUNT_SUCCESS_TIMES ="zjb_personal_account_success_times";

    /**
     * 个人号胜出用户
     */
    String PERSONAL_ACCOUNT_SUCCESS_PERSON ="zjb_personal_account_success_person";

    /**
     * 个人号胜出流水号
     */
    String PERSONAL_ACCOUNT_SUCCESS_RANDOM_NUM = "zjb_personal_account_success_random_num";
    /**
     * 用户个人号胜出次数
     */
    String PERSONAL_ACCOUNT_SUCCESS_PERSON_TIMES = "zjb_personal_account_success_person_times";

    /**
     * 个人号第一次胜出时间
     */
    String PERSONAL_ACCOUNT_FIRST_SUCCESS_TIME ="zjb_personal_account_first_success_time";

    /**
     * 个人号最后一次胜出时间
     */
    String PERSONAL_ACCOUNT_LAST_SUCCESS_TIME ="zjb_personal_account_last_success_time";

    /**
     * 个人号类型
     */
    String PERSONAL_ACCOUNT_TYPE = "zjb_personal_account_type";

    /**
     * 用户每天是否第一次获取广告
     */
    String REDIS_OPENID_DAY_SHOW_AD_FIRST = "zjb_openid_day_show_ad_first";

    /**
     * 非竞价广告展示次数
     */
    String WITHOUT_BIDDING_PRICE_AD_SHOW_TIME = "zjb_without_bidding_price_ad_show_time";

    /**
     * 非竞价广告展示用户
     */
    String WITHOUT_BIDDING_PRICE_AD_SHOW_PERSON = "zjb_without_bidding_price_ad_show_person";

    /**
     * 非竞价广告点击转化次数
     */
    String WITHOUT_BIDDING_PRICE_AD_CLICK_TIME = "zjb_without_bidding_price_ad_click_time";

    /**
     * 非竞价广告点击转化用户
     */
    String WITHOUT_BIDDING_PRICE_AD_CLICK_PERSON = "zjb_without_bidding_price_ad_click_person";

    /**
     * DATAV统计广告耗时
     */
    String DATAV_AD_TIME = "datav_ad_time";
    /**
     * DATAV统计广告竞价详情
     */
    String DATAV_AD_DETAIL = "datav_ad_detail";

    /**
     * DATAV  广告耗时分布
     */
    String DATAV_AD_TIME_DISTRIBUTE = "datav_ad_time_distribute";
    String DATAV_AD_TIME_LT_100 = "datav_ad_time_lt_100";
    String DATAV_AD_TIME_100_200 = "datav_ad_time_100_200";
    String DATAV_AD_TIME_200_300 = "datav_ad_time_200_300";
    String DATAV_AD_TIME_300_400 = "datav_ad_time_300_400";
    String DATAV_AD_TIME_400_500 = "datav_ad_time_400_500";
    String DATAV_AD_TIME_500_600 = "datav_ad_time_500_600";
    String DATAV_AD_TIME_600_700 = "datav_ad_time_600_700";
    String DATAV_AD_TIME_700_800 = "datav_ad_time_700_800";
    String DATAV_AD_TIME_800_900 = "datav_ad_time_800_900";
    String DATAV_AD_TIME_900_1000 = "datav_ad_time_900_1000";
    String DATAV_AD_TIME_GT_1000 = "datav_ad_time_gt_1000";

    /**
     * 第三方调取次数相关
     * */
    String THIRD_PARTY_CLENT_COUNT = "zjb_third_party_clent_count";

    /**
     * 第三方公众号胜出次数
     */
    String THIRD_PLATFORM_GZH_SUCCESS_TIMES ="zjb_third_platform_gzh_success_times";

    /**
     * 第三方公众号胜出用户
     */
    String THIRD_PLATFORM_GZH_SUCCESS_PERSON ="zjb_third_platform_gzh_success_person";

    /**
     * 公众号胜出流水号
     */
    String THIRD_PLATFORM_GZH_SUCCESS_RANDOM_NUM ="zjb_third_platform_gzh_success_random_num";

    /**
     * 用户第三方公众号胜出次数
     */
    String THIRD_PLATFORM_GZH_SUCCESS_PERSON_TIMES = "zjb_third_platform_gzh_success_person_times";

    /**
     * 第三方公众号第一次胜出时间
     */
    String THIRD_PLATFORM_GZH_FIRST_SUCCESS_TIME ="zjb_third_platform_gzh_first_success_time";

    /**
     * 第三方公众号最后一次胜出时间
     */
    String THIRD_PLATFORM_GZH_LAST_SUCCESS_TIME ="zjb_third_platform_gzh_last_success_time";



}
