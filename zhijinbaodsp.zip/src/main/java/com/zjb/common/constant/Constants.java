package com.zjb.common.constant;

/**
 * 通用常量信息
 *
 * @author zjb
 */
public class Constants {
    /**
     * UTF-8 字符集
     */
    public static final String UTF8 = "UTF-8";

    /**
     * 通用成功标识
     */
    public static final String SUCCESS = "0";

    /**
     * 通用失败标识
     */
    public static final String FAIL = "1";

    /**
     * 登录成功
     */
    public static final String LOGIN_SUCCESS = "Success";

    /**
     * 注销
     */
    public static final String LOGOUT = "Logout";

    /**
     * 登录失败
     */
    public static final String LOGIN_FAIL = "Error";

    /**
     * 自动去除表前缀
     */
    public static String AUTO_REOMVE_PRE = "true";

    /**
     * 当前记录起始索引
     */
    public static String PAGE_NUM = "pageNum";

    /**
     * 每页显示记录数
     */
    public static String PAGE_SIZE = "pageSize";

    /**
     * 排序列
     */
    public static String ORDER_BY_COLUMN = "orderByColumn";

    /**
     * 排序的方向 "desc" 或者 "asc".
     */
    public static String IS_ASC = "isAsc";


    /**
     * 纸巾宝数据库标识ID
     */
    public static final String DB_ZJB_ID = "db.zjb";

    /**
     * 淘宝IP解析获取地理位置连接
     */
    public static final String IP_PARSE_URL = "http://ip.taobao.com/service/getIpInfo.php?ip=";

    /**
     * 系统唯一标识ID
     */
    public static final String SYSTEM_ID = String.valueOf(System.currentTimeMillis());
}
