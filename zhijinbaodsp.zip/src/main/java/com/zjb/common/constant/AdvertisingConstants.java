package com.zjb.common.constant;

/**
 * @author songjy
 * @Date 2019/10/31
 **/
public final class AdvertisingConstants {

    /**
     * 系统标识主键
     */
    public static final String KEY_SYSTEM_ID = "systemId";

    /**
     * 公众号停止之广告投放计划暂停联动事件
     */
    public static final String KEY_APP_ID_STOP_AD_PLAN_EVENT = "key_app_id_stop_ad_plan_event";

    /**
     * $ZJBPL下发事件
     */
    public static final String KEY_ZJB_PL_DSP_EVENT = "key_zjb_pl_dsp_event";

    /**
     * $ZJBPR 上报事件
     */
    public static final String KEY_ZJB_PR_DSP_EVENT = "key_zjb_pr_dsp_event";

    /**
     * 用户第一次授权事件
     */
    public static final String KEY_USER_FIRST_AUTH_EVENT = "key_user_first_auth_event";

    /**
     * 用户第一次$ZJBPL事件
     */
    public static final String KEY_USER_FIRST_PL_EVENT = "key_user_first_pl_event";

    /**
     * 用户第一次$ZJBPR事件
     */
    public static final String KEY_USER_FIRST_PR_EVENT = "key_user_first_pr_event";

    /**
     * 用户第一次授权&第一次$ZJBPL事件
     */
    public static final String KEY_USER_FIRST_AUTH_PL_EVENT = "key_user_first_auth_pl_event";

    /**
     * 售卖规则变更事件
     */
    public static final String MEDIUM_SELL_RULE_UPDATE_EVENT = "key_medium_sell_rule_update_event";

    /**
     * 胜出广告计划
     */
    public static final String MAP_KEY_AD_PLAN_WIN = "map_key_ad_plan_win";

    /**
     * 统计广告信息事件
     */
    public static final String KEY_STATISTICS_AD_INFO_EVENT = "key_statistics_ad_info_event";

    /**
     * 系统应用停止事件
     */
    public static final String KEY_STOP_SYSTEM_APP_EVENT = "key_stop_system_app_event";

    /**
     * CPU、内存占用率百分比事件
     */
    public static final String KEY_CPU_MEN_PERCENTAGE_EVENT = "key_cpu_men_percentage_event";

    /**
     * 人工授权公众号信息记录保存事件
     */
    public static final String KEY_MANUAL_APPID_OPENID_INSERT_OR_UPDATE_EVENT = "manual_appId_openId_insert_or_update";

    /**
     * 处理展示通广告计划迁移至粉丝通
     */
    public static final String KEY_HANDLE_ALI_PAY_PLAN_TO_FANS_PLAN = "handle_ali_pay_plan_to_fans_plan";

    /**
     * 处理扫码补贴分成记录事件
     */
    public static final String KEY_HANDLE_DEVICE_SMBT_INSERT = "handle_device_smbt_insert";

    /**
     * 公众号屏蔽记录添加
     */
    public static final String KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_ADD = "key_forbid_put_official_account_config_add";

    /**
     * 公众号屏蔽记录删除
     */
    public static final String KEY_FORBID_PUT_OFFICIAL_ACCOUNT_CONFIG_DELETE = "key_forbid_put_official_account_config_delete";

    /**
     * 微信公众号信息更新
     */
    public static final String KEY_COMPONENT_AUTHORIZATION_INFO_UPDATE = "key_component_authorization_info_update";

    /**
     * 微信公众号日关注量清零
     */
    public static final String KEY_COMPONENT_AUTHORIZATION_INFO_CLEAN_DAY_FOLLOW_AMOUNT = "key_component_authorization_info_clean_day_follow_amount";

    /**
     * 广告竞价结果处理
     */
    public static final String KEY_HANDLE_BIDDING_RESULT_EVENT = "key_handle_bidding_result_event";

    /**
     * 参与竞价广告计划
     */
    public static final String MAP_KEY_PARTICIPATE_BID_AD_PLAN = "map_key_participate_bid_ad_plan";

    /**
     * 个人微信号修改事件
     */
    public static final String KEY_WE_CHAT_PERSONAL_UPDATE_EVENT = "key_we_chat_personal_update_event";

    /**
     * 个人QQ号修改事件
     */
    public static final String KEY_QQ_PERSONAL_UPDATE_EVENT = "key_qq_personal_update_event";

    /**
     * 广告计划胜出事件
     */
    public static final String KEY_AD_PLAN_WIN_EVENT = "key_ad_plan_win_event";

    /**
     * 第三方个人号广告方案胜出事件
     */
    public static final String KEY_AD_COMBINATION_INFO_WIN_THIRD_EVENT = "key_ad_combination_info_win_third_event";
    /**
     * 纸巾宝个人号广告方案胜出事件
     */
    public static final String KEY_AD_COMBINATION_INFO_WIN_OWN_EVENT = "key_ad_combination_info_win_own_event";

    /**
     * 广告类型添加事件
     */
    public static final String KEY_ADVERTISING_TYPE_ADD_EVENT = "key_advertising_type_add_event";

    /**
     * 广告类型删除事件
     */
    public static final String KEY_ADVERTISING_TYPE_REMOVE_EVENT = "key_advertising_type_remove_event";

    /**
     * 个人号屏蔽记录添加
     */
    public static final String KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_ADD = "key_forbid_put_personal_account_config_add";

    /**
     * 个人号屏蔽记录删除
     */
    public static final String KEY_FORBID_PUT_PERSONAL_ACCOUNT_CONFIG_DELETE = "key_forbid_put_personal_account_config_delete";

    /**
     * 允许打印日志的用户白名单添加
     */
    public static final String KEY_USER_PRINT_LOG_WHITE_ADD = "key_user_print_log_white_add";

    /**
     * 允许打印日志的用户白名单移除
     */
    public static final String KEY_USER_PRINT_LOG_WHITE_REMOVE = "key_user_print_log_white_remove";
}
