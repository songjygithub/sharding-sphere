package com.zjb.common.utils;

import cn.hutool.http.HttpUtil;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.constant.ZjbConstantsRedis;
import com.zjb.common.utils.file.ZjbFileUtils;
import com.zjb.common.utils.http.HttpClient;
import com.zjb.common.utils.http.HttpUtils;
import com.zjb.framework.config.JedisPoolCacheUtils;
import com.zjb.project.dsp.subscribeUserInfo.domain.SubscribeUserInfo;
import com.zjb.project.dsp.weChatNews.domain.WeChatNews;
import org.apache.commons.lang.StringEscapeUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.*;

import static com.zjb.common.constant.ZjbConstantsRedis.*;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_COMPONENT_APPID;
import static com.zjb.common.enums.ZjbConfigEnum.ZJB_COMPONENT_SECRET;
import static com.zjb.framework.config.JedisPoolCacheUtils.EXRP_YEAR;


/**
 * 请求校验工具类
 *
 * @author zjb
 */
public class WeChatUtil {
    private static final Logger logger = LoggerFactory.getLogger(WeChatUtil.class);

    // 临时二维码
    private final static String QR_SCENE = "QR_SCENE";
    private final static String QR_STR_SCENE = "QR_STR_SCENE";
    // 永久二维码
    private final static String QR_LIMIT_SCENE = "QR_LIMIT_SCENE";
    // 永久二维码(字符串)
    private final static String QR_LIMIT_STR_SCENE = "QR_LIMIT_STR_SCENE";
    // 创建二维码
    private final static String create_ticket_path = "https://api.weixin.qq.com/cgi-bin/qrcode/create";
    // 通过ticket换取二维码
    private final static String showqrcode_path = "https://mp.weixin.qq.com/cgi-bin/showqrcode";
    // 创建公众号底部菜单
    private final static String create_menu_url = "https://api.weixin.qq.com/cgi-bin/menu/create";
    // 获取用户基本信息
    private final static String get_user_info = "https://api.weixin.qq.com/cgi-bin/user/info";
    // 长链接转短链接
    private final static String long_to_short_url = "https://api.weixin.qq.com/cgi-bin/shorturl?";
    // 获取永久素材管理
    private final static String get_img_url = "https://api.weixin.qq.com/cgi-bin/material/batchget_material";
    //获取媒体文件
    private final static String get_url = "https://qyapi.weixin.qq.com/cgi-bin/media/get";
    /**上传图文消息素材*/
    private final static String uploadnews_url = "https://api.weixin.qq.com/cgi-bin/media/uploadnews?access_token=";
    /** 新增其他类型永久素材  媒体文件类型，分别有图片（image）、语音（voice）、视频（video）和缩略图（thumb）*/
    private final static String add_mzterial_url = "https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=";
    /** 群发接口-上传图文素材—thumb_media_id获取 */
    private final static String upload_url = "http://file.api.weixin.qq.com/cgi-bin/media/upload?access_token=";
    /** 新增永久图文素材 */
    private final static String add_news = "https://api.weixin.qq.com/cgi-bin/material/add_news?access_token=";
    /**上传图文消息内的图片获取URL【订阅号与服务号认证后均可用】*/
    private final static String uploadimg_url = "https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=";
    /** 获取上传视频素材id群发消息用 */
    private final static String uploadvideo_url = "https://api.weixin.qq.com/cgi-bin/media/uploadvideo?access_token=";
    /**根据标签群发消息【订阅号与服务号认证后均可用】*/
    private final static String sendall_url = "https://api.weixin.qq.com/cgi-bin/message/mass/sendall?access_token=";
    /** 根据OpenID列表群发【订阅号不可用，服务号认证后可用】 */
    private final static String send_url = "https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token=";
    /*
        第三方平台信息
     */
    private final static String component_app_id = "wx70372a6f90bbae02"; // 纸巾宝正式
    private final static String component_app_secret = "19afd0f53e3eadca1a47f827becc4977"; //纸巾宝正式

    //    private final static String component_app_id = "wx47cf36cd1c9fa65c"; // 纸巾宝测试
//    private final static String component_app_secret = "34f9a8c472c80852b3683a2e72c3bd46"; //纸巾宝测试
    private static final String component_access_token_url = "https://api.weixin.qq.com/cgi-bin/component/api_component_token";
    private static final String api_authorizer_token = "https://api.weixin.qq.com/cgi-bin/component/api_authorizer_token";
    private static final String pre_auth_code_url = "https://api.weixin.qq.com/cgi-bin/component/api_create_preauthcode";

    public static String getComponent_app_id() {
        return component_app_id;
    }


    /**
     * 将字节数组转换为十六进制字符串
     *
     * @param byteArray
     * @return
     */
    private static String byteToStr(byte[] byteArray) {
        String strDigest = "";
        for (int i = 0; i < byteArray.length; i++) {
            strDigest += byteToHexStr(byteArray[i]);
        }
        return strDigest;
    }

    /**
     * 将字节转换为十六进制字符串
     *
     * @param mByte
     * @return
     */
    private static String byteToHexStr(byte mByte) {
        char[] Digit = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
        char[] tempArr = new char[2];
        tempArr[0] = Digit[(mByte >>> 4) & 0X0F];
        tempArr[1] = Digit[mByte & 0X0F];

        String s = new String(tempArr);
        return s;
    }

    private static void sort(String a[]) {
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = i + 1; j < a.length; j++) {
                if (a[j].compareTo(a[i]) < 0) {
                    String temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
    }

    /**
     * 解析微信发来的请求(xml)
     *
     * @param request
     * @return
     * @throws Exception
     */
    @SuppressWarnings({"unchecked"})
    public static Map<String, String> parseXml(HttpServletRequest request) throws Exception {
        // 将解析结果存储在HashMap中
        Map<String, String> map = new HashMap<String, String>();

        // 从request中取得输入流
        InputStream inputStream = request.getInputStream();
        // 读取输入流
        SAXReader reader = new SAXReader();
        Document document = reader.read(inputStream);
        // 得到xml根元素
        Element root = document.getRootElement();
        // 得到根元素的所有子节点
        List<Element> elementList = root.elements();
        // 遍历所有子节点
        for (Element e : elementList) {
            String text = e.getText();
            text = text == null ? "" : text;
            map.put(e.getName(), text);
        }

        // 释放资源
        inputStream.close();
        inputStream = null;
        return map;
    }

    public static String mapToXML(Map map) {
        StringBuffer sb = new StringBuffer();
        sb.append("<xml>");
        mapToXML2(map, sb);
        sb.append("</xml>");
        try {
            return sb.toString();
        } catch (Exception e) {
        }
        return null;
    }

    private static void mapToXML2(Map map, StringBuffer sb) {
        Set set = map.keySet();
        for (Iterator it = set.iterator(); it.hasNext(); ) {
            String key = (String) it.next();
            Object value = map.get(key);
            if (null == value) {
                value = "";
            }
            if (value.getClass().getName().equals("java.util.ArrayList")) {
                ArrayList list = (ArrayList) map.get(key);
                sb.append("<" + key + ">");
                for (int i = 0; i < list.size(); i++) {
                    HashMap hm = (HashMap) list.get(i);
                    mapToXML2(hm, sb);
                }
                sb.append("</" + key + ">");

            } else {
                if (value instanceof HashMap) {
                    sb.append("<" + key + ">");
                    mapToXML2((HashMap) value, sb);
                    sb.append("</" + key + ">");
                } else {
                    sb.append("<" + key + "><![CDATA[" + value + "]]></" + key + ">");
                }

            }

        }
    }

    /**
     * 判断url是否被微信屏蔽
     *
     * @param appid
     * @param appsecret
     * @param url
     * @return
     */
    public static boolean verifyUrl(String appid, String appsecret, String url) {
        // 获取短链接失败时重复3次，3次获取失败直接返回true；
        String jsonResult = "";
        for (int i = 0; i < 3; i++) {
            String accessToken = getAccessToken(appid, appsecret);
            TreeMap<String, String> params = new TreeMap<>();
            params.put("access_token", accessToken);
            Map<String, Object> paramsMap = new HashMap<String, Object>();
            paramsMap.put("action", "long2short");
            paramsMap.put("long_url", url);
            String data = JSON.toJSONString(paramsMap);
            jsonResult = HttpRequestUtil.HttpDefaultExecute(HttpRequestUtil.POST_METHOD, long_to_short_url, params, data);
            if (jsonResult.contains("short_url")) {
                break;
            }
            if (i == 2) {
                return true;
            }
        }
        logger.info("short_url" + jsonResult);
        if (StringUtils.isNotEmpty(jsonResult)) {
            JSONObject jsonObject = JSON.parseObject(jsonResult);
            String shortUrl = jsonObject.getString("short_url");
            shortUrl = StringEscapeUtils.unescapeJava(shortUrl);
            if (StringUtils.isNotEmpty(shortUrl)) {
                jsonResult = HttpUtils.sendGet(shortUrl, null);
                if (StringUtils.isEmpty(jsonResult) || (!jsonResult.contains("已停止访问该网页") && !jsonResult.contains("临时链接已失效"))) {
                    return true;
                } else {
                    return false;
                }
            }
        }
        return false;
    }

    /**
     * 获取第三方平台component_access_token
     * http请求方式: POST（请使用https协议）
     * https://api.weixin.qq.com/cgi-bin/component/api_component_token
     * <p>
     * 参数:
     * component_appid	        第三方平台appid
     * component_appsecret	    第三方平台appsecret
     * component_verify_ticket	微信后台推送的ticket，此ticket会定时推送，具体请见本页的推送说明
     */
    public static String getComponentAccessToken() {

        String key = REDIS_CONFIG_INFO_KEY + '_' + ZJB_COMPONENT_APPID.getKey();
        String configVal = JedisPoolCacheUtils.getVStr(key, ZJB_DB_6);

        String appId = StringUtils.defaultIfBlank(configVal, ZJB_COMPONENT_APPID.getValue());

        key = REDIS_CONFIG_INFO_KEY + '_' + ZJB_COMPONENT_SECRET.getKey();
        configVal = JedisPoolCacheUtils.getVStr(key, ZJB_DB_6);

        String secret = StringUtils.defaultIfBlank(configVal, ZJB_COMPONENT_SECRET.getValue());

        String token = JedisPoolCacheUtils.getVStr(GZH_THIRD_COMPONENT_AUTHORIZER_ACCESS_TOKEN + "_" + appId, ZJB_DB_6);
        if (StringUtils.isNotEmpty(token)) {
            return token;
        } else {
            //准备参数
            String ticket = JedisPoolCacheUtils.getVStr(GZH_COMPONENT_VERIFY_TICKET + "_" + appId, ZJB_DB_6);
            HashMap<String, Object> result_map = new HashMap<>();
            result_map.put("component_appid", appId);
            result_map.put("component_appsecret", secret);
            result_map.put("component_verify_ticket", ticket);
            //获取token
            String s = JSONObject.toJSON(result_map).toString();
            String s1 = HttpUtils.sendPost(component_access_token_url, s);
            if (StringUtils.isNotEmpty(s1)) {
                JSONObject jsonObject = JSON.parseObject(s1);
                //第三方平台access_token
                String component_access_token = jsonObject.getString("component_access_token");
                //提前 200s 刷新token
                JedisPoolCacheUtils.setRExpire(GZH_THIRD_COMPONENT_AUTHORIZER_ACCESS_TOKEN + "_" + appId, component_access_token, 7000, ZJB_DB_6);
                return component_access_token;
            }
            return "";
        }
    }

    /**
     * 获取授权方调用api的token
     */

    public static String getAuthorizerAccessToken(String authAppId) {
        String token = JedisPoolCacheUtils.getVStr(GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_TOKEN + "_" + authAppId, ZJB_DB_6);
        if (StringUtils.isEmpty(token)) {
            String key = ZjbConstantsRedis.REDIS_CONFIG_INFO_KEY + '_' + ZJB_COMPONENT_APPID.getKey();
            String configVal = JedisPoolCacheUtils.getVStr(key, ZJB_DB_6);
            String appId = StringUtils.defaultIfBlank(configVal, ZJB_COMPONENT_APPID.getValue());

            String refresh = JedisPoolCacheUtils.getVStr(GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_REFRESH + "_" + authAppId, ZJB_DB_6);
            HashMap<String, Object> result_map = new HashMap<>();
            result_map.put("component_appid", appId);
            result_map.put("authorizer_appid", authAppId);
            result_map.put("authorizer_refresh_token", refresh);

            String s2 = JSON.toJSON(result_map).toString();
            String componentAccessToken = getComponentAccessToken();
            String s = "component_access_token=" + componentAccessToken;
            String post = HttpUtil.post(api_authorizer_token + "?" + s, s2);
            logger.info("换取公众号或小程序的接口调用凭据和授权信息结果:{}", post);
            if (StringUtils.isNotEmpty(post)) {
                JSONObject jsonObject = JSON.parseObject(post);
                String authAccessToken = jsonObject.getString("authorizer_access_token");
                //过期时间
                Integer expiresSeconds = jsonObject.getInteger("expires_in");
                if (null == expiresSeconds) {
                    return null;
                }
                JedisPoolCacheUtils.setRExpire(GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_TOKEN + "_" + authAppId, authAccessToken, expiresSeconds - 200, ZJB_DB_6);
                // 刷新token的token
                String authorizer_refresh_token = jsonObject.getString("authorizer_refresh_token");
                JedisPoolCacheUtils.setRExpire(GZH_THIRD_COMPONENT_AUTHORIZER_AUTHORIZATION_REFRESH + "_" + authAppId, authorizer_refresh_token, EXRP_YEAR, ZJB_DB_6);
                return authAccessToken;
            }
        }
        return token;
    }

    /**
     * 获取关注公众号的用户基本信息
     */
    public static SubscribeUserInfo subscribeUserInfo(String accessToken, String openid) {
        Map<String, String> params = new TreeMap<>();
        params.put("access_token", accessToken);
        params.put("openid", openid);
        params.put("lang", "zh_CN");
        String jsonResult = HttpRequestUtil.HttpDefaultExecute(HttpRequestUtil.GET_METHOD, get_user_info, params, "");
        logger.debug("调用地址{}返回结果：{},请求参数：{}", get_user_info, jsonResult, JSON.toJSONString(params));

        if (StringUtils.isBlank(jsonResult)) {
            return null;
        }
        return JSON.parseObject(jsonResult, SubscribeUserInfo.class);
    }

    /**
     * 获取access_token
     *
     * @param appid     凭证
     * @param appsecret 密钥
     * @return
     */
    public static String getAccessToken(String appid, String appsecret) {

        String result = JedisPoolCacheUtils.getVStr(ZjbConstantsRedis.GZH_TOKEN + "_" + appid + "_" + appsecret, ZJB_DB_6);
        if (StringUtils.isNotEmpty(result)) {
            return result;
        } else {
            result = HttpRequestUtil.getAccessToken(appid, appsecret);
            JSONObject jsonObject = JSON.parseObject(result);
            if (null != jsonObject) {
                result = jsonObject.getString("access_token");
                JedisPoolCacheUtils.setRExpire(ZjbConstantsRedis.GZH_TOKEN + "_" + appid + "_" + appsecret, result, 3600, ZJB_DB_6);
            }
            return result;
        }
    }

    /**
     * 判断用户是否已关注公众号
     */
    public static boolean isSubscribe(String accessToken, String openid) {
        boolean flag = true;
        TreeMap<String, String> params = new TreeMap<>();
        params.put("access_token", accessToken);
        params.put("openid", openid);
        params.put("lang", "zh_CN");
        String jsonResult = HttpRequestUtil.HttpDefaultExecute(HttpRequestUtil.GET_METHOD, get_user_info, params, "");
        JSONObject jsonObject = JSON.parseObject(jsonResult);
        if (null != jsonResult) {
            Integer subscribe = jsonObject.getInteger("subscribe");
            if (subscribe != null) {
                if (0 == subscribe) {
                    flag = false;
                }
            }
        }
        return flag;
    }

    //保存二维码图片到本地
    public static String getBytesFromRemote(String url) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            URL u = new URL(url);
            BufferedImage image = ImageIO.read(u);

            ImageIO.write(image, "jpg", baos);
            baos.flush();
            //文件名
            String name = ZjbFileUtils.getRandomFileName() + ".png";

            String fileKey = "home/zjbadmin/gzhQrode/" +
                    DateUtils.getDate() + "/" +
                    name;
            OssUtil.uploadFile(fileKey, baos.toByteArray());
            return ZjbConstants.File_Domain + "/" + fileKey;
        }
    }

    public static String emoji2Unicode(String src) {
        StringBuffer unicode = new StringBuffer();

        for (int i = 0; i < src.length(); i++) {
            char c = src.charAt(i);
            int codepoint = src.codePointAt(i);
            if (isEmojiCharacter(codepoint)) {
                unicode.append("\\u").append(Integer.toHexString(c));
            } else {
                unicode.append(c);
            }
        }
        return unicode.toString();
    }

    /**
     * 判断是否包含Emoji符号
     *
     * @param codePoint
     * @return
     */
    public static boolean isEmojiCharacter(int codePoint) {
        return (codePoint >= 0x2600 && codePoint <= 0x27BF) // 杂项符号与符号字体
                || codePoint == 0x303D
                || codePoint == 0x2049
                || codePoint == 0x203C
                || (codePoint >= 0x2000 && codePoint <= 0x200F)//
                || (codePoint >= 0x2028 && codePoint <= 0x202F)//
                || codePoint == 0x205F //
                || (codePoint >= 0x2065 && codePoint <= 0x206F)//
                /* 标点符号占用区域 */
                || (codePoint >= 0x2100 && codePoint <= 0x214F)// 字母符号
                || (codePoint >= 0x2300 && codePoint <= 0x23FF)// 各种技术符号
                || (codePoint >= 0x2B00 && codePoint <= 0x2BFF)// 箭头A
                || (codePoint >= 0x2900 && codePoint <= 0x297F)// 箭头B
                || (codePoint >= 0x3200 && codePoint <= 0x32FF)// 中文符号
                || (codePoint >= 0xD800 && codePoint <= 0xDFFF)// 高低位替代符保留区域
                || (codePoint >= 0xE000 && codePoint <= 0xF8FF)// 私有保留区域
                || (codePoint >= 0xFE00 && codePoint <= 0xFE0F)// 变异选择器
                || codePoint >= 0x10000; // Plane在第二平面以上的，char都不可以存，全部都转
    }

    /**
     * 新增永久图文素材
     * */
    public static String addN_news(String token, WeChatNews wechatnews){
        if(StringUtils.isNotBlank(token) && StringUtils.isNotNull(wechatnews)){
            HashMap<String, Object> map = new HashMap<>();
            List data = new ArrayList();
            HashMap<String,Object> map1 = new HashMap<>();
            map1.put("thumb_media_id",wechatnews.getThumbMediaId());
            map1.put("title",wechatnews.getTitle());
            if (StringUtils.isNotBlank(wechatnews.getAuthor())) {
                map1.put("author", wechatnews.getAuthor());
            }
            if (StringUtils.isNotBlank(wechatnews.getContentSourceUrl())) {
                map1.put("content_source_url", wechatnews.getContentSourceUrl());
            }
            map1.put("content",wechatnews.getContent());
            if (StringUtils.isNotBlank(wechatnews.getDigest())){
                map1.put("digest",wechatnews.getDigest());
            }
            if (null != wechatnews.getShowCoverPic()){
                if (wechatnews.getShowCoverPic() == 1){
                    map1.put("show_cover_pic",true);
                }else {
                    map1.put("show_cover_pic",false);
                }
            }else {
                map1.put("show_cover_pic",false);
            }
            if (null != wechatnews.getNeedOpenComment()) {
                map1.put("need_open_comment", wechatnews.getNeedOpenComment());
            }else {
                map1.put("need_open_comment", 0);
            }
            if (null != wechatnews.getOnlyFansCanComment()) {
                map1.put("only_fans_can_comment", wechatnews.getOnlyFansCanComment());
            }else {
                map1.put("only_fans_can_comment", 0);
            }
            data.add(map1);
            map.put("articles",data);
            logger.info("新增永久图文素材==?[{}]",map);
            String url = add_news + token ;
            String s = HttpClient.postForJSON(url, map);
            logger.info("新增永久图文素材==?[{}]",s);
            if(StringUtils.isNotBlank(s)){
                JSONObject jsonObject = JSONObject.parseObject(s);
                WeChatNews weChatNewsResult = new WeChatNews();
                String media_id = jsonObject.getString("media_id");
                if (StringUtils.isNotBlank(media_id)) {
                    return media_id;
                }else {
                    String errcode = jsonObject.getString("errcode");
                    logger.info("新增永久图文素材==?[{}]",s);
                }
            }
        }
        return null;
    }


    /**
     * 上传图文消息素材【订阅号与服务号认证后均可用】
     * */
    public static WeChatNews addNews(String token, WeChatNews wechatnews){
        if(StringUtils.isNotBlank(token) && StringUtils.isNotNull(wechatnews)){
            HashMap<String, Object> map = new HashMap<>();
            List data = new ArrayList();
            HashMap<String,Object> map1 = new HashMap<>();
            map1.put("thumb_media_id",wechatnews.getThumbMediaId());
            map1.put("title",wechatnews.getTitle());
            if (StringUtils.isNotBlank(wechatnews.getAuthor())) {
                map1.put("author", wechatnews.getAuthor());
            }
            if (StringUtils.isNotBlank(wechatnews.getContentSourceUrl())) {
                map1.put("content_source_url", wechatnews.getContentSourceUrl());
            }
            map1.put("content",wechatnews.getContent());
            if (StringUtils.isNotBlank(wechatnews.getDigest())){
                map1.put("digest",wechatnews.getDigest());
            }
            if (null != wechatnews.getShowCoverPic()){
                if (wechatnews.getShowCoverPic() == 1){
                    map1.put("show_cover_pic",true);
                }else {
                    map1.put("show_cover_pic",false);
                }
            }else {
                map1.put("show_cover_pic",false);
            }
            if (null != wechatnews.getNeedOpenComment()) {
                map1.put("need_open_comment", wechatnews.getNeedOpenComment());
            }else {
                map1.put("need_open_comment", 0);
            }
            if (null != wechatnews.getOnlyFansCanComment()) {
                map1.put("only_fans_can_comment", wechatnews.getOnlyFansCanComment());
            }else {
                map1.put("only_fans_can_comment", 0);
            }
            data.add(map1);
            map.put("articles",data);
            logger.info("上传图文消息素材==?[{}]",map);
            String url = uploadnews_url + token ;
            String s = HttpClient.postForJSON(url, map);
            logger.info("上传图文消息素材==?[{}]",s);
            if(StringUtils.isNotBlank(s)){
                JSONObject jsonObject = JSONObject.parseObject(s);
                WeChatNews weChatNewsResult = new WeChatNews();
                String media_id = jsonObject.getString("media_id");
                if (StringUtils.isNotBlank(media_id)) {
                    String type = jsonObject.getString("type");
                    Long created_at = jsonObject.getLong("created_at");
                    String timeStamp = DateUtils.parseTimeStamp(created_at);
                    weChatNewsResult.setMediaId(media_id);
                    weChatNewsResult.setType(type);
                    weChatNewsResult.setCreatedAt(timeStamp);
                    if (StringUtils.isNotBlank(media_id)) {
                        return weChatNewsResult;
                    }
                }else {
                    String errcode = jsonObject.getString("errcode");
					logger.info("上传图文消息素材==?[{}]",s);
                }
            }
        }
        return null;
    }

    /**
     * 上传图文消息内的图片获取URL【订阅号与服务号认证后均可用】
     * */
    public static String uploadimg(File file, String accessToken) throws Exception {
        try {
            if(StringUtils.isBlank(accessToken)){
                return null;
            }
            //上传素材
            //HPb4PQugmc1j0Dxhf7_9U4c3MhGHzvkJGhi7Yi6GZ2s
            String path = uploadimg_url + accessToken;
            String result=HttpRequestUtil.connectHttpsByPost(path, file,false,null,null);
            result=result.replaceAll("[\\\\]", "");

            JSONObject resultJSON=JSON.parseObject(result);
            if(resultJSON!=null){
                if(resultJSON.get("url")!=null){
                    return resultJSON.get("url").toString();
                }
            }
            return null;
        } catch (Exception e) {
            throw e;
        }
    }

    /**
     * 获取上传视频素材id
     * */
    public static String uploadvideo(String token, String mediaId,String title,String description){
        if(StringUtils.isNotBlank(token) && StringUtils.isNotBlank(mediaId)){
            HashMap<String, Object> map = new HashMap<>();
            map.put("media_id",mediaId);
            map.put("title",title);
            map.put("description",description);
            String url = uploadvideo_url + token ;
            String s = HttpClient.postForJSON(url, map);
            logger.info("获取上传视频素材id==?[{}]",s);
            if(StringUtils.isNotBlank(s)){
                JSONObject jsonObject = JSONObject.parseObject(s);
                String media_id = jsonObject.getString("media_id");
                if(StringUtils.isNotBlank(media_id)){
                    return media_id;
                }
            }
        }
        return null;
    }
    /**
     * 上传其他永久素材(图片素材的上限为5000，其他类型为1000)
     * @return
     * @throws Exception
     */
    public static WeChatNews addMaterialImage(File file,String accessToken, String type,boolean isvideo,String title,String introduction) throws Exception {
        try {
            if(StringUtils.isBlank(accessToken)){
                return null;
            }
            //上传素材
            //HPb4PQugmc1j0Dxhf7_9U4c3MhGHzvkJGhi7Yi6GZ2s
            String path = add_mzterial_url+accessToken+"&type="+type;
            System.out.println("地址："+path);
            String result=HttpRequestUtil.connectHttpsByPost(path, file,isvideo,title,introduction);
            result=result.replaceAll("[\\\\]", "");

            JSONObject resultJSON=JSON.parseObject(result);
            logger.info("上传其他永久素材(图片素材):resultJSON=",resultJSON);
            if(resultJSON!=null){
                if(resultJSON.get("media_id")!=null){
                    logger.info("上传其他永久素材(图片素材):resultJSON=>{}",resultJSON);
                    WeChatNews weChatNews = new WeChatNews();
                    String media_id = resultJSON.get("media_id").toString();
                    if (null != resultJSON.get("url")) {
                        String url = resultJSON.get("url").toString();
                        weChatNews.setUrl(url);
                    }
                    weChatNews.setMediaId(media_id);
                    return weChatNews;
                }
            }
            return null;
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return null;
    }

    /**
     * 上传图文消息-upload_url
     * */
    public static WeChatNews upload(File file,String accessToken, String type,boolean isvideo,String title,String introduction) throws Exception {
        try {
            if(StringUtils.isBlank(accessToken)){
                return null;
            }
            //上传素材
            //HPb4PQugmc1j0Dxhf7_9U4c3MhGHzvkJGhi7Yi6GZ2s
            String path = upload_url+accessToken+"&type="+type;
            System.out.println("地址："+path);
            String result=HttpRequestUtil.connectHttpsByPost(path, file,isvideo,title,introduction);
            result=result.replaceAll("[\\\\]", "");

            JSONObject resultJSON=JSON.parseObject(result);
            if(resultJSON!=null){
                if(resultJSON.get("thumb_media_id")!=null){
                    WeChatNews weChatNews = new WeChatNews();
                    String media_id = resultJSON.get("thumb_media_id").toString();
                    if (null != resultJSON.get("type")) {
                        String url = resultJSON.get("type").toString();
                        weChatNews.setUrl(url);
                    }
                    if (resultJSON.get("created_at") != null){
                        Long created_at = resultJSON.getLong("created_at");

                    }
                    weChatNews.setMediaId(media_id);
                    return weChatNews;
                }
            }
            return null;
        } catch (Exception e) {
            logger.info(e.getMessage());
        }
        return null;
    }

    /**
     * 根据标签进行群发【订阅号与服务号认证后均可用】
     * */
    public static WeChatNews sendall(String token, WeChatNews weChatSendall){
        if(StringUtils.isNotBlank(token) && StringUtils.isNotNull(weChatSendall)){
            HashMap<String, Object> map = new HashMap<>();
            if (StringUtils.isNotBlank(weChatSendall.getMsgtype())){
                HashMap<String,Object> map1 = new HashMap<>();
                if (null != weChatSendall.getIsToAll()) {
                    if (1 == weChatSendall.getIsToAll()) {
                        map1.put("tag_id", weChatSendall.getTagId());
                        map1.put("is_to_all", false);
                    } else {
                        map1.put("is_to_all", true);
                    }
                }else {
                    map1.put("is_to_all", true);
                }
                map.put("filter",map1); // 具体参考微信开发文档
                if ("text".equals(weChatSendall.getMsgtype())){
                    //文本消息
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("content",weChatSendall.getContent());
                    map.put("text",map2);
                }else if ("mpnews".equals(weChatSendall.getMsgtype())){
                    //图文消息
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("mpnews",map2);
                    if (null != weChatSendall.getSendIgnoreReprint()) {
                        map.put("send_ignore_reprint", weChatSendall.getSendIgnoreReprint());
                    }else {
                        map.put("send_ignore_reprint", 1);
                    }
                }else if ("voice".equals(weChatSendall.getMsgtype())){
                    //语音/音频
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("voice",map2);
                }else if ("image".equals(weChatSendall.getMsgtype())){
                    //图片
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("image",map2);
                }else if ("mpvideo".equals(weChatSendall.getMsgtype())){
                    //视频
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("mpvideo",map2);
                }else {
                    //卡卷
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("card_id",weChatSendall.getMediaId());
                    map.put("wxcard",map2);
                }
                map.put("msgtype",weChatSendall.getMsgtype());
            }

            String url = sendall_url + token ;
            logger.info("根据标签进行群发url==?[{}]",url);
            String s = HttpClient.postForJSON(url, map);
            logger.info("根据标签进行群发==?[{}]",s);
            if(StringUtils.isNotBlank(s)){
                JSONObject jsonObject = JSONObject.parseObject(s);
                String errmsg = jsonObject.getString("errmsg");
                Integer errcode = jsonObject.getInteger("errcode");
                WeChatNews weChatSendallResult = new WeChatNews();
                if(0 == errcode){
                    String msg_id = jsonObject.getString("msg_id");
                    String msg_data_id = jsonObject.getString("msg_data_id");
                    weChatSendallResult.setErrcode(errcode);
                    weChatSendallResult.setErrmsg(errmsg);
                    weChatSendallResult.setMsgId(msg_id);
                    weChatSendallResult.setMsgDataId(msg_data_id);
                }else {
                    logger.info("根据标签进行群发错误==?[{}]",s);
                    weChatSendallResult.setErrcode(errcode);
                    weChatSendallResult.setErrmsg(errmsg);
                }
                return weChatSendallResult;
            }
        }
        return null;
    }

    /**
     * 根据OpenID列表群发【订阅号不可用，服务号认证后可用】
     * */
    /*public static boolean send(String token, WeChatNews weChatSendall){
        if(StringUtils.isNotBlank(token) && StringUtils.isNotNull(weChatSendall)){
            HashMap<String, Object> map = new HashMap<>();
            if (StringUtils.isNotBlank(weChatSendall.getMsgtype())){
                HashMap<String,Object> map1 = new HashMap<>();
                map.put("touser",weChatSendall.getTouser()); // 具体参考微信开发文档
                if ("text".equals(weChatSendall.getMsgtype())){
                    //文本消息
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("content",weChatSendall.getContent());
                    map.put("text",map2);
                }else if ("mpnews".equals(weChatSendall.getMsgtype())){
                    //图文消息
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("mpnews",map2);
                    map.put("send_ignore_reprint",weChatSendall.getSendIgnoreReprint());
                }else if ("voice".equals(weChatSendall.getMsgtype())){
                    //语音/音频
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("voice",map2);
                }else if ("image".equals(weChatSendall.getMsgtype())){
                    //图片
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map.put("image",map2);
                }else if ("mpvideo".equals(weChatSendall.getMsgtype())){
                    //视频
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("media_id",weChatSendall.getMediaId());
                    map2.put("title",weChatSendall.getTitle());
                    map.put("description",weChatSendall.getDescription());
                    map.put("mpvideo",map2);
                }else {
                    //卡卷
                    HashMap<String, String> map2 = new HashMap<>();
                    map2.put("card_id",weChatSendall.getMediaId());
                    map.put("wxcard",map2);
                }
                map.put("msgtype",weChatSendall.getMsgtype());
            }

            String url = send_url + token ;
            String s = HttpClient.postForJSON(url, map);
            logger.info("根据标签进行群发==?[{}]",s);
            if(StringUtils.isNotBlank(s)){
                JSONObject jsonObject = JSONObject.parseObject(s);
                String errmsg = jsonObject.getString("errmsg");
                int errcode = jsonObject.getIntValue("errcode");
                if("send job submission success".equals(errmsg) && errcode == 0){
                    return true;
                }
            }
        }
        return false;
    }*/
}
