package com.zjb.common.utils;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.*;

public class Base64Utils {
    private static final Logger log = LoggerFactory.getLogger(Base64Utils.class);

    /**
     * 图片转化成base64字符串
     *
     * @param imgPath
     * @return
     */
    public static String GetImageStr(String imgPath) {
        // 待处理的图片
        String imgFile = imgPath;
        // 返回Base64编码过的字节数组字符串
        String encode = null;
        // 对字节数组Base64编码
        BASE64Encoder encoder = new BASE64Encoder();
        try (InputStream in = new FileInputStream(imgFile)) {
            // 读取图片字节数组
            byte[] data = new byte[in.available()];
            in.read(data);
            encode = encoder.encode(data);
        } catch (IOException e) {
            log.error(e.getMessage() , e);
        }

        return encode;
    }

    /**
     * base64字符串转化成图片
     *
     * @param imgData     图片编码
     * @param imgFilePath 存放到本地路径
     * @return
     * @throws IOException
     */
    public static boolean GenerateImage(String imgData , String imgFilePath) throws IOException {
        // 图像数据为空
        if (imgData == null) {
            return false;
        }

        BASE64Decoder decoder = new BASE64Decoder();
        try (OutputStream out = new FileOutputStream(imgFilePath)) {
            // Base64解码
            byte[] b = decoder.decodeBuffer(imgData);
            for (int i = 0; i < b.length; ++i) {
                // 调整异常数据
                if (b[i] < 0) {
                    b[i] += 256;
                }
            }
            out.write(b);
            out.flush();
        } catch (FileNotFoundException e) {
            log.error(e.getMessage() , e);
            return false;
        } catch (IOException e) {
            log.error(e.getMessage() , e);
            return false;
        }

        return true;
    }
}