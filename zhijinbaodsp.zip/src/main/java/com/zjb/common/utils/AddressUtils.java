package com.zjb.common.utils;

import com.alibaba.fastjson.JSONObject;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.utils.http.HttpUtils;
import com.zjb.framework.config.ZjbConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.text.DecimalFormat;

/**
 * 获取地址类
 *
 * @author zjb
 */
public class AddressUtils {
    private static final Logger log = LoggerFactory.getLogger(AddressUtils.class);

    public static final String IP_URL = "http://ip.taobao.com/service/getIpInfo.php";

    public static String getRealAddressByIP(String ip) {
        String address = "XX XX";
        if ("127.0.0.1".equals(ip)) {
            address = "内网IP";
            return address;
        }

        if ("ONLINE".equals(ZjbConstants.ZJB_CURRENT_EVN) && ZjbConfig.isAddressEnabled()) {
            String rspStr = HttpUtils.sendPost(IP_URL , "ip=" + ip);
            if (StringUtils.isBlank(rspStr)) {
                log.warn("获取地理位置异常 {}" , ip);
                return address;
            }
            JSONObject obj = JSONObject.parseObject(rspStr);
            JSONObject data = obj.getObject("data" , JSONObject.class);
            if (StringUtils.isNotNull(data)) {
                String region = data.getString("region");
                String city = data.getString("city");
                String isp = data.getString("isp");
                address = region + " " + city + " " + isp;
            }
        }
        return address;
    }

    // 调用百度地图API根据地址，获取坐标
    public static String getCoordinate(String address) {
        if (address != null && !"".equals(address)) {
            address = address.replaceAll("\\s*" , "").replace("#" , "栋");
            String url = "http://api.map.baidu.com/geocoder/v2/?address=" + address + "&output=json&ak=sysD7HcYmNlwA8ctEYSasO8rALutgtO6";
            String json = loadJSON(url);
            if (json != null && !"".equals(json)) {
                JSONObject obj = JSONObject.parseObject(json);
                if ("0".equals(obj.getString("status"))) {
                    double lng = obj.getJSONObject("result").getJSONObject("location").getDouble("lng"); // 经度
                    double lat = obj.getJSONObject("result").getJSONObject("location").getDouble("lat"); // 纬度
                    DecimalFormat df = new DecimalFormat("#.######");
                    return df.format(lng) + "," + df.format(lat);
                }
            }
        }
        return null;
    }

    public static String loadJSON(String url) {
        StringBuilder json = new StringBuilder();
        try {
            URL oracle = new URL(url);
            URLConnection yc = oracle.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream() , "UTF-8"));
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                json.append(inputLine);
            }
            in.close();
        } catch (MalformedURLException e) {
        } catch (IOException e) {
        }
        return json.toString();
    }
}
