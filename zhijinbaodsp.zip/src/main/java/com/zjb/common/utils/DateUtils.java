package com.zjb.common.utils;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.FastDateFormat;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * 时间工具类
 *
 * @author zjb
 */
public class DateUtils {
    public static String YYYY_MM_DD = "yyyy-MM-dd";

    public static String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";

    public static String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static String YYYY_MM_DD_HH_MM_SS_SSS_24 = "yyyy-MM-dd HH:mm:ss.SSS";

    public static final FastDateFormat DATETIME_FORMAT = FastDateFormat.getInstance(YYYY_MM_DD_HH_MM_SS);
    public static final FastDateFormat DATE_FORMAT = FastDateFormat.getInstance(YYYY_MM_DD);
    public static final FastDateFormat DAY_FORMAT = FastDateFormat.getInstance("yyyyMMdd");
    public static final FastDateFormat FORMAT_DATETIME = FastDateFormat.getInstance(YYYYMMDDHHMMSS);

    /**
     * 获取当前Date型日期
     *
     * @return Date() 当前日期
     */
    public static Date getNowDate() {
        return new Date();
    }

    /**
     * 获取距离1970的毫秒数
     */
    public static long getNowTime() {
        return getNowDate().getTime();
    }

    /**
     * 获取当前日期, 默认格式为yyyy-MM-dd
     *
     * @return String
     */
    public static String getDate() {
        return dateTimeNow(YYYY_MM_DD);
    }

    public static final String getTime() {
        return dateTimeNow(YYYY_MM_DD_HH_MM_SS);
    }

    public static final String dateTimeNow() {
        return dateTimeNow(YYYYMMDDHHMMSS);
    }

    public static final String dateTimeNow(final String format) {
        return parseDateToStr(format, new Date());
    }

    public static final String dateTime(final Date date) {
        return parseDateToStr(YYYY_MM_DD, date);
    }

    public static final String parseDateToStr(final String format, final Date date) {
        return new SimpleDateFormat(format).format(date);
    }

    public static final String parseTimeStampToStr(final long timestamp) {
        SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS);
        Date date = new Date(timestamp);
        String str_date = df.format(date);

        return str_date;
    }

    public static final Date dateTime(final String format, final String ts) {
        try {
            return new SimpleDateFormat(format).parse(ts);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 日期路径 即年/月/日 如2018/08/08
     */
    public static final String datePath() {
        Date now = new Date();
        return DateFormatUtils.format(now, "yyyy/MM/dd");
    }

    /**
     * 日期路径 即年/月/日 如20180808
     */
    public static final String dateTime() {
        Date now = new Date();
        return DateFormatUtils.format(now, "yyyyMMdd");
    }

    /**
     * 计算日期差（秒）
     */
    public static long getDatePoor(Date d1, Date d2, boolean is_sec) {
        // 获得两个时间的毫秒时间差异
        long diff = d1.getTime() - d2.getTime();

        // 计算差多少//输出结果
        if (is_sec) {//秒
            return diff / 1000;
        } else {//毫秒
            return diff;
        }
    }

    public static Date toDate(LocalDateTime localDateTime) {
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zonedDateTime = localDateTime.atZone(zoneId);
        return Date.from(zonedDateTime.toInstant());
    }

    public static Date toDate(LocalDate localDate) {
        ZoneId zoneId = ZoneId.systemDefault();
        ZonedDateTime zonedDateTime = localDate.atStartOfDay(zoneId);
        return Date.from(zonedDateTime.toInstant());
    }

    public static LocalDateTime toLocalDateTime(Date date) {
        Instant instant = date.toInstant();
        ZoneId zone = ZoneId.systemDefault();
        return LocalDateTime.ofInstant(instant, zone);
    }

    /**
     * 耗时
     *
     * @param hs
     * @return
     * @method time
     * @since v1.0
     */
    public static String timeConsuming(long hs) {

        StringBuffer sb = new StringBuffer();

        //天
        long d = hs / org.apache.commons.lang3.time.DateUtils.MILLIS_PER_DAY;

        if (d > 0) {
            hs -= (d * org.apache.commons.lang3.time.DateUtils.MILLIS_PER_DAY);
        }

        //时
        long h = hs / org.apache.commons.lang3.time.DateUtils.MILLIS_PER_HOUR;

        if (h > 0) {
            hs -= (h * org.apache.commons.lang3.time.DateUtils.MILLIS_PER_HOUR);
        }

        //分
        long m = hs / org.apache.commons.lang3.time.DateUtils.MILLIS_PER_MINUTE;

        if (m > 0) {
            hs -= (m * org.apache.commons.lang3.time.DateUtils.MILLIS_PER_MINUTE);
        }

        //秒
        long s = hs / org.apache.commons.lang3.time.DateUtils.MILLIS_PER_SECOND;

        /*毫秒*/
        if (s > 0) {
            hs -= (s * org.apache.commons.lang3.time.DateUtils.MILLIS_PER_SECOND);
        }

        if (d > 0) {
            sb.append(d).append("天").append(h).append("小时").append(m).append("分钟").append(s).append("秒").append(hs).append("毫秒");
        } else if (h > 0) {
            sb.append(h).append("小时").append(m).append("分钟").append(s).append("秒").append(hs).append("毫秒");
        } else if (m > 0) {
            sb.append(m).append("分钟").append(s).append("秒").append(hs).append("毫秒");
        } else if (s > 0) {
            sb.append(s).append("秒").append(hs).append("毫秒");
        } else {
            sb.append(hs).append("毫秒");
        }

        return sb.toString();

    }

    /**
     * 相差天数
     *
     * @param start
     * @param end
     * @return
     * @method diffDays
     * @since v1.0
     */
    public static long diffDays(LocalDate start, LocalDate end) {
        if (null == start || null == end) {
            return 0L;
        }

        long diffDays = start.toEpochDay() - end.toEpochDay();

        return Math.abs(diffDays);
    }

    /**
     * start与end之间相差天数
     *
     * @param start
     * @param end
     * @return
     */
    public static Long diffDays(Date start, Date end) {
        if (null == start || null == end) {
            return 0L;
        }
        return diffDays(toLocalDateTime(start).toLocalDate(), toLocalDateTime(end).toLocalDate());
    }
    /**
     * 获取两个日期之间的所有日期
     *
     * @param startTime
     * @param endTime
     * @return
     */
    public static List<String> getDays(String startTime, String endTime) {
        // 返回的日期集合
        List<String> days = new ArrayList<String>();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            Date start = dateFormat.parse(startTime);
            Date end = dateFormat.parse(endTime);

            Calendar tempStart = Calendar.getInstance();
            tempStart.setTime(start);

            Calendar tempEnd = Calendar.getInstance();
            tempEnd.setTime(end);
            tempEnd.add(Calendar.DATE, +1);// 日期加1(包含结束)
            while (tempStart.before(tempEnd)) {
                days.add(dateFormat.format(tempStart.getTime()));
                tempStart.add(Calendar.DAY_OF_YEAR, 1);
            }

        } catch (ParseException e) {
            e.printStackTrace();
        }

        return days;
    }

    /**
     * 判断date是否在startDate与endDate之间
     * @param date
     * @param startDate
     * @param endDate
     * @return
     */
    public static boolean getDateBetweenStartAndEndDate(Date date,Date startDate,Date endDate){
        boolean result = false;
        if(date == null){
            return false;
        }else{
            Calendar dateCalenda = Calendar.getInstance();
            dateCalenda.setTime(date);
            if(startDate != null && endDate != null){
                Calendar begin = Calendar.getInstance();
                begin.setTime(startDate);
                Calendar end = Calendar.getInstance();
                end.setTime(endDate);
                if(dateCalenda.after(begin) && dateCalenda.before(end)){
                    result = true;
                }else if(date.compareTo(startDate) == 0 || date.compareTo(endDate) == 0){
                    result = true;
                }else{
                    result = false;
                }
            }else if(startDate == null && endDate != null){
                Calendar end = Calendar.getInstance();
                end.setTime(endDate);
                if(dateCalenda.before(end) || date.compareTo(endDate) == 0){
                    result = true;
                }else{
                    result = false;
                }
            }else if(startDate != null && endDate == null){
                Calendar begin = Calendar.getInstance();
                begin.setTime(startDate);
                if(dateCalenda.after(begin) || date.compareTo(startDate) == 0){
                    result = true;
                }else{
                    result = false;
                }

            }else{
                result = true;
            }
        }
        return result;
    }

    /**
     * 获取两个时间之间的分钟差
     * @param startDate
     * @param endDate
     * @return
     */
    public static long getDatePoorMinute(String startDate, String endDate) {
        Date start = dateTime("yyyy-MM-dd HH:mm:ss",startDate);
        Date end = dateTime("yyyy-MM-dd HH:mm:ss",endDate);
        // 获得两个时间的分钟时间差异
        long diff = end.getTime() - start.getTime();
        long nm = 1000 * 60;
        return diff / nm;
    }
	public static final String parseTimeStamp(final long timestamp) {
        SimpleDateFormat df = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS_SSS_24);
        Date date = new Date(timestamp);
        String str_date = df.format(date);

        return str_date;
    }

    /**
     * 获取某个时间之前几分钟
     *
     * @param time
     * @param minute
     * @return
     */
    public static String getBeforeMinute(String time, int minute) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        if (StringUtils.isNotEmpty(time)) {
            try {
                date = sdf.parse(time);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.MINUTE, minute);
        date = calendar.getTime();
        return sdf.format(date);
    }

    /**
     * 当前日期前后几天
     *
     * @param day 负数：前，正数：后
     */
    public static String getBackDate(int day) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Date date = new Date();
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        date = calendar.getTime();

        return sdf.format(date);
    }

    /**
     * 当前日期前后几天
     *
     * @param day 负数：前，正数：后
     */
    public static String getBackDateBegin(int day, String beginDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date;
        try {

            if (StringUtils.isNotBlank(beginDate)) {
                if(beginDate.length() == 10){
                    beginDate = beginDate +" 00:00:00";
                }else if(beginDate.length() != 19)  {
                    //时间格式不正确
                    return null;
                }
                date = sdf.parse(beginDate);
            } else {
                date = new Date();
            }
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, day);
        date = calendar.getTime();

        return sdf.format(date);
    }

    /**
     * 获取某个时间之前或之后几秒时间（正数：之后 负数：之前）
     * @param time
     * @param second
     * @return
     */
    public static String getBeforeSecond(String time, int second) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date = new Date();
        if (StringUtils.isNotEmpty(time)) {
            try {
                date = sdf.parse(time);
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.SECOND, second);
        date = calendar.getTime();
        return sdf.format(date);
    }

}
