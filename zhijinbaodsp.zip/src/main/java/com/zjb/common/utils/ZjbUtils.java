package com.zjb.common.utils;

import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.project.system.role.domain.Role;
import com.zjb.project.system.role.service.IRoleService;
import com.zjb.project.system.user.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;


/**
 * zjb 公共util
 *
 * @author zjb
 */
@Component
public class ZjbUtils {
    @Autowired
    private IRoleService roleService;

    /**
     * 是否管理员
     * @param user User
     * @return boolean
     */
    public boolean isAdmin(User user) {
        boolean isAdmin = false;

        List<Role> lst_roles = roleService.selectRolesByUserId(user.getUserId());
        for(Role role : lst_roles){
            if(role.isFlag()) {
                String role_key = role.getRoleKey();
                if (ZjbDictionaryEnum.ROLE_ADMIN.getValue().equals(role_key)) {
                    isAdmin = true;
                    break;
                }
            }
        }

        return isAdmin;
    }

}
