package com.zjb.common.utils.http;

import java.io.IOException;
import java.io.Serializable;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLException;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.NoHttpResponseException;
import org.apache.http.client.HttpRequestRetryHandler;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.concurrent.FutureCallback;
import org.apache.http.conn.ConnectTimeoutException;
import org.apache.http.conn.ConnectionPoolTimeoutException;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClients;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.nio.reactor.ConnectingIOReactor;
import org.apache.http.nio.reactor.IOReactorException;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.zjb.common.utils.StringUtils;

/**
 * @author songjy
 * @date 2019/08/08
 */
public class HttpClient {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpClient.class);

    /**
     * 从连接池获取连接的超时时间(毫秒)
     */
    public static final int CONNECTION_REQUEST_TIMEOUT = 1000;
    /**
     * 连接建立时间，三次握手完成时间(毫秒)
     */
    public static final int CONNECT_TIMEOUT = 2000;

    /**
     * 数据传输过程中数据包之间间隔的最大时间
     */
    public static final int SOCKET_TIMEOUT = 3000;

    public static final BasicHeader[] HEADERS = {new BasicHeader("user-agent", "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)")};

    public static final Charset DEFAULT_CHARSET = Charset.forName("UTF-8");

    private static final HttpClient INSTANCE = new HttpClient();

    private final static HttpRequestRetryHandler retryHandler = new HttpRequestRetryHandler() {

        /* 允许重连次数 */
        private static final int retryCount = 3;

        @Override
        public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {

            if (executionCount > retryCount) {
                LOGGER.warn("重连{}次失败,放弃", retryCount);
                return false;
            }

            if (exception instanceof UnknownHostException) {
                LOGGER.warn("UnknownHostException丢掉了连接：重连");
                return true;
            }

            if (exception instanceof ConnectTimeoutException) {
                LOGGER.warn("ConnectTimeoutException丢掉了连接：重连");
                return true;
            }

            if (exception instanceof NoHttpResponseException) {
                LOGGER.warn("服务器丢掉了连接：重连");
                return true;
            }

            if (exception instanceof SSLException) {
                LOGGER.warn("SSL握手异常：放弃");
                return false;
            }

            LOGGER.warn("重连次数：{}", executionCount);

            HttpClientContext clientContext = HttpClientContext.adapt(context);
            HttpRequest request = clientContext.getRequest();
            boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);

            if (idempotent) {
                /* 如果请求被认为是幂等的，那么就重试。即重复执行不影响程序其他效果的 */
                LOGGER.warn("请求是幂等：重连 ");
                return true;
            }

            return false;

        }
    };
    /**
     * 配置重连策略
     */
    private final static HttpRequestRetryHandler RETRY_HANDLER = new HttpRequestRetryHandler() {

        /* 允许重连次数 */
        private static final int RETRY_COUNT = 3;

        @Override
        public boolean retryRequest(IOException exception, int executionCount, HttpContext context) {

            if (executionCount > RETRY_COUNT) {
                LOGGER.warn("重连{}次失败,放弃", RETRY_COUNT);
                return false;
            }

            if (exception instanceof UnknownHostException) {
                LOGGER.warn("UnknownHostException丢掉了连接：重连");
                return true;
            }

            if (exception instanceof ConnectTimeoutException) {
                LOGGER.warn("ConnectTimeoutException丢掉了连接：重连");
                return true;
            }

            if (exception instanceof NoHttpResponseException) {
                LOGGER.warn("服务器丢掉了连接：重连");
                return true;
            }

            if (exception instanceof SSLException) {
                LOGGER.warn("SSL握手异常：放弃");
                return false;
            }

            LOGGER.warn("重连次数：{}", executionCount);

            HttpClientContext clientContext = HttpClientContext.adapt(context);
            HttpRequest request = clientContext.getRequest();
            boolean idempotent = !(request instanceof HttpEntityEnclosingRequest);

            if (idempotent) {
                /* 如果请求被认为是幂等的，那么就重试。即重复执行不影响程序其他效果的 */
                LOGGER.warn("请求是幂等：重连 ");
                return true;
            }

            return false;

        }
    };
    /**
     * 配置连接池管理
     */
    private final static PoolingHttpClientConnectionManager CONNECTION_MANAGER = new PoolingHttpClientConnectionManager();
    protected final static CloseableHttpClient HTTP_CLIENT = HttpClients.custom()
            .setRetryHandler(RETRY_HANDLER)
            .setConnectionManager(CONNECTION_MANAGER)
            .build();
    private CloseableHttpAsyncClient closeableHttpAsyncClient;
    private CloseableHttpClient closeableHttpClient;

    /**
     * 默认连接超时设置
     */
    public static final RequestConfig defaultRequestConfig = RequestConfig.custom()
            .setConnectionRequestTimeout(CONNECTION_REQUEST_TIMEOUT)
            .setConnectTimeout(CONNECT_TIMEOUT)
            .setSocketTimeout(SOCKET_TIMEOUT)
            .build();

    /**
     * 单例模式之饿汉模式
     *
     * @return
     */
    public static HttpClient getInstance() {
        return INSTANCE;
    }

    private HttpClient() {

        PoolingHttpClientConnectionManager cm = new PoolingHttpClientConnectionManager();
        cm.setMaxTotal(100);
        cm.setDefaultMaxPerRoute(50);

        closeableHttpClient = HttpClients.custom()
                .setDefaultRequestConfig(defaultRequestConfig)
                .setRetryHandler(retryHandler)
                .setConnectionManager(cm)
                .build();

        /*========异步连接配置处理========*/

        /*配置异步io线程*/
        IOReactorConfig ioReactorConfig = IOReactorConfig.custom()
                .setIoThreadCount(Runtime.getRuntime().availableProcessors())
                .setSoKeepAlive(true)
                .build();

        try {
            ConnectingIOReactor connectingIOReactor = new DefaultConnectingIOReactor(ioReactorConfig);
            PoolingNHttpClientConnectionManager poolingNHttpClientConnectionManager = new PoolingNHttpClientConnectionManager(connectingIOReactor);
            poolingNHttpClientConnectionManager.setMaxTotal(20);
            poolingNHttpClientConnectionManager.setDefaultMaxPerRoute(10);

            closeableHttpAsyncClient = HttpAsyncClients.custom()
                    .setConnectionManager(poolingNHttpClientConnectionManager)
                    .setDefaultRequestConfig(defaultRequestConfig)
                    .build();
        } catch (IOReactorException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }

    /**
     * @param uri
     * @param object
     * @return
     */
    public static String postForJSON(String uri, Serializable object, RequestConfig requestConfig) {
        HttpPost httpPost = new HttpPost(uri);

        if (null != requestConfig) {
            httpPost.setConfig(requestConfig);
        }

        String content = String.class == object.getClass() ? (String) object : JSON.toJSONString(object);
        httpPost.setEntity(new StringEntity(content, ContentType.APPLICATION_JSON));

        try {
            HttpResponse response = getInstance().closeableHttpClient.execute(httpPost);
            LOGGER.info("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            return EntityUtils.toString(entity, DEFAULT_CHARSET);
        } catch (ConnectionPoolTimeoutException e) {
            LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
        } catch (ConnectTimeoutException e) {
            LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
        } catch (SocketTimeoutException e) {
            LOGGER.error(uri + "数据传输超时：" + e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(uri + e.getMessage(), e);
        }

        return null;
    }

    /**
     * @param uri
     * @param object
     * @return
     */
    public static String postForJSON(String uri, Serializable object) {
        HttpPost httpPost = new HttpPost(uri);
        String content = String.class == object.getClass() ? (String) object : JSON.toJSONString(object);
        httpPost.setEntity(new StringEntity(content, ContentType.APPLICATION_JSON));

        try {
            HttpResponse response = HTTP_CLIENT.execute(httpPost);
            LOGGER.debug("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            String json = EntityUtils.toString(entity, DEFAULT_CHARSET);
            if (StringUtils.isBlank(json)) {
                return null;
            }

            char c = json.charAt(0);

            return (c == '{' || c == '[') ? json : null;
        } catch (IOException e) {
            LOGGER.error(e.getMessage(), e);
        }

        return null;
    }

    /**
     * @param uri
     * @param object
     * @param clazz
     * @return
     */
    public static <T> T postForObject(String uri, Serializable object, Class<T> clazz) {
        String json = postForJSON(uri, object, defaultRequestConfig);
        if (StringUtils.isBlank(json) || (json.charAt(0) != '{' && json.charAt(0) != '[')) {
            return null;
        }

        return JSON.parseObject(json, clazz);
    }

    /**
     * @param uri
     * @param requestConfig 请求配置，如超时配置等
     * @param header        头部信息，如：new BasicHeader("user-agent" , "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)")
     * @return
     */
    public static String get(String uri, RequestConfig requestConfig, Header... header) {

        if (null == requestConfig) {
            return get(uri, header);
        }

        HttpGet httpGet = new HttpGet(uri);
        httpGet.setConfig(requestConfig);

        for (Header h : header) {
            httpGet.setHeader(h);
        }

        try {
            HttpResponse response = getInstance().closeableHttpClient.execute(httpGet);
            LOGGER.info("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            return EntityUtils.toString(entity, DEFAULT_CHARSET);
        } catch (ConnectionPoolTimeoutException e) {
            LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
        } catch (ConnectTimeoutException e) {
            LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
        } catch (SocketTimeoutException e) {
            LOGGER.error(uri + "数据传输超时：" + e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(uri + e.getMessage(), e);
        }

        return null;

    }

    /**
     * @param uri
     * @param header,头部信息，如：new BasicHeader("user-agent" , "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)")
     * @return
     */
    public static String get(String uri, Header... header) {
        HttpGet httpGet = new HttpGet(uri);

        for (Header h : header) {
            httpGet.setHeader(h);
        }

        try {
            HttpResponse response = getInstance().closeableHttpClient.execute(httpGet);
            LOGGER.info("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            return EntityUtils.toString(entity, DEFAULT_CHARSET);
        } catch (ConnectionPoolTimeoutException e) {
            LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
        } catch (ConnectTimeoutException e) {
            LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
        } catch (SocketTimeoutException e) {
            LOGGER.error(uri + "数据传输超时：" + e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(uri + e.getMessage(), e);
        }

        return null;
    }

    /**
     * @param uri
     * @param clazz
     * @param header
     * @param <T>
     * @return
     */
    public static <T> T getForObject(String uri, Class<T> clazz, Header... header) {
        String json = get(uri, header);
        if (StringUtils.isBlank(json) || (json.charAt(0) != '{' && json.charAt(0) != '[')) {
            return null;
        }

        return JSON.parseObject(json, clazz);
    }

    /**
     * @param uri
     * @param param
     * @param requestConfig      请求配置，如超时配置等
     * @param headers,头部信息，如：new BasicHeader("user-agent" , "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)")
     * @return
     */
    public static String post(String uri, Map<String, Serializable> param, RequestConfig requestConfig, Header... headers) {
        HttpPost httpPost = new HttpPost(uri);
        for (Header header : headers) {
            httpPost.setHeader(header);
        }

        if (null != requestConfig) {
            httpPost.setConfig(requestConfig);
        }

        if (null != param && !param.isEmpty()) {
            List<NameValuePair> nvps = new ArrayList<>();

            for (Map.Entry<String, Serializable> entry : param.entrySet()) {
                if (StringUtils.isBlank(entry.getKey()) || null == entry.getValue()) {
                    continue;
                }
                nvps.add(new BasicNameValuePair(entry.getKey(), entry.getValue().toString()));
            }

            httpPost.setEntity(new UrlEncodedFormEntity(nvps, DEFAULT_CHARSET));
        }

        try {
            HttpResponse response = getInstance().closeableHttpClient.execute(httpPost);
            LOGGER.debug("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            return EntityUtils.toString(entity, DEFAULT_CHARSET);
        } catch (ConnectionPoolTimeoutException e) {
            LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
        } catch (ConnectTimeoutException e) {
            LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
        } catch (SocketTimeoutException e) {
            LOGGER.warn(uri + "数据传输超时，参数：" + JSON.toJSONString(param), e);
        } catch (IOException e) {
            LOGGER.error(uri + e.getMessage(), e);
        }

        return null;
    }

    /**
     * post异步请求
     *
     * @param uri
     * @param object
     * @return
     */
    public static void postAsyncForJSON(String uri, Serializable object) {
        HttpPost httpPost = new HttpPost(uri);
        String content = String.class == object.getClass() ? (String) object : JSON.toJSONString(object);
        httpPost.setEntity(new StringEntity(content, ContentType.APPLICATION_JSON));
        CloseableHttpAsyncClient client = getInstance().closeableHttpAsyncClient;
        client.start();
        client.execute(httpPost, new FutureCallback<HttpResponse>() {

            private long start = System.currentTimeMillis();

            @Override
            public void completed(HttpResponse response) {
                HttpEntity entity = response.getEntity();
                try {
                    LOGGER.debug("响应状态：{}", response.getStatusLine());

                    LOGGER.debug("调用地址{}，请求数据：{}，返回结果：{}", uri, content, EntityUtils.toString(entity, DEFAULT_CHARSET));

                    LOGGER.debug("耗时(毫秒)：{}", System.currentTimeMillis() - start);
                } catch (ConnectionPoolTimeoutException e) {
                    LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
                } catch (ConnectTimeoutException e) {
                    LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
                } catch (SocketTimeoutException e) {
                    LOGGER.error(uri + "数据传输超时：" + e.getMessage(), e);
                } catch (IOException e) {
                    LOGGER.error(uri + e.getMessage(), e);
                }
            }

            @Override
            public void failed(Exception e) {
                LOGGER.error(e.getMessage(), e);
            }

            @Override
            public void cancelled() {
                LOGGER.warn("cancelled");
            }
        });
    }

    /**
     * @param uri
     * @param header,头部信息，如：new BasicHeader("user-agent" , "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)")
     * @return
     */
    public static byte[] getForBytes(String uri, Header... header) {
        HttpGet httpGet = new HttpGet(uri);

        for (Header h : header) {
            httpGet.setHeader(h);
        }

        try {
            HttpResponse response = getInstance().closeableHttpClient.execute(httpGet);
            LOGGER.info("响应状态：{}", response.getStatusLine());

            HttpEntity entity = response.getEntity();

            return EntityUtils.toByteArray(entity);
        } catch (ConnectionPoolTimeoutException e) {
            LOGGER.error(uri + "获取空闲连接超时" + e.getMessage(), e);
        } catch (ConnectTimeoutException e) {
            LOGGER.error(uri + "建立连接超时：" + e.getMessage(), e);
        } catch (SocketTimeoutException e) {
            LOGGER.error(uri + "数据传输超时：" + e.getMessage(), e);
        } catch (IOException e) {
            LOGGER.error(uri + e.getMessage(), e);
        }

        return null;
    }
}
