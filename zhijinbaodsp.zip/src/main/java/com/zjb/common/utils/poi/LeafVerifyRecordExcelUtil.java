package com.zjb.common.utils.poi;

import com.zjb.common.utils.StringUtils;
import com.zjb.common.utils.bean.BeanUtils;
import com.zjb.common.utils.http.HttpClient;
import com.zjb.framework.aspectj.lang.annotation.Excel;
import com.zjb.framework.web.domain.AjaxResult;
import com.zjb.project.dsp.leafTask.domain.LeafFormField;
import com.zjb.project.dsp.leafVerifyRecord.domain.LeafVerifyRecord;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.CellStyle;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

/**
 * @author songjy
 * @date 2019/09/09
 */
public class LeafVerifyRecordExcelUtil extends ExcelUtil<LeafVerifyRecord> {

    private Logger log = LoggerFactory.getLogger(this.getClass());

    public LeafVerifyRecordExcelUtil(Class<LeafVerifyRecord> clazz) {
        super(clazz);
    }

    /**
     * 按照domain中的excel注解导出
     * 对list数据源将其里面的数据导入到excel表单
     *
     * @param sheetName 工作表的名称
     */
    @Override
    public AjaxResult exportExcel(List<LeafVerifyRecord> list, String sheetName) {
        // 得到所有定义字段
        Collection<Field> allFields = BeanUtils.getAllField(clazz).values();
        List<Field> fields = new ArrayList<>();
        Field userSubmitImgField = null;
        // 得到所有field并存放到一个list中.
        for (Field field : allFields) {

            if (field.getName().equals("userSubmitImg")) {
                userSubmitImgField = field;
                continue;
            }

            if (field.isAnnotationPresent(Excel.class)) {
                fields.add(field);
            }

        }

        /*保证用户提交截图在末尾*/
        fields.add(userSubmitImgField);

        // 产生工作薄对象
        HSSFWorkbook workbook = new HSSFWorkbook();
        // excel2003中每个sheet中最多有65536行
        int sheetSize = 65535;
        // 取出一共有多少个sheet.
        double sheetNo = Math.ceil(list.size() / sheetSize);
        for (int index = 0; index <= sheetNo; index++) {
            // 产生工作表对象
            HSSFSheet sheet = workbook.createSheet();
            HSSFPatriarch patriarch = sheet.createDrawingPatriarch();
            if (sheetNo == 0) {
                workbook.setSheetName(index, sheetName);
            } else {
                // 设置工作表的名称.
                workbook.setSheetName(index, sheetName + index);
            }
            HSSFRow row;
            HSSFCell cell; // 产生单元格

            // 产生一行
            row = sheet.createRow(0);
            // 写入各个字段的列头名称
            for (int i = 0; i < fields.size(); i++) {
                Field field = fields.get(i);
                Excel attr = field.getAnnotation(Excel.class);
                // 创建列
                cell = row.createCell(i);
                // 设置列中写入内容为String类型
                cell.setCellType(HSSFCell.CELL_TYPE_STRING);
                HSSFCellStyle cellStyle = workbook.createCellStyle();
                cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
                cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
                if (attr.name().indexOf("注：") >= 0) {
                    HSSFFont font = workbook.createFont();
                    font.setColor(HSSFFont.COLOR_RED);
                    cellStyle.setFont(font);
                    cellStyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
                    sheet.setColumnWidth(i, 6000);
                } else {
                    HSSFFont font = workbook.createFont();
                    // 粗体显示
                    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
                    // 选择需要用到的字体格式
                    cellStyle.setFont(font);
                    cellStyle.setFillForegroundColor(HSSFColor.LIGHT_YELLOW.index);
                    // 设置列宽
                    sheet.setColumnWidth(i, 3766);
                }
                cellStyle.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                cellStyle.setWrapText(true);
                cell.setCellStyle(cellStyle);

                // 写入列名
                cell.setCellValue(attr.name());

                // 如果设置了提示信息则鼠标放上去提示.
                if (StringUtils.isNotEmpty(attr.prompt())) {
                    // 这里默认设了2-101列提示.
                    setHSSFPrompt(sheet, "", attr.prompt(), 1, 100, i, i);
                }
                // 如果设置了combo属性则本列只能选择不能输入
                if (attr.combo().length > 0) {
                    // 这里默认设了2-101列只能选择不能输入.
                    setHSSFValidation(sheet, attr.combo(), 1, 100, i, i);
                }
            }

            int startNo = index * sheetSize;
            int endNo = Math.min(startNo + sheetSize, list.size());
            // 写入各条记录,每条记录对应excel表中的一行
            HSSFCellStyle cs = workbook.createCellStyle();
            cs.setAlignment(HSSFCellStyle.ALIGN_CENTER);
            cs.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            /*自动换行*/
            cs.setWrapText(true);
            for (int i = startNo; i < endNo; i++) {
                row = sheet.createRow(i + 1 - startNo);
                // 得到导出对象.
                LeafVerifyRecord vo = list.get(i);
                for (int j = 0; j < fields.size(); j++) {
                    // 获得field.
                    Field field = fields.get(j);
                    Object value;
                    try {
                        value = BeanUtils.PROPERTY_UTILS_BEAN.getProperty(vo, field.getName());
                    } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                        log.error(e.getMessage(), e);
                        return AjaxResult.error("导出Excel失败，请联系网站管理员！");
                    }

                    Excel attr = field.getAnnotation(Excel.class);

                    try {
                        // 根据Excel中设置情况决定是否导出,有些情况需要保持为空,希望用户填写这一列.
                        if (!attr.isExport()) {
                            continue;
                        }

                        if (0 == j) {
                            sheet.setColumnWidth(j, 5000);
                        } else if (2 == j) {
                            sheet.setColumnWidth(j, 6000);
                        }

                        // 创建cell
                        cell = row.createCell(j);
                        cell.setCellStyle(cs);

                        if (null == value) {
                            cell.setCellValue("");
                            continue;
                        }

                        /*用户提交截图*/
                        if ("userSubmitImg".equals(field.getName())) {

                            String[] userSubmitImg = vo.getUserSubmitImg();
                            int len = userSubmitImg.length;
                            for (int k = 0; k < len; k++) {

                                int rowNum = row.getRowNum();

                                HSSFClientAnchor anchor = new HSSFClientAnchor();
                                anchor.setRow1(rowNum);
                                anchor.setRow2(rowNum + 1);

                                int columnIndex = cell.getColumnIndex();
                                anchor.setCol1(columnIndex + k);
                                anchor.setCol2(columnIndex + 1 + k);

                                String url = userSubmitImg[k];
                                byte[] bytes = HttpClient.getForBytes(url);
                                String ext = FilenameUtils.getExtension(url);
                                int format = ext.equalsIgnoreCase("png") ? HSSFWorkbook.PICTURE_TYPE_PNG : HSSFWorkbook.PICTURE_TYPE_JPEG;

                                patriarch.createPicture(anchor, workbook.addPicture(bytes, format));
                            }

                            continue;
                        }

                        /*用户提交信息*/
                        if ("leafFormFields".equals(field.getName())) {
                            StringBuffer sb = new StringBuffer();
                            List<LeafFormField> leafFormFields = vo.getLeafFormFields();
                            for (LeafFormField leafFormField : leafFormFields) {
                                sb.append(leafFormField.getFieldName()).append('：').append(leafFormField.getFieldValue()).append("\r\n");
                            }

                            /*自动换行：HSSFRichTextString*/
                            //cell.setCellValue(new HSSFRichTextString(sb.toString().trim()));
                            cell.setCellValue(sb.toString());

                            continue;
                        }

                        /*设置高度*/
                        //row.setHeightInPoints(4 * 15.625F);

                        if (value instanceof Date) {
                            cell.setCellValue(DateFormatUtils.format((Date) value, "yyyy-MM-dd HH:mm:ss"));
                            continue;
                        }

                        cell.setCellValue(value.toString());

                    } catch (Exception e) {
                        log.error("导出Excel失败{}", e.getMessage());
                    }
                }
            }
        }
        try {
            String filename = encodingFilename(sheetName);
            OutputStream out = new FileOutputStream(new File(FileUtils.getTempDirectory(), filename));
            workbook.write(out);
            out.close();
            return AjaxResult.success(filename);
        } catch (Exception e) {
            log.error("关闭flush失败{}", e.getMessage());
            return AjaxResult.error("导出Excel失败，请联系网站管理员！");
        }
    }
}
