package com.zjb.common.utils.shortmsg;

import java.util.HashMap;
import java.util.Map;

import com.aliyuncs.dysmsapi.model.v20170525.SendSmsRequest;
import com.aliyuncs.dysmsapi.model.v20170525.SendSmsResponse;
import com.aliyuncs.exceptions.ClientException;
import com.zjb.common.constant.ZjbConstants;
import com.zjb.common.enums.ZjbDictionaryEnum;
import com.zjb.common.utils.StringUtils;

public class ShortMsgUtils {

    /**
     *
     * @param code
     * @param map_para
     * @param isRealSendMsg 是否真正发送短信
     * @return
     */
    public static Map<String, String> sendSms(String code, Map<String, String> map_para, String isRealSendMsg) {

        Map<String, String> map_rtn = new HashMap<String, String>();
        map_rtn.put("status", ZjbDictionaryEnum.SMS_SUCCESS.getValue());
        map_rtn.put("msg", "");
        if (map_para.get("agencyId") != null && StringUtils.isNotEmpty(map_para.get("agencyId"))){
            map_rtn.put("agencyId",map_para.get("agencyId"));
            map_rtn.put("agencyName",map_para.get("agencyName"));
        }

        try{
            if("DY".equals(ZjbConstants.ZJB_CURRENT_SMS)){
                SendSmsRequest request = getSendSmsRequest(code, map_para);
                map_rtn.put("content", request.getTemplateParam());

                if(("ONLINE".equals(ZjbConstants.ZJB_CURRENT_EVN) || "PRERELEASE".equals(ZjbConstants.ZJB_CURRENT_EVN)) && ZjbConstants.ZJB_SMS_FORCE_SEND.equals(isRealSendMsg)){
                    SendSmsResponse sendSmsResponse = DysmsUtil.sendSms(request);

                    String tmp_code = sendSmsResponse.getCode();
                    String tmp_mess = sendSmsResponse.getMessage();
                    if (tmp_code != null && tmp_code.equals("OK")) {
                        return map_rtn;
                    } else {
                        map_rtn.put("status", ZjbDictionaryEnum.SMS_FAIL.getValue());
                        map_rtn.put("msg", tmp_mess);

                        return map_rtn;
                    }
                }else {
                    return map_rtn;
                }
            }

            return map_rtn;
        }catch (ClientException ce){
            map_rtn.put("status", ZjbDictionaryEnum.SMS_FAIL.getValue());
            map_rtn.put("msg", ce.getMessage());

            return map_rtn;
        }
    }

    /**
     * 根据业务code获取短信内容
     * @param code
     * @return
     */
    private static SendSmsRequest getSendSmsRequest(String code, Map<String, String> map_para){
        SendSmsRequest request = new SendSmsRequest();

        if(ZjbDictionaryEnum.SMS_TONGYONG.getValue().equals(code)){//通用验证码
            request.setPhoneNumbers(map_para.get("phone"));
            request.setSignName("纸巾宝");
            request.setTemplateCode("SMS_148592380");
            request.setTemplateParam("{ 'code':'" + map_para.get("random") + "'}");
        }

        //选填-上行短信扩展码(无特殊需求用户请忽略此字段)
        //request.setSmsUpExtendCode("90997");

        //可选:outId为提供给业务方扩展字段,最终在短信回执消息中将此值带回给调用者
        //request.setOutId("yourOutId");

        return request;
    }
}
