package com.zjb.common.utils;

import com.aliyun.oss.model.*;
import com.zjb.common.constant.ZjbEnvConstants;
import org.apache.shiro.crypto.hash.Md5Hash;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.util.List;

import com.aliyun.oss.ClientException;
import com.aliyun.oss.OSSClient;
import com.aliyun.oss.OSSException;

public class OssUtil {
    private static final Logger logger = LoggerFactory.getLogger(OssUtil.class);

    private static String endpoint = "http://oss-cn-shanghai.aliyuncs.com";

    private static String accessKeyId = "LTAI4Fidzx3X97fBKvqAgAsC";
    private static String accessKeySecret = "rG3l5fkyfOYTLMnH21IfQIUS5O1y2o";

    private static final String bucketName = ZjbEnvConstants.BUCKET_NAME;

    private static int counter = 0;

    private OssUtil() {
    }

    private static OSSClient ossClient;

    public static OSSClient getOssClient() {
        if (ossClient == null) {
            ossClient = new OSSClient(endpoint, accessKeyId, accessKeySecret);
        }

        return ossClient;
    }

    public static void uploadFile(String fileKey, File file) {
        OSSClient tmp_ossClient = getOssClient();
        tmp_ossClient.putObject(bucketName, fileKey, file);
    }

    public static void uploadFile(String fileKey, InputStream inputStream) {
        OSSClient tmp_ossClient = getOssClient();
        tmp_ossClient.putObject(bucketName, fileKey, inputStream);
    }

    public static void uploadFile(String fileKey, byte[] content) {
        OSSClient tmp_ossClient = getOssClient();
        tmp_ossClient.putObject(bucketName, fileKey, new ByteArrayInputStream(content));
    }

    public static void uploadFile(String fileKey, String content) {
        OSSClient tmp_ossClient = getOssClient();
        tmp_ossClient.putObject(bucketName, fileKey, new ByteArrayInputStream(content.getBytes()));
    }

    public static OSSObject downloadFile(String fileKey) {
        OSSClient tmp_ossClient = getOssClient();
        return tmp_ossClient.getObject(bucketName, fileKey);
    }

    public static void deleted(String fileKey) {

        if (StringUtils.isBlank(fileKey)) {
            return;
        }

        OSSClient tmp_ossClient = getOssClient();
        tmp_ossClient.deleteObject(bucketName, fileKey);
    }

    /**
     * 编码文件名
     */
    public static final String encodingFilename(String filename, String extension) {
        filename = filename.replace("_", " ");
        filename = new Md5Hash(filename + System.nanoTime() + counter++).toHex().toString() + extension;
        return filename;
    }

    public static void main(String[] args) {
        logger.info("Started");

        OSSClient ossClient = new OSSClient(endpoint, accessKeyId, accessKeySecret);

        try {
            if (ossClient.doesBucketExist(bucketName)) {
                System.out.println("您已经创建Bucket：" + bucketName + "。");
            } else {
                System.out.println("您的Bucket不存在，创建Bucket：" + bucketName + "。");
                ossClient.createBucket(bucketName);
            }

            BucketInfo info = ossClient.getBucketInfo(bucketName);
            System.out.println("Bucket " + bucketName + "的信息如下：");
            System.out.println("\t数据中心：" + info.getBucket().getLocation());
            System.out.println("\t创建时间：" + info.getBucket().getCreationDate());
            System.out.println("\t用户标志：" + info.getBucket().getOwner());

            InputStream is = new ByteArrayInputStream("Hello OSS".getBytes());
            String firstKey = "my-first-key";
            ossClient.putObject(bucketName, firstKey, is);
            System.out.println("Object：" + firstKey + "存入OSS成功。");

            OSSObject ossObject = ossClient.getObject(bucketName, firstKey);
            InputStream inputStream = ossObject.getObjectContent();
            StringBuilder objectContent = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            while (true) {
                String line = reader.readLine();
                if (line == null) {
                    break;
                }
                objectContent.append(line);
            }
            inputStream.close();
            System.out.println("Object：" + firstKey + "的内容是：" + objectContent);

            String fileKey = "README.md";
            ossClient.putObject(bucketName, fileKey, new File("README.md"));
            System.out.println("Object：" + fileKey + "存入OSS成功。");

            ObjectListing objectListing = ossClient.listObjects(bucketName);
            List<OSSObjectSummary> objectSummary = objectListing.getObjectSummaries();
            System.out.println("您有以下Object：");
            for (OSSObjectSummary object : objectSummary) {
                System.out.println("\t" + object.getKey());
            }

            //ossClient.deleteObject(bucketName, firstKey);
            //System.out.println("删除Object：" + firstKey + "成功。");
            //ossClient.deleteObject(bucketName, fileKey);
            //System.out.println("删除Object：" + fileKey + "成功。");

        } catch (Exception oe) {
            oe.printStackTrace();
        } finally {
            ossClient.shutdown();
        }

        logger.info("Completed");
    }
}
