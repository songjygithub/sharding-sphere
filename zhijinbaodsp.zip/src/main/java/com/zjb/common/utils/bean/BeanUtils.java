package com.zjb.common.utils.bean;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.PropertyUtilsBean;

/**
 * Bean 工具类
 *
 * @author zjb
 */
public class BeanUtils {
    /**
     * Bean方法名中属性名开始的下标
     */
    private static final int BEAN_METHOD_PROP_INDEX = 3;

    /**
     * 匹配getter方法的正则表达式
     */
    private static final Pattern GET_PATTERN = Pattern.compile("get(\\p{javaUpperCase}\\w*)");

    /**
     * 匹配setter方法的正则表达式
     */
    private static final Pattern SET_PATTERN = Pattern.compile("set(\\p{javaUpperCase}\\w*)");

    /**
     * 类对应字段属性, Map<类名, Map<属性名, Field>>
     */
    private static final Map<String, Map<String, Field>> ALL_CLASS_FIELD = new HashMap<>();

    public static final BeanUtilsBean BEAN_UTILS_BEAN = BeanUtilsBean.getInstance();
    public static final PropertyUtilsBean PROPERTY_UTILS_BEAN = BEAN_UTILS_BEAN.getPropertyUtils();

    /**
     * Bean属性复制工具方法。
     *
     * @param dest 目标对象
     * @param src  源对象
     */
    public static void copyBeanProp(Object dest , Object src) {
        List<Method> destSetters = getSetterMethods(dest);
        List<Method> srcGetters = getGetterMethods(src);
        try {
            for (Method setter : destSetters) {
                for (Method getter : srcGetters) {
                    if (isMethodPropEquals(setter.getName() , getter.getName())
                            && setter.getParameterTypes()[0].equals(getter.getReturnType())) {
                        setter.invoke(dest , getter.invoke(src));
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取对象的setter方法。
     *
     * @param obj 对象
     * @return 对象的setter方法列表
     */
    public static List<Method> getSetterMethods(Object obj) {
        // setter方法列表
        List<Method> setterMethods = new ArrayList<Method>();

        // 获取所有方法
        Method[] methods = obj.getClass().getMethods();

        // 查找setter方法

        for (Method method : methods) {
            Matcher m = SET_PATTERN.matcher(method.getName());
            if (m.matches() && (method.getParameterTypes().length == 1)) {
                setterMethods.add(method);
            }
        }
        // 返回setter方法列表
        return setterMethods;
    }

    /**
     * 获取对象的getter方法。
     *
     * @param obj 对象
     * @return 对象的getter方法列表
     */

    public static List<Method> getGetterMethods(Object obj) {
        // getter方法列表
        List<Method> getterMethods = new ArrayList<Method>();
        // 获取所有方法
        Method[] methods = obj.getClass().getMethods();
        // 查找getter方法
        for (Method method : methods) {
            Matcher m = GET_PATTERN.matcher(method.getName());
            if (m.matches() && (method.getParameterTypes().length == 0)) {
                getterMethods.add(method);
            }
        }
        // 返回getter方法列表
        return getterMethods;
    }

    /**
     * 检查Bean方法名中的属性名是否相等。<br>
     * 如getName()和setName()属性名一样，getName()和setAge()属性名不一样。
     *
     * @param m1 方法名1
     * @param m2 方法名2
     * @return 属性名一样返回true，否则返回false
     */

    public static boolean isMethodPropEquals(String m1 , String m2) {
        return m1.substring(BEAN_METHOD_PROP_INDEX).equals(m2.substring(BEAN_METHOD_PROP_INDEX));
    }

    /**
     * 获取指定类所有字段属性信息(忽略与父类同名字段)
     *
     * @param clazz
     * @return key=属性字段名称
     * @method getAllField
     * @since v1.0
     */
    public static Map<String, Field> getAllField(Class<?> clazz) {

        if (null == clazz) {
            return null;
        }

        String className = clazz.getName();
        /* 从缓存中获取结果 */
        Map<String, Field> allField = ALL_CLASS_FIELD.get(className);

        if (null != allField && !allField.isEmpty()) {
            return allField;
        }

        allField = new HashMap<>();

        while (null != clazz) {

            Field[] fields = clazz.getDeclaredFields();

            for (Field field : fields) {

                String fieldName = field.getName();

                if ("serialVersionUID".equals(fieldName)) {
                    /* 忽略序列化标识字段 */
                    continue;
                }

                if (allField.containsKey(fieldName)) {
                    /* 忽略与父类同名字段 */
                    continue;
                }

                allField.put(fieldName , field);
            }

            clazz = clazz.getSuperclass();
        }

        /* 缓存结果 */
        ALL_CLASS_FIELD.put(className , allField);

        return allField;
    }

    /**
     * 对象属性拷贝
     * <p>
     * 源对象属性为NULL则忽略
     * 目标对象属性不为NULL则忽略
     * 属性字段类型不一致则忽略
     * </p>
     *
     * @param source
     * @param target
     */
    public static void copyProperties(Object source , Object target) {
        if (null == source || null == target) {
            return;
        }

        Map<String, Field> fieldSources = getAllField(source.getClass());
        Map<String, Field> fieldTargets = getAllField(target.getClass());

        try {
            for (Map.Entry<String, Field> entry : fieldSources.entrySet()) {
                String fieldName = entry.getKey();
                Field fieldSource = entry.getValue();
                Object valueSource = PROPERTY_UTILS_BEAN.getProperty(source , fieldName);

                if (!fieldTargets.containsKey(fieldName) || null == valueSource
                        || null != PROPERTY_UTILS_BEAN.getProperty(target , fieldName)
                        || fieldTargets.get(fieldName).getType() != fieldSource.getType()) {
                    continue;
                }

                PROPERTY_UTILS_BEAN.setProperty(target , fieldName , valueSource);

            }
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
        }

    }
}
