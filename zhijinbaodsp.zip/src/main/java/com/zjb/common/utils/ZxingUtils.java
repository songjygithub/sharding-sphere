package com.zjb.common.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

/**
 * 二维码
 *
 * @author zjb
 */
public class ZxingUtils {
    /**
     * 生成二维码
     * @param contents 内容字符串
     * @return ByteArrayOutputStream
     * @throws IOException
     * @throws WriterException
     */
    public static ByteArrayOutputStream genQrcode(String contents) throws IOException, WriterException {
        int width = 300;
        int height = 300;
        String format = "png";

        HashMap map = new HashMap();
        map.put(EncodeHintType.CHARACTER_SET, "utf-8");
        map.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        map.put(EncodeHintType.MARGIN, 0);

        ByteArrayOutputStream baos = null;
        try {
            BitMatrix bm = new MultiFormatWriter().encode(contents, BarcodeFormat.QR_CODE, width, height);
            baos = new ByteArrayOutputStream();
            MatrixToImageWriter.writeToStream(bm, format, baos);
        } catch (WriterException e) {
            throw new WriterException(e);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            throw new IOException(e);
        }

        return baos;
    }
}
