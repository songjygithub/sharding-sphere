package com.zjb.common.utils;

import com.zjb.common.enums.ZjbDictionaryEnum;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

public class UserAgentUtil {
    /**
     * 判断 移动端/PC端
     *
     * @param request
     * @return
     * @Title: isMobile
     * @author: pk
     * @Description: TODO
     * @return: boolean
     */
    public static boolean isMobile(HttpServletRequest request) {
        List<String> mobileAgents = Arrays.asList("ipad", "iphone os", "rv:1.2.3.4", "ucweb", "android", "windows ce", "windows mobile");
        String ua = request.getHeader("User-Agent").toLowerCase();
        for (String sua : mobileAgents) {
            if (ua.indexOf(sua) > -1) {
                return true;//手机端
            }
        }
        return false;//PC端
    }

    /**
     * 是否微信浏览器
     *
     * @param request
     * @return: boolean
     */
    public static boolean isWechat(HttpServletRequest request) {
        String ua = request.getHeader("User-Agent").toLowerCase();
        if (ua.indexOf("micromessenger") > -1) {
            return true;//微信
        }
        return false;//非微信手机浏览器

    }

    /**
     * 浏览器类型
     *
     * @param request
     * @return: wx微信，zfb支付宝，其他other
     */
    public static String getBrowserType(HttpServletRequest request) {
        String browserType = ZjbDictionaryEnum.BROWSER_TYPE_OTHER.getValue();//非微信手机浏览器

        String ua = request.getHeader("User-Agent").toLowerCase();
        if(StringUtils.isEmpty(ua)){
            return browserType;//非微信手机浏览器
        }else {
            if (ua.indexOf("micromessenger") > -1) {
                browserType = ZjbDictionaryEnum.BROWSER_TYPE_WX.getValue();//微信
            }else if (ua.indexOf("alipayclient") > -1) {
                browserType = ZjbDictionaryEnum.BROWSER_TYPE_ZFB.getValue();//支付宝
            }
        }

        return browserType;
    }

    /**
     * 区分终端类型
     *
     */
    public static int getDeviceType(HttpServletRequest request) {
        int deviceType = 0 ;//其他手机类型
        String User_Agent = request.getHeader("User-Agent");
        if (User_Agent.contains("Android")) {
            deviceType = 2; //安卓
        }else if(User_Agent.contains("iPhone")){
            deviceType = 1 ; //ios
        }

        return deviceType;
    }

    public static void main(String[] args) {
        List<String> mobileAgents = Arrays.asList("ipad", "iphone os", "rv:1.2.3.4", "ucweb", "android", "windows ce", "windows mobile");
        String ua = "mozilla/5.0 (windows nt 10.0; win64; x64) applewebkit/537.36 (khtml, like gecko) chrome/65.0.3325.146 safari/537.36".toLowerCase();
        for (String sua : mobileAgents) {
            if (ua.indexOf(sua) > -1) {
                System.out.println("移动端");
                return;
            }
        }
        System.out.println("PC端");
    }
}
