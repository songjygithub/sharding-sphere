package com.zjb.common.utils;

import org.apache.commons.beanutils.BeanComparator;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections.ComparatorUtils;
import org.apache.commons.collections.comparators.ComparableComparator;
import org.apache.commons.collections.comparators.ComparatorChain;
import org.apache.commons.lang.ArrayUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * 集合工具类
 * @Auther: Administrator
 * @Date: 2018/8/15 11 15
 * @Description:
 */
public class CollectionUtils extends org.apache.commons.collections.CollectionUtils {

    private final static org.slf4j.Logger logger = LoggerFactory.getLogger(CollectionUtils.class);

    public enum SORT_ORDER {
        ASC("asc"), DESC("desc");
        public String order = "asc";

        SORT_ORDER(String o) {
            this.order = o;
        }
    }

    /**
     * list按照某几个属性排序
     *
     * @param list
     * @param sortFields
     * @param sortOrder
     */
    public static void sortTheList(List list, String[] sortFields, final SORT_ORDER sortOrder) {
        if (isEmpty(list) || list.size() < 1 ||
                sortFields == null || sortFields.length <= 0) {
            return;
        }
        List sorts = new ArrayList();

        Comparator c = ComparableComparator.getInstance();
        c = ComparatorUtils.nullLowComparator(c);
        if (SORT_ORDER.DESC == sortOrder) {
            c = ComparatorUtils.reversedComparator(c);
        }

        String sortField;
        for (int i = 0; i < sortFields.length; i++) {
            sortField = sortFields[i];
            if (!StringUtils.isEmpty(sortField)) {
                sorts.add(new BeanComparator(sortField, c));
            }
        }
        ComparatorChain multiSort = new ComparatorChain(sorts);
        Collections.sort(list, multiSort);
    }

    /**
     * 集合排序
     *
     * @param list
     * @param sortFiled
     * @param sortOrder
     */
    public static void sortTheList(List list, String sortFiled, final SORT_ORDER sortOrder) {
        if (isEmpty(list) || StringUtils.isEmpty(sortFiled)) {
            return;
        }
        String[] sortFields = new String[]{sortFiled};
        sortTheList(list, sortFields, sortOrder);
    }


    /**
     * 将一个集合转化为Map,属性值作为key,集合作为value
     *
     * @param collection
     * @param keyPropertyName
     * @return
     */
    public static Map extractConllectionToMap(final Collection collection, final String keyPropertyName) {
        if (isEmpty(collection) || StringUtils.isEmpty(keyPropertyName)) {
            return new HashMap(0);
        }
        Map map = new LinkedHashMap(collection.size());
        for (Object obj : collection) {
            try {
                map.put(PropertyUtils.getProperty(obj, keyPropertyName), obj);
            } catch (Exception e) {
                logger.error("Fail to extractConllectionToMap ! ", e);
                return map;
            }
        }
        return map;
    }

    /**
     * 提取集合中的两个属性作为key=value对
     *
     * @param collection        集合
     * @param keyPropertyName   key属性
     * @param valuePropertyName value属性
     * @return
     */
    @SuppressWarnings("unchecked")

    public static Map extractPropsToMap(final Collection collection, final String keyPropertyName,
                                        final String valuePropertyName) {
        if (isEmpty(collection) || StringUtils.isEmpty(keyPropertyName)
                || StringUtils.isEmpty(valuePropertyName)) {
            return new HashMap();
        }
        Map map = new LinkedHashMap(collection.size());
        for (Object obj : collection) {
            try {
                map.put(PropertyUtils.getProperty(obj, keyPropertyName),
                        PropertyUtils.getProperty(obj, valuePropertyName));
            } catch (Exception e) {
                logger.error("Fail to extractPropsToMap ! ", e);
                return map;
            }
        }
        return map;
    }


    /**
     * 提取集合中属性所对应的list集合
     *
     * @param collection
     * @param keyPropertyName
     * @param <K>
     * @param <V>
     * @return
     */
    public static <K, V> Map<K, List<V>> convertListToMap(
            final Collection<? extends V> collection, final String keyPropertyName) {
        Map<K, List<V>> result = new LinkedHashMap<>();
        if (isEmpty(collection)) {
            return result;
        }
        try {
            for (V obj : collection) {
                @SuppressWarnings("unchecked")
                K k = (K) PropertyUtils.getProperty(obj, keyPropertyName);
                List<V> list = result.get(k);
                if (list == null) {
                    list = new LinkedList<>();
                }
                list.add(obj);
                result.put(k, list);
            }
        } catch (Exception e) {
            logger.error("Fail to convertListToMap ! ", e);
            return result;
        }
        return result;
    }


    /**
     * 统计集合中某个属性值的个数
     *
     * @param collection
     * @param propertyName
     * @return
     */
    public static Map<Object, Integer> extractConllectionPropCount(
            final Collection collection, final String propertyName) {
        if (isEmpty(collection) || StringUtils.isEmpty(propertyName)) {
            return Collections.emptyMap();
        }
        List list = extractDuplicateProps(collection, propertyName);
        Map<Object, Integer> map = new HashMap<>();
        if (isNotEmpty(list)) {
            for (Object obj : list) {
                Integer count = map.get(obj);
                if (count == null)
                    map.put(obj, 1);
                else
                    map.put(obj, count.intValue() + 1);
            }
        }
        return map;
    }


    /**
     * 提取集合中的某个属性list,这个list做过去重处理
     */
    @SuppressWarnings("unchecked")
    public static List extractUniqueProps(final Collection collection, final String propertyName) {
        if (isEmpty(collection) || StringUtils.isEmpty(propertyName)) {
            return Collections.emptyList();
        }
        List list = new ArrayList(collection.size());
        Set set = new LinkedHashSet(collection.size());
        for (Object obj : collection) {
            if (obj == null) {
                continue;
            }
            try {
                set.add(PropertyUtils.getProperty(obj, propertyName));
            } catch (Exception e) {
                logger.error("Fail to extractUniqueProps ! ", e);
                return list;
            }
        }
        list.addAll(set);
        return list;
    }


    /**
     * 提取集合中的某个属性list,可能会有重复值
     */
    @SuppressWarnings("unchecked")
    public static List extractDuplicateProps(final Collection collection, final String propertyName) {
        if (isEmpty(collection) || StringUtils.isEmpty(propertyName)) {
            return new ArrayList(0);
        }
        List list = new ArrayList(collection.size());
        for (Object obj : collection) {
            if (obj == null) {
                continue;
            }
            try {
                list.add(PropertyUtils.getProperty(obj, propertyName));
            } catch (Exception e) {
                logger.error("Fail to extractDuplicateProps ! ", e);
                return list;
            }
        }
        return list;
    }


    public static String extractToString(final Collection collection, final String propertyName, final String separator) {
        List list = extractDuplicateProps(collection, propertyName);
        return StringUtils.join(list, separator);
    }


    public static String convertToString(final Collection collection, final String separator) {
        if (isEmpty(collection)) {
            return StringUtils.EMPTY;
        }
        return StringUtils.join(collection, separator);
    }


    public static String convertToString(final Collection collection, final String prefix, final String postfix) {
        if (isEmpty(collection)) {
            return StringUtils.EMPTY;
        }
        StringBuilder builder = new StringBuilder();
        for (Object o : collection) {
            builder.append(prefix).append(o).append(postfix);
        }
        return builder.toString();
    }

    public static boolean isEmpty(Collection collection) {
        return (collection == null || collection.isEmpty());
    }

    public static boolean isNotEmpty(Collection collection) {
        return (collection != null && !collection.isEmpty());
    }

    public static <T> T getFirst(Collection<T> collection) {
        if (isEmpty(collection)) {
            return null;
        }
        return collection.iterator().next();
    }

    public static <T> T getLast(Collection<T> collection) {
        if (isEmpty(collection)) {
            return null;
        }
        if (collection instanceof List) {
            List<T> list = (List<T>) collection;
            return list.get(list.size() - 1);
        }
        Iterator<T> iterator = collection.iterator();
        while (true) {
            T current = iterator.next();
            if (!iterator.hasNext()) {
                return current;
            }
        }
    }

    /**
     * <p> 取两个集合的并集 </p>
     *
     * @param a
     * @param b
     * @param <T>
     * @return
     */
    public static <T> List<T> union2(final List<T> a, final List<T> b) {
        List<T> result = new ArrayList<>(a);
        result.addAll(b);
        return result;
    }


    //======================================================
    // Arrays
    //======================================================
    public static Set<String> findDuplicateElement(List<String> elements) {
        final Set<String> setToReturn = new HashSet<>();
        final Set<String> set1 = new HashSet<>();
        for (String yourInt : elements) {
            if (!set1.add(yourInt)) {
                setToReturn.add(yourInt);
            }
        }
        return setToReturn;
    }

    public static List<Long> findDuplicateElement(long[] array) {
        final List<Long> duplicateSet = new ArrayList<>();
        final Set<Long> set = new HashSet<>();
        for (long e : array) {
            if (!set.add(e)) {
                duplicateSet.add(e);
            }
        }
        return duplicateSet;
    }

    public static long[] removeElement(long[] array, long element) {
        if (ArrayUtils.isEmpty(array)) {
            return ArrayUtils.EMPTY_LONG_ARRAY;
        }
        List<Long> list = new ArrayList<>();
        for (long arrayEle : array) {
            if (arrayEle != element) {
                list.add(arrayEle);
            }
        }
        return ArrayUtils.toPrimitive(list.toArray(new Long[list.size()]));
    }
}
