package com.zjb.common.exception.user;

/**
 * 用户密码不正确或不符合规范异常类
 * 
 * @author zjb
 */
public class PhoneCaptcheNotMatchException extends UserException
{

    private static final long serialVersionUID = 1L;

    public PhoneCaptcheNotMatchException()
    {
        super("user.captcha.error", null);
    }
}
