package com.zjb.common.mail;

import cn.hutool.extra.mail.MailUtil;

import java.io.File;
import java.math.BigDecimal;


public class SendMail {

    public static void sendMail(String email , String subject, Integer agencyId, String agencyName, BigDecimal total , String month , String cycle, Integer deviceNum, Integer btTimes, BigDecimal llbt, BigDecimal yj, File file) {
        String s ="<!DOCTYPE html>\n" +
                "\n" +
                "<head>\n" +
                "  <title></title>\n" +
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                "\n" +
                "  <meta charset=\"utf-8\">\n" +
                "</head>\n" +
                "\n" +
                "<body style=\"margin: 0;padding: 0;background-color:#E0F4FF;\">\n" +
                "  <div style=\"\n" +
                "  border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;\n" +
                "    border-radius: 5px;background-color:#E0F4FF;\">\n" +
                "    <img style=\"width:100%;height: 100%;\" src=\"https://file.zhijinbao.net/h5/static/img/mobiletitle3.png\">\n" +
                "  </div>\n" +
                "  <div style=\"border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;\n" +
                "  background-color:#ffffff;\n" +
                " border-radius: 5px;\">\n" +
                "    <img src=\"https://file.zhijinbao.net/h5/static/img/mobilelogo.png\" style=\"margin-top:30px;\n" +
                "    padding-left:25px;width: 80px;display: inline-block;\">\n" +
                "    <img src=\"https://file.zhijinbao.net/h5/static/img/mobiletele.png\" style=\"margin-right:25px;float:right;\n" +
                "    margin-top:40px;width: 160px;display: inline-block;\">\n" +
                "    <p style=\"border-top:2px solid #3597CB;margin-left: 25px;margin-right:25px;\"></p>\n" +
                "    <p style=\"font-size: 17px;text-align:center;font-weight: bold;color: #333333;\">\n"+subject+"</p>\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;\">亲爱的&nbsp;&nbsp;<span\n" +
                "        style=\"color:#3597CB;font-weight: bold;font-size: 16px;\">"+agencyName+"</span>\n" +
                "    </p>\n" +
                "\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;margin-bottom:0;\">\n" +
                "      感谢您对纸巾宝的信任与支持，以下是您的\n" +
                "    </p>\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;margin-top:8px;margin-bottom:0;padding-bottom:10px;\">\n" +
                "      <span style=\"color:#3597CB;font-size: 15px;font-weight: bold;\">"+cycle+"</span>的月度账单\n" +
                "    </p>\n" +
                "  </div>\n" +
                "  <div\n" +
                "    style=\"background: #ffffff;height: 505px;border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;border-radius: 5px;\">\n" +
                "    <p style=\"margin-left: 20px;margin-right: 20px;font-size: 15px;\n" +
                "        padding-bottom: 15px;color: #333333;\n" +
                "    border-bottom: 2px dashed #3597CB;padding-top:23px;margin-bottom:0;\">"+month+"月账单结算金额：\n" +
                "      <span style=\"color: #3597CB;font-size: 18px;\">￥"+total+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;height: 60px;line-height: 60px;margin-right: 20px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">代理商ID</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+agencyId+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">代理商名称</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+agencyName+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">账单周期</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+cycle+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">补贴设备数量</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+deviceNum+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">扫码补贴次数</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+btTimes+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">流量补贴金额</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">￥"+llbt+"</span></p>\n" +
                "    <p style=\"margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">纸巾押金返还金额</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">￥"+yj+"</span></p>\n" +
                "\n" +
                "  </div>\n" +
                "\n" +
                "  <div style=\"height:130px;font-size: 13px;text-align:center;color: #333333;\n" +
                "      background-color: #E0F4FF;border-top: #E0F4FF 20px solid;padding-bottom: 20px;\">\n" +
                "    <p style=\"font-size: 12px;color:#666666;padding:0;margin:0;\">温馨提示：如需了解更多账单详情，请到纸巾宝管理后台中查看</p>\n" +
                "    <p style=\"margin-bottom:10px;\">如对以上账单有异议，代理商请在收到邮件之日起 </p>\n" +
                "    <p style=\"margin-bottom:10px;margin-top: 0;\"> 2日内与纸巾宝平台联系，联系电话：400-015-1788 </p>\n" +
                "    <p style=\"margin-bottom:10px;margin-top: 0;\"> 如2日内未反馈，视为没有异议。 </p>\n" +
                "\n" +
                "  </div>\n" +
                "</body>\n" +
                "\n" +
                "</html>";
        MailUtil.send(email, subject , s, true,file);
    }
    public static void sendMail(String email , String subject, Integer agencyId, String agencyName, BigDecimal total , String month, String cycle, Integer deviceNum, Integer btTimes, BigDecimal llbt, BigDecimal yj) {
        String s ="<!DOCTYPE html>\n" +
                "\n" +
                "<head>\n" +
                "  <title></title>\n" +
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n" +
                "\n" +
                "  <meta charset=\"utf-8\">\n" +
                "</head>\n" +
                "\n" +
                "<body style=\"margin: 0;padding: 0;background-color:#E0F4FF;\">\n" +
                "  <div style=\"\n" +
                "  border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;\n" +
                "    border-radius: 5px;background-color:#E0F4FF;\">\n" +
                "    <img style=\"width:100%;height: 100%;\" src=\"https://file.zhijinbao.net/h5/static/img/mobiletitle3.png\">\n" +
                "  </div>\n" +
                "  <div style=\"border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;\n" +
                "  background-color:#ffffff;\n" +
                " border-radius: 5px;\">\n" +
                "    <img src=\"https://file.zhijinbao.net/h5/static/img/mobilelogo.png\" style=\"margin-top:30px;\n" +
                "    padding-left:25px;width: 80px;display: inline-block;\">\n" +
                "    <img src=\"https://file.zhijinbao.net/h5/static/img/mobiletele.png\" style=\"margin-right:25px;float:right;\n" +
                "    margin-top:40px;width: 160px;display: inline-block;\">\n" +
                "    <p style=\"border-top:2px solid #3597CB;margin-left: 25px;margin-right:25px;\"></p>\n" +
                "    <p style=\"font-size: 17px;text-align:center;font-weight: bold;color: #333333;\">\n"+subject+"</p>\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;\">亲爱的&nbsp;&nbsp;<span\n" +
                "        style=\"color:#3597CB;font-weight: bold;font-size: 16px;\">"+agencyName+"</span>\n" +
                "    </p>\n" +
                "\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;margin-bottom:0;\">\n" +
                "      感谢您对纸巾宝的信任与支持，以下是您的\n" +
                "    </p>\n" +
                "    <p style=\"font-size: 14px;text-align:center;color: #333333;margin-top:8px;margin-bottom:0;padding-bottom:10px;\">\n" +
                "      <span style=\"color:#3597CB;font-size: 15px;font-weight: bold;\">"+cycle+"</span>的月度账单\n" +
                "    </p>\n" +
                "  </div>\n" +
                "  <div\n" +
                "    style=\"background: #ffffff;height: 505px;border-top: #E0F4FF 15px solid;border-left: #E0F4FF 15px solid;border-right: #E0F4FF 15px solid;border-radius: 5px;\">\n" +
                "    <p style=\"margin-left: 20px;margin-right: 20px;font-size: 15px;\n" +
                "        padding-bottom: 15px;color: #333333;\n" +
                "    border-bottom: 2px dashed #3597CB;padding-top:23px;margin-bottom:0;\">"+month+"月账单结算金额：\n" +
                "      <span style=\"color: #3597CB;font-size: 18px;\">￥"+total+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;height: 60px;line-height: 60px;margin-right: 20px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">代理商ID</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+agencyId+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">代理商名称</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+agencyName+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">账单周期</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+cycle+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">补贴设备数量</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+deviceNum+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">扫码补贴次数</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">"+btTimes+"</span></p>\n" +
                "    <p style=\"border-bottom:2px solid #F5F5F5;margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">流量补贴金额</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">￥"+llbt+"</span></p>\n" +
                "    <p style=\"margin:0;margin-left: 20px;margin-right: 20px;height: 60px;line-height: 60px;\n" +
                "    font-size: 16px;\"><span style=\"color:#666666;\">纸巾押金返还金额</span><span\n" +
                "        style=\"font-size: 18px;color: #3597CB;float:right;\">￥"+yj+"</span></p>\n" +
                "\n" +
                "  </div>\n" +
                "\n" +
                "  <div style=\"height:130px;font-size: 13px;text-align:center;color: #333333;\n" +
                "      background-color: #E0F4FF;border-top: #E0F4FF 20px solid;padding-bottom: 20px;\">\n" +
                "    <p style=\"font-size: 12px;color:#666666;padding:0;margin:0;\">温馨提示：如需了解更多账单详情，请到纸巾宝管理后台中查看</p>\n" +
                "    <p style=\"margin-bottom:10px;\">如对以上账单有异议，代理商请在收到邮件之日起 </p>\n" +
                "    <p style=\"margin-bottom:10px;margin-top: 0;\"> 2日内与纸巾宝平台联系，联系电话：400-015-1788 </p>\n" +
                "    <p style=\"margin-bottom:10px;margin-top: 0;\"> 如2日内未反馈，视为没有异议。 </p>\n" +
                "\n" +
                "  </div>\n" +
                "</body>\n" +
                "\n" +
                "</html>";
        MailUtil.send(email, subject , s, true);
    }
}
