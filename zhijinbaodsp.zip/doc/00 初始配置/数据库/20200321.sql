INSERT INTO `zjb_medium_sell_rull` VALUES (6, '个人微信号广告黑名单', '当某个个人微信号命中该规则配置的情况时，系统将该个人微信号加入黑名单，并向指定邮箱发送通知。黑名单的个人微信号在参与竞价时将会被过滤掉。', '个人微信号广告', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,NULL, NULL, 0);

ALTER TABLE `zjb_medium_sell_rull`
  ADD COLUMN `interval_time` int(11) DEFAULT NULL  COMMENT '屏蔽个人微信号时间间隔' AFTER `take_paper_times`;

ALTER TABLE `zjb_medium_sell_rull`
  ADD COLUMN `success_times` int(11) DEFAULT NULL  COMMENT '屏蔽个人微信号胜出次数' AFTER `interval_time`;

ALTER TABLE `zjb_medium_sell_rull`
  ADD COLUMN `success_person` int(11) DEFAULT NULL  COMMENT '屏蔽个人微信号胜出人数' AFTER `success_times`;

ALTER TABLE `zjb_medium_sell_rull`
  ADD COLUMN `receive_alarm_mail` varchar(255) DEFAULT NULL  COMMENT '个人微信号黑名单邮箱' AFTER `success_person`;



CREATE TABLE IF NOT EXISTS `zjb_black_personal_account` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `personal_app_id` VARCHAR (15) NOT NULL DEFAULT '' COMMENT '个人号唯一标识',
  `personal_nick_name` VARCHAR (256) DEFAULT NULL COMMENT '个人号名称',
  `personal_source_type` VARCHAR (256) NOT NULL COMMENT '个人号来源通道(参考字典)',
  `join_black_time` DATETIME DEFAULT NULL COMMENT '本次进入黑名单时间',
  `join_black_count` INT (11) NOT NULL DEFAULT '1' COMMENT '累计进入黑名单次数',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `black_uk_personal_id` (`personal_app_id`),
  KEY `idx_personal_id` (`personal_app_id`,`deleted`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '个人号黑名单';


CREATE TABLE `zjb_grh_push_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personal_app_id` varchar(64) DEFAULT NULL COMMENT '个人号唯一标识',
  `open_id` varchar(64) DEFAULT NULL COMMENT 'openid',
  `view_count` int(11) DEFAULT NULL COMMENT '展示次数',
  `createTime` date DEFAULT NULL COMMENT '创建时间(年月日)',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_personal_appid_openid` (`personal_app_id`,`open_id`) COMMENT '唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='个人号推送记录表';


CREATE TABLE `zjb_advertising_unit_media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertising_id` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '广告id  格式：“15”+id',
  `msgtype` varchar(11) COLLATE utf8_bin DEFAULT NULL COMMENT '参考：zjb_msg_type；群发的消息类型，图文消息为mpnews，文本消息为text，语音为voice，音乐为music，图片为image，视频为video，卡券为wxcard',
  `name` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '广告名称',
  `title` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '消息的标题',
  `author` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '作者',
  `description` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '广告描述',
  `img_url` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '图片地址',
  `digest` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '文章摘要',
  `content` text COLLATE utf8_bin COMMENT '正文',
  `content_source_url` varchar(1024) COLLATE utf8_bin DEFAULT NULL COMMENT '阅读原文地址',
  `count` int(11) DEFAULT NULL COMMENT '推送数量',
  `send_status` int(11) DEFAULT '0' COMMENT '推送状态 zjb_msg_send_status',
  `send_time` datetime DEFAULT NULL COMMENT '推送时间',
  `remark` varchar(225) COLLATE utf8_bin DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='媒体矩阵广告池';

CREATE TABLE `zjb_we_chat_news` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `appid` varchar(225) DEFAULT NULL COMMENT 'appid',
  `news_id` int(11) DEFAULT NULL COMMENT '媒体广告池表id',
  `media_id` varchar(225) DEFAULT NULL COMMENT '素材id',
  `title` varchar(225) DEFAULT NULL COMMENT '标题',
  `thumb_media_id` varchar(225) DEFAULT NULL COMMENT '图文消息缩略图/推送图片 的media_id，微信公众平台',
  `author` varchar(225) DEFAULT NULL COMMENT '图文消息的作者',
  `url` varchar(1024) DEFAULT NULL COMMENT '图文消息缩略图/推送图片 url，微信公众平台',
  `content_source_url` varchar(1024) DEFAULT NULL COMMENT '阅读原文地址',
  `content` text COMMENT '图文消息页面/文本消息 的内容-微信公众平台',
  `digest` varchar(225) DEFAULT NULL COMMENT '描述',
  `show_cover_pic` int(11) DEFAULT '1' COMMENT '是否显示封面，1为显示，0为不显示',
  `need_open_comment` int(11) DEFAULT '1' COMMENT 'Uint32 是否打开评论，0不打开，1打开',
  `only_fans_can_comment` int(11) DEFAULT '0' COMMENT 'Uint32 是否粉丝才可评论，0所有人可评论，1粉丝才可评论',
  `type` varchar(11) DEFAULT NULL COMMENT '媒体文件类型，分别有图片（image）、语音（voice）、视频（video）和缩略图（thumb），图文消息（news）',
  `is_to_all` int(11) DEFAULT '0' COMMENT '0：true；1：false。用于设定是否向全部用户发送，值为true或false，选择true该消息群发给所有用户，选择false可根据tag_id发送给指定群组的用户',
  `tag_id` varchar(225) DEFAULT NULL COMMENT '群发到的标签的tag_id，参见用户管理中用户分组接口，若is_to_all值为true，可不填写tag_id',
  `msgtype` varchar(225) DEFAULT NULL COMMENT '参考：zjb_msg_type；群发的消息类型，图文消息为mpnews，文本消息为text，语音为voice，音乐为music，图片为image，视频为video，卡券为wxcard',
  `send_ignore_reprint` int(11) DEFAULT '1' COMMENT '图文消息被判定为转载时，是否继续群发。 1为继续群发（转载），0为停止群发。 该参数默认为0。',
  `created_at` varchar(225) DEFAULT NULL COMMENT '媒体文件上传时间',
  `errcode` int(11) DEFAULT NULL COMMENT '推送消息错误码',
  `errmsg` varchar(225) DEFAULT NULL COMMENT '推送消息错误信息',
  `msg_id` varchar(225) DEFAULT NULL COMMENT '消息发送任务的ID',
  `msg_data_id` varchar(225) DEFAULT NULL COMMENT '消息的数据ID，该字段只有在群发图文消息时，才会出现。可以用于在图文分析数据接口中，获取到对应的图文消息的数据，是图文分析数据接口中的msgid字段中的前半部分，详见图文分析数据接口中的msgid字段的介绍',
  `remark` varchar(225) DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标识 0：未删除；1：已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=COMPACT COMMENT='推送消息素材表';