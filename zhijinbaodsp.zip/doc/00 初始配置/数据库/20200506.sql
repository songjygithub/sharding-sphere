CREATE TABLE IF NOT EXISTS `zjb_user_cors_device`
(
    `id`               BIGINT(20)   NOT NULL AUTO_INCREMENT COMMENT '自增主键',
    `open_id`          VARCHAR(36)  NOT NULL COMMENT '扫码用户ID',
    `day_scan`         DATE         NOT NULL COMMENT '扫码日期',
    `count_scan`       INT(11)      NOT NULL DEFAULT '0' COMMENT '扫码次数',
    `count_pl`         INT(11)      NOT NULL DEFAULT '0' COMMENT 'PL次数',
    `count_pr`         INT(11)      NOT NULL DEFAULT '0' COMMENT 'PR次数',
    `count_pr_success` INT(11)      NOT NULL DEFAULT '0' COMMENT 'PR成功次数',
    `device_sn`        VARCHAR(36)  NOT NULL COMMENT '设备SN',
    `device_name`      VARCHAR(36)  NOT NULL COMMENT '设备通讯号',
    `agency_id`        INT(11)      NOT NULL COMMENT '设备所属代理商ID',
    `agency_name`      VARCHAR(128) NOT NULL COMMENT '设备所属代理商名称',
    `country`          VARCHAR(36)  NOT NULL DEFAULT '' COMMENT '用户所在国家',
    `province`         VARCHAR(36)  NOT NULL DEFAULT '' COMMENT '用户所在省',
    `city`             VARCHAR(36)  NOT NULL DEFAULT '' COMMENT '用户所在城市',
    `sex`              TINYINT(1)   NOT NULL DEFAULT '0' COMMENT '性别  1:男性，2:女性，0:未知',
    `province_id`      INT(11)               DEFAULT NULL COMMENT '设备所在省编码',
    `province_name`    VARCHAR(36)           DEFAULT NULL COMMENT '设备所在省名称',
    `city_id`          INT(11)               DEFAULT NULL COMMENT '设备所在市编码',
    `city_name`        VARCHAR(36)           DEFAULT NULL COMMENT '设备所在市名称',
    `area_id`          INT(11)               DEFAULT NULL COMMENT '设备所在县编码',
    `area_name`        VARCHAR(36)           DEFAULT NULL COMMENT '设备所在县名称',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_user_device` (`open_id`, `day_scan`, `device_name`)
) ENGINE = INNODB
  DEFAULT CHARSET = utf8mb4 COMMENT ='用户跨设备出纸记录'