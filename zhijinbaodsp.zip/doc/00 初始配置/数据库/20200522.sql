ALTER TABLE `zjb_advertising_unit_fans`
ADD COLUMN `gzh_subscribe_msg`  varchar(255) NULL COMMENT '跳转类型为公众号且出纸流程为关注直接出纸，回复消息' AFTER `take_the_paper_process`;