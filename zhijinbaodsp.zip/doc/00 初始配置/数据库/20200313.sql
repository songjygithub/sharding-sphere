ALTER TABLE `zjb_advertising_combination_unit_fans`
ADD COLUMN `position`  int(11) NULL COMMENT '位置；用于区分同一广告位的不同位置' AFTER `ad_unit_id`;

ALTER TABLE `zjb_device_assign_banner`
ADD COLUMN `ad_position`  int(11) NULL COMMENT '定向投放广告位置 zjb_ad_position' AFTER `ad_name`;
UPDATE zjb_device_assign_banner SET ad_position = 0;