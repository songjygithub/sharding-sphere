ALTER TABLE `zjb_advertising_plan_pepole`
  ADD COLUMN `user_zone` varchar (256) DEFAULT NULL COMMENT '用户位置,多个之间用,分隔，省和市之间用_隔开，如：北京市_北京城区,江苏省_无锡市' AFTER `age_lower_limit`;