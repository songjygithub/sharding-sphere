CREATE TABLE `zjb_autorize_company_third_platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `company_id` int(11) DEFAULT NULL  COMMENT '授权公司主体ID',
  `company_name` varchar(1024) DEFAULT NULL COMMENT '授权公司主体名称',
  `app_id` varchar(50) NOT NULL COMMENT '开放平台APPID',
  `app_secret` varchar(255) NOT NULL COMMENT '开放平台密钥',
  `app_name` varchar(255) NOT NULL COMMENT '开放平台名称',
  `domain_name` varchar(255) NOT NULL  COMMENT '授权域名',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_appid` (`app_id`) COMMENT '唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='授权公司第三方平台表';


ALTER TABLE `zjb_component_authorization_info`
  ADD COLUMN `third_platform_app_id` int(11) DEFAULT NULL  COMMENT '授权公司主体第三方平台ID' AFTER `company_name`;
ALTER TABLE `zjb_component_authorization_info`
  ADD COLUMN `third_platform_app_name` varchar(255) DEFAULT NULL  COMMENT '授权公司主体第三方平台名称' AFTER `third_platform_app_id`;

INSERT INTO `zjb_autorize_company_third_platform` VALUES (1, 1, '杭州数策指今科技有限公司', 'wx70372a6f90bbae02', '19afd0f53e3eadca1a47f827becc4977', '纸巾宝', 'https://hello699.top', NULL, NULL, NULL, NULL, 0);
INSERT INTO `zjb_autorize_company_third_platform` VALUES (2, 2, '杭州小师妹科技有限公司', 'wx171caf46ee5d5cb9', '134e8aaa63740d208a08cac227a2862b', '小师妹', 'https://hello699.top', NULL, NULL, NULL, NULL, 0);
INSERT INTO `zjb_autorize_company_third_platform` VALUES (3, 2, '杭州小师妹科技有限公司', 'wx37429e9eaa7c713b', 'e208450f39a81cc21dddb2a489178ba1', '小师妹引擎', 'http://tuituibao.top', NULL, NULL, NULL, NULL, 0);


UPDATE `zjb_component_authorization_info` SET `third_platform_app_id` = 1,`third_platform_app_name` ='纸巾宝' WHERE `company_id` = 1 AND `third_platform_app_id` is null;

UPDATE `zjb_component_authorization_info` SET `third_platform_app_id` = 2,`third_platform_app_name` ='小师妹' WHERE `company_id` = 2 AND `third_platform_app_id` is null;


ALTER TABLE `zjbdsp`.`zjb_advertising_unit_fans`
ADD COLUMN `ad_url` varchar(512) NULL COMMENT '广告链接' AFTER `probability`;








