ALTER TABLE `zjb_advertising_plan_fans`
  ADD COLUMN `unit_price` DECIMAL(19,4) DEFAULT 0.0000  NOT NULL  COMMENT '广告收益单价(元)' AFTER `total_spend`;

ALTER TABLE `zjb_advertising_plan`
  ADD COLUMN `unit_price` DECIMAL(19,4) DEFAULT 0.0000  NOT NULL  COMMENT '广告收益单价(元)' AFTER `total_spend`;

ALTER TABLE `zjb_advertising_plan_wx`
  ADD COLUMN `unit_price` DECIMAL(19,4) DEFAULT 0.0000  NOT NULL  COMMENT '广告收益单价(元)' AFTER `total_spend`;

ALTER TABLE `zjb_advertising_plan_pay`
  ADD COLUMN `unit_price` DECIMAL(19,4) DEFAULT 0.0000  NOT NULL  COMMENT '广告收益单价(元)' AFTER `total_spend`;