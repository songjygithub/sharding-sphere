CREATE TABLE `zjb_black_third_platform_gzh_temporary` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `third_platform_channel` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台标识(参考字典)',
  `third_platform_app_id` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台公众号唯一标识',
  `third_platform_app_name` VARCHAR (256) DEFAULT NULL COMMENT '第三方平台公众号名称',
  `random_nums` MEDIUMTEXT NULL  COMMENT '用户扫码流水号，多个之间用英文逗号分隔',
  `create_time` datetime DEFAULT NULL COMMENT '生成时间',
  `join_black_type` tinyint(1) DEFAULT NULL COMMENT '加入黑名单类型（1:人数，2:次数）',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`id`),
  KEY `rds_idx_0` (`third_platform_channel`,`deleted`),
  KEY `rds_idx_1` (`third_platform_channel`,`third_platform_app_id`,`deleted`),
  KEY `rds_idx_2` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号黑名单临时表';

CREATE TABLE `zjb_black_personal_account_temporary` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `personal_app_id` varchar(50) NOT NULL DEFAULT '' COMMENT '个人号唯一标识',
  `personal_nick_name` varchar(256) DEFAULT NULL COMMENT '个人号名称',
  `personal_source_type` varchar(256) NOT NULL COMMENT '个人号来源通道(参考字典)',
  `random_nums` MEDIUMTEXT NULL  COMMENT '用户扫码流水号，多个之间用英文逗号分隔',
  `create_time` datetime DEFAULT NULL COMMENT '生成时间',
  `join_black_type` tinyint(1) DEFAULT NULL COMMENT '加入黑名单类型（1:人数，2:次数）',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  KEY `idx_personal_id` (`personal_app_id`,`deleted`),
  KEY `rds_idx_2` (`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='个人号黑名单临时表';




















