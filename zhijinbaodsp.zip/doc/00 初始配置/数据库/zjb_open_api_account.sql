/*
 Navicat Premium Data Transfer

 Source Server         : mac
 Source Server Type    : MySQL
 Source Server Version : 50710
 Source Host           : localhost:3306
 Source Schema         : zjb

 Target Server Type    : MySQL
 Target Server Version : 50710
 File Encoding         : 65001

 Date: 10/08/2019 13:59:01
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for zjb_open_api_account
-- ----------------------------
DROP TABLE IF EXISTS `zjb_open_api_account`;
CREATE TABLE `zjb_open_api_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` varchar(128) DEFAULT NULL COMMENT '唯一标识',
  `secret` varchar(128) DEFAULT NULL COMMENT '密钥',
  `name` varchar(128) DEFAULT NULL COMMENT '名称',
  `out_paper_count` int(11) DEFAULT NULL COMMENT '每个用户每天取纸限制次数',
  `creater_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `gmt_created` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `appid` (`appid`) COMMENT '唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COMMENT='开放平台对接渠道账号申请表';

SET FOREIGN_KEY_CHECKS = 1;
