CREATE TABLE IF NOT EXISTS `zjb_scan_user_backup` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `open_id` VARCHAR (36) NOT NULL COMMENT '用户唯一标识',
  `day_backup` DATE NOT NULL COMMENT '备份日期，yyyy-MM-dd',
  `time_backup` TIME NOT NULL COMMENT '备份时间，HH:mm:ss',
  `json` TEXT NOT NULL COMMENT '对象数据，JSON格式',
  PRIMARY KEY (`id`),
  KEY `uk_open_id` (`open_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '扫码用户信息备份：MongoDB宕机时使用'