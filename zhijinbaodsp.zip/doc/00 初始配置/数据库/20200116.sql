/*
 Navicat Premium Data Transfer

 Source Server         : mac
 Source Server Type    : MySQL
 Source Server Version : 50710
 Source Host           : localhost:3306
 Source Schema         : zjbdsp

 Target Server Type    : MySQL
 Target Server Version : 50710
 File Encoding         : 65001

 Date: 16/01/2020 19:47:56
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for zjb_gzh_push_record
-- ----------------------------
DROP TABLE IF EXISTS `zjb_gzh_push_record`;
CREATE TABLE `zjb_gzh_push_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` varchar(64) DEFAULT NULL COMMENT 'appid',
  `open_id` varchar(64) DEFAULT NULL COMMENT 'openid',
  `view_count` int(11) DEFAULT NULL COMMENT '展示次数',
  `createTime` date DEFAULT NULL COMMENT '创建时间(年月日)',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_appid_openid` (`app_id`,`open_id`) COMMENT '唯一索引'
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='公众号推送记录表';

SET FOREIGN_KEY_CHECKS = 1;
