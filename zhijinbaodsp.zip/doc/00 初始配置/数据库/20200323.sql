CREATE TABLE IF NOT EXISTS `zjb_personal_account_win_record` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `personal_app_id` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '个人号唯一标识',
  `open_id` VARCHAR (50) NOT NULL COMMENT '用户openid',
  `random_num` VARCHAR (50) NOT NULL COMMENT '用户扫码流水号',
  `win_date` DATETIME NOT NULL COMMENT '胜出时间',
  `issue_pl_status` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否下发PL，0：否 1：是',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  KEY `idx_personal_app_id` (`personal_app_id`),
  KEY `idx_personal_id` (`personal_app_id`,`random_num`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '个人号胜出记录';