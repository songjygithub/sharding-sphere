ALTER TABLE `zjb_qq_personal`
  ADD COLUMN `wait_pl_threshold_second` INT (11) DEFAULT 300 NOT NULL COMMENT '个人号胜出到下发PL最大等待时间（秒）' AFTER `delivery_status` ;

ALTER TABLE `zjb_we_chat_personal`
  ADD COLUMN `wait_pl_threshold_second` INT (11) DEFAULT 300 NOT NULL COMMENT '个人号胜出到下发PL最大等待时间（秒）' AFTER `delivery_status` ;