INSERT INTO `zjb_medium_sell_rull` VALUES (8, '指定次数禁投个人号广告', '用户扫描该规则配置的设备进行指定次数取纸时，将自动过滤标记“个人号”标签的广告计划', '指定设备，指定取纸次数', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);

CREATE TABLE `zjb_forbid_put_personal_account_config` (
  `config_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '配置主键',
  `device_id` int(11) DEFAULT NULL COMMENT '设备id',
  `device_name` varchar(50) DEFAULT NULL COMMENT '设备名称',
  `device_sn` varchar(50) DEFAULT NULL COMMENT '设备SN',
  `agency_id` int(11) DEFAULT NULL COMMENT '代理商id',
  `agency_name` varchar(50) DEFAULT NULL COMMENT '代理商名称',
  `install_scene_type_code` varchar(50) DEFAULT NULL COMMENT '安装场景分类编码(参考字典)',
  `install_scene_code` varchar(50) DEFAULT NULL COMMENT '安装场景编码(参考字典)',
  `forbid_put_personal_account_type` int(11) DEFAULT NULL COMMENT '禁投个人号的取纸次数类型(参考字典)',
  `take_paper_times` longtext COMMENT '禁投个人号的取纸次数，多个之间用,分隔',
  `config_status` int(11) DEFAULT NULL COMMENT '指定次数禁投个人号广告配置状态(参考字典)',
  `effective_time` datetime DEFAULT NULL COMMENT '生效时间',
  `lose_efficacy_time` datetime DEFAULT NULL COMMENT '失效时间',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`config_id`),
  KEY `rds_idx_0` (`device_id`,`deleted`),
  KEY `rds_idx_1` (`agency_id`,`deleted`),
  KEY `rds_idx_2` (`device_id`,`config_status`,`deleted`),
  KEY `rds_idx_3` (`agency_id`,`config_status`,`deleted`),
  KEY `rds_idx_4` (`device_id`,`agency_id`,`config_status`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='指定次数禁投个人号广告配置';


ALTER TABLE `zjb_advertising_plan_device`
  ADD COLUMN `is_personal_account` tinyint(1) DEFAULT '0' COMMENT '是否个人号，0:否1:是' AFTER `is_we_chat_account`;

















