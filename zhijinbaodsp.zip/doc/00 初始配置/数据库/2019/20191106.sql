CREATE TABLE `zjb_medium_sell_rull` (
  `rull_id` int(11) NOT NULL AUTO_INCREMENT COMMENT '售卖规则主键',
  `rull_name` varchar(255) DEFAULT NULL COMMENT '售卖规则名称',
  `rull_desc` varchar(1024) DEFAULT NULL COMMENT '售卖规则描述',
  `applied_range` varchar(1024) DEFAULT NULL COMMENT '应用范围',
  `rull_status` int(11) DEFAULT NULL COMMENT '规则使用状态(参考字典)',
  `device_sn` longtext COMMENT '公众号广告规则指定设备SN，多个之间用,分隔',
  `agency_id` longtext COMMENT '公众号广告规则指定代理商ID，多个之间用,分隔',
  `advertising_unit_id` longtext COMMENT '第三方平台在广告任务池中ID，多个之间用,分隔',
  `rull_device_excel` varchar(256) DEFAULT NULL COMMENT '售卖规则指定设备文件名',
  `rull_device_url` varchar(512) DEFAULT NULL COMMENT '售卖规则指定设备文件路径',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`rull_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='媒体售卖规则';

INSERT INTO `zjb_medium_sell_rull` VALUES (1, '禁投金融行业', '学校场景，禁投金融行业广告', '学校场景', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `zjb_medium_sell_rull` VALUES (2, '禁投公众号广告', '该规则配置的设备将自动过滤标记“公众号”标签的广告计划', '已配置的设备', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `zjb_medium_sell_rull` VALUES (3, '标记第三方平台广告', '标记了第三方平台广告的任务，当系统请求广告时间超过预设阈值时，将自动过滤该平台广告', '已配置的广告平台', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);