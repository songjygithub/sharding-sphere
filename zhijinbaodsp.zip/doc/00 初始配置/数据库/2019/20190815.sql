SET FOREIGN_KEY_CHECKS=0;

ALTER TABLE `zjb_advertising_combination`
  ADD COLUMN `template` VARCHAR(11) NULL  COMMENT '广告方案模板类型' AFTER `ad_unit_type`;

-- ----------------------------
-- Table structure for zjb_advertising_unit_wx
-- ----------------------------
DROP TABLE IF EXISTS `zjb_advertising_unit_wx`;
CREATE TABLE `zjb_advertising_unit_wx` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ad_id` varchar(128) DEFAULT NULL COMMENT '业务主键id 格式 “08+id”  zjb_advertising_unit_rule',
  `ad_unit_type` varchar(4) DEFAULT '5' COMMENT '广告产品单元类型，参阅字典：zjb_ad_unit_type',
  `ad_space_identifier` varchar(11) DEFAULT NULL COMMENT '广告位标识  zjb_ad_space_identifier_wx',
  `ad_name` varchar(255) DEFAULT NULL COMMENT '广告名称',
  `information_source` int(11) DEFAULT NULL COMMENT '信息来源 zjb_information_source',
  `ad_photo_url` varchar(1024) DEFAULT NULL COMMENT '广告图片链接',
  `general_name` varchar(255) DEFAULT NULL COMMENT 'tab名称/文字链名称',
  `redirect_url_type` int(11) DEFAULT NULL COMMENT '跳转类型  zjb_redirect_url_type',
  `redirect_url` varchar(1024) DEFAULT NULL COMMENT '跳转路径',
  `ad_from` varchar(255) DEFAULT NULL COMMENT '来源标识,手动输入',
  `ad_use_status` int(11) DEFAULT NULL COMMENT '使用状态 zjb_ad_use_status',
  `supplement_param1` varchar(255) DEFAULT NULL COMMENT '补充id1,跳转辅助参数等',
  `supplement_param2` varchar(255) DEFAULT NULL COMMENT '补充id2，跳转辅助参数等',
  `app_id` varchar(64) DEFAULT NULL COMMENT '小程序标识',
  `titile` varchar(255) DEFAULT NULL COMMENT '标题',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除标识，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_ad_id` (`ad_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告池--微信';

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zjb_advertising_combination_wx
-- ----------------------------
DROP TABLE IF EXISTS `zjb_advertising_combination_wx`;
CREATE TABLE `zjb_advertising_combination_wx` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `com_id` varchar(255) DEFAULT NULL COMMENT '方案编号',
  `name` varchar(255) DEFAULT NULL COMMENT '方案名称',
  `description` varchar(1024) DEFAULT NULL COMMENT '方案描述',
  `program_type` int(11) DEFAULT NULL COMMENT '方案类型  zjb_program_type',
  `ad_unit_type` varchar(4) DEFAULT NULL COMMENT '所属广告产品 zjb_ad_unit_type',
  `template` varchar(11) DEFAULT NULL COMMENT '广告方案模板类型',
  `remark` varchar(255) DEFAULT NULL,
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告方案表-微信';

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zjb_advertising_combination_unit_wx
-- ----------------------------
DROP TABLE IF EXISTS `zjb_advertising_combination_unit_wx`;
CREATE TABLE `zjb_advertising_combination_unit_wx` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `combination_id` int(11) NOT NULL COMMENT '广告方案id,表【zjb_advertising_combination】主键ID',
  `ad_unit_id` int(11) NOT NULL COMMENT '广告id，表【zjb_advertising_unit】主键ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(4) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='广告方案/广告池-微信 中间表';