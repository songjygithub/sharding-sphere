ALTER TABLE `zjbdsp`.`zjb_component_authorization_info` 
ADD COLUMN `leaping_link` varchar(128) NULL COMMENT '直跳链接' AFTER `label_status`;