ALTER TABLE `zjb_leaf_task`
  ADD COLUMN `task_type` VARCHAR(8) DEFAULT ''  NOT NULL  COMMENT '任务类型,1：系统预置类 2：手动交单类' AFTER `task_icon`,
  ADD COLUMN `task_point` VARCHAR(52) DEFAULT ''  NOT NULL  COMMENT '任务要点' AFTER `task_type`,
  ADD COLUMN `gmt_shelf` DATETIME NULL  COMMENT '上架时间' AFTER `leaf_amount`,
  ADD COLUMN `day_delivery_amount` INT(11) NULL  COMMENT '每日投放量' AFTER `show_order`,
  ADD COLUMN `today_consume_amount` INT(11) DEFAULT 0  NOT NULL  COMMENT '当日投放量消耗' AFTER `day_delivery_amount`,
  ADD COLUMN `total_delivery_amount` INT(11) NULL  COMMENT '总投放量' AFTER `today_consume_amount`,
  ADD COLUMN `total_consume_anount` INT(11) DEFAULT 0  NULL  COMMENT '总投放量消耗' AFTER `total_delivery_amount`,
  DROP COLUMN `gmt_shelf`,
  ADD COLUMN `long_term_shelf` INT(11) DEFAULT 0  NOT NULL  COMMENT '任务是否长期有效 0: 指定时间 1:长期有效' AFTER `shelf_status`,
  ADD COLUMN `gmt_shelf_start` DATETIME NULL  COMMENT '上架开始时间' AFTER `long_term_shelf`,
  ADD COLUMN `gmt_shelf_end` DATETIME NULL  COMMENT '上架结束时间' AFTER `gmt_shelf_start`,
  ADD COLUMN `single_user_frequency` INT(11) DEFAULT 0  NULL  COMMENT '单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每个用户每日仅投一次 2：每个用户(openId)仅投一次' AFTER `total_consume_anount`;

CREATE TABLE IF NOT EXISTS `zjb_leaf_verify_record` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `open_id` VARCHAR (64) NOT NULL COMMENT '微信openid或支付宝id',
  `scan_tool` INT (11) NOT NULL DEFAULT '9' COMMENT '完成任务途径(zjb_scan_tool)，1:微信 2:支付宝 9：其它',
  `task_id` VARCHAR(13) NOT NULL COMMENT '小树叶任务业务主键ID，即表【zjb_leaf_task】的字段【task_id】',
  `task_name` VARCHAR (64) NOT NULL COMMENT '任务名称',
  `task_icon` VARCHAR (256) DEFAULT NULL COMMENT '任务图标',
  `task_node_id` BIGINT(20) NOT NULL COMMENT '任务节点唯一标识',
  `task_node` VARCHAR (64) NOT NULL COMMENT '任务节点名称',
  `leaf_amount` INT (11) DEFAULT '0' COMMENT '奖励小树叶数量',
  `gmt_submit` DATETIME NOT NULL COMMENT '用户提交时间',
  `verify_date` DATE NOT NULL COMMENT '用户提交日期',
  `verify_status` INT (2) NOT NULL DEFAULT '0' COMMENT '审核状态，0：待审核 1：审核通过 2：审核不通过',
  `reviewer_id` INT (11) DEFAULT NULL COMMENT '审核人',
  `gmt_verity` DATETIME DEFAULT NULL COMMENT '审核时间',
  `failure_reason` VARCHAR (128) DEFAULT NULL COMMENT '不通过原因',
  PRIMARY KEY (`id`)
  KEY `idex_open_id_date` (`open_id`,`verify_date`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '小树叶发放审核';

CREATE TABLE IF NOT EXISTS `zjb_leaf_issue_record` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `open_id` VARCHAR (64) NOT NULL COMMENT '微信openid或支付宝id',
  `scan_tool` INT (11) NOT NULL COMMENT '广告投放扫码环境(zjb_ scan_tool)，1:微信 2:支付宝 9：其它',
  `task_id` VARCHAR (13) DEFAULT NULL COMMENT '任务业务主键ID，即表【zjb_leaf_task】的字段【task_id】',
  `task_name` VARCHAR (64) NOT NULL COMMENT '任务名称',
  `task_icon` VARCHAR (256) NOT NULL COMMENT '任务图标',
  `task_node_id` INT (11) NOT NULL COMMENT '任务节点唯一标识',
  `task_node` VARCHAR (64) NOT NULL COMMENT '任务节点名称',
  `leaf_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '发放小树叶数量',
  `gmt_issue` DATETIME NOT NULL COMMENT '发放时间',
  `type_issue` VARCHAR (2) NOT NULL DEFAULT '0' COMMENT '发放方式，0：手动发放 1：自动发放',
  `status_issue` VARCHAR (2) NOT NULL DEFAULT '0' COMMENT '发放状态，0：发放成功',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '小树叶发放记录';