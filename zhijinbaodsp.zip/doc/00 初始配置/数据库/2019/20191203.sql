ALTER TABLE `zjb_medium_sell_rull`
ADD COLUMN `take_paper_times` longtext COMMENT '当日取纸次数，多个之间用,分隔' AFTER `advertising_unit_id`;

INSERT INTO `zjb_medium_sell_rull` VALUES (4, '指定次数禁投公众号广告', '用户扫描该规则配置的设备进行指定次数取纸时，将自动过滤标记“公众号”标签的广告计划', '指定设备指定取纸次数', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,NULL, NULL, 0);