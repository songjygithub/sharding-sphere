ALTER TABLE `zjbdsp`.`zjb_gzh_push_ad_info` 
ADD COLUMN `ad_type` varchar(32) NULL COMMENT '跳转类型' AFTER `status`,
ADD COLUMN `appid` varchar(128) NULL COMMENT '微信小程序appid' AFTER `ad_type`,
ADD COLUMN `page_index` varchar(512) NULL COMMENT '微信小程序路径' AFTER `appid`;