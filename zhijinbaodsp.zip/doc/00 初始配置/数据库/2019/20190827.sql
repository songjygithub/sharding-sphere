ALTER TABLE `zjb_scan_task`
  ADD COLUMN `expansion_a_img` VARCHAR(255) NULL  COMMENT '保底广告素材(图片),对应三图广告的第1个广告位置' AFTER `expansion_c`,
  ADD COLUMN `expansion_a_url` VARCHAR(255) NULL  COMMENT '保底广告跳转路径,对应三图广告的第1个广告位置' AFTER `expansion_a_img`,
  ADD COLUMN `expansion_b_img` VARCHAR(255) NULL  COMMENT '保底广告素材(图片),对应三图广告的第2个广告位置' AFTER `expansion_a_url`,
  ADD COLUMN `expansion_b_url` VARCHAR(255) NULL  COMMENT '保底广告跳转路径,对应三图广告的第2个广告位置' AFTER `expansion_b_img`,
  ADD COLUMN `expansion_c_img` VARCHAR(255) NULL  COMMENT '保底广告素材(图片),对应三图广告的第3个广告位置' AFTER `expansion_b_url`,
  ADD COLUMN `expansion_c_url` VARCHAR(255) NULL  COMMENT '保底广告跳转路径,对应三图广告的第3个广告位置' AFTER `expansion_c_img`;

  CREATE TABLE IF NOT EXISTS `zjb_backup_file_record` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `src_file_name` VARCHAR (255) NOT NULL COMMENT '源文件名',
  `backup_file_name` VARCHAR (255) NOT NULL COMMENT '备份文件名',
  `md5` VARCHAR (36) NOT NULL COMMENT '文件MD5',
  `gmt_file_create` DATETIME NOT NULL COMMENT '源文件创建时间',
  `gmt_file_modify` DATETIME NOT NULL COMMENT '源文件修改时间',
  `creater_id` INT (11) NOT NULL COMMENT '备份者ID',
  `gmt_created` DATETIME NOT NULL COMMENT '备份时间',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_md5` (`md5`,`backup_file_name`(100),`local_ip`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '文件备份记录' ;