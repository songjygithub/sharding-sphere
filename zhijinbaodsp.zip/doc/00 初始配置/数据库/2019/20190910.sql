ALTER TABLE `zjb_advertising_plan_device`
  ADD COLUMN `radio_device_sn` INT(2) DEFAULT 0  NOT NULL  COMMENT '设备SN定向，0：不限 1：指定设备 2：不投设备' AFTER `ad_plan_id`,
  ADD COLUMN `radio_device_scene` INT(2) DEFAULT 0 NOT NULL  COMMENT '设备安装场景定向，0:不限 1:指定安装场景 2:不投安装场景' AFTER `device_install_zone`,
  ADD COLUMN `radio_agency_id` INT(2) DEFAULT 0 NOT NULL  COMMENT '代理商定向，0:不限 1:指定代理商 2:不投代理商' AFTER `device_scene`;