ALTER TABLE `zjb_advertising_unit`
ADD COLUMN `out_paper_delay`  int(11) NULL DEFAULT 0 COMMENT '出纸延迟时间 单位毫秒' AFTER `titile`;

ALTER TABLE `zjb_advertising_unit_wx`
ADD COLUMN `out_paper_delay`  int(11) NULL DEFAULT 0 COMMENT '延迟出纸时间 单位毫秒' AFTER `titile`;