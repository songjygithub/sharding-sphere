ALTER TABLE `zjb_user_first_statistics`
  ADD COLUMN `first_auth_we_chat_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次授权微信用户数量' AFTER `first_auth_amount`,
  ADD COLUMN `first_auth_ali_pay_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次授权支付宝用户数量' AFTER `first_auth_we_chat_amount`,
  ADD COLUMN `first_auth_other_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次授权其他用户数量' AFTER `first_auth_ali_pay_amount`;
