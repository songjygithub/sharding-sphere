ALTER TABLE `zjb_advertising_unit`
ADD COLUMN `program_url`  varchar(1024) NULL COMMENT '过渡页跳转小程序或生活号URL' AFTER `redirect_url`;

ALTER TABLE `zjb_advertising_plan_pepole`
  ADD COLUMN `radio_we_chat_official_account` BIGINT(11) DEFAULT 0  NOT NULL  COMMENT '公众号定向，0：不限 1：仅投从未关注过的用户 2：可投已关注且已取关用户' AFTER `custom_label`,
  ADD COLUMN `we_chat_official_accounts` MEDIUMTEXT NULL  COMMENT '公众号，多个之间用英文逗号分隔' AFTER `radio_we_chat_official_account`;

ALTER TABLE `zjb_leaf_income_expenditure_details`
  ADD COLUMN `failure_reason` VARCHAR(128) NULL  COMMENT '不通过原因' AFTER `amount_income_expenditure`;

ALTER TABLE `zjb_component_authorization_info`
  ADD COLUMN `day_delivery_limit` INT(11) NULL  COMMENT '日投放量' AFTER `msg_name`,
  ADD COLUMN `day_follow_amount` INT(11) DEFAULT 0  NOT NULL  COMMENT '日关注量' AFTER `day_delivery_limit`,
  ADD COLUMN `total_delivery_limit` INT(11) NULL  COMMENT '总投放量' AFTER `day_follow_amount`,
  ADD COLUMN `total_follow_amount` INT(11) DEFAULT 0  NULL  COMMENT '总关注量' AFTER `total_delivery_limit`,
  ADD COLUMN `delivery_status` INT(11) DEFAULT 1  NULL  COMMENT '投放状态，1：生效中：公众号状态正常，可正常调用展示给用户关注 2：手动停用：手动停止使用 3：日投放量不足停用：日投放量不足自动停用 总投放量不足停用：总投放量不足自动停用' AFTER `total_follow_amount`;

ALTER TABLE `zjb_advertising_plan`
  ADD COLUMN `ad_app_id` VARCHAR(72) NULL  COMMENT '广告投放投放计划关联的微信公众号（订阅号）' AFTER `participate_bid_percentage`;

ALTER TABLE `zjb_advertising_plan_wx`
  ADD COLUMN `ad_app_id` VARCHAR(72) NULL  COMMENT '广告投放投放计划关联的微信公众号（订阅号）' AFTER `participate_bid_percentage`;