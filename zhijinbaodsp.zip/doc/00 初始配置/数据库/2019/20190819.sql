/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 50710
Source Host           : localhost:3306
Source Database       : zjbdsp

Target Server Type    : MYSQL
Target Server Version : 50710
File Encoding         : 65001

Date: 2019-08-19 17:54:14
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zjb_smallprocedures_unit
-- ----------------------------
DROP TABLE IF EXISTS `zjb_smallprocedures_unit`;
CREATE TABLE `zjb_smallprocedures_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sp_id` varchar(128) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '小程序Id 格式 “06+id”',
  `sp_name` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '小程序名称',
  `sp_describe` varchar(512) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '描述',
  `sp_code` varchar(1024) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '小程序码',
  `remark` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除标识，0：否 1：是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='微信小程序池';

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE IF NOT EXISTS `zjb_advertising_plan_wx` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '主键,广告计划ID',
  `plan_id` VARCHAR (13) NOT NULL DEFAULT '' COMMENT '业务标识自增主键，且必须是05开头，即05 + id',
  `plan_name` VARCHAR (128) NOT NULL COMMENT '广告计划名称',
  `plan_group` VARCHAR (2) NOT NULL DEFAULT '0' COMMENT '广告计划所属广告组(zjb_ad_plan_group),0：通用广告组',
  `combination_id` INT (11) NOT NULL COMMENT '广告方案定向，即表[zjb_advertising_combination_wx]主键ID',
  `plan_bid` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '出价(元)',
  `plan_weight` INT (11) DEFAULT '3' COMMENT '投放权重',
  `day_budget` DECIMAL (19, 4) DEFAULT NULL COMMENT '日预算(元)',
  `total_budget` DECIMAL (19, 4) DEFAULT NULL COMMENT '总预算(元)',
  `today_win_num` INT (11) NOT NULL DEFAULT '0' COMMENT '今日胜出次数',
  `today_spend` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '今日花费(元)',
  `total_win_num` INT (11) NOT NULL DEFAULT '0' COMMENT '总胜出次数',
  `total_spend` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '总花费(元)',
  `participate_bid_num` INT (11) NOT NULL DEFAULT '0' COMMENT '参与竞价次数',
  `bid_win_num` INT (11) DEFAULT '0' COMMENT '竞价胜出次数',
  `gmt_show_start` DATETIME DEFAULT NULL COMMENT '投放开始时间',
  `gmt_show_end` DATETIME DEFAULT NULL COMMENT '投放结束时间',
  `long_term_effective` VARCHAR (1) DEFAULT '0' COMMENT '投放长期有效(zjb_long_term_effective)，0：否 1：是',
  `advertising_status` VARCHAR (1) DEFAULT '1' COMMENT '投放状态(zjb_advertising_status)，1：投放中(正常投放) 2：手动暂停(手动暂停投放) 3：投放时间截至暂停 4：日预算不足暂停 5：总预算不足暂停',
  `category` VARCHAR (2) DEFAULT '0' COMMENT '行业分类(zjb_advertising_category)，0：其它 1：金融',
  `ad_single_user_frequency` INT (11) NOT NULL DEFAULT '0' COMMENT '单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每日仅投一次',
  `participate_bid_percentage` INT (11) DEFAULT NULL COMMENT '参与竞价概率',
  `creater_id` INT (11) NOT NULL COMMENT '创建人',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改人',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wx_plan_id` (`plan_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '广告投放计划(微信)';
