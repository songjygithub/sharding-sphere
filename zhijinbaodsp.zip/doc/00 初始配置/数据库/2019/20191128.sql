ALTER TABLE `zjb_user_first_statistics`
  ADD COLUMN `first_pl_we_chat_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PL微信用户数量' AFTER `first_pl_amount`,
  ADD COLUMN `first_pl_ali_pay_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PL支付宝用户数量' AFTER `first_pl_we_chat_amount`,
  ADD COLUMN `first_pl_other_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PL其他用户数量' AFTER `first_pl_ali_pay_amount`,
  ADD COLUMN `first_pr_we_chat_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PR微信用户数量' AFTER `first_pr_amount`,
  ADD COLUMN `first_pr_ali_pay_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PR支付宝用户数量' AFTER `first_pr_we_chat_amount`,
  ADD COLUMN `first_pr_other_amount` INT DEFAULT 0  NOT NULL  COMMENT '第一次PR其他用户数量' AFTER `first_pr_ali_pay_amount`;
