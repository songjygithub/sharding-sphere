ALTER TABLE `zjb_advertising_plan_device`
  ADD COLUMN `is_finance` TINYINT(1) DEFAULT 0  NOT NULL  COMMENT '是否金融行业，0：否 1：是' AFTER `ad_plan_device_url`,
  ADD COLUMN `is_we_chat_account` TINYINT(1) DEFAULT 0  NOT NULL  COMMENT '是否公众号，0：否 1：是' AFTER `is_finance`;

ALTER TABLE `zjb_advertising_plan`
  ADD COLUMN `is_third_platform` TINYINT(1) DEFAULT 0  NOT NULL  COMMENT '是否第三方平台，0：否 1：是' AFTER `ad_app_id`;

ALTER TABLE `zjb_advertising_plan_wx`
  ADD COLUMN `is_third_platform` TINYINT(1) DEFAULT 0  NOT NULL  COMMENT '是否第三方平台，0：否 1：是' AFTER `ad_app_id`;
