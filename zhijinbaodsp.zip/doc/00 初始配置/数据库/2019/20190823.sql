CREATE TABLE IF NOT EXISTS `zjb_leaf_task` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `task_id` VARCHAR (13) NOT NULL DEFAULT '11' COMMENT '任务ID，11 + id',
  `task_name` VARCHAR (64) NOT NULL COMMENT '任务名称',
  `task_icon` VARCHAR (256) NOT NULL COMMENT '任务图标，即图片地址',
  `task_desc` VARCHAR (128) NOT NULL COMMENT '任务描述',
  `leaf_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '奖励小树叶数量',
  `shelf_status` INT (11) NOT NULL DEFAULT '1' COMMENT '上架状态，0：准备中 1：上架中 2：已下架',
  `task_weight` INT (11) NOT NULL DEFAULT '3' COMMENT '任务权重',
  `show_order` INT (11) NOT NULL DEFAULT '0' COMMENT '展示顺序',
  `task_config` VARCHAR (32) DEFAULT NULL COMMENT '配置，技术对接完成后，生成任务标识，该标识用于识别具体为哪个任务，填入该任务即启用',
  `creater_id` INT (11) NOT NULL COMMENT '创建者',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改者',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_task_id` (`task_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '小树叶任务池' ;