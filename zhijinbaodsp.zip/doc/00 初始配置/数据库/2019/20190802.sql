CREATE TABLE IF NOT EXISTS `zjb_scan_task` (
  `id` INT(11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `task_id` VARCHAR(13) DEFAULT NULL COMMENT '任务唯一ID，即：''02'' + id',
  `task_name` VARCHAR(255) DEFAULT NULL COMMENT '任务名称',
  `task_desc` VARCHAR(255) DEFAULT NULL COMMENT '任务描述',
  `complete_identification` VARCHAR(255) DEFAULT NULL COMMENT '完成标识',
  `configured_number` INT(11) DEFAULT NULL COMMENT '已配置数量',
  `expansion_a` VARCHAR(255) DEFAULT NULL COMMENT '扩展字段a',
  `expansion_b` VARCHAR(255) DEFAULT NULL COMMENT '扩展字段b',
  `expansion_c` VARCHAR(255) DEFAULT NULL COMMENT '扩展字段c',
  `creater_id` INT(11) DEFAULT NULL COMMENT '创建id',
  `modifier_id` INT(11) DEFAULT NULL COMMENT '修改id',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `deleted` TINYINT(1) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `ind_task_id` (`task_id`)
) ENGINE=INNODB DEFAULT CHARSET=utf8mb4 COMMENT='扫码任务配置表'

ALTER TABLE `zjb_advertising_unit`
  ADD COLUMN `app_id` VARCHAR(64) NULL  COMMENT '小程序标识' AFTER `supplement_param2`,
  ADD COLUMN `titile` VARCHAR(255) NULL  COMMENT '标题' AFTER `app_id`;
  
  ALTER TABLE `zjb_advertising_combination`
ADD COLUMN `com_id`  varchar(255) NULL COMMENT '方案编号' AFTER `id`;