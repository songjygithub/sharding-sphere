SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_push_info
-- ----------------------------
DROP TABLE IF EXISTS `sys_push_info`;
CREATE TABLE `sys_push_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键Id',
  `title` varchar(255) NOT NULL COMMENT '标题',
  `content` varchar(255) NOT NULL COMMENT '内容',
  `push_type` int(1) NOT NULL COMMENT '推送类型:1.取纸次数,2.环保等级,3.成就系统',
  `push_require` int(11) NOT NULL COMMENT '推送要求,推送类型对应的值',
  `push_icon` varchar(1024) NOT NULL COMMENT '推送图标',
  `remark` varchar(255) CHARACTER SET utf8mb4 DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除标识，0：否 1：是',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页推送信息表';

CREATE TABLE IF NOT EXISTS `zjb_leaf_home_config` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `config_position` VARCHAR (4) NOT NULL DEFAULT '' COMMENT '配置位置，1：轮播Banner 2：四宫格',
  `show_name` VARCHAR (64) NOT NULL COMMENT '名称',
  `img` VARCHAR (256) NOT NULL COMMENT '图片',
  `jump_type` VARCHAR (8) NOT NULL COMMENT '跳转类型，1：H5 2：小树叶任务',
  `url` VARCHAR (256) DEFAULT NULL COMMENT '跳转路径/任务名称',
  `task_id` VARCHAR(13) DEFAULT NULL COMMENT '任务ID，11 + id，即表【zjb_leaf_task】字段【task_id】',
  `show_order` INT (11) NOT NULL DEFAULT '0' COMMENT '展示顺序',
  `enabled_state` VARCHAR (4) DEFAULT '1' COMMENT '启用状态，0：禁用 1：启用',
  `creater_id` INT (11) NOT NULL COMMENT '创建者',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改者',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '首页配置';

ALTER TABLE `zjb_leaf_task`
  ADD COLUMN `limit_time` TINYINT(1) DEFAULT 0  NULL  COMMENT '是否限时领取，0：否 1：是' AFTER `task_config`,
  ADD COLUMN `high_reward` TINYINT(1) DEFAULT 0  NULL  COMMENT '是否高额奖励，0：否 1：是' AFTER `limit_time`;
