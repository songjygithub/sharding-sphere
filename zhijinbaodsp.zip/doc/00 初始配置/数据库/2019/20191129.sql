
ALTER TABLE `zjbdsp`.`zjb_component_authorization_info` 
ADD COLUMN `record_status` tinyint(1) NULL COMMENT '未认证公众号记录openid开关' AFTER `leaping_link`;

CREATE TABLE `zjb_advertising_combination_fans` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `com_id` varchar(255) DEFAULT NULL COMMENT '方案编号',
  `name` varchar(255) DEFAULT NULL COMMENT '方案名称',
  `description` varchar(1024) DEFAULT NULL COMMENT '方案描述',
  `program_type` int(11) DEFAULT NULL COMMENT '方案类型  zjb_program_type',
  `ad_unit_type` varchar(4) DEFAULT NULL COMMENT '所属广告产品 zjb_ad_unit_type',
  `template` varchar(32) DEFAULT NULL COMMENT '广告方案模板类型',
  `remark` varchar(255) DEFAULT NULL,
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='粉丝通广告方案表';

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `zjb_advertising_combination_unit_fans` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `combination_id` int(11) NOT NULL COMMENT '广告方案id,表【zjb_advertising_combination_fans】主键ID',
  `ad_unit_id` int(11) NOT NULL COMMENT '广告id，表【zjb_advertising_unit_fans】主键ID',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(4) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='广告方案/广告池 中间表';

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `zjb_advertising_plan_fans` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键,广告计划ID',
  `plan_id` varchar(13) NOT NULL DEFAULT '' COMMENT '业务标识自增主键，且必须是01开头，即01 + id',
  `plan_name` varchar(128) NOT NULL COMMENT '广告计划名称',
  `plan_group` varchar(2) NOT NULL DEFAULT '0' COMMENT '广告计划所属广告组(zjb_ad_plan_group),0：通用广告组',
  `combination_id` int(11) NOT NULL COMMENT '广告方案定向，即表[zjb_advertising_combination]主键ID',
  `plan_bid` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '出价(元)',
  `plan_weight` int(11) DEFAULT '3' COMMENT '投放权重',
  `day_budget` decimal(19,4) DEFAULT NULL COMMENT '日预算(元)',
  `total_budget` decimal(19,4) DEFAULT NULL COMMENT '总预算(元)',
  `today_win_num` int(11) NOT NULL DEFAULT '0' COMMENT '今日胜出次数',
  `today_spend` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '今日花费(元)',
  `total_win_num` int(11) NOT NULL DEFAULT '0' COMMENT '总胜出次数',
  `total_spend` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '总花费(元)',
  `participate_bid_num` int(11) NOT NULL DEFAULT '0' COMMENT '参与竞价次数',
  `bid_win_num` int(11) DEFAULT '0' COMMENT '竞价胜出次数',
  `gmt_show_start` datetime DEFAULT NULL COMMENT '投放开始时间',
  `gmt_show_end` datetime DEFAULT NULL COMMENT '投放结束时间',
  `long_term_effective` varchar(1) DEFAULT '0' COMMENT '投放长期有效(zjb_long_term_effective)，0：否 1：是',
  `advertising_status` varchar(1) DEFAULT '1' COMMENT '投放状态(zjb_advertising_status)，1：投放中(正常投放) 2：手动暂停(手动暂停投放) 3：投放时间截至暂停 4：日预算不足暂停 5：总预算不足暂停',
  `category` varchar(2) DEFAULT '0' COMMENT '行业分类(zjb_advertising_category)，0：其它 1：金融',
  `ad_single_user_frequency` int(11) NOT NULL DEFAULT '0' COMMENT '单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每日仅投一次',
  `participate_bid_percentage` int(11) DEFAULT NULL COMMENT '参与竞价概率',
  `ad_app_id` varchar(72) DEFAULT NULL COMMENT '广告投放投放计划关联的微信公众号（订阅号）',
  `is_third_platform` int(1) NOT NULL DEFAULT '0' COMMENT '是否第三方平台，0：否 1：是',
  `component_authorization_type` int(1) DEFAULT '0' COMMENT '公众号授权类型（参考字典）',
  `creater_id` int(11) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier_id` int(11) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_plan_id` (`plan_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='粉丝通广告投放计划';

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE `zjb_advertising_unit_fans` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ad_id` varchar(128) DEFAULT NULL COMMENT '业务主键id 格式 “01+id”',
  `ad_unit_type` varchar(4) DEFAULT NULL COMMENT '广告产品单元类型，参阅字典：zjb_ad_unit_type',
  `ad_space_identifier` varchar(11) DEFAULT NULL COMMENT '广告位标识  zjb_ad_space_identifier',
  `ad_name` varchar(255) DEFAULT NULL COMMENT '广告名称',
  `information_source` int(11) DEFAULT NULL COMMENT '信息来源 zjb_information_source',
  `ad_photo_url` varchar(1024) DEFAULT NULL COMMENT '广告图片链接',
  `general_name` varchar(255) DEFAULT NULL COMMENT 'tab名称/文字链名称',
  `redirect_url_type` int(11) DEFAULT NULL COMMENT '跳转类型  zjb_redirect_url_type',
  `redirect_url` varchar(1024) DEFAULT NULL COMMENT '跳转路径',
  `program_url` varchar(1024) DEFAULT NULL COMMENT '过渡页跳转小程序或生活号URL',
  `ad_from` varchar(255) DEFAULT NULL COMMENT '来源标识,手动输入',
  `ad_use_status` int(11) DEFAULT NULL COMMENT '使用状态 zjb_ad_use_status',
  `supplement_param1` varchar(255) DEFAULT NULL COMMENT '补充id1,跳转辅助参数等',
  `supplement_param2` varchar(255) DEFAULT NULL COMMENT '补充id2，跳转辅助参数等',
  `app_id` varchar(64) DEFAULT NULL COMMENT '小程序标识',
  `titile` varchar(255) DEFAULT NULL COMMENT '标题',
  `out_paper_delay` int(11) DEFAULT '0' COMMENT '出纸延迟时间 单位毫秒',
  `we_chat_account` varchar(32) DEFAULT NULL COMMENT '微信公众号ID，即表【zjb_component_authorization_info】字段【component_id】',
  `we_chat_account_name` varchar(64) DEFAULT NULL COMMENT '微信公众号名称',
  `take_the_paper_process` varchar(255) DEFAULT NULL COMMENT '取纸流程',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除标识，0：否 1：是',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `index_ad_id` (`ad_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='粉丝通广告池表';

SET FOREIGN_KEY_CHECKS = 1;