ALTER TABLE `zjbdsp`.`zjb_component_authorization_info` 
ADD COLUMN `label_id` int(11) NULL COMMENT '标签ID' AFTER `delivery_status`,
ADD COLUMN `label_name` varchar(128) NULL COMMENT '标签名称' AFTER `label_id`,
ADD COLUMN `label_status` int(11) NULL COMMENT '标签状态' AFTER `label_name`;



SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for zjb_gzh_label
-- ----------------------------
DROP TABLE IF EXISTS `zjb_gzh_label`;
CREATE TABLE `zjb_gzh_label` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` varchar(128) DEFAULT NULL COMMENT '公众号appid',
  `label_id` int(11) DEFAULT NULL COMMENT '标签id',
  `label_name` varchar(128) DEFAULT NULL COMMENT '标签名称',
  `label_count` int(11) DEFAULT NULL COMMENT '标签人数',
  `remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `gmt_created` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号粉丝标签详情表';

SET FOREIGN_KEY_CHECKS = 1;
