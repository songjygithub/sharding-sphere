CREATE TABLE IF NOT EXISTS `zjb_leaf_income_expenditure_details` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `verify_id` BIGINT(20) NOT NULL COMMENT '审核记录ID，即表【zjb_leaf_verify_record】的主键字段【id】',
  `open_id` VARCHAR (64) NOT NULL COMMENT '用户微信|支付宝唯一标识',
  `task_id` VARCHAR(13) DEFAULT '' COMMENT '小树叶任务业务主键，即表【zjb_leaf_task】的字段【task_id】',
  `task_name` VARCHAR(64) DEFAULT '' COMMENT '小树叶任务名称',
  `task_node_id` BIGINT(20) NOT NULL COMMENT '任务节点唯一标识',
  `type_income_expenditure` VARCHAR (4) NOT NULL COMMENT '收支类型，1：普通取纸赠送 2：XXX任务 3：免广告取纸',
  `status_income_expenditure` INT(2) NOT NULL DEFAULT '0' COMMENT '0：审核通过后入账 1：已入账 2：审核未通过',
  `amount_income_expenditure` INT (11) NOT NULL DEFAULT '0' COMMENT '收支数量，正数代表增加，负数代表减少',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_verify_id` (`verify_id`),
  KEY `idx_open_id` (`open_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '小树叶收支明细' ;

DROP TABLE IF EXISTS `zjb_gzh_push_ad_info`;
CREATE TABLE `zjb_gzh_push_ad_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ad_id` varchar(32) DEFAULT NULL COMMENT '编号',
  `ad_name` varchar(64) DEFAULT NULL COMMENT '广告名称',
  `ad_desc` varchar(256) DEFAULT NULL COMMENT '广告描述',
  `ad_push_msg` varchar(512) DEFAULT NULL COMMENT '推送消息',
  `ad_out_url` varchar(256) DEFAULT NULL COMMENT '外链',
  `ad_inside_uri` varchar(256) DEFAULT NULL COMMENT '内部跳转标识',
  `status` int(2) DEFAULT NULL COMMENT '状态',
  `creater_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `gmt_created` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='关注公众号推送广告信息表';

SET FOREIGN_KEY_CHECKS = 1;


DROP TABLE IF EXISTS `zjb_gzh_push_ad_tj`;
CREATE TABLE `zjb_gzh_push_ad_tj` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `msg_id` varchar(32) DEFAULT NULL COMMENT '消息广告id',
  `out_url` varchar(512) DEFAULT NULL COMMENT '外部链接',
  `inside_uri` varchar(512) DEFAULT NULL COMMENT '内部跳转标识',
  `click_time` datetime DEFAULT NULL COMMENT '点击事件',
  `qrcode` varchar(128) DEFAULT NULL COMMENT '设备码',
  `openid` varchar(128) DEFAULT NULL COMMENT '用户标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='消息广告点击统计';

SET FOREIGN_KEY_CHECKS = 1;

ALTER TABLE `zjbdsp`.`zjb_component_authorization_info` 
ADD COLUMN `msg_id` varchar(11) NULL COMMENT '推送信息广告id' AFTER `authorization_status`;

ALTER TABLE `zjbdsp`.`zjb_component_authorization_info` 
ADD COLUMN `msg_name` varchar(128) NULL COMMENT '推送消息广告名称' AFTER `msg_id`;
