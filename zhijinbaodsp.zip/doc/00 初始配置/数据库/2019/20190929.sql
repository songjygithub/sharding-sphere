SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sys_vipid_list
-- ----------------------------
DROP TABLE IF EXISTS `sys_vipid_list`;
CREATE TABLE `sys_vipid_list` (
  `vip_id` int(11) NOT NULL DEFAULT '0' COMMENT '待使用的vipId'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='待使用的vipId表';