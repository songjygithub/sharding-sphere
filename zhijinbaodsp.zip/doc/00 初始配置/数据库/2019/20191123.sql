CREATE TABLE IF NOT EXISTS `zjb_user_first_statistics` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `statistics_date` DATE NOT NULL COMMENT '统计日期',
  `first_auth_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '第一次授权数量',
  `first_auth_pl_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '第一次授权&第一次PL数量',
  `first_pl_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '第一次PL数量',
  `first_pr_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '第一次PR数量',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_date` (`statistics_date`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '用户第一次情况统计'