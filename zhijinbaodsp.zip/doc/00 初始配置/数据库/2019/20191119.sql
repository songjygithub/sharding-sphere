ALTER TABLE `zjb_advertising_unit`
  ADD COLUMN `we_chat_account` VARCHAR(32) NULL  COMMENT '微信公众号ID，即表【zjb_component_authorization_info】字段【component_id】' AFTER `out_paper_delay`,
  ADD COLUMN `we_chat_account_name` VARCHAR(64) NULL  COMMENT '微信公众号名称' AFTER `we_chat_account`;

ALTER TABLE `zjb_advertising_unit_wx`
  ADD COLUMN `we_chat_account` VARCHAR(32) NULL  COMMENT '微信公众号ID，即表【zjb_component_authorization_info】字段【component_id】' AFTER `out_paper_delay`,
  ADD COLUMN `we_chat_account_name` VARCHAR(64) NULL  COMMENT '微信公众号名称' AFTER `we_chat_account`;