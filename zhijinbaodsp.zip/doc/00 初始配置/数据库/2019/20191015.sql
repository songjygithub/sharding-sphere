ALTER TABLE `zjb_leaf_income_expenditure_details`
  ADD COLUMN `random_num` BIGINT(20) DEFAULT 0  NOT NULL  COMMENT '用户扫码流水号' AFTER `open_id`,
  DROP INDEX `idx_open_id`,
  ADD  INDEX `idx_open_id` (`open_id`, `random_num`);