update zjb_component_authorization_info set component_authorization_type = 1 where component_authorization_type is null
ALTER TABLE zjb_component_authorization_info
  ADD COLUMN `zjb_app_id` varchar(100) DEFAULT NULL COMMENT '广告主唯一标识' AFTER `app_id`;
ALTER TABLE zjb_component_authorization_info
  ADD COLUMN `component_authorization_type` TINYINT(1) DEFAULT 0  NOT NULL COMMENT '公众号授权类型（参考字典）' AFTER `zjb_app_id`;
ALTER TABLE zjb_component_authorization_info
  ADD COLUMN `public_platform_url` varchar(500) DEFAULT NULL COMMENT '公众号获取地址' AFTER `component_authorization_type`;

alter table zjb_component_authorization_info modify column component_authorization_type TINYINT(1) DEFAULT 0 COMMENT '公众号授权类型（参考字典）';

ALTER TABLE `zjb_advertising_plan`
  ADD COLUMN `component_authorization_type` TINYINT(1) DEFAULT 0  COMMENT '公众号授权类型（参考字典）' AFTER `is_third_platform`;

ALTER TABLE `zjb_advertising_plan_wx`
  ADD COLUMN `component_authorization_type` TINYINT(1) DEFAULT 0  COMMENT '公众号授权类型（参考字典）' AFTER `is_third_platform`;