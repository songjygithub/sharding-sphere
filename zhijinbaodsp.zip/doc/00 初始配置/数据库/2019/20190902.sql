ALTER TABLE sys_config ADD deleted tinyint(1) DEFAULT 0 COMMENT '是否删除标识，0：否 1：是';
ALTER TABLE sys_dict_type ADD deleted tinyint(1) DEFAULT 0 COMMENT '是否删除标识，0：否 1：是';
ALTER TABLE sys_dict_data ADD deleted tinyint(1) DEFAULT 0 COMMENT '是否删除标识，0：否 1：是';