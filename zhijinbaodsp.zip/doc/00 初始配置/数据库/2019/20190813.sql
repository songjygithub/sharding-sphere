ALTER TABLE `zjb_advertising_plan_pepole`
  CHANGE `paper_today_num` `paper_today_num` VARCHAR(11) NULL  COMMENT '广告投放当日取纸次数，多个之间用,分隔',
  ADD COLUMN `paper_today_lower_num` INT(11) NULL  COMMENT '广告投放当日取纸下限次数' AFTER `paper_today_num`,
  ADD COLUMN `paper_today_upper_num` INT(11) NULL  COMMENT '广告投放当日取纸上限次数' AFTER `paper_today_lower_num`;

  ALTER TABLE `zjb_advertising_plan`
  ADD COLUMN `ad_single_user_frequency` INT(11) DEFAULT 0  NOT NULL  COMMENT '单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每日仅投一次' AFTER `category`,
  ADD COLUMN `participate_bid_percentage` INT(11) NULL  COMMENT '参与竞价概率' AFTER `ad_single_user_frequency`;
