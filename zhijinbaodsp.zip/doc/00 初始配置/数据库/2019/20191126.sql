CREATE TABLE IF NOT EXISTS `zjb_system_app_info` (
  `id` BIGINT (20) NOT NULL COMMENT '主键',
  `system_app_id` VARCHAR (36) NOT NULL COMMENT '系统应用唯一标识',
  `system_app_user` VARCHAR (16) NOT NULL COMMENT '系统应用所属用户',
  `system_app_user_dir` VARCHAR (256) NOT NULL COMMENT '系统应用所在目录',
  `system_app_ip` VARCHAR (16) NOT NULL COMMENT '系统应用所属IP',
  `system_app_status` TINYINT (1) NOT NULL DEFAULT '0' COMMENT '系统应用是否运行中，0：否 1：是',
  `system_app_pid` VARCHAR (32) NOT NULL COMMENT '系统应用进程ID',
  `system_name` VARCHAR (32) NOT NULL COMMENT '操作系统类型',
  `java_version` VARCHAR (16) NOT NULL COMMENT '操作系统java版本',
  `cpu_percentage` VARCHAR(12) NOT NULL DEFAULT '' COMMENT 'CPU占用百分比',
  `men_percentage` VARCHAR(12) NOT NULL DEFAULT '' COMMENT '内存占用百分比',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '系统应用信息'