ALTER TABLE `zjb_advertising_plan_device`
  ADD COLUMN `ad_plan_device_excel` VARCHAR(256) NULL  COMMENT '广告投放指定设备文件名' AFTER `regex`,
  ADD COLUMN `ad_plan_device_url` VARCHAR(512) NULL  COMMENT '广告投放指定设备文件路径' AFTER `ad_plan_device_excel`;