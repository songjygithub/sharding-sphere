CREATE TABLE `zjb_advertising_combination_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `com_id` varchar(255) DEFAULT NULL COMMENT '方案编号',
  `name` varchar(255) DEFAULT NULL COMMENT '方案名称',
  `description` varchar(1024) DEFAULT NULL COMMENT '方案描述',
  `program_type` int(11) DEFAULT NULL COMMENT '方案类型  zjb_program_type',
  `program_url` varchar(1024) DEFAULT NULL COMMENT '方案路径',
  `ad_unit_type` varchar(4) DEFAULT NULL COMMENT '所属广告产品 zjb_ad_unit_type',
  `template` varchar(11) DEFAULT NULL COMMENT '广告方案模板类型',
  `remark` varchar(255) DEFAULT NULL,
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='广告方案表-支付';



CREATE TABLE `zjb_advertising_plan_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键,广告计划ID',
  `plan_id` varchar(13) NOT NULL DEFAULT '' COMMENT '业务标识自增主键，且必须是06开头，即06 + id',
  `plan_name` varchar(128) NOT NULL COMMENT '广告计划名称',
  `plan_group` varchar(2) NOT NULL DEFAULT '0' COMMENT '广告计划所属广告组(zjb_ad_plan_group),0：通用广告组',
  `combination_id` int(11) NOT NULL COMMENT '广告方案定向，即表[zjb_advertising_combination_pay]主键ID',
  `plan_bid` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '出价(元)',
  `plan_weight` int(11) DEFAULT '3' COMMENT '投放权重',
  `day_budget` decimal(19,4) DEFAULT NULL COMMENT '日预算(元)',
  `total_budget` decimal(19,4) DEFAULT NULL COMMENT '总预算(元)',
  `today_win_num` int(11) NOT NULL DEFAULT '0' COMMENT '今日胜出次数',
  `today_spend` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '今日花费(元)',
  `total_win_num` int(11) NOT NULL DEFAULT '0' COMMENT '总胜出次数',
  `total_spend` decimal(19,4) NOT NULL DEFAULT '0.0000' COMMENT '总花费(元)',
  `participate_bid_num` int(11) NOT NULL DEFAULT '0' COMMENT '参与竞价次数',
  `bid_win_num` int(11) DEFAULT '0' COMMENT '竞价胜出次数',
  `gmt_show_start` datetime DEFAULT NULL COMMENT '投放开始时间',
  `gmt_show_end` datetime DEFAULT NULL COMMENT '投放结束时间',
  `long_term_effective` varchar(1) DEFAULT '0' COMMENT '投放长期有效(zjb_long_term_effective)，0：否 1：是',
  `advertising_status` varchar(1) DEFAULT '1' COMMENT '投放状态(zjb_advertising_status)，1：投放中(正常投放) 2：手动暂停(手动暂停投放) 3：投放时间截至暂停 4：日预算不足暂停 5：总预算不足暂停',
  `category` varchar(2) DEFAULT '0' COMMENT '行业分类(zjb_advertising_category)，0：其它 1：金融',
  `ad_single_user_frequency` int(11) NOT NULL DEFAULT '0' COMMENT '单用户投放频次，参阅字典(zjb_ad_single_user_frequency)， 0：不限 1：每日仅投一次',
  `participate_bid_percentage` int(11) DEFAULT NULL COMMENT '参与竞价概率',
  `ad_app_id` varchar(72) DEFAULT NULL COMMENT '广告投放投放计划关联的微信公众号（订阅号）',
  `is_third_platform` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否第三方平台，0：否 1：是',
  `creater_id` int(11) NOT NULL COMMENT '创建人',
  `gmt_created` datetime NOT NULL COMMENT '创建时间',
  `modifier_id` int(11) NOT NULL COMMENT '修改人',
  `gmt_modified` datetime NOT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `pay_plan_id` (`plan_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='广告投放计划(支付)';

INSERT INTO `zjb_advertising_combination_pay` VALUES (1, '061', '付费取纸默认广告方案', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);