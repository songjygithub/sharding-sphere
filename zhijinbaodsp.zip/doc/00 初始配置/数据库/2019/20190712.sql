CREATE TABLE IF NOT EXISTS `zjb_advertising_unit` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ad_id` VARCHAR (128) COLLATE utf8mb4_general_ci NOT NULL COMMENT '业务主键id 格式 “01+id”',
  `ad_unit_type` VARCHAR (4) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '广告产品单元类型，参阅字典：zjb_ad_unit_type',
  `ad_space_identifier` VARCHAR (11) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '广告位标识  zjb_ad_space_identifier',
  `ad_name` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '广告名称',
  `information_source` INT (11) DEFAULT NULL COMMENT '信息来源 zjb_information_source',
  `ad_photo_url` VARCHAR (1024) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '广告图片链接',
  `general_name` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT 'tab名称/文字链名称',
  `redirect_url_type` INT (11) DEFAULT NULL COMMENT '跳转类型  zjb_redirect_url_type',
  `redirect_url` VARCHAR (1024) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '跳转路径',
  `ad_from` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '来源标识,手动输入',
  `ad_use_status` INT (11) DEFAULT NULL COMMENT '使用状态 zjb_ad_use_status',
  `supplement_param1` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '补充id1,跳转辅助参数等',
  `supplement_param2` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '补充id2，跳转辅助参数等',
  `remark` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) DEFAULT '0' COMMENT '是否删除标识，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_ad_id` (`ad_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '广告池表';

CREATE TABLE IF NOT EXISTS `zjb_advertising_combination` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '方案名称',
  `description` VARCHAR (1024) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '方案描述',
  `program_type` INT (11) DEFAULT NULL COMMENT '方案类型  zjb_program_type',
  `ad_unit_type` VARCHAR (4) DEFAULT NULL COMMENT '所属广告产品 zjb_ad_unit_type',
  `remark` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '广告方案表' ;

CREATE TABLE IF NOT EXISTS `zjb_advertising_combination_unit` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `combination_id` INT (11) NOT NULL COMMENT '广告方案id,表【zjb_advertising_combination】主键ID',
  `ad_unit_id` INT (11) NOT NULL COMMENT '广告id，表【zjb_advertising_unit】主键ID',
  `remark` VARCHAR (255) COLLATE utf8mb4_general_ci DEFAULT NULL COMMENT '备注',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建人员',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改人员',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `deleted` TINYINT (4) DEFAULT NULL COMMENT '删除标识',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '广告方案/广告池 中间表';

CREATE TABLE IF NOT EXISTS `zjb_advertising_plan` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '主键,广告计划ID',
  `plan_id` VARCHAR(13) NOT NULL DEFAULT '' COMMENT '业务标识自增主键，且必须是01开头，即01 + id',
  `plan_name` VARCHAR (128) NOT NULL COMMENT '广告计划名称',
  `plan_group` VARCHAR (2) NOT NULL DEFAULT '0' COMMENT '广告计划所属广告组(zjb_ad_plan_group),0：通用广告组',
  `combination_id` INT (11) NOT NULL COMMENT '广告方案定向，即表[zjb_advertising_combination]主键ID',
  `plan_bid` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '出价(元)',
  `plan_weight` INT (11) DEFAULT '3' COMMENT '投放权重',
  `day_budget` DECIMAL (19, 4) DEFAULT NULL COMMENT '日预算(元)',
  `total_budget` DECIMAL (19, 4) DEFAULT NULL COMMENT '总预算(元)',
  `today_win_num` INT (11) NOT NULL DEFAULT '0' COMMENT '今日胜出次数',
  `today_spend` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '今日花费(元)',
  `total_win_num` INT (11) NOT NULL DEFAULT '0' COMMENT '总胜出次数',
  `total_spend` DECIMAL (19, 4) NOT NULL DEFAULT '0.0000' COMMENT '总花费(元)',
  `participate_bid_num` INT (11) NOT NULL DEFAULT '0' COMMENT '参与竞价次数',
  `bid_win_num` INT (11) DEFAULT '0' COMMENT '竞价胜出次数',
  `gmt_show_start` DATETIME DEFAULT NULL COMMENT '投放开始时间',
  `gmt_show_end` DATETIME DEFAULT NULL COMMENT '投放结束时间',
  `long_term_effective` VARCHAR (1) DEFAULT '0' COMMENT '投放长期有效(zjb_long_term_effective)，0：否 1：是',
  `advertising_status` VARCHAR (1) DEFAULT '1' COMMENT '投放状态(zjb_advertising_status)，1：投放中(正常投放) 2：手动暂停(手动暂停投放) 3：投放时间截至暂停 4：日预算不足暂停 5：总预算不足暂停',
  `category` VARCHAR (2) DEFAULT '0' COMMENT '行业分类(zjb_advertising_category)，0：其它 1：金融',
  `creater_id` INT (11) NOT NULL COMMENT '创建人',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改人',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `deleted` TINYINT (1) DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_plan_id` (`plan_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '广告投放计划';

CREATE TABLE IF NOT EXISTS `zjb_advertising_plan_device` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ad_plan_id` VARCHAR (20) NOT NULL COMMENT '广告投放计划主键，即表[zjb_advertising_plan]的业务主键[plan_id]',
  `device_sn` VARCHAR (256) DEFAULT NULL COMMENT '投放指定设备SN，多个之间用,分隔',
  `sex` INT (11) DEFAULT NULL COMMENT '面向人群(zjb_face_sex) 0：男 1：女 2：综合',
  `device_install_code` VARCHAR (128) DEFAULT NULL COMMENT '指定投放设备安装地址编码,多个之间用,分隔，如：330000,330482,...',
  `device_install_zone` VARCHAR (256) DEFAULT NULL COMMENT '指定投放设备安装地址,多个之间用,分隔，如：北京市北京城区东城区,江苏省无锡市惠山区',
  `device_scene` VARCHAR (256) DEFAULT NULL COMMENT '指定投放设备安装场合code 参考 字典 安装场合 SCENE，多个之间用,分隔',
  `agency_id_array` VARCHAR (128) DEFAULT NULL COMMENT '指定投放代理商ID集合，多个之间用,分隔',
  `regex` VARCHAR (1024) DEFAULT NULL COMMENT '正则表达式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_plan_id` (`ad_plan_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '广告投放设备定向';

CREATE TABLE IF NOT EXISTS `zjb_advertising_plan_pepole` (
  `id` INT (20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `ad_plan_id` VARCHAR (20) NOT NULL COMMENT '广告投放计划主键，即表[zjb_advertising_plan]的业务主键[plan_id]',
  `paper_upper_num` INT (11) DEFAULT NULL COMMENT '广告投放总取纸上限次数',
  `paper_lower_num` INT (11) DEFAULT NULL COMMENT '广告投放总取纸下限次数',
  `paper_today_num` INT (11) DEFAULT NULL COMMENT '广告投放当日取纸次数',
  `sex` INT (11) DEFAULT NULL COMMENT '面向人群(zjb_face_sex) 0：男 1：女 2：综合',
  `age` INT (11) DEFAULT NULL COMMENT '指定投放年龄',
  `age_upper_limit` INT (11) DEFAULT NULL COMMENT '广告投放年龄上限',
  `age_lower_limit` INT (11) DEFAULT NULL COMMENT '广告投放年龄下限',
  `platform_type` INT (11) DEFAULT '0' COMMENT '广告投放平台类型(zjb_platform_type)，如：0:不限1:Android 2:IOS, 9:其它',
  `scan_tool` INT (11) DEFAULT '0' COMMENT '广告投放扫码环境(zjb_ scan_tool)，0:不限1:微信 2:支付宝 9：其它',
  `network_type` INT (11) DEFAULT '0' COMMENT '广告投放网络类型(zjb_ network_type)，0:不限1：WIFI 2：4G 3：3G 4：2G 9：其它',
  `operator_type` INT (11) DEFAULT '0' COMMENT '广告投放运营商(zjb_operator_type)，0:不限1：移动 2：联通 3：电信 9：其它',
  `black_user_enable` INT (11) DEFAULT '0' COMMENT '广告投放黑名单用户(zjb_black_user_enable)，0：不限 1：不投 2：只投',
  `hobby` VARCHAR (128) DEFAULT NULL COMMENT '广告投放兴趣爱好',
  `custom_label` VARCHAR (128) DEFAULT NULL COMMENT '广告投放自定义标签',
  `regex` VARCHAR (1024) DEFAULT NULL COMMENT '正则表达式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_plan_id` (`ad_plan_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '广告投放人群定向';