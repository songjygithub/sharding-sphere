ALTER TABLE `zjb_scan_task`
ADD COLUMN `investigate_first_url` varchar(200) DEFAULT NULL COMMENT '问卷调查第一次出纸URL' AFTER `expansion_c_url`,
ADD COLUMN `investigate_second_url` varchar(200) DEFAULT NULL COMMENT '问卷调查第二次出纸URL' AFTER `investigate_first_url`,
ADD COLUMN `investigate_third_url` varchar(200) DEFAULT NULL COMMENT '问卷调查第三次出纸URL' AFTER `investigate_second_url`,
ADD COLUMN `investigate_fourth_url` varchar(200) DEFAULT NULL COMMENT '问卷调查第四次出纸URL' AFTER `investigate_third_url`,
ADD COLUMN `investigate_fifth_url` varchar(200) DEFAULT NULL COMMENT '问卷调查第五次出纸URL' AFTER `investigate_fourth_url`;