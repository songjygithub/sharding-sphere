/*
 Navicat Premium Data Transfer

 Source Server         : mac
 Source Server Type    : MySQL
 Source Server Version : 50710
 Source Host           : localhost:3306
 Source Schema         : zjbdsp

 Target Server Type    : MySQL
 Target Server Version : 50710
 File Encoding         : 65001

 Date: 17/08/2019 18:28:23
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for zjb_gzh_group
-- ----------------------------
DROP TABLE IF EXISTS `zjb_gzh_group`;
CREATE TABLE `zjb_gzh_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` varchar(128) DEFAULT NULL COMMENT '组id',
  `group_name` varchar(128) DEFAULT NULL COMMENT '组名',
  `gzh_list` varchar(128) DEFAULT NULL COMMENT '公众号列表',
  `group_desc` varchar(512) DEFAULT NULL COMMENT '描述',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号组表';

SET FOREIGN_KEY_CHECKS = 1;


DROP TABLE IF EXISTS `zjb_gzhxcx_info`;
CREATE TABLE `zjb_gzhxcx_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gzh_id` varchar(128) DEFAULT NULL COMMENT '公众号id',
  `name` varchar(128) DEFAULT NULL COMMENT '公众号名称',
  `type` int(11) DEFAULT NULL COMMENT '类型',
  `appid` varchar(64) DEFAULT NULL,
  `appsecret` varchar(128) DEFAULT NULL,
  `subscribe_msg` text COMMENT '关注后推送的消息',
  `creater_id` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `gmt_created` datetime DEFAULT NULL,
  `gmt_modified` datetime DEFAULT NULL,
  `deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `gzh_id` (`gzh_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='公众号小程序信息表';

SET FOREIGN_KEY_CHECKS = 1;

DROP TABLE IF EXISTS `zjb_component_authorization_info`;
CREATE TABLE `zjb_component_authorization_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `component_id` varchar(128) DEFAULT NULL,
  `app_id` varchar(128) DEFAULT NULL COMMENT '公众号appid',
  `user_name` varchar(128) DEFAULT NULL COMMENT '授权方公众号的原始ID',
  `nick_name` varchar(128) DEFAULT NULL COMMENT '授权方昵称\n',
  `head_img` varchar(512) DEFAULT NULL COMMENT '授权方头像',
  `service_type_info` varchar(10) DEFAULT NULL COMMENT '授权方公众号类型，0代表订阅号，1代表由历史老帐号升级后的订阅号，2代表服务号',
  `verify_type_info` varchar(10) DEFAULT NULL COMMENT '授权方认证类型，-1代表未认证，0代表微信认证，1代表新浪微博认证，2代表腾讯微博认证，3代表已资质认证通过但还未通过名称认证，4代表已资质认证通过、还未通过名称认证，但通过了新浪微博认证，5代表已资质认证通过、还未通过名称认证，但通过了腾讯微博认证',
  `principal_name` varchar(128) DEFAULT NULL COMMENT '公众号的主体名称\n',
  `alias` varchar(128) DEFAULT NULL COMMENT '授权方公众号所设置的微信号，可能为空',
  `qrcode_url` varchar(512) DEFAULT NULL COMMENT '二维码图片的URL，开发者最好自行也进行保存',
  `business_info` varchar(128) DEFAULT NULL COMMENT '用以了解以下功能的开通状况（0代表未开通，1代表已开通）： open_store:是否开通微信门店功能 open_scan:是否开通微信扫商品功能 open_pay:是否开通微信支付功能 open_card:是否开通微信卡券功能 open_shake:是否开通微信摇一摇功能',
  `func_info` varchar(1024) DEFAULT NULL COMMENT '公众号授权给开发者的权限集列表',
  `authorization_status` varchar(8) DEFAULT NULL COMMENT '授权状态',
  `gmt_created` datetime DEFAULT NULL COMMENT '授权时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '授权更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `appid` (`app_id`,`component_id`) USING BTREE COMMENT '唯一索引',
  UNIQUE KEY `idx_app_id` (`app_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='公众号或小程序的第三方平台授权信息表\n';

SET FOREIGN_KEY_CHECKS = 1;
