CREATE TABLE IF NOT EXISTS `zjb_advertisement_without_bidding_price` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `advertising_unit_id` INT (11) NOT NULL COMMENT '广告池id,即表【zjb_advertising_unit_fans】主键id',
  `ad_space_identifier` varchar(11) DEFAULT NULL COMMENT '广告位标识  zjb_ad_space_identifier',
  `advertisement_status` int(11) NOT NULL DEFAULT '0' COMMENT '非竞价广告状态，参考字典',
  `advertisement_weight` INT (11) DEFAULT NULL COMMENT '权重',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '非竞价广告投放';


CREATE TABLE `zjb_without_bidding_adid_openid_index` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `zjb_openid` varchar(50) DEFAULT NULL COMMENT '用户微信unionid',
  `advertising_unit_id` INT (11) NOT NULL COMMENT '广告池id,即表【zjb_advertising_unit_fans】主键id',
  `remark` text COMMENT '备注',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `create_date` date DEFAULT NULL COMMENT '创建日期',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT '0' COMMENT '删除标志',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rds_idx_0` (`zjb_openid`,`advertising_unit_id`) USING BTREE,
  KEY `rds_idx_1` (`zjb_openid`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='非竞价广告id和openid关系表';

CREATE TABLE `zjb_without_bidding_ad_push_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertising_unit_id` INT (11) NOT NULL COMMENT '广告池id,即表【zjb_advertising_unit_fans】主键id',
  `open_id` varchar(64) DEFAULT NULL COMMENT 'openid',
  `view_count` int(11) DEFAULT NULL COMMENT '展示次数',
  `click_count` int(11) DEFAULT NULL COMMENT '点击次数',
  `createTime` date DEFAULT NULL COMMENT '创建时间(年月日)',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_adid_openid` (`advertising_unit_id`,`open_id`) COMMENT '唯一索引'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='非竞价广告推送记录表';


CREATE TABLE `zjb_without_bidding_ad_statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `advertising_unit_id` INT (11) NOT NULL COMMENT '广告池id,即表【zjb_advertising_unit_fans】主键id',
  `statistics_date` varchar(50) DEFAULT NULL COMMENT '统计日期(年月日)',
  `show_count` int(11) DEFAULT NULL COMMENT '展示次数',
  `show_person_count` int(11) DEFAULT NULL COMMENT '展示人数',
  `click_count` int(11) DEFAULT NULL COMMENT '转化点击次数',
  `click_person_count` int(11) DEFAULT NULL COMMENT '转化点击人数',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_ad_statistics` (`statistics_date`,`advertising_unit_id`) COMMENT '唯一索引',
KEY `rds_idx_1` (`advertising_unit_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='非竞价广告统计表';