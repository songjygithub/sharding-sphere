CREATE TABLE IF NOT EXISTS `zjb_third_platform_gzh_win_record` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `third_platform_channel` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台标识(参考字典)',
  `third_platform_app_id` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台公众号唯一标识',
  `open_id` VARCHAR (50) NOT NULL COMMENT '用户openid',
  `random_num` VARCHAR (50) NOT NULL COMMENT '用户扫码流水号',
  `win_date` DATETIME NOT NULL COMMENT '胜出时间',
  `issue_pl_status` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否下发PL，0：否 1：是',
  `remark` varchar (500) DEFAULT NULL COMMENT '备注',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  KEY `idx_app_id` (`third_platform_app_id`),
  KEY `idx_platform_id` (`third_platform_channel`,`third_platform_app_id`,`random_num`),
  KEY `idx_platform_app_id` (`third_platform_app_id`,`random_num`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '第三方平台公众号胜出记录';


INSERT INTO `zjb_medium_sell_rull` VALUES (7, '第三方公众号广告黑名单', '当某个第三方公众号命中该规则配置的情况时，系统将该第三方公众号加入黑名单，并向指定邮箱发送通知。黑名单的第三方公众号在参与竞价时将会被过滤掉。', '第三方公众号广告', 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0);

CREATE TABLE IF NOT EXISTS `zjb_black_third_platform_gzh` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `third_platform_channel` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台标识(参考字典)',
  `third_platform_app_id` VARCHAR (50) NOT NULL DEFAULT '' COMMENT '第三方平台公众号唯一标识',
  `third_platform_app_name` VARCHAR (256) DEFAULT NULL COMMENT '第三方平台公众号名称',
  `join_black_time` DATETIME DEFAULT NULL COMMENT '本次进入黑名单时间',
  `join_black_count` INT (11) NOT NULL DEFAULT '1' COMMENT '累计进入黑名单次数',
  `gmt_created` DATETIME DEFAULT NULL COMMENT '创建时间',
  `creater_id` INT (11) DEFAULT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME DEFAULT NULL COMMENT '修改时间',
  `modifier_id` INT (11) DEFAULT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `black_uk_app_id` (`third_platform_app_id`),
  KEY `idx_app_id` (`third_platform_app_id`,`deleted`),
  KEY `idx_platform_app_id` (`third_platform_channel`,`third_platform_app_id`,`deleted`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '第三方平台公众号黑名单';