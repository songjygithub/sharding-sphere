CREATE TABLE IF NOT EXISTS `zjb_we_chat_personal` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `personal_id` VARCHAR (15) NOT NULL DEFAULT '' COMMENT '编号主键，13+自然序号',
  `personal_group` INT (11) NOT NULL DEFAULT '-1' COMMENT '个人号编组',
  `nick_name` VARCHAR (256) NOT NULL COMMENT '个人微信号名称',
  `qr_code_url` VARCHAR (1024) NOT NULL COMMENT '二维码',
  `day_delivery_limit` INT (11) NOT NULL DEFAULT '0' COMMENT '日投放量限制',
  `day_follow_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '日关注量',
  `total_delivery_limit` INT (11) NOT NULL DEFAULT '0' COMMENT '总投放量限制',
  `total_follow_amount` INT (11) NOT NULL DEFAULT '0' COMMENT '总关注量',
  `delivery_status` INT (11) NOT NULL DEFAULT '1' COMMENT '投放状态',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `creater_id` INT (11) NOT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改者ID',
  `deleted` TINYINT(1) NOT NULL DEFAULT '0' COMMENT '是否删除，0：否 1：是',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_personal_id` (`personal_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '个人微信号池';

ALTER TABLE `zjb_advertising_unit_fans`
  ADD COLUMN `we_chat_personal_id` VARCHAR(15) NULL  COMMENT '表zjb_we_chat_personal字段personal_id' AFTER `remark`,
  ADD COLUMN `we_chat_personal_nick_name` VARCHAR(128) NULL  COMMENT '表zjb_we_chat_personal字段nick_name' AFTER `we_chat_personal_id`;

ALTER TABLE `zjb_advertising_plan_fans`
  ADD COLUMN `win_frequency` BIGINT DEFAULT 0  NOT NULL  COMMENT '广告计划胜出间隔频率（秒）' AFTER `component_authorization_type`,
  ADD COLUMN `we_chat_personal_id` VARCHAR(15) NULL  COMMENT '表zjb_we_chat_personal字段personal_id' AFTER `win_frequency`;