ALTER TABLE `zjbdsp`.`zjb_advertising_unit_fans` 
ADD COLUMN `probability` int(11) NULL COMMENT '概率' AFTER `take_the_paper_process`;