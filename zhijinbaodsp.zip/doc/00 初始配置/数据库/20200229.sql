DROP TABLE IF EXISTS `zjb_autorize_company`;
CREATE TABLE `zjb_autorize_company` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `company_name` varchar(1024) DEFAULT NULL COMMENT '公司名称',
  `app_id` varchar(255) DEFAULT NULL COMMENT '开放平台APPID',
  `app_secret` varchar(255) DEFAULT NULL COMMENT '开放平台密钥',
  `creater_id` int(11) DEFAULT NULL COMMENT '创建人员id',
  `modifier_id` int(11) DEFAULT NULL COMMENT '修改人员id',
  `gmt_created` datetime DEFAULT NULL COMMENT '创建时间',
  `gmt_modified` datetime DEFAULT NULL COMMENT '修改时间',
  `deleted` tinyint(1) DEFAULT NULL COMMENT '删除标志',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COMMENT='授权公司主体表';


INSERT INTO `zjb_autorize_company` VALUES (1, '杭州数策指今科技有限公司', 'wx70372a6f90bbae02', '19afd0f53e3eadca1a47f827becc4977', NULL, NULL, NULL, NULL, 0);
INSERT INTO `zjb_autorize_company` VALUES (2, '杭州小师妹科技有限公司', 'wx171caf46ee5d5cb9', '134e8aaa63740d208a08cac227a2862b', NULL, NULL, NULL, NULL, 0);

ALTER TABLE `zjb_component_authorization_info`
  ADD COLUMN `company_id` int(11) DEFAULT NULL  COMMENT '授权公司主体ID' AFTER `zjb_app_id`;
ALTER TABLE `zjb_component_authorization_info`
  ADD COLUMN `company_name` varchar(255) DEFAULT NULL  COMMENT '授权公司主体名称' AFTER `company_id`;