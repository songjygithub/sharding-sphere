CREATE TABLE IF NOT EXISTS `zjb_backup_record` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `day_data` DATE NOT NULL COMMENT '备份数据的日期',
  `hour` INT(4) NOT NULL COMMENT '备份数据的小时：0~23',
  `count_data` INT (11) NOT NULL DEFAULT '0' COMMENT '备份条数',
  `type_data` VARCHAR (32) NOT NULL COMMENT '备份数据类型：用表名代替即可',
  `gmt_start_backup` DATETIME NOT NULL COMMENT '备份开始时间',
  `gmt_end_backup` DATETIME NOT NULL COMMENT '备份结束时间',
  `file_url` VARCHAR (2048) NOT NULL COMMENT '备份文件路径',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_day_type` (`day_data`, `hour`, `type_data`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '数据备份记录'