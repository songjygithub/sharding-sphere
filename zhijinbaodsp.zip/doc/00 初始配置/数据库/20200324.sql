CREATE TABLE IF NOT EXISTS `zjb_advertising_type` (
  `id` INT (11) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `type_name` VARCHAR (16) NOT NULL COMMENT '广告类型名称',
  `type_desc` VARCHAR (128) NOT NULL COMMENT '广告类型描述',
  `count_ad_config` INT(11) NOT NULL DEFAULT '0' COMMENT '已配置广告数量',
  `type_status` INT (2) NOT NULL DEFAULT '1' COMMENT '使用状态,0：停用 1：启用',
  `gmt_created` DATETIME NOT NULL COMMENT '创建时间',
  `creater_id` INT (11) NOT NULL COMMENT '创建者ID',
  `gmt_modified` DATETIME NOT NULL COMMENT '修改时间',
  `modifier_id` INT (11) NOT NULL COMMENT '修改者ID',
  PRIMARY KEY (`id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '广告类型' ;

ALTER TABLE `zjb_advertising_unit_fans`
  ADD COLUMN `ad_type_id` INT(11) NULL  COMMENT '广告类型ID，即表【zjb_advertising_type】主键【id】' AFTER `qq_personal_nick_name`;
  
ALTER TABLE `zjb_advertising_unit`   
  ADD COLUMN `ad_type_id` INT(11) NULL  COMMENT '广告类型ID，即表【zjb_advertising_type】主键【id】' AFTER `we_chat_account_name`;
  