CREATE TABLE IF NOT EXISTS `zjb_user_print_log_white` (
  `id` BIGINT (20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `open_id` VARCHAR (36) NOT NULL COMMENT '扫码用户唯一标识',
  `gmt_start_print` DATETIME NOT NULL COMMENT '允许打印日志时间段：开始',
  `gmt_end_print` DATETIME NOT NULL COMMENT '允许打印日志时间段：结束',
  `count_print` BIGINT (20) NOT NULL DEFAULT '0' COMMENT '允许打印次数，0代表无限制',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_open_id` (`open_id`)
) ENGINE = INNODB DEFAULT CHARSET = utf8mb4 COMMENT = '允许打印日志的用户白名单'