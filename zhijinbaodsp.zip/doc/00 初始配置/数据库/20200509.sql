ALTER TABLE `zjbdsp`.`zjb_component_authorization_info`
ADD COLUMN `pick_paper_type` tinyint(1) NULL DEFAULT 1 COMMENT '取纸二维码类型  1:自动生成  2:指定二维码' AFTER `record_status`,
ADD COLUMN `pick_paper_url` varchar(512) NULL COMMENT '指定取纸二维码链接' AFTER `pick_paper_type`;
-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('非竞价广告投放设备定向', '1513', '1', '/dsp/advertisementPlanDevice', 'C', '0', 'dsp:advertisementPlanDevice:view', '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '非竞价广告投放设备定向菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('非竞价广告投放设备定向查询', @parentId, '1',  '#',  'F', '0', 'dsp:advertisementPlanDevice:list',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('非竞价广告投放设备定向新增', @parentId, '2',  '#',  'F', '0', 'dsp:advertisementPlanDevice:add',          '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('非竞价广告投放设备定向修改', @parentId, '3',  '#',  'F', '0', 'dsp:advertisementPlanDevice:edit',         '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');

insert into sys_menu  (menu_name, parent_id, order_num, url,menu_type, visible, perms, icon, create_by, create_time, update_by, update_time, remark)
values('非竞价广告投放设备定向删除', @parentId, '4',  '#',  'F', '0', 'dsp:advertisementPlanDevice:remove',       '#', 'admin', '2018-03-01', 'ry', '2018-03-01', '');
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for zjb_advertisement_plan_device
-- ----------------------------
DROP TABLE IF EXISTS `zjb_advertisement_plan_device`;
CREATE TABLE `zjb_advertisement_plan_device`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `advertising_unit_id` int(11) NULL DEFAULT NULL COMMENT '广告池id,即表【zjb_advertising_unit_fans】主键id',
  `advertisement_plan_id` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '非竞价广告投放计划主键，即表[zjb_advertisement_without_bidding_price]的主键[id]',
  `radio_device_sn` int(2) NOT NULL DEFAULT 0 COMMENT '设备SN定向，0：不限 1：指定设备 2：不投设备',
  `device_sn` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '投放指定设备SN，多个之间用,分隔',
  `sex` int(11) NULL DEFAULT NULL COMMENT '面向人群(zjb_face_sex) 0：男 1：女 2：综合',
  `device_install_code` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指定投放设备安装地址编码,多个之间用,分隔，如：330000,330482,...',
  `device_install_zone` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '指定投放设备安装地址,多个之间用,分隔，如：北京市北京城区东城区,江苏省无锡市惠山区',
  `radio_device_scene` int(2) NOT NULL DEFAULT 0 COMMENT '设备安装场景定向，0:不限 1:指定安装场景 2:不投安装场景',
  `device_scene` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '指定投放设备安装场合code 参考 字典 安装场合 SCENE，多个之间用,分隔',
  `radio_agency_id` int(2) NOT NULL DEFAULT 0 COMMENT '代理商定向，0:不限 1:指定代理商 2:不投代理商',
  `agency_id_array` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '指定投放代理商ID集合，多个之间用,分隔',
  `regex` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '正则表达式',
  `ad_plan_device_excel` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '广告投放指定设备文件名',
  `ad_plan_device_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '广告投放指定设备文件路径',
  `is_finance` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否金融行业，0：否 1：是',
  `is_we_chat_account` tinyint(1) NOT NULL DEFAULT 0 COMMENT '是否公众号，0：否 1：是',
  `is_personal_account` tinyint(1) NULL DEFAULT 0 COMMENT '是否个人号，0:否1:是',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `index_plan_id`(`advertisement_plan_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 673 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '非竞价广告投放设备定向' ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;