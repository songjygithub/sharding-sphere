ALTER TABLE `zjb_personal_account_win_record`
  ADD COLUMN `remark` varchar (500) DEFAULT NULL COMMENT '备注' AFTER `issue_pl_status`;