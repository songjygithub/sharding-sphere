CREATE TABLE IF NOT EXISTS `zjb_agency_we_chat_account_statistics` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `statistics_day` DATE NOT NULL COMMENT '统计日期',
  `subscribe_count` INT (11) NOT NULL DEFAULT 0 COMMENT '关注数',
  `unsubscribe_count` INT (11) NOT NULL DEFAULT 0 COMMENT '取关数',
  `same_day_unsubscribe_count` INT (11) NOT NULL DEFAULT 0 COMMENT '关注并当日取关数',
  `agency_id` INT (11) NOT NULL COMMENT '代理商ID',
  `agency_name` VARCHAR (64) NOT NULL COMMENT '代理商名称',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_day_agency` (`statistics_day`,`agency_id`)
) COMMENT = '代理商维度公众号统计' ;